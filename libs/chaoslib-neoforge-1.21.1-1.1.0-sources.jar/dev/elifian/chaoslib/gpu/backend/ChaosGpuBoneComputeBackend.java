package dev.elifian.chaoslib.gpu.backend;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.elifian.chaoslib.gpu.debug.ChaosGlDebug;
import dev.elifian.chaoslib.gpu.mesh.ChaosGpuGeoMesh;
import dev.elifian.chaoslib.gpu.shader.ChaosGpuShaderSources;

import dev.elifian.chaoslib.platform.ClientOnly;
import org.lwjgl.opengl.*;
import org.lwjgl.system.MemoryUtil;

import java.nio.FloatBuffer;
import java.util.*;

@ClientOnly
final class ChaosGpuBoneComputeBackend implements ChaosGpuBoneResolveBackend {
    private static final int LOCAL_POSE_TEXTURE_UNIT = 5;
    private static final int MAX_CACHED_POSES_PER_MESH = 512;
    private static final int WORKGROUP_SIZE = 64;
    private static final String COMPUTE_SHADER = ChaosGpuShaderSources.load("assets/chaoslib/shaders/internal/bone_resolve/compute.comp");
    private static final ThreadLocal<UploadBuffer> LOCAL_POSE_UPLOAD_BUFFER = ThreadLocal.withInitial(UploadBuffer::new);
    private static final ThreadLocal<ReadbackBuffer> RESOLVED_READBACK_BUFFER = ThreadLocal.withInitial(ReadbackBuffer::new);
    private static final Map<ChaosGpuGeoMesh, MeshState> CACHE = Collections.synchronizedMap(new IdentityHashMap<>());
    private static int program = -1;
    private static int localPoseSamplerLocation = -1;
    private static int boneCountLocation = -1;
    private static int localPoseBaseLocation = -1;
    private static int localPoseBufferId = -1;
    private static int localPoseTextureId = -1;

    @Override
    public boolean isSupported() {
        GLCapabilities capabilities = GL.getCapabilities();
        return capabilities.OpenGL43 || (capabilities.GL_ARB_compute_shader && capabilities.GL_ARB_shader_storage_buffer_object && (capabilities.OpenGL31 || capabilities.GL_ARB_texture_buffer_object));
    }

    @Override
    public void invalidateAll() {
        synchronized (CACHE) {
            for (MeshState state : CACHE.values()) {
                state.close();
            }
            CACHE.clear();
        }
        if (program != -1) {
            GL20.glDeleteProgram(program);
            ChaosGlDebug.check("ChaosGpuBoneComputeBackend.invalidateAll.glDeleteProgram");
            program = -1;
            localPoseSamplerLocation = -1;
            boneCountLocation = -1;
        localPoseBaseLocation = -1;
        }
        if (localPoseTextureId != -1) {
            GL11.glDeleteTextures(localPoseTextureId);
            ChaosGlDebug.check("ChaosGpuBoneComputeBackend.invalidateAll.glDeleteTextures.localPose");
            localPoseTextureId = -1;
        }
        if (localPoseBufferId != -1) {
            GL15.glDeleteBuffers(localPoseBufferId);
            ChaosGlDebug.check("ChaosGpuBoneComputeBackend.invalidateAll.glDeleteBuffers.localPose");
            localPoseBufferId = -1;
        }
    }

    @Override
    public void invalidateLocalPose(Object localPoseData, int localPoseTextureId) {
        synchronized (CACHE) {
            for (MeshState state : CACHE.values()) {
                state.invalidateLocalPose(localPoseData, localPoseTextureId);
            }
        }
    }

    @Override
    public int resolveAndBind(ChaosGpuGeoMesh mesh, Object localPoseData) {
        if (!isSupported()) {
            return -1;
        }

        ensureProgram();
        if (program == -1 || localPoseSamplerLocation == -1 || boneCountLocation == -1) {
            return -1;
        }

        MeshState state = CACHE.computeIfAbsent(mesh, MeshState::new);
        int localPoseTexture = ChaosGpuAnimationPoseStorage.textureIdFor(localPoseData);
        CachedResolvedPose cachedPose = state.getCachedPose(localPoseData, localPoseTexture);
        if (cachedPose != null) {
            bindResolvedTexture(cachedPose.textureId());
            return cachedPose.textureId();
        }

        if (localPoseTexture < 0) {
            if (!(localPoseData instanceof float[] rawLocalPoseData) || rawLocalPoseData.length != state.boneCount * 16) {
                return -1;
            }
            ensureLocalPoseStorage();
            FloatBuffer buffer = LOCAL_POSE_UPLOAD_BUFFER.get().prepare(rawLocalPoseData);
            GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, localPoseBufferId);
            ChaosGlDebug.check("ChaosGpuBoneComputeBackend.resolveAndBind.uploadLocalPose.glBindBuffer");
            GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, buffer, GL15.GL_DYNAMIC_DRAW);
            ChaosGlDebug.check("ChaosGpuBoneComputeBackend.resolveAndBind.uploadLocalPose.glBufferData");
            attachTextureBuffer(localPoseTextureId, GL30.GL_RGBA32F, localPoseBufferId);
            GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, 0);
            ChaosGlDebug.check("ChaosGpuBoneComputeBackend.resolveAndBind.uploadLocalPose.glBindBuffer.0");
            localPoseTexture = localPoseTextureId;
        }

        CachedResolvedPose resolvedPose = state.acquirePose(localPoseData, localPoseTexture);
        GL20.glUseProgram(program);
        ChaosGlDebug.check("ChaosGpuBoneComputeBackend.resolveAndBind.glUseProgram");
        try {
            bindTextureBufferToUnit(LOCAL_POSE_TEXTURE_UNIT, localPoseTexture);
            GL20.glUniform1i(localPoseSamplerLocation, LOCAL_POSE_TEXTURE_UNIT);
            ChaosGlDebug.check("ChaosGpuBoneComputeBackend.resolveAndBind.glUniform1i.LocalBonePoseSampler");
            GL20.glUniform1i(boneCountLocation, state.boneCount);
            ChaosGlDebug.check("ChaosGpuBoneComputeBackend.resolveAndBind.glUniform1i.BoneCount");
            if (localPoseBaseLocation != -1) {
                GL20.glUniform1i(localPoseBaseLocation, ChaosGpuAnimationPoseStorage.poseBaseFor(localPoseData));
            }
            if (ChaosGlDebug.failIfErrored("ChaosGpuBoneComputeBackend.resolveAndBind.uniforms")) {
                return -1;
            }
            GL30.glBindBufferBase(GL43.GL_SHADER_STORAGE_BUFFER, 0, resolvedPose.bufferId());
            ChaosGlDebug.check("ChaosGpuBoneComputeBackend.resolveAndBind.glBindBufferBase.output");
            GL43.glDispatchCompute(Math.max(1, (state.boneCount + WORKGROUP_SIZE - 1) / WORKGROUP_SIZE), 1, 1);
            ChaosGlDebug.check("ChaosGpuBoneComputeBackend.resolveAndBind.glDispatchCompute");
            GL42.glMemoryBarrier(GL43.GL_SHADER_STORAGE_BARRIER_BIT | GL43.GL_TEXTURE_FETCH_BARRIER_BIT | GL42.GL_TEXTURE_UPDATE_BARRIER_BIT);
            ChaosGlDebug.check("ChaosGpuBoneComputeBackend.resolveAndBind.glMemoryBarrier");
            if (ChaosGlDebug.failIfErrored("ChaosGpuBoneComputeBackend.resolveAndBind.dispatch")) {
                return -1;
            }
        } finally {
            GL30.glBindBufferBase(GL43.GL_SHADER_STORAGE_BUFFER, 0, 0);
            ChaosGlDebug.check("ChaosGpuBoneComputeBackend.resolveAndBind.cleanup.glBindBufferBase.0");
            unbindLocalPoseSampler();
            GL20.glUseProgram(0);
            ChaosGlDebug.check("ChaosGpuBoneComputeBackend.resolveAndBind.cleanup.glUseProgram.0");
        }
        bindResolvedTexture(resolvedPose.textureId());
        return resolvedPose.textureId();
    }

    @Override
    public float[] resolveAndRead(ChaosGpuGeoMesh mesh, Object localPoseData) {
        if (!isSupported()) {
            return null;
        }

        ensureProgram();
        if (program == -1 || localPoseSamplerLocation == -1 || boneCountLocation == -1) {
            return null;
        }

        MeshState state = CACHE.computeIfAbsent(mesh, MeshState::new);
        int localPoseTexture = ChaosGpuAnimationPoseStorage.textureIdFor(localPoseData);
        CachedResolvedPose cachedPose = state.getCachedPose(localPoseData, localPoseTexture);
        if (cachedPose == null) {
            if (this.resolveAndBind(mesh, localPoseData) < 0) {
                return null;
            }
            localPoseTexture = ChaosGpuAnimationPoseStorage.textureIdFor(localPoseData);
            cachedPose = state.getCachedPose(localPoseData, localPoseTexture);
            if (cachedPose == null) {
                return null;
            }
        }

        return RESOLVED_READBACK_BUFFER.get().read(cachedPose.bufferId(), state.boneCount);
    }

    private static void ensureProgram() {
        if (program != -1) {
            return;
        }

        int shader = GL20.glCreateShader(GL43.GL_COMPUTE_SHADER);
        ChaosGlDebug.check("ChaosGpuBoneComputeBackend.ensureProgram.glCreateShader");
        GL20.glShaderSource(shader, COMPUTE_SHADER);
        ChaosGlDebug.check("ChaosGpuBoneComputeBackend.ensureProgram.glShaderSource");
        GL20.glCompileShader(shader);
        ChaosGlDebug.check("ChaosGpuBoneComputeBackend.ensureProgram.glCompileShader");
        if (GL20.glGetShaderi(shader, GL20.GL_COMPILE_STATUS) == GL11.GL_FALSE) {
            ChaosGlDebug.check("ChaosGpuBoneComputeBackend.ensureProgram.glGetShaderi.COMPILE_STATUS");
            String log = GL20.glGetShaderInfoLog(shader);
            ChaosGlDebug.check("ChaosGpuBoneComputeBackend.ensureProgram.glGetShaderInfoLog");
            GL20.glDeleteShader(shader);
            ChaosGlDebug.check("ChaosGpuBoneComputeBackend.ensureProgram.glDeleteShader.failed");
            throw new IllegalStateException("Failed to compile Chaos GPU bone compute shader: " + log);
        }
        ChaosGlDebug.check("ChaosGpuBoneComputeBackend.ensureProgram.glGetShaderi.COMPILE_STATUS");

        int glProgram = GL20.glCreateProgram();
        ChaosGlDebug.check("ChaosGpuBoneComputeBackend.ensureProgram.glCreateProgram");
        GL20.glAttachShader(glProgram, shader);
        ChaosGlDebug.check("ChaosGpuBoneComputeBackend.ensureProgram.glAttachShader");
        GL20.glLinkProgram(glProgram);
        ChaosGlDebug.check("ChaosGpuBoneComputeBackend.ensureProgram.glLinkProgram");
        GL20.glDetachShader(glProgram, shader);
        ChaosGlDebug.check("ChaosGpuBoneComputeBackend.ensureProgram.glDetachShader");
        GL20.glDeleteShader(shader);
        ChaosGlDebug.check("ChaosGpuBoneComputeBackend.ensureProgram.glDeleteShader");
        if (GL20.glGetProgrami(glProgram, GL20.GL_LINK_STATUS) == GL11.GL_FALSE) {
            ChaosGlDebug.check("ChaosGpuBoneComputeBackend.ensureProgram.glGetProgrami.LINK_STATUS");
            String log = GL20.glGetProgramInfoLog(glProgram);
            ChaosGlDebug.check("ChaosGpuBoneComputeBackend.ensureProgram.glGetProgramInfoLog");
            GL20.glDeleteProgram(glProgram);
            ChaosGlDebug.check("ChaosGpuBoneComputeBackend.ensureProgram.glDeleteProgram.failed");
            throw new IllegalStateException("Failed to link Chaos GPU bone compute program: " + log);
        }
        ChaosGlDebug.check("ChaosGpuBoneComputeBackend.ensureProgram.glGetProgrami.LINK_STATUS");

        program = glProgram;
        localPoseSamplerLocation = GL20.glGetUniformLocation(glProgram, "LocalBonePoseSampler");
        ChaosGlDebug.check("ChaosGpuBoneComputeBackend.ensureProgram.glGetUniformLocation.LocalBonePoseSampler");
        boneCountLocation = GL20.glGetUniformLocation(glProgram, "BoneCount");
        ChaosGlDebug.check("ChaosGpuBoneComputeBackend.ensureProgram.glGetUniformLocation.BoneCount");
    }

    private static void ensureLocalPoseStorage() {
        if (localPoseBufferId != -1) {
            return;
        }

        localPoseBufferId = GL15.glGenBuffers();
        ChaosGlDebug.check("ChaosGpuBoneComputeBackend.ensureLocalPoseStorage.glGenBuffers");
        localPoseTextureId = GL11.glGenTextures();
        ChaosGlDebug.check("ChaosGpuBoneComputeBackend.ensureLocalPoseStorage.glGenTextures");
    }

    private static void bindResolvedTexture(int textureId) {
        bindTextureBufferToUnit(ChaosGpuBoneDataStorage.BONE_TEXTURE_UNIT, textureId);
    }

    private static void bindTextureBufferToUnit(int textureUnit, int textureId) {
        int activeTexture = GlStateManager._getActiveTexture();
        RenderSystem.activeTexture(GL13.GL_TEXTURE0 + textureUnit);
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, textureId);
        ChaosGlDebug.check("ChaosGpuBoneComputeBackend.bindTextureBufferToUnit.glBindTexture." + textureUnit);
        GlStateManager._activeTexture(activeTexture);
    }

    private static void unbindLocalPoseSampler() {
        int activeTexture = GlStateManager._getActiveTexture();
        RenderSystem.activeTexture(GL13.GL_TEXTURE0 + LOCAL_POSE_TEXTURE_UNIT);
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, 0);
        ChaosGlDebug.check("ChaosGpuBoneComputeBackend.unbindLocalPoseSampler.glBindTexture.0");
        GlStateManager._activeTexture(activeTexture);
    }

    private static void attachTextureBuffer(int textureId, int internalFormat, int bufferId) {
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, textureId);
        ChaosGlDebug.check("ChaosGpuBoneComputeBackend.attachTextureBuffer.glBindTexture");
        if (GL.getCapabilities().OpenGL31) {
            GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, internalFormat, bufferId);
            ChaosGlDebug.check("ChaosGpuBoneComputeBackend.attachTextureBuffer.glTexBuffer");
        } else {
            ARBTextureBufferObject.glTexBufferARB(ARBTextureBufferObject.GL_TEXTURE_BUFFER_ARB, internalFormat, bufferId);
            ChaosGlDebug.check("ChaosGpuBoneComputeBackend.attachTextureBuffer.glTexBufferARB");
        }
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, 0);
        ChaosGlDebug.check("ChaosGpuBoneComputeBackend.attachTextureBuffer.glBindTexture.0");
    }

    private static final class MeshState implements AutoCloseable {
        private final int boneCount;
        private final IdentityHashMap<Object, CachedResolvedPose> cacheByPoseRef = new IdentityHashMap<>();
        private final ArrayDeque<Object> cacheOrder = new ArrayDeque<>();
        private final LinkedHashMap<Long, CachedResolvedPose> cacheByPoseKey = new LinkedHashMap<>(16, 0.75f, true);
        private final ArrayDeque<CachedResolvedPose> availablePoses = new ArrayDeque<>();

        private MeshState(ChaosGpuGeoMesh mesh) {
            this.boneCount = mesh.getIndexedBones().size();
        }

        private static long poseKey(Object poseDataRef, int localPoseTextureId) {
            return ((long) localPoseTextureId << 32) | (ChaosGpuAnimationPoseStorage.poseBaseFor(poseDataRef) & 0xFFFFFFFFL);
        }

        private CachedResolvedPose getCachedPose(Object poseDataRef, int localPoseTextureId) {
            if (localPoseTextureId >= 0) {
                return this.cacheByPoseKey.get(poseKey(poseDataRef, localPoseTextureId));
            }

            return this.cacheByPoseRef.get(poseDataRef);
        }

        private CachedResolvedPose acquirePose(Object poseDataRef, int localPoseTextureId) {
            CachedResolvedPose cachedPose = this.getCachedPose(poseDataRef, localPoseTextureId);
            if (cachedPose != null) {
                return cachedPose;
            }

            if (localPoseTextureId >= 0) {
                CachedResolvedPose pose;
                if (this.cacheByPoseKey.size() >= MAX_CACHED_POSES_PER_MESH) {
                    Map.Entry<Long, CachedResolvedPose> eldest = this.cacheByPoseKey.entrySet().iterator().next();
                    pose = eldest.getValue();
                    this.cacheByPoseKey.remove(eldest.getKey());
                } else {
                    pose = this.obtainPose();
                }

                this.cacheByPoseKey.put(poseKey(poseDataRef, localPoseTextureId), pose);
                return pose;
            }

            CachedResolvedPose pose;
            if (this.cacheOrder.size() >= MAX_CACHED_POSES_PER_MESH) {
                Object oldestRef = this.cacheOrder.removeFirst();
                pose = this.cacheByPoseRef.remove(oldestRef);
                if (pose == null) {
                    pose = this.obtainPose();
                }
            } else {
                pose = this.obtainPose();
            }
            this.cacheByPoseRef.put(poseDataRef, pose);
            this.cacheOrder.addLast(poseDataRef);
            return pose;
        }

        private void invalidateLocalPose(Object poseDataRef, int localPoseTextureId) {
            if (localPoseTextureId >= 0) {
                CachedResolvedPose cachedPose = this.cacheByPoseKey.remove(poseKey(poseDataRef, localPoseTextureId));
                if (cachedPose != null) {
                    this.availablePoses.addLast(cachedPose);
                }
                return;
            }

            CachedResolvedPose cachedPose = this.cacheByPoseRef.remove(poseDataRef);
            if (cachedPose != null) {
                this.cacheOrder.remove(poseDataRef);
                this.availablePoses.addLast(cachedPose);
            }
        }

        private CachedResolvedPose obtainPose() {
            CachedResolvedPose reused = this.availablePoses.pollFirst();
            return reused != null ? reused : this.createPose();
        }

        private CachedResolvedPose createPose() {
            int bufferId = GL15.glGenBuffers();
            ChaosGlDebug.check("ChaosGpuBoneComputeBackend.MeshState.createPose.glGenBuffers");
            int textureId = GL11.glGenTextures();
            ChaosGlDebug.check("ChaosGpuBoneComputeBackend.MeshState.createPose.glGenTextures");
            long byteSize = (long) this.boneCount * 16L * Float.BYTES;
            GL15.glBindBuffer(GL43.GL_SHADER_STORAGE_BUFFER, bufferId);
            ChaosGlDebug.check("ChaosGpuBoneComputeBackend.MeshState.createPose.glBindBuffer");
            GL15.glBufferData(GL43.GL_SHADER_STORAGE_BUFFER, byteSize, GL15.GL_DYNAMIC_DRAW);
            ChaosGlDebug.check("ChaosGpuBoneComputeBackend.MeshState.createPose.glBufferData");
            GL15.glBindBuffer(GL43.GL_SHADER_STORAGE_BUFFER, 0);
            ChaosGlDebug.check("ChaosGpuBoneComputeBackend.MeshState.createPose.glBindBuffer.0");
            attachTextureBuffer(textureId, GL30.GL_RGBA32F, bufferId);
            return new CachedResolvedPose(bufferId, textureId);
        }

        @Override
        public void close() {
            for (CachedResolvedPose cachedPose : this.cacheByPoseRef.values()) {
                cachedPose.close();
            }
            for (CachedResolvedPose cachedPose : this.availablePoses) {
                cachedPose.close();
            }
            this.availablePoses.clear();
            for (CachedResolvedPose cachedPose : this.cacheByPoseKey.values()) {
                cachedPose.close();
            }
        }
    }

    private record CachedResolvedPose(int bufferId, int textureId) implements AutoCloseable {
        @Override
        public void close() {
            GL15.glDeleteBuffers(this.bufferId);
            ChaosGlDebug.check("ChaosGpuBoneComputeBackend.CachedResolvedPose.close.glDeleteBuffers");
            GL11.glDeleteTextures(this.textureId);
            ChaosGlDebug.check("ChaosGpuBoneComputeBackend.CachedResolvedPose.close.glDeleteTextures");
        }
    }

    private static final class UploadBuffer {
        private FloatBuffer buffer = MemoryUtil.memAllocFloat(16);

        private FloatBuffer prepare(float[] source) {
            if (this.buffer.capacity() < source.length) {
                MemoryUtil.memFree(this.buffer);
                this.buffer = MemoryUtil.memAllocFloat(source.length);
            }

            this.buffer.clear();
            this.buffer.put(source);
            this.buffer.flip();
            return this.buffer;
        }
    }

    private static final class ReadbackBuffer {
        private FloatBuffer buffer = MemoryUtil.memAllocFloat(16);

        private float[] read(int bufferId, int boneCount) {
            int floatCount = boneCount * 16;
            if (this.buffer.capacity() < floatCount) {
                MemoryUtil.memFree(this.buffer);
                this.buffer = MemoryUtil.memAllocFloat(floatCount);
            }

            this.buffer.clear();
            this.buffer.limit(floatCount);
            GL15.glBindBuffer(GL43.GL_SHADER_STORAGE_BUFFER, bufferId);
            ChaosGlDebug.check("ChaosGpuBoneComputeBackend.ReadbackBuffer.read.glBindBuffer");
            GL15.glGetBufferSubData(GL43.GL_SHADER_STORAGE_BUFFER, 0, this.buffer);
            ChaosGlDebug.check("ChaosGpuBoneComputeBackend.ReadbackBuffer.read.glGetBufferSubData");
            GL15.glBindBuffer(GL43.GL_SHADER_STORAGE_BUFFER, 0);
            ChaosGlDebug.check("ChaosGpuBoneComputeBackend.ReadbackBuffer.read.glBindBuffer.0");
            float[] matrices = new float[floatCount];
            this.buffer.position(0);
            this.buffer.get(matrices);
            return matrices;
        }
    }
}
