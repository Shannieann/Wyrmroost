package dev.elifian.chaoslib.gpu.backend;

import dev.elifian.chaoslib.api.animation.AnimationPlaybackController;

import java.util.LinkedHashMap;
import java.util.Map;

public final class GpuProceduralPoseLayer {
    private final LinkedHashMap<String, BonePose> bones = new LinkedHashMap<>();
    private AnimationPlaybackController.BlendMode blendMode = AnimationPlaybackController.BlendMode.MIX;
    private float weight = 1.0f;

    public boolean isEmpty() {
        if (this.weight <= 1.0e-6f) {
            return true;
        }

        for (BonePose pose : this.bones.values()) {
            if (pose.hasPosition || pose.hasRotation || pose.hasScale) {
                return false;
            }
        }
        return true;
    }

    public void setBlendMode(AnimationPlaybackController.BlendMode blendMode) {
        this.blendMode = blendMode == null ? AnimationPlaybackController.BlendMode.MIX : blendMode;
    }

    public void setWeight(float weight) {
        this.weight = Math.max(0.0f, weight);
    }

    public AnimationPlaybackController.BlendMode blendMode() {
        return this.blendMode;
    }

    public float weight() {
        return this.weight;
    }

    public BonePose bone(String boneName) {
        return this.bones.computeIfAbsent(boneName, ignored -> new BonePose());
    }

    public Map<String, BonePose> bones() {
        return this.bones;
    }

    /**
     * Resets every pose back to "no transform applied" while keeping the {@link BonePose} objects and
     * the bone map intact, so a per-model layer can be reused across frames/instances instead of being
     * reallocated. The result is identical to a freshly constructed layer (untouched bones are treated
     * as identity via the {@code hasPosition/hasRotation/hasScale} flags); only the allocation and the
     * map churn are avoided.
     */
    public void reset() {
        for (BonePose pose : this.bones.values()) {
            pose.reset();
        }
        this.blendMode = AnimationPlaybackController.BlendMode.MIX;
        this.weight = 1.0f;
    }

    public static final class BonePose {
        private boolean hasPosition;
        private boolean hasRotation;
        private boolean hasScale;
        private float posX;
        private float posY;
        private float posZ;
        private float rotX;
        private float rotY;
        private float rotZ;
        private float scaleX = 1.0f;
        private float scaleY = 1.0f;
        private float scaleZ = 1.0f;

        private void reset() {
            this.hasPosition = false;
            this.hasRotation = false;
            this.hasScale = false;
            this.posX = 0.0f;
            this.posY = 0.0f;
            this.posZ = 0.0f;
            this.rotX = 0.0f;
            this.rotY = 0.0f;
            this.rotZ = 0.0f;
            this.scaleX = 1.0f;
            this.scaleY = 1.0f;
            this.scaleZ = 1.0f;
        }

        public void position(float x, float y, float z) {
            this.hasPosition = true;
            this.posX = x;
            this.posY = y;
            this.posZ = z;
        }

        public void rotation(float x, float y, float z) {
            this.hasRotation = true;
            this.rotX = x;
            this.rotY = y;
            this.rotZ = z;
        }

        public void scale(float x, float y, float z) {
            this.hasScale = true;
            this.scaleX = x;
            this.scaleY = y;
            this.scaleZ = z;
        }

        public boolean hasPosition() {
            return this.hasPosition;
        }

        public boolean hasRotation() {
            return this.hasRotation;
        }

        public boolean hasScale() {
            return this.hasScale;
        }

        public float posX() {
            return this.posX;
        }

        public float posY() {
            return this.posY;
        }

        public float posZ() {
            return this.posZ;
        }

        public float rotX() {
            return this.rotX;
        }

        public float rotY() {
            return this.rotY;
        }

        public float rotZ() {
            return this.rotZ;
        }

        public float scaleX() {
            return this.scaleX;
        }

        public float scaleY() {
            return this.scaleY;
        }

        public float scaleZ() {
            return this.scaleZ;
        }
    }
}
