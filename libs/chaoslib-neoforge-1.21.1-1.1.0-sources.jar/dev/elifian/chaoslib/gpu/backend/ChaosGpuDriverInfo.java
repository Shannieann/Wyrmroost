package dev.elifian.chaoslib.gpu.backend;


import dev.elifian.chaoslib.platform.ClientOnly;
import org.lwjgl.opengl.GL11;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Locale;
import java.util.regex.Pattern;

@ClientOnly
public final class ChaosGpuDriverInfo {
    private static final Logger LOGGER = LoggerFactory.getLogger(ChaosGpuDriverInfo.class);
    private static Boolean amdAtiRadeon;

    private ChaosGpuDriverInfo() {
    }

    public static boolean isAmdAtiRadeon() {
        Boolean cached = amdAtiRadeon;
        if (cached != null) {
            return cached;
        }

        String vendor = safeGlString(GL11.GL_VENDOR);
        String renderer = safeGlString(GL11.GL_RENDERER);
        String version = safeGlString(GL11.GL_VERSION);
        boolean detected = containsAnyWord(vendor, "amd", "ati")
                || containsAnyWord(renderer, "amd", "ati", "radeon")
                || containsAnyWord(version, "amd", "ati");
        amdAtiRadeon = detected;
        return detected;
    }

    private static String safeGlString(int name) {
        String value = GL11.glGetString(name);
        return value == null ? "" : value;
    }

    private static boolean containsAnyWord(String value, String... needles) {
        String lower = value.toLowerCase(Locale.ROOT);
        for (String needle : needles) {
            if (Pattern.compile("\\b" + Pattern.quote(needle) + "\\b").matcher(lower).find()) return true;
        }
        return false;
    }
}
