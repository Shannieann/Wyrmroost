package dev.elifian.chaoslib.gpu.backend;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.elifian.chaoslib.gpu.debug.ChaosGlDebug;
import dev.elifian.chaoslib.gpu.mesh.ChaosGpuGeoMesh;
import dev.elifian.chaoslib.gpu.shader.ChaosGpuShaderSources;

import dev.elifian.chaoslib.platform.ClientOnly;
import org.lwjgl.opengl.*;
import org.lwjgl.system.MemoryUtil;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.ArrayDeque;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Map;

@ClientOnly
final class ChaosGpuBonePrepass implements ChaosGpuBoneResolveBackend {
    private static final int LOCAL_POSE_TEXTURE_UNIT = 5;
    private static final int PREVIOUS_RESOLVED_TEXTURE_UNIT = 6;
    private static final int MAX_CACHED_POSES_PER_MESH = 512;
    private static final String PREPASS_VERTEX_SHADER = ChaosGpuShaderSources.load("assets/chaoslib/shaders/internal/bone_resolve/transform_feedback.vsh");
    private static final String PREPASS_FRAGMENT_SHADER = ChaosGpuShaderSources.load("assets/chaoslib/shaders/internal/transform_feedback/passthrough_150.fsh");
    private static final Map<ChaosGpuGeoMesh, MeshState> CACHE = Collections.synchronizedMap(new IdentityHashMap<>());
    private static final ThreadLocal<UploadBuffer> LOCAL_POSE_UPLOAD_BUFFER = ThreadLocal.withInitial(UploadBuffer::new);
    private static final ThreadLocal<UploadBuffer> IDENTITY_UPLOAD_BUFFER = ThreadLocal.withInitial(UploadBuffer::new);
    private static final ThreadLocal<ReadbackBuffer> RESOLVED_READBACK_BUFFER = ThreadLocal.withInitial(ReadbackBuffer::new);
    private static int program = -1;
    private static int localPoseSamplerLocation = -1;
    private static int previousResolvedSamplerLocation = -1;
    private static int resolveDepthLocation = -1;
    private static int localPoseBaseLocation = -1;
    private static int localPoseBufferId = -1;
    private static int localPoseTextureId = -1;

    @Override
    public boolean isSupported() {
        GLCapabilities capabilities = GL.getCapabilities();
        return (capabilities.OpenGL31 || capabilities.GL_ARB_texture_buffer_object) && capabilities.OpenGL32;
    }

    @Override
    public void invalidateAll() {
        synchronized (CACHE) {
            for (MeshState state : CACHE.values()) {
                state.close();
            }
            CACHE.clear();
        }

        if (program != -1) {
            GL20.glDeleteProgram(program);
            ChaosGlDebug.check("ChaosGpuBonePrepass.invalidateAll.glDeleteProgram");
            program = -1;
            localPoseSamplerLocation = -1;
            previousResolvedSamplerLocation = -1;
            resolveDepthLocation = -1;
            localPoseBaseLocation = -1;
        }
        if (localPoseTextureId != -1) {
            GL11.glDeleteTextures(localPoseTextureId);
            ChaosGlDebug.check("ChaosGpuBonePrepass.invalidateAll.glDeleteTextures.localPose");
            localPoseTextureId = -1;
        }
        if (localPoseBufferId != -1) {
            GL15.glDeleteBuffers(localPoseBufferId);
            ChaosGlDebug.check("ChaosGpuBonePrepass.invalidateAll.glDeleteBuffers.localPose");
            localPoseBufferId = -1;
        }
    }

    @Override
    public void invalidateLocalPose(Object localPoseData, int localPoseTextureId) {
        synchronized (CACHE) {
            for (MeshState state : CACHE.values()) {
                state.invalidateLocalPose(localPoseData);
            }
        }
    }

    @Override
    public int resolveAndBind(ChaosGpuGeoMesh mesh, Object localPoseData) {
        if (!isSupported()) {
            return -1;
        }

        ensureProgram();
        if (program == -1 || localPoseSamplerLocation == -1 || previousResolvedSamplerLocation == -1 || resolveDepthLocation == -1) {
            return -1;
        }

        MeshState state = CACHE.computeIfAbsent(mesh, MeshState::new);
        CachedResolvedPose cachedPose = state.cacheByPoseRef.get(localPoseData);
        if (cachedPose != null) {
            bindResolvedTexture(cachedPose.textureId());
            return cachedPose.textureId();
        }

        int localPoseTexture = ChaosGpuAnimationPoseStorage.textureIdFor(localPoseData);
        if (localPoseTexture < 0) {
            if (!(localPoseData instanceof float[] rawLocalPoseData) || rawLocalPoseData.length != state.boneCount * 16) {
                return -1;
            }
            uploadLocalPoseData(rawLocalPoseData);
            localPoseTexture = localPoseTextureId;
        }
        uploadIdentityPoseData(state.boneCount, state.workingBufferIds[0], state.workingTextureIds[0]);

        GL20.glUseProgram(program);
        ChaosGlDebug.check("ChaosGpuBonePrepass.resolveAndBind.glUseProgram");
        try {
            bindTextureBufferToUnit(LOCAL_POSE_TEXTURE_UNIT, localPoseTexture);
            GL20.glUniform1i(localPoseSamplerLocation, LOCAL_POSE_TEXTURE_UNIT);
            ChaosGlDebug.check("ChaosGpuBonePrepass.resolveAndBind.glUniform1i.LocalBonePoseSampler");
            if (localPoseBaseLocation != -1) {
                GL20.glUniform1i(localPoseBaseLocation, ChaosGpuAnimationPoseStorage.poseBaseFor(localPoseData));
            }
            if (ChaosGlDebug.failIfErrored("ChaosGpuBonePrepass.resolveAndBind.localPoseSetup")) {
                return -1;
            }

            int previousIndex = 0;
            int currentIndex = 1;
            for (int depth = 0; depth <= state.maxBoneDepth; depth++) {
                bindTextureBufferToUnit(PREVIOUS_RESOLVED_TEXTURE_UNIT, state.workingTextureIds[previousIndex]);
                GL20.glUniform1i(previousResolvedSamplerLocation, PREVIOUS_RESOLVED_TEXTURE_UNIT);
                ChaosGlDebug.check("ChaosGpuBonePrepass.resolveAndBind.glUniform1i.PreviousResolvedBoneSampler");
                GL20.glUniform1i(resolveDepthLocation, depth);
                ChaosGlDebug.check("ChaosGpuBonePrepass.resolveAndBind.glUniform1i.ResolveDepth");

                GL11.glEnable(GL30.GL_RASTERIZER_DISCARD);
                ChaosGlDebug.check("ChaosGpuBonePrepass.resolveAndBind.glEnable.RASTERIZER_DISCARD");
                GL30.glBindBufferBase(GL30.GL_TRANSFORM_FEEDBACK_BUFFER, 0, state.workingBufferIds[currentIndex]);
                ChaosGlDebug.check("ChaosGpuBonePrepass.resolveAndBind.glBindBufferBase.transformFeedback");
                GL30.glBindVertexArray(state.boneVertexArrayId);
                ChaosGlDebug.check("ChaosGpuBonePrepass.resolveAndBind.glBindVertexArray");
                GL30.glBeginTransformFeedback(GL11.GL_POINTS);
                ChaosGlDebug.check("ChaosGpuBonePrepass.resolveAndBind.glBeginTransformFeedback");
                GL11.glDrawArrays(GL11.GL_POINTS, 0, state.boneCount);
                ChaosGlDebug.check("ChaosGpuBonePrepass.resolveAndBind.glDrawArrays");
                GL30.glEndTransformFeedback();
                ChaosGlDebug.check("ChaosGpuBonePrepass.resolveAndBind.glEndTransformFeedback");
                ensureTransformFeedbackWritesVisible();
                GL30.glBindBufferBase(GL30.GL_TRANSFORM_FEEDBACK_BUFFER, 0, 0);
                ChaosGlDebug.check("ChaosGpuBonePrepass.resolveAndBind.glBindBufferBase.0");
                GL30.glBindVertexArray(0);
                ChaosGlDebug.check("ChaosGpuBonePrepass.resolveAndBind.glBindVertexArray.0");
                GL11.glDisable(GL30.GL_RASTERIZER_DISCARD);
                ChaosGlDebug.check("ChaosGpuBonePrepass.resolveAndBind.glDisable.RASTERIZER_DISCARD");
                if (ChaosGlDebug.failIfErrored("ChaosGpuBonePrepass.resolveAndBind.depth." + depth)) {
                    return -1;
                }

                int swap = previousIndex;
                previousIndex = currentIndex;
                currentIndex = swap;
            }
            CachedResolvedPose resolvedPose = state.cacheResolvedPose(localPoseData, state.workingBufferIds[previousIndex]);
            bindResolvedTexture(resolvedPose.textureId());
            return resolvedPose.textureId();
        } finally {
            unbindPrepassSamplers();
            GL20.glUseProgram(0);
            ChaosGlDebug.check("ChaosGpuBonePrepass.resolveAndBind.cleanup.glUseProgram.0");
        }
    }

    @Override
    public float[] resolveAndRead(ChaosGpuGeoMesh mesh, Object localPoseData) {
        if (!isSupported()) {
            return null;
        }

        ensureProgram();
        if (program == -1 || localPoseSamplerLocation == -1 || previousResolvedSamplerLocation == -1 || resolveDepthLocation == -1) {
            return null;
        }

        MeshState state = CACHE.computeIfAbsent(mesh, MeshState::new);
        CachedResolvedPose cachedPose = state.cacheByPoseRef.get(localPoseData);
        if (cachedPose == null) {
            if (this.resolveAndBind(mesh, localPoseData) < 0) {
                return null;
            }
            cachedPose = state.cacheByPoseRef.get(localPoseData);
            if (cachedPose == null) {
                return null;
            }
        }

        return RESOLVED_READBACK_BUFFER.get().read(cachedPose.bufferId(), state.boneCount);
    }

    private static void ensureTransformFeedbackWritesVisible() {
        GLCapabilities capabilities = GL.getCapabilities();
        if (capabilities.OpenGL42) {
            GL42.glMemoryBarrier(GL42.GL_TRANSFORM_FEEDBACK_BARRIER_BIT | GL42.GL_TEXTURE_FETCH_BARRIER_BIT | GL42.GL_BUFFER_UPDATE_BARRIER_BIT);
            ChaosGlDebug.check("ChaosGpuBonePrepass.ensureTransformFeedbackWritesVisible.glMemoryBarrier");
            return;
        }

        GL11.glFinish();
        ChaosGlDebug.check("ChaosGpuBonePrepass.ensureTransformFeedbackWritesVisible.glFinish");
    }

    private static void ensureProgram() {
        if (program != -1) {
            return;
        }

        int vertexShader = GL20.glCreateShader(GL20.GL_VERTEX_SHADER);
        ChaosGlDebug.check("ChaosGpuBonePrepass.ensureProgram.glCreateShader");
        GL20.glShaderSource(vertexShader, PREPASS_VERTEX_SHADER);
        ChaosGlDebug.check("ChaosGpuBonePrepass.ensureProgram.glShaderSource");
        GL20.glCompileShader(vertexShader);
        ChaosGlDebug.check("ChaosGpuBonePrepass.ensureProgram.glCompileShader");
        if (GL20.glGetShaderi(vertexShader, GL20.GL_COMPILE_STATUS) == GL11.GL_FALSE) {
            ChaosGlDebug.check("ChaosGpuBonePrepass.ensureProgram.glGetShaderi.COMPILE_STATUS");
            String log = GL20.glGetShaderInfoLog(vertexShader);
            ChaosGlDebug.check("ChaosGpuBonePrepass.ensureProgram.glGetShaderInfoLog");
            GL20.glDeleteShader(vertexShader);
            ChaosGlDebug.check("ChaosGpuBonePrepass.ensureProgram.glDeleteShader.failed");
            throw new IllegalStateException("Failed to compile Chaos GPU bone prepass shader: " + log);
        }
        ChaosGlDebug.check("ChaosGpuBonePrepass.ensureProgram.glGetShaderi.COMPILE_STATUS");

        int fragmentShader = GL20.glCreateShader(GL20.GL_FRAGMENT_SHADER);
        ChaosGlDebug.check("ChaosGpuBonePrepass.ensureProgram.glCreateShader.fragment");
        GL20.glShaderSource(fragmentShader, PREPASS_FRAGMENT_SHADER);
        ChaosGlDebug.check("ChaosGpuBonePrepass.ensureProgram.glShaderSource.fragment");
        GL20.glCompileShader(fragmentShader);
        ChaosGlDebug.check("ChaosGpuBonePrepass.ensureProgram.glCompileShader.fragment");
        if (GL20.glGetShaderi(fragmentShader, GL20.GL_COMPILE_STATUS) == GL11.GL_FALSE) {
            ChaosGlDebug.check("ChaosGpuBonePrepass.ensureProgram.glGetShaderi.COMPILE_STATUS.fragment");
            String log = GL20.glGetShaderInfoLog(fragmentShader);
            ChaosGlDebug.check("ChaosGpuBonePrepass.ensureProgram.glGetShaderInfoLog.fragment");
            GL20.glDeleteShader(vertexShader);
            ChaosGlDebug.check("ChaosGpuBonePrepass.ensureProgram.glDeleteShader.vertex.failed");
            GL20.glDeleteShader(fragmentShader);
            ChaosGlDebug.check("ChaosGpuBonePrepass.ensureProgram.glDeleteShader.fragment.failed");
            throw new IllegalStateException("Failed to compile Chaos GPU bone prepass fragment shader: " + log);
        }
        ChaosGlDebug.check("ChaosGpuBonePrepass.ensureProgram.glGetShaderi.COMPILE_STATUS.fragment");

        int glProgram = GL20.glCreateProgram();
        ChaosGlDebug.check("ChaosGpuBonePrepass.ensureProgram.glCreateProgram");
        GL20.glAttachShader(glProgram, vertexShader);
        ChaosGlDebug.check("ChaosGpuBonePrepass.ensureProgram.glAttachShader.vertex");
        GL20.glAttachShader(glProgram, fragmentShader);
        ChaosGlDebug.check("ChaosGpuBonePrepass.ensureProgram.glAttachShader.fragment");
        GL20.glBindAttribLocation(glProgram, 0, "BoneIndex");
        ChaosGlDebug.check("ChaosGpuBonePrepass.ensureProgram.glBindAttribLocation.BoneIndex");
        GL20.glBindAttribLocation(glProgram, 1, "BoneDepth");
        ChaosGlDebug.check("ChaosGpuBonePrepass.ensureProgram.glBindAttribLocation.BoneDepth");
        GL30.glTransformFeedbackVaryings(glProgram, new CharSequence[]{"TfPose0", "TfPose1", "TfPose2", "TfPose3"}, GL30.GL_INTERLEAVED_ATTRIBS);
        ChaosGlDebug.check("ChaosGpuBonePrepass.ensureProgram.glTransformFeedbackVaryings");
        GL20.glLinkProgram(glProgram);
        ChaosGlDebug.check("ChaosGpuBonePrepass.ensureProgram.glLinkProgram");
        GL20.glDetachShader(glProgram, vertexShader);
        ChaosGlDebug.check("ChaosGpuBonePrepass.ensureProgram.glDetachShader.vertex");
        GL20.glDetachShader(glProgram, fragmentShader);
        ChaosGlDebug.check("ChaosGpuBonePrepass.ensureProgram.glDetachShader.fragment");
        GL20.glDeleteShader(vertexShader);
        ChaosGlDebug.check("ChaosGpuBonePrepass.ensureProgram.glDeleteShader.vertex");
        GL20.glDeleteShader(fragmentShader);
        ChaosGlDebug.check("ChaosGpuBonePrepass.ensureProgram.glDeleteShader.fragment");

        if (GL20.glGetProgrami(glProgram, GL20.GL_LINK_STATUS) == GL11.GL_FALSE) {
            ChaosGlDebug.check("ChaosGpuBonePrepass.ensureProgram.glGetProgrami.LINK_STATUS");
            String log = GL20.glGetProgramInfoLog(glProgram);
            ChaosGlDebug.check("ChaosGpuBonePrepass.ensureProgram.glGetProgramInfoLog");
            GL20.glDeleteProgram(glProgram);
            ChaosGlDebug.check("ChaosGpuBonePrepass.ensureProgram.glDeleteProgram.failed");
            throw new IllegalStateException("Failed to link Chaos GPU bone prepass program: " + log);
        }
        ChaosGlDebug.check("ChaosGpuBonePrepass.ensureProgram.glGetProgrami.LINK_STATUS");

        program = glProgram;
        localPoseSamplerLocation = GL20.glGetUniformLocation(glProgram, "LocalBonePoseSampler");
        ChaosGlDebug.check("ChaosGpuBonePrepass.ensureProgram.glGetUniformLocation.LocalBonePoseSampler");
        previousResolvedSamplerLocation = GL20.glGetUniformLocation(glProgram, "PreviousResolvedBoneSampler");
        ChaosGlDebug.check("ChaosGpuBonePrepass.ensureProgram.glGetUniformLocation.PreviousResolvedBoneSampler");
        resolveDepthLocation = GL20.glGetUniformLocation(glProgram, "ResolveDepth");
        ChaosGlDebug.check("ChaosGpuBonePrepass.ensureProgram.glGetUniformLocation.ResolveDepth");
    }

    private static void uploadLocalPoseData(float[] localPoseData) {
        ensureLocalPoseStorage();
        FloatBuffer buffer = LOCAL_POSE_UPLOAD_BUFFER.get().prepare(localPoseData);
        GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, localPoseBufferId);
        ChaosGlDebug.check("ChaosGpuBonePrepass.uploadLocalPoseData.glBindBuffer");
        GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, buffer, GL15.GL_DYNAMIC_DRAW);
        ChaosGlDebug.check("ChaosGpuBonePrepass.uploadLocalPoseData.glBufferData");
        attachTextureBuffer(localPoseTextureId, GL30.GL_RGBA32F, localPoseBufferId);
        GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, 0);
        ChaosGlDebug.check("ChaosGpuBonePrepass.uploadLocalPoseData.glBindBuffer.0");
    }

    private static void uploadIdentityPoseData(int boneCount, int bufferId, int textureId) {
        float[] identityData = new float[boneCount * 16];
        for (int i = 0; i < boneCount; i++) {
            int offset = i * 16;
            identityData[offset] = 1.0f;
            identityData[offset + 5] = 1.0f;
            identityData[offset + 10] = 1.0f;
            identityData[offset + 15] = 1.0f;
        }

        FloatBuffer buffer = IDENTITY_UPLOAD_BUFFER.get().prepare(identityData);
        GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, bufferId);
        ChaosGlDebug.check("ChaosGpuBonePrepass.uploadIdentityPoseData.glBindBuffer");
        GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, buffer, GL15.GL_DYNAMIC_DRAW);
        ChaosGlDebug.check("ChaosGpuBonePrepass.uploadIdentityPoseData.glBufferData");
        attachTextureBuffer(textureId, GL30.GL_RGBA32F, bufferId);
        GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, 0);
        ChaosGlDebug.check("ChaosGpuBonePrepass.uploadIdentityPoseData.glBindBuffer.0");
    }

    private static void ensureLocalPoseStorage() {
        if (localPoseBufferId != -1) {
            return;
        }

        localPoseBufferId = GL15.glGenBuffers();
        ChaosGlDebug.check("ChaosGpuBonePrepass.ensureLocalPoseStorage.glGenBuffers");
        localPoseTextureId = GL11.glGenTextures();
        ChaosGlDebug.check("ChaosGpuBonePrepass.ensureLocalPoseStorage.glGenTextures");
    }

    private static void bindResolvedTexture(int textureId) {
        bindTextureBufferToUnit(ChaosGpuBoneDataStorage.BONE_TEXTURE_UNIT, textureId);
    }

    private static void bindTextureBufferToUnit(int textureUnit, int textureId) {
        int activeTexture = GlStateManager._getActiveTexture();
        RenderSystem.activeTexture(GL13.GL_TEXTURE0 + textureUnit);
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, textureId);
        ChaosGlDebug.check("ChaosGpuBonePrepass.bindTextureBufferToUnit.glBindTexture." + textureUnit);
        GlStateManager._activeTexture(activeTexture);
    }

    private static void unbindPrepassSamplers() {
        int activeTexture = GlStateManager._getActiveTexture();
        RenderSystem.activeTexture(GL13.GL_TEXTURE0 + LOCAL_POSE_TEXTURE_UNIT);
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, 0);
        ChaosGlDebug.check("ChaosGpuBonePrepass.unbindPrepassSamplers.glBindTexture.localPose.0");
        RenderSystem.activeTexture(GL13.GL_TEXTURE0 + PREVIOUS_RESOLVED_TEXTURE_UNIT);
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, 0);
        ChaosGlDebug.check("ChaosGpuBonePrepass.unbindPrepassSamplers.glBindTexture.previousResolved.0");
        GlStateManager._activeTexture(activeTexture);
    }

    private static void attachTextureBuffer(int textureId, int internalFormat, int bufferId) {
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, textureId);
        ChaosGlDebug.check("ChaosGpuBonePrepass.attachTextureBuffer.glBindTexture");
        if (GL.getCapabilities().OpenGL31) {
            GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, internalFormat, bufferId);
            ChaosGlDebug.check("ChaosGpuBonePrepass.attachTextureBuffer.glTexBuffer");
        } else {
            ARBTextureBufferObject.glTexBufferARB(ARBTextureBufferObject.GL_TEXTURE_BUFFER_ARB, internalFormat, bufferId);
            ChaosGlDebug.check("ChaosGpuBonePrepass.attachTextureBuffer.glTexBufferARB");
        }
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, 0);
        ChaosGlDebug.check("ChaosGpuBonePrepass.attachTextureBuffer.glBindTexture.0");
    }

    private static final class MeshState implements AutoCloseable {
        private final int boneCount;
        private final int maxBoneDepth;
        private final int boneVertexArrayId;
        private final int boneVertexBufferId;
        private final int[] workingBufferIds = new int[2];
        private final int[] workingTextureIds = new int[2];
        private final IdentityHashMap<Object, CachedResolvedPose> cacheByPoseRef = new IdentityHashMap<>();
        private final ArrayDeque<Object> cacheOrder = new ArrayDeque<>();

        private MeshState(ChaosGpuGeoMesh mesh) {
            this.boneCount = mesh.getIndexedBones().size();
            this.maxBoneDepth = mesh.getMaxBoneDepth();
            this.boneVertexArrayId = GL30.glGenVertexArrays();
            ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.glGenVertexArrays");
            this.boneVertexBufferId = GL15.glGenBuffers();
            ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.glGenBuffers.boneVertex");
            this.workingBufferIds[0] = GL15.glGenBuffers();
            ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.glGenBuffers.working.0");
            this.workingBufferIds[1] = GL15.glGenBuffers();
            ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.glGenBuffers.working.1");
            this.workingTextureIds[0] = GL11.glGenTextures();
            ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.glGenTextures.working.0");
            this.workingTextureIds[1] = GL11.glGenTextures();
            ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.glGenTextures.working.1");
            allocateWorkingBuffer(this.workingBufferIds[0], this.workingTextureIds[0]);
            allocateWorkingBuffer(this.workingBufferIds[1], this.workingTextureIds[1]);
            uploadBoneIndexData(mesh);
        }

        private void allocateWorkingBuffer(int bufferId, int textureId) {
            long byteSize = (long) this.boneCount * 16L * Float.BYTES;
            GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, bufferId);
            ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.allocateWorkingBuffer.glBindBuffer");
            GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, byteSize, GL15.GL_DYNAMIC_DRAW);
            ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.allocateWorkingBuffer.glBufferData");
            attachTextureBuffer(textureId, GL30.GL_RGBA32F, bufferId);
            GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, 0);
            ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.allocateWorkingBuffer.glBindBuffer.0");
        }

        private CachedResolvedPose cacheResolvedPose(Object poseDataRef, int sourceBufferId) {
            CachedResolvedPose existing = this.cacheByPoseRef.get(poseDataRef);
            if (existing != null) {
                return existing;
            }

            CachedResolvedPose cachedPose;
            if (this.cacheOrder.size() >= MAX_CACHED_POSES_PER_MESH) {
                Object oldestRef = this.cacheOrder.removeFirst();
                cachedPose = this.cacheByPoseRef.remove(oldestRef);
                if (cachedPose == null) {
                    cachedPose = this.createCachedPose();
                }
            } else {
                cachedPose = this.createCachedPose();
            }
            long byteSize = (long) this.boneCount * 16L * Float.BYTES;
            GL15.glBindBuffer(GL31.GL_COPY_READ_BUFFER, sourceBufferId);
            ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.cacheResolvedPose.glBindBuffer.copyRead");
            GL15.glBindBuffer(GL31.GL_COPY_WRITE_BUFFER, cachedPose.bufferId());
            ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.cacheResolvedPose.glBindBuffer.copyWrite");
            GL15.glBufferData(GL31.GL_COPY_WRITE_BUFFER, byteSize, GL15.GL_DYNAMIC_DRAW);
            ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.cacheResolvedPose.glBufferData.copyWrite");
            GL31.glCopyBufferSubData(GL31.GL_COPY_READ_BUFFER, GL31.GL_COPY_WRITE_BUFFER, 0L, 0L, byteSize);
            ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.cacheResolvedPose.glCopyBufferSubData");
            ensureCopiedBufferVisible();
            GL15.glBindBuffer(GL31.GL_COPY_READ_BUFFER, 0);
            ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.cacheResolvedPose.glBindBuffer.copyRead.0");
            GL15.glBindBuffer(GL31.GL_COPY_WRITE_BUFFER, 0);
            ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.cacheResolvedPose.glBindBuffer.copyWrite.0");
            this.cacheByPoseRef.put(poseDataRef, cachedPose);
            this.cacheOrder.addLast(poseDataRef);
            return cachedPose;
        }

        private void invalidateLocalPose(Object poseDataRef) {
            CachedResolvedPose cachedPose = this.cacheByPoseRef.remove(poseDataRef);
            if (cachedPose != null) {
                this.cacheOrder.remove(poseDataRef);
                cachedPose.close();
            }
        }

        private CachedResolvedPose createCachedPose() {
            int cacheBufferId = GL15.glGenBuffers();
            ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.createCachedPose.glGenBuffers");
            int cacheTextureId = GL11.glGenTextures();
            ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.createCachedPose.glGenTextures");
            long byteSize = (long) this.boneCount * 16L * Float.BYTES;
            GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, cacheBufferId);
            ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.createCachedPose.glBindBuffer");
            GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, byteSize, GL15.GL_DYNAMIC_DRAW);
            ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.createCachedPose.glBufferData");
            GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, 0);
            ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.createCachedPose.glBindBuffer.0");
            attachTextureBuffer(cacheTextureId, GL30.GL_RGBA32F, cacheBufferId);
            return new CachedResolvedPose(cacheBufferId, cacheTextureId);
        }

        private void ensureCopiedBufferVisible() {
            GLCapabilities capabilities = GL.getCapabilities();
            if (capabilities.OpenGL42) {
                GL42.glMemoryBarrier(GL42.GL_BUFFER_UPDATE_BARRIER_BIT | GL42.GL_TEXTURE_FETCH_BARRIER_BIT);
                ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.ensureCopiedBufferVisible.glMemoryBarrier");
                return;
            }

            GL11.glFinish();
            ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.ensureCopiedBufferVisible.glFinish");
        }

        private void uploadBoneIndexData(ChaosGpuGeoMesh mesh) {
            IntBuffer buffer = MemoryUtil.memAllocInt(this.boneCount * 2);
            try {
                for (int boneIndex = 0; boneIndex < this.boneCount; boneIndex++) {
                    buffer.put(boneIndex);
                    buffer.put(mesh.getBoneDepth(boneIndex));
                }
                buffer.flip();

                GL30.glBindVertexArray(this.boneVertexArrayId);
                ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.uploadBoneIndexData.glBindVertexArray");
                GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, this.boneVertexBufferId);
                ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.uploadBoneIndexData.glBindBuffer");
                GL15.glBufferData(GL15.GL_ARRAY_BUFFER, buffer, GL15.GL_STATIC_DRAW);
                ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.uploadBoneIndexData.glBufferData");
                GL20.glEnableVertexAttribArray(0);
                ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.uploadBoneIndexData.glEnableVertexAttribArray.0");
                GL30.glVertexAttribIPointer(0, 1, GL11.GL_INT, Integer.BYTES * 2, 0L);
                ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.uploadBoneIndexData.glVertexAttribIPointer.0");
                GL20.glEnableVertexAttribArray(1);
                ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.uploadBoneIndexData.glEnableVertexAttribArray.1");
                GL30.glVertexAttribIPointer(1, 1, GL11.GL_INT, Integer.BYTES * 2, Integer.BYTES);
                ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.uploadBoneIndexData.glVertexAttribIPointer.1");
            } finally {
                GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, 0);
                ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.uploadBoneIndexData.cleanup.glBindBuffer.0");
                GL30.glBindVertexArray(0);
                ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.uploadBoneIndexData.cleanup.glBindVertexArray.0");
                MemoryUtil.memFree(buffer);
            }
        }

        @Override
        public void close() {
            GL15.glDeleteBuffers(this.boneVertexBufferId);
            ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.close.glDeleteBuffers.boneVertex");
            GL30.glDeleteVertexArrays(this.boneVertexArrayId);
            ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.close.glDeleteVertexArrays.bone");
            GL15.glDeleteBuffers(this.workingBufferIds[0]);
            ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.close.glDeleteBuffers.working.0");
            GL15.glDeleteBuffers(this.workingBufferIds[1]);
            ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.close.glDeleteBuffers.working.1");
            GL11.glDeleteTextures(this.workingTextureIds[0]);
            ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.close.glDeleteTextures.working.0");
            GL11.glDeleteTextures(this.workingTextureIds[1]);
            ChaosGlDebug.check("ChaosGpuBonePrepass.MeshState.close.glDeleteTextures.working.1");
            for (CachedResolvedPose cachedPose : this.cacheByPoseRef.values()) {
                cachedPose.close();
            }
        }
    }

    private record CachedResolvedPose(int bufferId, int textureId) implements AutoCloseable {
        @Override
        public void close() {
            GL15.glDeleteBuffers(this.bufferId);
            ChaosGlDebug.check("ChaosGpuBonePrepass.CachedResolvedPose.close.glDeleteBuffers");
            GL11.glDeleteTextures(this.textureId);
            ChaosGlDebug.check("ChaosGpuBonePrepass.CachedResolvedPose.close.glDeleteTextures");
        }
    }

    private static final class UploadBuffer {
        private FloatBuffer buffer = MemoryUtil.memAllocFloat(16);

        private FloatBuffer prepare(float[] source) {
            if (this.buffer.capacity() < source.length) {
                MemoryUtil.memFree(this.buffer);
                this.buffer = MemoryUtil.memAllocFloat(source.length);
            }

            this.buffer.clear();
            this.buffer.put(source);
            this.buffer.flip();
            return this.buffer;
        }
    }

    private static final class ReadbackBuffer {
        private FloatBuffer buffer = MemoryUtil.memAllocFloat(16);

        private float[] read(int bufferId, int boneCount) {
            int floatCount = boneCount * 16;
            if (this.buffer.capacity() < floatCount) {
                MemoryUtil.memFree(this.buffer);
                this.buffer = MemoryUtil.memAllocFloat(floatCount);
            }

            this.buffer.clear();
            this.buffer.limit(floatCount);
            GL15.glBindBuffer(GL31.GL_COPY_READ_BUFFER, bufferId);
            ChaosGlDebug.check("ChaosGpuBonePrepass.ReadbackBuffer.read.glBindBuffer.copyRead");
            GL15.glGetBufferSubData(GL31.GL_COPY_READ_BUFFER, 0, this.buffer);
            ChaosGlDebug.check("ChaosGpuBonePrepass.ReadbackBuffer.read.glGetBufferSubData");
            GL15.glBindBuffer(GL31.GL_COPY_READ_BUFFER, 0);
            ChaosGlDebug.check("ChaosGpuBonePrepass.ReadbackBuffer.read.glBindBuffer.copyRead.0");
            float[] matrices = new float[floatCount];
            this.buffer.position(0);
            this.buffer.get(matrices);
            return matrices;
        }
    }
}
