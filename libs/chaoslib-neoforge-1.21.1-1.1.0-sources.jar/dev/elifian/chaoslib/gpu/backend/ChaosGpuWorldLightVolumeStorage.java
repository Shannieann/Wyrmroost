package dev.elifian.chaoslib.gpu.backend;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.elifian.chaoslib.gpu.debug.ChaosGlDebug;
import net.minecraft.client.Minecraft;
import com.mojang.blaze3d.shaders.Uniform;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.core.SectionPos;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.chunk.DataLayer;
import net.minecraft.world.level.lighting.LayerLightEventListener;
import net.minecraft.world.level.lighting.LevelLightEngine;

import dev.elifian.chaoslib.platform.ClientOnly;
import it.unimi.dsi.fastutil.longs.Long2IntMap;
import it.unimi.dsi.fastutil.longs.Long2IntOpenHashMap;
import org.lwjgl.opengl.ARBTextureBufferObject;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GL31;
import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;
import java.util.Arrays;

@ClientOnly
public final class ChaosGpuWorldLightVolumeStorage {
    private static final int LIGHT_MASK_BLOCK = 1;
    private static final int LIGHT_MASK_SKY = 1 << 1;
    public static final int BLOCK_LIGHT_TEXTURE_UNIT = 11;
    public static final int SKY_LIGHT_TEXTURE_UNIT = 12;
    private static final int SECTION_RADIUS_XZ = 6;
    private static final int SECTION_DIAMETER_XZ = SECTION_RADIUS_XZ * 2 + 1;
    private static final int SECTION_REBUILD_THRESHOLD_XZ = Math.max(1, SECTION_RADIUS_XZ / 2);
    private static final int BLOCKS_PER_SECTION = 16;
    private static final byte INVALID_LIGHT = (byte) -1;
    private static final ThreadLocal<ByteUploadBuffer> BLOCK_UPLOAD_BUFFER = ThreadLocal.withInitial(ByteUploadBuffer::new);
    private static final ThreadLocal<ByteUploadBuffer> SKY_UPLOAD_BUFFER = ThreadLocal.withInitial(ByteUploadBuffer::new);
    private static ClientLevel currentWorld;
    private static int currentCameraSectionX = Integer.MIN_VALUE;
    private static int currentCameraSectionZ = Integer.MIN_VALUE;
    private static int blockLightBufferId = -1;
    private static int blockLightTextureId = -1;
    private static int skyLightBufferId = -1;
    private static int skyLightTextureId = -1;
    private static int uploadedVoxelCapacity = -1;
    private static byte[] blockLightVolume = new byte[0];
    private static byte[] skyLightVolume = new byte[0];
    private static int blockOriginX;
    private static int blockOriginY;
    private static int blockOriginZ;
    private static int sizeX;
    private static int sizeY;
    private static int sizeZ;
    private static boolean dirty;
    private static final Object PENDING_SECTION_UPDATES_LOCK = new Object();
    private static final Long2IntOpenHashMap pendingSectionUpdates = new Long2IntOpenHashMap();
    private static final Long2IntOpenHashMap pendingColumnUpdates = new Long2IntOpenHashMap();
    private static boolean lightUpdateListenerRegistered;

    private ChaosGpuWorldLightVolumeStorage() {
    }

    public static boolean isSupported() {
        return ChaosGpuRuntimePolicy.isTextureBufferSupported();
    }

    public static boolean shouldUseVolume(int fallbackPackedLight) {
        if (!isSupported() || fallbackPackedLight == LightTexture.FULL_BRIGHT) {
            return false;
        }

        Minecraft client = Minecraft.getInstance();
        return client.level != null && client.gameRenderer.getMainCamera() != null;
    }

    public static void invalidateAll() {
        deleteTextureAndBuffer(blockLightTextureId, blockLightBufferId);
        deleteTextureAndBuffer(skyLightTextureId, skyLightBufferId);
        blockLightTextureId = -1;
        blockLightBufferId = -1;
        skyLightTextureId = -1;
        skyLightBufferId = -1;
        uploadedVoxelCapacity = -1;
        currentWorld = null;
        currentCameraSectionX = Integer.MIN_VALUE;
        currentCameraSectionZ = Integer.MIN_VALUE;
        blockLightVolume = new byte[0];
        skyLightVolume = new byte[0];
        blockOriginX = 0;
        blockOriginY = 0;
        blockOriginZ = 0;
        sizeX = 0;
        sizeY = 0;
        sizeZ = 0;
        dirty = false;
        synchronized (PENDING_SECTION_UPDATES_LOCK) {
            pendingSectionUpdates.clear();
            pendingColumnUpdates.clear();
        }
    }

    public static void registerLightUpdateListener() {
        if (lightUpdateListenerRegistered) {
            return;
        }

        lightUpdateListenerRegistered = true;
        ChaosGpuWorldLightUpdateDispatcher.registerSectionListener(ChaosGpuWorldLightVolumeStorage::onSectionLightDirty);
        ChaosGpuWorldLightUpdateDispatcher.registerColumnListener(ChaosGpuWorldLightVolumeStorage::onColumnLightDirty);
    }

    public static void unbindSamplers(int blockLightTextureUnit, int skyLightTextureUnit) {
        int activeTexture = GlStateManager._getActiveTexture();
        RenderSystem.activeTexture(GL13.GL_TEXTURE0 + blockLightTextureUnit);
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, 0);
        RenderSystem.activeTexture(GL13.GL_TEXTURE0 + skyLightTextureUnit);
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, 0);
        GlStateManager._activeTexture(activeTexture);
    }

    public static void unbindSamplers() {
        int activeTexture = GlStateManager._getActiveTexture();
        unbindTexture(BLOCK_LIGHT_TEXTURE_UNIT);
        unbindTexture(SKY_LIGHT_TEXTURE_UNIT);
        GlStateManager._activeTexture(activeTexture);
    }

    public static boolean bindCurrentVolume(ShaderInstance shader) {
        Uniform useWorldLightVolumeUniform = shader.getUniform("UseWorldLightVolume");
        Uniform blockOriginUniform = shader.getUniform("LightVolumeBlockOrigin");
        Uniform sizeUniform = shader.getUniform("LightVolumeSize");
        Uniform cameraWorldPosUniform = shader.getUniform("CameraWorldPos");
        if (useWorldLightVolumeUniform == null
                || blockOriginUniform == null
                || sizeUniform == null
                || cameraWorldPosUniform == null) {
            return false;
        }

        if (!isSupported()) {
            useWorldLightVolumeUniform.set(0);
            return false;
        }

        Minecraft client = Minecraft.getInstance();
        ClientLevel world = client.level;
        if (world == null || client.gameRenderer.getMainCamera() == null) {
            useWorldLightVolumeUniform.set(0);
            return false;
        }

        Vec3 cameraPos = client.gameRenderer.getMainCamera().getPosition();
        ensureCurrentVolume(world, cameraPos);
        if (sizeX < 1 || sizeY < 1 || sizeZ < 1) {
            useWorldLightVolumeUniform.set(0);
            return false;
        }

        ensureInitialized();
        applyPendingSectionUpdates();
        uploadIfNeeded();
        bindTextureToUnit(BLOCK_LIGHT_TEXTURE_UNIT, blockLightTextureId);
        bindTextureToUnit(SKY_LIGHT_TEXTURE_UNIT, skyLightTextureId);
        useWorldLightVolumeUniform.set(1);
        blockOriginUniform.set(blockOriginX, blockOriginY, blockOriginZ);
        sizeUniform.set(sizeX, sizeY, sizeZ);
        cameraWorldPosUniform.set((float) cameraPos.x, (float) cameraPos.y, (float) cameraPos.z);
        return true;
    }

    public static boolean bindCurrentVolumeRaw(
            int fallbackPackedLight,
            int useWorldLightVolumeUniformLocation,
            int lightVolumeBlockOriginUniformLocation,
            int lightVolumeSizeUniformLocation,
            int cameraWorldPosUniformLocation,
            int blockLightVolumeSamplerUniformLocation,
            int skyLightVolumeSamplerUniformLocation
    ) {
        return bindCurrentVolumeRaw(
                fallbackPackedLight,
                useWorldLightVolumeUniformLocation,
                lightVolumeBlockOriginUniformLocation,
                lightVolumeSizeUniformLocation,
                cameraWorldPosUniformLocation,
                blockLightVolumeSamplerUniformLocation,
                skyLightVolumeSamplerUniformLocation,
                BLOCK_LIGHT_TEXTURE_UNIT,
                SKY_LIGHT_TEXTURE_UNIT
        );
    }

    public static boolean bindCurrentVolumeRaw(
            int fallbackPackedLight,
            int useWorldLightVolumeUniformLocation,
            int lightVolumeBlockOriginUniformLocation,
            int lightVolumeSizeUniformLocation,
            int cameraWorldPosUniformLocation,
            int blockLightVolumeSamplerUniformLocation,
            int skyLightVolumeSamplerUniformLocation,
            int blockLightTextureUnit,
            int skyLightTextureUnit
    ) {
        if (useWorldLightVolumeUniformLocation < 0
                || lightVolumeBlockOriginUniformLocation < 0
                || lightVolumeSizeUniformLocation < 0
                || cameraWorldPosUniformLocation < 0
                || blockLightVolumeSamplerUniformLocation < 0
                || skyLightVolumeSamplerUniformLocation < 0) {
            if (useWorldLightVolumeUniformLocation >= 0) {
                GL20.glUniform1i(useWorldLightVolumeUniformLocation, 0);
            }
            return false;
        }

        if (!shouldUseVolume(fallbackPackedLight)) {
            GL20.glUniform1i(useWorldLightVolumeUniformLocation, 0);
            return false;
        }

        Minecraft client = Minecraft.getInstance();
        ClientLevel world = client.level;
        if (world == null || client.gameRenderer.getMainCamera() == null) {
            GL20.glUniform1i(useWorldLightVolumeUniformLocation, 0);
            return false;
        }

        Vec3 cameraPos = client.gameRenderer.getMainCamera().getPosition();
        ensureCurrentVolume(world, cameraPos);
        if (sizeX < 1 || sizeY < 1 || sizeZ < 1) {
            GL20.glUniform1i(useWorldLightVolumeUniformLocation, 0);
            return false;
        }

        ensureInitialized();
        applyPendingSectionUpdates();
        uploadIfNeeded();
        bindTextureToUnit(blockLightTextureUnit, blockLightTextureId);
        bindTextureToUnit(skyLightTextureUnit, skyLightTextureId);
        GL20.glUniform1i(useWorldLightVolumeUniformLocation, 1);
        GL20.glUniform3i(lightVolumeBlockOriginUniformLocation, blockOriginX, blockOriginY, blockOriginZ);
        GL20.glUniform3i(lightVolumeSizeUniformLocation, sizeX, sizeY, sizeZ);
        GL20.glUniform3f(cameraWorldPosUniformLocation, (float) cameraPos.x, (float) cameraPos.y, (float) cameraPos.z);
        GL20.glUniform1i(blockLightVolumeSamplerUniformLocation, blockLightTextureUnit);
        GL20.glUniform1i(skyLightVolumeSamplerUniformLocation, skyLightTextureUnit);
        return true;
    }

    private static void ensureCurrentVolume(ClientLevel world, Vec3 cameraPos) {
        int cameraSectionX = SectionPos.blockToSectionCoord(cameraPos.x);
        int cameraSectionZ = SectionPos.blockToSectionCoord(cameraPos.z);
        if (world == currentWorld
                && Math.abs(cameraSectionX - currentCameraSectionX) < SECTION_REBUILD_THRESHOLD_XZ
                && Math.abs(cameraSectionZ - currentCameraSectionZ) < SECTION_REBUILD_THRESHOLD_XZ) {
            return;
        }

        rebuildVolume(world, cameraSectionX, cameraSectionZ);
    }

    private static void rebuildVolume(ClientLevel world, int cameraSectionX, int cameraSectionZ) {
        LevelLightEngine lightingProvider = world.getLightEngine();
        LayerLightEventListener blockView = lightingProvider.getLayerListener(LightLayer.BLOCK);
        LayerLightEventListener skyView = lightingProvider.getLayerListener(LightLayer.SKY);
        int originSectionX = cameraSectionX - SECTION_RADIUS_XZ;
        int originSectionZ = cameraSectionZ - SECTION_RADIUS_XZ;
        int originSectionY = SectionPos.blockToSectionCoord(lightingProvider.getMinLightSection());
        int maxSectionY = SectionPos.blockToSectionCoord(lightingProvider.getMaxLightSection() - 1);
        int sectionCountY = maxSectionY - originSectionY + 1;
        if (sectionCountY < 1) {
            sectionCountY = 1;
        }

        blockOriginX = SectionPos.sectionToBlockCoord(originSectionX);
        blockOriginY = SectionPos.sectionToBlockCoord(originSectionY);
        blockOriginZ = SectionPos.sectionToBlockCoord(originSectionZ);
        sizeX = SECTION_DIAMETER_XZ * BLOCKS_PER_SECTION;
        sizeY = sectionCountY * BLOCKS_PER_SECTION;
        sizeZ = SECTION_DIAMETER_XZ * BLOCKS_PER_SECTION;
        int voxelCount = sizeX * sizeY * sizeZ;
        ensureCapacity(voxelCount);
        Arrays.fill(blockLightVolume, 0, voxelCount, INVALID_LIGHT);
        Arrays.fill(skyLightVolume, 0, voxelCount, INVALID_LIGHT);

        BlockPos.MutableBlockPos samplePos = new BlockPos.MutableBlockPos();
        for (int sectionY = 0; sectionY < sectionCountY; sectionY++) {
            int worldSectionY = originSectionY + sectionY;
            for (int sectionZ = 0; sectionZ < SECTION_DIAMETER_XZ; sectionZ++) {
                int worldSectionZ = originSectionZ + sectionZ;
                for (int sectionX = 0; sectionX < SECTION_DIAMETER_XZ; sectionX++) {
                    int worldSectionX = originSectionX + sectionX;
                    SectionPos sectionPos = SectionPos.of(worldSectionX, worldSectionY, worldSectionZ);
                    if (!lightingProvider.lightOnInSection(sectionPos)) {
                        continue;
                    }

                    int baseX = sectionX * BLOCKS_PER_SECTION;
                    int baseY = sectionY * BLOCKS_PER_SECTION;
                    int baseZ = sectionZ * BLOCKS_PER_SECTION;
                    copyLightSection(blockView, sectionPos, baseX, baseY, baseZ, blockLightVolume, samplePos);
                    copyLightSection(skyView, sectionPos, baseX, baseY, baseZ, skyLightVolume, samplePos);
                }
            }
        }

        currentWorld = world;
        currentCameraSectionX = cameraSectionX;
        currentCameraSectionZ = cameraSectionZ;
        synchronized (PENDING_SECTION_UPDATES_LOCK) {
            pendingSectionUpdates.clear();
            pendingColumnUpdates.clear();
        }
        dirty = true;
    }

    public static void onSectionLightDirty(ClientLevel world, long sectionPos, int lightMask) {
        if (world == null || lightMask == 0 || world != currentWorld) {
            return;
        }

        synchronized (PENDING_SECTION_UPDATES_LOCK) {
            pendingSectionUpdates.put(sectionPos, pendingSectionUpdates.get(sectionPos) | lightMask);
        }
        dirty = true;
    }

    public static void onColumnLightDirty(ClientLevel world, long chunkPos, int lightMask) {
        if (world == null || lightMask == 0 || world != currentWorld) {
            return;
        }

        synchronized (PENDING_SECTION_UPDATES_LOCK) {
            pendingColumnUpdates.put(chunkPos, pendingColumnUpdates.get(chunkPos) | lightMask);
        }
        dirty = true;
    }

    private static void copyLightSection(
            LayerLightEventListener lightView,
            SectionPos sectionPos,
            int baseX,
            int baseY,
            int baseZ,
            byte[] target,
            BlockPos.MutableBlockPos samplePos
    ) {
        if (lightView == null) {
            fillSection(baseX, baseY, baseZ, target, (byte) 0);
            return;
        }

        DataLayer section = lightView.getDataLayerData(sectionPos);
        if (section != null && !section.isEmpty()) {
            for (int localZ = 0; localZ < BLOCKS_PER_SECTION; localZ++) {
                int worldZ = baseZ + localZ;
                for (int localY = 0; localY < BLOCKS_PER_SECTION; localY++) {
                    int worldY = baseY + localY;
                    for (int localX = 0; localX < BLOCKS_PER_SECTION; localX++) {
                        target[index(baseX + localX, worldY, worldZ)] = (byte) section.get(localX, localY, localZ);
                    }
                }
            }
            return;
        }

        int minX = sectionPos.minBlockX();
        int minY = sectionPos.minBlockY();
        int minZ = sectionPos.minBlockZ();
        for (int localZ = 0; localZ < BLOCKS_PER_SECTION; localZ++) {
            int worldZ = minZ + localZ;
            int volumeZ = baseZ + localZ;
            for (int localY = 0; localY < BLOCKS_PER_SECTION; localY++) {
                int worldY = minY + localY;
                int volumeY = baseY + localY;
                for (int localX = 0; localX < BLOCKS_PER_SECTION; localX++) {
                    samplePos.set(minX + localX, worldY, worldZ);
                    target[index(baseX + localX, volumeY, volumeZ)] = (byte) lightView.getLightValue(samplePos);
                }
            }
        }
    }

    private static void fillSection(int baseX, int baseY, int baseZ, byte[] target, byte value) {
        for (int localZ = 0; localZ < BLOCKS_PER_SECTION; localZ++) {
            int worldZ = baseZ + localZ;
            for (int localY = 0; localY < BLOCKS_PER_SECTION; localY++) {
                int worldY = baseY + localY;
                for (int localX = 0; localX < BLOCKS_PER_SECTION; localX++) {
                    target[index(baseX + localX, worldY, worldZ)] = value;
                }
            }
        }
    }

    private static int index(int localX, int localY, int localZ) {
        return localX + sizeX * (localY + sizeY * localZ);
    }

    private static void ensureCapacity(int voxelCount) {
        if (blockLightVolume.length < voxelCount) {
            blockLightVolume = new byte[voxelCount];
        }
        if (skyLightVolume.length < voxelCount) {
            skyLightVolume = new byte[voxelCount];
        }
    }

    private static void applyPendingSectionUpdates() {
        Long2IntOpenHashMap updates;
        synchronized (PENDING_SECTION_UPDATES_LOCK) {
            if (pendingSectionUpdates.isEmpty() && pendingColumnUpdates.isEmpty()) {
                return;
            }

            updates = new Long2IntOpenHashMap(pendingSectionUpdates);
            if (!pendingColumnUpdates.isEmpty()) {
                mergeColumnUpdatesIntoSections(pendingColumnUpdates, updates);
            }
            pendingSectionUpdates.clear();
            pendingColumnUpdates.clear();
        }

        LevelLightEngine lightingProvider = currentWorld.getLightEngine();
        LayerLightEventListener blockView = lightingProvider.getLayerListener(LightLayer.BLOCK);
        LayerLightEventListener skyView = lightingProvider.getLayerListener(LightLayer.SKY);
        BlockPos.MutableBlockPos samplePos = new BlockPos.MutableBlockPos();
        boolean copiedAny = false;

        for (Long2IntMap.Entry entry : updates.long2IntEntrySet()) {
            long sectionPosLong = entry.getLongKey();
            int lightMask = entry.getIntValue();
            SectionPos sectionPos = SectionPos.of(sectionPosLong);
            int baseX = sectionPos.minBlockX() - blockOriginX;
            int baseY = sectionPos.minBlockY() - blockOriginY;
            int baseZ = sectionPos.minBlockZ() - blockOriginZ;
            if (baseX < 0 || baseY < 0 || baseZ < 0
                    || baseX + BLOCKS_PER_SECTION > sizeX
                    || baseY + BLOCKS_PER_SECTION > sizeY
                    || baseZ + BLOCKS_PER_SECTION > sizeZ) {
                continue;
            }

            if ((lightMask & LIGHT_MASK_BLOCK) != 0) {
                copyLightSection(blockView, sectionPos, baseX, baseY, baseZ, blockLightVolume, samplePos);
                copiedAny = true;
            }
            if ((lightMask & LIGHT_MASK_SKY) != 0) {
                copyLightSection(skyView, sectionPos, baseX, baseY, baseZ, skyLightVolume, samplePos);
                copiedAny = true;
            }
        }

        if (copiedAny) {
            dirty = true;
        }
    }

    private static void mergeColumnUpdatesIntoSections(Long2IntOpenHashMap columnUpdates, Long2IntOpenHashMap sectionUpdates) {
        int minSectionY = SectionPos.blockToSectionCoord(blockOriginY);
        int maxSectionY = minSectionY + (sizeY / BLOCKS_PER_SECTION) - 1;
        int minSectionX = SectionPos.blockToSectionCoord(blockOriginX);
        int maxSectionX = minSectionX + SECTION_DIAMETER_XZ - 1;
        int minSectionZ = SectionPos.blockToSectionCoord(blockOriginZ);
        int maxSectionZ = minSectionZ + SECTION_DIAMETER_XZ - 1;

        for (Long2IntMap.Entry entry : columnUpdates.long2IntEntrySet()) {
            long chunkPosLong = entry.getLongKey();
            int sectionX = ChunkPos.getX(chunkPosLong);
            int sectionZ = ChunkPos.getZ(chunkPosLong);
            if (sectionX < minSectionX || sectionX > maxSectionX || sectionZ < minSectionZ || sectionZ > maxSectionZ) {
                continue;
            }

            int lightMask = entry.getIntValue();
            for (int sectionY = minSectionY; sectionY <= maxSectionY; sectionY++) {
                long sectionPos = SectionPos.of(sectionX, sectionY, sectionZ).asLong();
                sectionUpdates.put(sectionPos, sectionUpdates.get(sectionPos) | lightMask);
            }
        }
    }

    private static void ensureInitialized() {
        if (blockLightBufferId == -1) {
            blockLightBufferId = GL15.glGenBuffers();
            ChaosGlDebug.check("ChaosGpuWorldLightVolumeStorage.ensureInitialized.glGenBuffers.block");
            blockLightTextureId = GL11.glGenTextures();
            ChaosGlDebug.check("ChaosGpuWorldLightVolumeStorage.ensureInitialized.glGenTextures.block");
        }
        if (skyLightBufferId != -1) {
            return;
        }

        skyLightBufferId = GL15.glGenBuffers();
        ChaosGlDebug.check("ChaosGpuWorldLightVolumeStorage.ensureInitialized.glGenBuffers.sky");
        skyLightTextureId = GL11.glGenTextures();
        ChaosGlDebug.check("ChaosGpuWorldLightVolumeStorage.ensureInitialized.glGenTextures.sky");
    }

    private static void uploadIfNeeded() {
        if (!dirty) {
            return;
        }

        int voxelCount = sizeX * sizeY * sizeZ;
        boolean reallocate = uploadedVoxelCapacity != voxelCount;
        ByteBuffer blockBuffer = BLOCK_UPLOAD_BUFFER.get().prepare(blockLightVolume, voxelCount);
        GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, blockLightBufferId);
        ChaosGlDebug.check("ChaosGpuWorldLightVolumeStorage.uploadIfNeeded.glBindBuffer.block");
        if (reallocate) {
            GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, blockBuffer, GL15.GL_DYNAMIC_DRAW);
            ChaosGlDebug.check("ChaosGpuWorldLightVolumeStorage.uploadIfNeeded.glBufferData.block");
            attachTextureBuffer(blockLightTextureId, GL30.GL_R8I, blockLightBufferId);
        } else {
            GL15.glBufferSubData(GL31.GL_TEXTURE_BUFFER, 0L, blockBuffer);
            ChaosGlDebug.check("ChaosGpuWorldLightVolumeStorage.uploadIfNeeded.glBufferSubData.block");
        }

        ByteBuffer skyBuffer = SKY_UPLOAD_BUFFER.get().prepare(skyLightVolume, voxelCount);
        GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, skyLightBufferId);
        ChaosGlDebug.check("ChaosGpuWorldLightVolumeStorage.uploadIfNeeded.glBindBuffer.sky");
        if (reallocate) {
            GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, skyBuffer, GL15.GL_DYNAMIC_DRAW);
            ChaosGlDebug.check("ChaosGpuWorldLightVolumeStorage.uploadIfNeeded.glBufferData.sky");
            attachTextureBuffer(skyLightTextureId, GL30.GL_R8I, skyLightBufferId);
            uploadedVoxelCapacity = voxelCount;
        } else {
            GL15.glBufferSubData(GL31.GL_TEXTURE_BUFFER, 0L, skyBuffer);
            ChaosGlDebug.check("ChaosGpuWorldLightVolumeStorage.uploadIfNeeded.glBufferSubData.sky");
        }
        GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, 0);
        ChaosGlDebug.check("ChaosGpuWorldLightVolumeStorage.uploadIfNeeded.glBindBuffer.0");
        dirty = false;
    }

    private static void bindTextureToUnit(int textureUnit, int textureId) {
        int activeTexture = GlStateManager._getActiveTexture();
        RenderSystem.activeTexture(GL13.GL_TEXTURE0 + textureUnit);
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, textureId);
        ChaosGlDebug.check("ChaosGpuWorldLightVolumeStorage.bindTextureToUnit.glBindTexture." + textureUnit);
        GlStateManager._activeTexture(activeTexture);
    }

    private static void unbindTexture(int textureUnit) {
        RenderSystem.activeTexture(GL13.GL_TEXTURE0 + textureUnit);
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, 0);
        ChaosGlDebug.check("ChaosGpuWorldLightVolumeStorage.unbindTexture.glBindTexture.0." + textureUnit);
    }

    private static void attachTextureBuffer(int textureId, int internalFormat, int bufferId) {
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, textureId);
        ChaosGlDebug.check("ChaosGpuWorldLightVolumeStorage.attachTextureBuffer.glBindTexture");
        if (GL.getCapabilities().OpenGL31) {
            GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, internalFormat, bufferId);
            ChaosGlDebug.check("ChaosGpuWorldLightVolumeStorage.attachTextureBuffer.glTexBuffer");
        } else {
            ARBTextureBufferObject.glTexBufferARB(ARBTextureBufferObject.GL_TEXTURE_BUFFER_ARB, internalFormat, bufferId);
            ChaosGlDebug.check("ChaosGpuWorldLightVolumeStorage.attachTextureBuffer.glTexBufferARB");
        }
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, 0);
        ChaosGlDebug.check("ChaosGpuWorldLightVolumeStorage.attachTextureBuffer.glBindTexture.0");
    }

    private static void deleteTextureAndBuffer(int textureId, int bufferId) {
        if (textureId != -1) {
            GL11.glDeleteTextures(textureId);
            ChaosGlDebug.check("ChaosGpuWorldLightVolumeStorage.deleteTextureAndBuffer.glDeleteTextures");
        }
        if (bufferId != -1) {
            GL15.glDeleteBuffers(bufferId);
            ChaosGlDebug.check("ChaosGpuWorldLightVolumeStorage.deleteTextureAndBuffer.glDeleteBuffers");
        }
    }

    private static final class ByteUploadBuffer {
        private ByteBuffer buffer = MemoryUtil.memAlloc(16);

        private ByteBuffer prepare(byte[] source, int length) {
            if (this.buffer.capacity() < length) {
                MemoryUtil.memFree(this.buffer);
                this.buffer = MemoryUtil.memAlloc(length);
            }

            this.buffer.clear();
            this.buffer.put(source, 0, length);
            this.buffer.flip();
            return this.buffer;
        }
    }
}
