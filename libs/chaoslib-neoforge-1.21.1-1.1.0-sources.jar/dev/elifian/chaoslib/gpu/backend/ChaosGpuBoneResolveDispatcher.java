package dev.elifian.chaoslib.gpu.backend;

import dev.elifian.chaoslib.gpu.mesh.ChaosGpuGeoMesh;

import dev.elifian.chaoslib.platform.ClientOnly;

@ClientOnly
public final class ChaosGpuBoneResolveDispatcher {
    private static final ChaosGpuBoneResolveBackend COMPUTE_BACKEND = new ChaosGpuBoneComputeBackend();
    private static final ChaosGpuBoneResolveBackend TRANSFORM_FEEDBACK_BACKEND = new ChaosGpuBonePrepass();

    private ChaosGpuBoneResolveDispatcher() {
    }

    public static boolean isSupported() {
        return ChaosGpuRuntimePolicy.getResolvedBackendMode() != ChaosGpuRuntimePolicy.ResolvedBackendMode.NONE;
    }

    public static boolean usesResolvedBackend() {
        return isSupported();
    }

    public static void invalidateAll() {
        COMPUTE_BACKEND.invalidateAll();
        TRANSFORM_FEEDBACK_BACKEND.invalidateAll();
    }

    public static void invalidateLocalPose(Object localPoseData, int localPoseTextureId) {
        COMPUTE_BACKEND.invalidateLocalPose(localPoseData, localPoseTextureId);
        TRANSFORM_FEEDBACK_BACKEND.invalidateLocalPose(localPoseData, localPoseTextureId);
    }

    public static ChaosGpuRuntimePolicy.ResolvedBackendMode getResolvedBackendMode() {
        return ChaosGpuRuntimePolicy.getResolvedBackendMode();
    }

    public static int resolveAndBind(ChaosGpuGeoMesh mesh, Object localPoseData) {
        ChaosGpuAnimationPoseStorage.ensureBatchFlushed();
        return switch (getResolvedBackendMode()) {
            case COMPUTE -> COMPUTE_BACKEND.resolveAndBind(mesh, localPoseData);
            case TRANSFORM_FEEDBACK -> TRANSFORM_FEEDBACK_BACKEND.resolveAndBind(mesh, localPoseData);
            case NONE -> -1;
        };
    }

    public static float[] resolveAndRead(ChaosGpuGeoMesh mesh, Object localPoseData) {
        ChaosGpuAnimationPoseStorage.ensureBatchFlushed();
        return switch (getResolvedBackendMode()) {
            case COMPUTE -> COMPUTE_BACKEND.resolveAndRead(mesh, localPoseData);
            case TRANSFORM_FEEDBACK -> TRANSFORM_FEEDBACK_BACKEND.resolveAndRead(mesh, localPoseData);
            case NONE -> null;
        };
    }
}
