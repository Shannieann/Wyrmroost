package dev.elifian.chaoslib.gpu.backend;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.elifian.chaoslib.gpu.debug.ChaosGlDebug;

import dev.elifian.chaoslib.platform.ClientOnly;
import org.lwjgl.opengl.ARBTextureBufferObject;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GL31;
import org.lwjgl.system.MemoryUtil;

import java.nio.IntBuffer;

@ClientOnly
public final class ChaosGpuLightDataStorage {
    public static final int BONE_LIGHT_TEXTURE_UNIT = 9;
    private static final ThreadLocal<IntUploadBuffer> BONE_LIGHT_UPLOAD_BUFFER = ThreadLocal.withInitial(IntUploadBuffer::new);
    private static int boneLightBufferId = -1;
    private static int boneLightTextureId = -1;
    private static int[] lastUploadedBoneLightData;

    private ChaosGpuLightDataStorage() {
    }

    public static boolean isSupported() {
        return ChaosGpuRuntimePolicy.isTextureBufferSupported();
    }

    public static void invalidateAll() {
        if (boneLightTextureId != -1) {
            GL11.glDeleteTextures(boneLightTextureId);
            ChaosGlDebug.check("ChaosGpuLightDataStorage.invalidateAll.glDeleteTextures");
            boneLightTextureId = -1;
        }
        if (boneLightBufferId != -1) {
            GL15.glDeleteBuffers(boneLightBufferId);
            ChaosGlDebug.check("ChaosGpuLightDataStorage.invalidateAll.glDeleteBuffers");
            boneLightBufferId = -1;
        }
        lastUploadedBoneLightData = null;
    }

    public static boolean bindBoneLights(int[] boneLightData) {
        return bindBoneLights(boneLightData, BONE_LIGHT_TEXTURE_UNIT);
    }

    public static boolean bindBoneLights(int[] boneLightData, int textureUnit) {
        if (!isSupported() || boneLightData == null) {
            return false;
        }

        ensureInitialized();
        uploadBoneLightsIfNeeded(boneLightData);
        bindTextureToUnit(textureUnit, boneLightTextureId);
        return true;
    }

    public static void unbindSampler() {
        unbindSampler(BONE_LIGHT_TEXTURE_UNIT);
    }

    public static void unbindSampler(int textureUnit) {
        int activeTexture = GlStateManager._getActiveTexture();
        RenderSystem.activeTexture(GL13.GL_TEXTURE0 + textureUnit);
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, 0);
        ChaosGlDebug.check("ChaosGpuLightDataStorage.unbindSampler.glBindTexture.0");
        GlStateManager._activeTexture(activeTexture);
    }

    private static void ensureInitialized() {
        if (boneLightBufferId != -1) {
            return;
        }

        boneLightBufferId = GL15.glGenBuffers();
        ChaosGlDebug.check("ChaosGpuLightDataStorage.ensureInitialized.glGenBuffers");
        boneLightTextureId = GL11.glGenTextures();
        ChaosGlDebug.check("ChaosGpuLightDataStorage.ensureInitialized.glGenTextures");
    }

    private static void uploadBoneLightsIfNeeded(int[] boneLightData) {
        if (boneLightData == lastUploadedBoneLightData) {
            return;
        }

        IntBuffer buffer = BONE_LIGHT_UPLOAD_BUFFER.get().prepare(boneLightData);
        GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, boneLightBufferId);
        ChaosGlDebug.check("ChaosGpuLightDataStorage.uploadBoneLightsIfNeeded.glBindBuffer");
        GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, buffer, GL15.GL_DYNAMIC_DRAW);
        ChaosGlDebug.check("ChaosGpuLightDataStorage.uploadBoneLightsIfNeeded.glBufferData");
        attachTextureBuffer(boneLightTextureId, GL30.GL_R32I, boneLightBufferId);
        GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, 0);
        ChaosGlDebug.check("ChaosGpuLightDataStorage.uploadBoneLightsIfNeeded.glBindBuffer.0");
        lastUploadedBoneLightData = boneLightData;
    }

    private static void bindTextureToUnit(int textureUnit, int textureId) {
        int activeTexture = GlStateManager._getActiveTexture();
        RenderSystem.activeTexture(GL13.GL_TEXTURE0 + textureUnit);
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, textureId);
        ChaosGlDebug.check("ChaosGpuLightDataStorage.bindTextureToUnit.glBindTexture." + textureUnit);
        GlStateManager._activeTexture(activeTexture);
    }

    private static void attachTextureBuffer(int textureId, int internalFormat, int bufferId) {
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, textureId);
        ChaosGlDebug.check("ChaosGpuLightDataStorage.attachTextureBuffer.glBindTexture");
        if (GL.getCapabilities().OpenGL31) {
            GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, internalFormat, bufferId);
            ChaosGlDebug.check("ChaosGpuLightDataStorage.attachTextureBuffer.glTexBuffer");
        } else {
            ARBTextureBufferObject.glTexBufferARB(ARBTextureBufferObject.GL_TEXTURE_BUFFER_ARB, internalFormat, bufferId);
            ChaosGlDebug.check("ChaosGpuLightDataStorage.attachTextureBuffer.glTexBufferARB");
        }
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, 0);
        ChaosGlDebug.check("ChaosGpuLightDataStorage.attachTextureBuffer.glBindTexture.0");
    }

    private static final class IntUploadBuffer {
        private IntBuffer buffer = MemoryUtil.memAllocInt(16);

        private IntBuffer prepare(int[] source) {
            if (this.buffer.capacity() < source.length) {
                MemoryUtil.memFree(this.buffer);
                this.buffer = MemoryUtil.memAllocInt(source.length);
            }

            this.buffer.clear();
            this.buffer.put(source);
            this.buffer.flip();
            return this.buffer;
        }
    }
}
