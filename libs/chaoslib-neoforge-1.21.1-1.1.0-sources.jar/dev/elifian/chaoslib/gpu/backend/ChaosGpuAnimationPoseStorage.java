package dev.elifian.chaoslib.gpu.backend;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.elifian.chaoslib.api.animatable.GeoAnimatable;
import dev.elifian.chaoslib.api.animation.AnimationPlaybackController;
import dev.elifian.chaoslib.api.animation.AnimationState;
import dev.elifian.chaoslib.api.animation.RawAnimation;
import dev.elifian.chaoslib.cache.object.GeoBone;
import dev.elifian.chaoslib.client.animation.GeoAnimationData;
import dev.elifian.chaoslib.client.animation.GeoAnimationRuntime;
import dev.elifian.chaoslib.gpu.animation.ChaosGpuAnimationPayload;
import dev.elifian.chaoslib.gpu.debug.ChaosGlDebug;
import dev.elifian.chaoslib.gpu.mesh.ChaosGpuGeoMesh;
import dev.elifian.chaoslib.gpu.shader.ChaosGpuShaderSources;
import dev.elifian.chaoslib.model.baked.StaticGeoBonePose;
import dev.elifian.chaoslib.renderer.block.ChaosBlockEntityRenderFrameClock;

import dev.elifian.chaoslib.platform.ClientOnly;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;
import org.lwjgl.opengl.*;
import org.lwjgl.system.MemoryUtil;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.*;
import java.util.function.Function;

@ClientOnly
public final class ChaosGpuAnimationPoseStorage {
    private static final int TRANSITION_POSE_TEXTURE_UNIT = 8;
    private static final int CLIP_TEXTURE_UNIT = 9;
    private static final int CHANNEL_TEXTURE_UNIT = 10;
    private static final int KEYFRAME_TEXTURE_UNIT = 11;
    private static final int BONE_DEFINITION_TEXTURE_UNIT = 12;
    private static final int ACTIVE_STATE_TEXTURE_UNIT = 13;
    private static final int RUNTIME_CHANNEL_TEXTURE_UNIT = 14;
    private static final int CONTROLLER_STATE_TEXTURE_UNIT = 15;
    private static final int WORKGROUP_SIZE = 64;
    private static final ThreadLocal<RequestUploadBuffer> REQUEST_UPLOAD_BUFFER = ThreadLocal.withInitial(RequestUploadBuffer::new);
    private static int batchUploadTag;
    private static final int MAX_CACHED_POSES_PER_STATE = 16;
    private static final float[] EMPTY_TEXTURE_BUFFER_UPLOAD = new float[4];
    private static final String COMPUTE_SHADER = ChaosGpuShaderSources.load("assets/chaoslib/shaders/internal/animation_sample/compute.comp");
    private static final String TRANSFORM_FEEDBACK_SHADER = ChaosGpuShaderSources.load("assets/chaoslib/shaders/internal/animation_sample/transform_feedback.vsh");
    private static final String TRANSFORM_FEEDBACK_FRAGMENT_SHADER = ChaosGpuShaderSources.load("assets/chaoslib/shaders/internal/transform_feedback/passthrough_140.fsh");
    private static final Map<ChaosGpuAnimationPayload, PayloadState> PAYLOAD_CACHE = new IdentityHashMap<>();
    private static final Map<ChaosGpuGeoMesh, MeshState> MESH_CACHE = new IdentityHashMap<>();
    private static final ThreadLocal<UploadBuffer> FLOAT_UPLOAD_BUFFER = ThreadLocal.withInitial(UploadBuffer::new);
    private static ActiveStateTextureSet scratchActiveStateTextures;
    private static int computeProgram = -1;
    private static int computeClipSamplerLocation = -1;
    private static int computeChannelSamplerLocation = -1;
    private static int computeKeyframeSamplerLocation = -1;
    private static int computeBoneDefinitionSamplerLocation = -1;
    private static int computeActiveStateSamplerLocation = -1;
    private static int computeTransitionPoseSamplerLocation = -1;
    private static int computeRuntimeChannelSamplerLocation = -1;
    private static int computeControllerStateSamplerLocation = -1;
    private static int computeBoneCountLocation = -1;
    private static int computeRequestCountLocation = -1;
    private static int computeActiveStateStrideLocation = -1;
    private static int computeControllerStateStrideLocation = -1;
    private static int computeTransitionPoseStrideLocation = -1;
    private static int computeRuntimeChannelStrideLocation = -1;
    private static final Map<Object, BatchGroupState> BATCH_GROUP_STATES = new HashMap<>();
    private static final Object SINGLE_DISPATCH_GROUP_KEY = new Object();
    private static final Map<FramePoseKey, LocalPoseHandle> FRAME_POSE_DEDUP = new HashMap<>();
    private static int transformFeedbackProgram = -1;
    private static int tfClipSamplerLocation = -1;
    private static int tfChannelSamplerLocation = -1;
    private static int tfKeyframeSamplerLocation = -1;
    private static int tfBoneDefinitionSamplerLocation = -1;
    private static int tfActiveStateSamplerLocation = -1;
    private static int tfTransitionPoseSamplerLocation = -1;
    private static int tfRuntimeChannelSamplerLocation = -1;
    private static int tfControllerStateSamplerLocation = -1;
    private static int tfBoneCountLocation = -1;
    private static int tfControllerStateCountLocation = -1;

    private ChaosGpuAnimationPoseStorage() {
    }

    public static boolean isSupported() {
        return backendMode() != BackendMode.NONE;
    }

    public static int textureIdFor(@Nullable Object localPoseHandle) {
        return localPoseHandle instanceof LocalPoseHandle handle ? handle.textureId() : -1;
    }

    public static int bufferIdFor(@Nullable Object localPoseHandle) {
        return localPoseHandle instanceof LocalPoseHandle handle ? handle.bufferId() : -1;
    }

    public static int poseBaseFor(@Nullable Object localPoseHandle) {
        return localPoseHandle instanceof LocalPoseHandle handle ? handle.poseBase() : 0;
    }

    public static @Nullable LocalPoseHandle prepareUploadedPoseToken(ChaosGpuGeoMesh mesh, float[] localPoseData, Object poseCacheKey) {
        return prepareUploadedPoseToken(mesh, localPoseData, poseCacheKey, null);
    }

    public static @Nullable LocalPoseHandle prepareUploadedPoseToken(ChaosGpuGeoMesh mesh, float[] localPoseData, Object poseCacheKey, @Nullable Object stableOwnerKey) {
        if (!ChaosGpuRuntimePolicy.isTextureBufferSupported()) {
            return null;
        }

        MeshState meshState = getOrCreateMeshState(mesh);
        if (stableOwnerKey != null) {
            OwnedPose ownedPose = meshState.acquireOwnedUploadedPose(stableOwnerKey, mesh.getIndexedBones().size());
            if (!ownedPose.matches(poseCacheKey)) {
                uploadLocalPoseData(ownedPose.pose().bufferId(), localPoseData);
                ownedPose.updatePoseKey(poseCacheKey);
                ChaosGpuBoneResolveDispatcher.invalidateLocalPose(ownedPose.pose().handle(), ownedPose.pose().textureId());
            }
            return ownedPose.pose().handle();
        }

        Object cacheKey = new UploadedPoseCacheKey(poseCacheKey);
        CachedPose cachedPose = meshState.cachedPose(cacheKey);
        if (cachedPose != null) {
            return cachedPose.handle();
        }
        cachedPose = meshState.acquirePose(cacheKey, mesh.getIndexedBones().size());
        uploadLocalPoseData(cachedPose.bufferId(), localPoseData);
        ChaosGpuBoneResolveDispatcher.invalidateLocalPose(cachedPose.handle(), cachedPose.textureId());
        return cachedPose.handle();
    }

    public static @Nullable LocalPoseHandle prepareStaticPoseToken(ChaosGpuGeoMesh mesh, Map<String, StaticGeoBonePose> staticBonePoses, Object poseCacheKey) {
        if (!ChaosGpuRuntimePolicy.isTextureBufferSupported()) {
            return null;
        }

        MeshState meshState = getOrCreateMeshState(mesh);
        Object cacheKey = List.of("static", poseCacheKey);
        CachedPose cachedPose = meshState.cachedPose(cacheKey);
        if (cachedPose != null) {
            return cachedPose.handle();
        }

        cachedPose = meshState.acquirePose(cacheKey, mesh.getIndexedBones().size());
        uploadStaticPoseData(mesh, staticBonePoses, cachedPose.bufferId());
        ChaosGpuBoneResolveDispatcher.invalidateLocalPose(cachedPose.handle(), cachedPose.textureId());
        return cachedPose.handle();
    }

    public static @Nullable LocalPoseHandle prepareRestPoseToken(ChaosGpuGeoMesh mesh) {
        return prepareStaticPoseToken(mesh, Collections.emptyMap(), RestPoseCacheKey.INSTANCE);
    }

    public static void invalidateAll() {
        ChaosGpuPoseSlotStore.invalidateAll();
        for (PayloadState state : PAYLOAD_CACHE.values()) {
            state.close();
        }
        PAYLOAD_CACHE.clear();
        for (MeshState state : MESH_CACHE.values()) {
            state.close();
        }
        MESH_CACHE.clear();
        if (scratchActiveStateTextures != null) {
            scratchActiveStateTextures.close();
            scratchActiveStateTextures = null;
        }
        if (computeProgram != -1) {
            GL20.glDeleteProgram(computeProgram);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.invalidateAll.glDeleteProgram.compute");
            computeProgram = -1;
        }
        if (transformFeedbackProgram != -1) {
            GL20.glDeleteProgram(transformFeedbackProgram);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.invalidateAll.glDeleteProgram.transformFeedback");
            transformFeedbackProgram = -1;
        }
        computeClipSamplerLocation = -1;
        computeChannelSamplerLocation = -1;
        computeKeyframeSamplerLocation = -1;
        computeBoneDefinitionSamplerLocation = -1;
        computeActiveStateSamplerLocation = -1;
        computeTransitionPoseSamplerLocation = -1;
        computeRuntimeChannelSamplerLocation = -1;
        computeControllerStateSamplerLocation = -1;
        computeBoneCountLocation = -1;
        computeRequestCountLocation = -1;
        computeActiveStateStrideLocation = -1;
        computeControllerStateStrideLocation = -1;
        computeTransitionPoseStrideLocation = -1;
        computeRuntimeChannelStrideLocation = -1;
        for (BatchGroupState groupState : BATCH_GROUP_STATES.values()) {
            groupState.close();
        }
        BATCH_GROUP_STATES.clear();
        tfClipSamplerLocation = -1;
        tfChannelSamplerLocation = -1;
        tfKeyframeSamplerLocation = -1;
        tfBoneDefinitionSamplerLocation = -1;
        tfActiveStateSamplerLocation = -1;
        tfTransitionPoseSamplerLocation = -1;
        tfRuntimeChannelSamplerLocation = -1;
        tfControllerStateSamplerLocation = -1;
        tfBoneCountLocation = -1;
        tfControllerStateCountLocation = -1;
    }

    public static final class LocalPoseHandle {
        private final int bufferId;
        private final int textureId;
        private final int poseBase;
        private final boolean arenaBacked;

        private LocalPoseHandle(int bufferId, int textureId) {
            this.bufferId = bufferId;
            this.textureId = textureId;
            this.poseBase = 0;
            this.arenaBacked = false;
        }

        private LocalPoseHandle(int poseBase) {
            this.bufferId = -1;
            this.textureId = -1;
            this.poseBase = poseBase;
            this.arenaBacked = true;
        }

        public int bufferId() {
            return this.arenaBacked ? ChaosGpuPoseArena.getBufferId() : this.bufferId;
        }

        public int textureId() {
            return this.arenaBacked ? ChaosGpuPoseArena.getTextureId() : this.textureId;
        }

        public int poseBase() {
            return this.poseBase;
        }
    }

    public static <T extends GeoAnimatable> @Nullable LocalPoseHandle preparePoseToken(
            ChaosGpuGeoMesh mesh,
            @Nullable GeoAnimationData animationData,
            ChaosGpuAnimationPayload payload,
            Iterable<? extends AnimationPlaybackController<T>> controllers,
            double animationTick,
            @Nullable AnimationState<T> animationState,
            Function<String, Optional<GeoBone>> boneResolver,
            @Nullable GpuProceduralPoseLayer proceduralLayer
    ) {
        return preparePoseToken(mesh, animationData, payload, controllers, animationTick, animationState, boneResolver, proceduralLayer, null);
    }

    public static <T extends GeoAnimatable> @Nullable LocalPoseHandle preparePoseToken(
            ChaosGpuGeoMesh mesh,
            @Nullable GeoAnimationData animationData,
            ChaosGpuAnimationPayload payload,
            Iterable<? extends AnimationPlaybackController<T>> controllers,
            double animationTick,
            @Nullable AnimationState<T> animationState,
            Function<String, Optional<GeoBone>> boneResolver,
            @Nullable GpuProceduralPoseLayer proceduralLayer,
            @Nullable Object poseCacheKey
    ) {
        BackendMode backendMode = backendMode();
        if (backendMode == BackendMode.NONE) {
            return null;
        }

        if (payload.isEmpty() && proceduralLayer == null) {
            return null;
        }

        Object owner = animationState != null ? animationState.getAnimatable() : null;
        boolean retained = owner != null && ChaosGpuPoseSlotStore.isSupported();
        MeshState meshState = getOrCreateMeshState(mesh);
        Object fastAnimationKey = poseCacheKey == null ? null : new AnimationPoseKey(backendMode, payload, poseCacheKey);

        ChaosGpuPoseSlotStore.Slot slot = null;
        if (retained) {
            slot = ChaosGpuPoseSlotStore.acquire(mesh, owner, mesh.getIndexedBones().size());
            if (slot != null && fastAnimationKey != null && slot.holds(fastAnimationKey)) {
                return (LocalPoseHandle) slot.poseHandle();
            }
        }

        if (!retained && fastAnimationKey != null) {
            CachedPose existingPose = meshState.cachedPose(fastAnimationKey);
            if (existingPose != null) {
                return existingPose.handle();
            }
        }

        ActiveStateCollection activeStateCollection = collectActiveStates(animationData, payload, controllers, animationTick, animationState, boneResolver, mesh, proceduralLayer);
        if (activeStateCollection.clipStates().isEmpty() && !activeStateCollection.hasTransitionPoseData()) {
            return null;
        }

        Object animationKey = fastAnimationKey != null ? fastAnimationKey : new AnimationPoseKey(backendMode, payload, activeStateKey(activeStateCollection));

        if (retained && slot != null) {
            if (slot.holds(animationKey)) {
                return (LocalPoseHandle) slot.poseHandle();
            }

            LocalPoseHandle sharedHandle = FRAME_POSE_DEDUP.get(new FramePoseKey(mesh, animationKey));
            if (sharedHandle != null) {
                return sharedHandle;
            }

            if (!ensureComputeProgram()) {
                return null;
            }

            ChaosGpuAnimationBatchScheduler.submit(mesh, payload, slot.poseBase(), activeStateCollection);

            LocalPoseHandle handle = new LocalPoseHandle(slot.poseBase());
            slot.update(animationKey, handle);
            FRAME_POSE_DEDUP.put(new FramePoseKey(mesh, animationKey), handle);
            ChaosGpuBoneResolveDispatcher.invalidateLocalPose(handle, ChaosGpuPoseArena.getTextureId());
            return handle;
        }

        CachedPose existingPose = meshState.cachedPose(animationKey);
        if (existingPose != null) {
            return existingPose.handle();
        }

        if (!ensureProgram(backendMode)) {
            return null;
        }

        PayloadState payloadState = getOrCreatePayloadState(payload);
        CachedPose cachedPose = meshState.acquirePose(animationKey, mesh.getIndexedBones().size());
        boolean dispatched = switch (backendMode) {
            case COMPUTE ->
                    dispatchCompute(payloadState, meshState, cachedPose, activeStateCollection, mesh.getIndexedBones().size());
            case TRANSFORM_FEEDBACK ->
                    dispatchTransformFeedback(payloadState, meshState, cachedPose, activeStateCollection, mesh.getIndexedBones().size());
            case NONE -> false;
        };
        if (!dispatched) {
            return null;
        }

        return cachedPose.handle();
    }

    public static void beginFrame() {
        FRAME_POSE_DEDUP.clear();
    }

    public static void ensureBatchFlushed() {
        if (!ChaosGpuAnimationBatchScheduler.hasPendingWork()) {
            return;
        }

        if (!ensureComputeProgram()) {
            ChaosGpuAnimationBatchScheduler.discardPending();
            return;
        }

        ChaosGpuAnimationBatchScheduler.flush(ChaosGpuAnimationPoseStorage::dispatchGroup);
    }

    private static void dispatchGroup(
            ChaosGpuGeoMesh mesh,
            ChaosGpuAnimationPayload payload,
            List<ChaosGpuAnimationBatchScheduler.PendingRequest> requests) {
        int arenaBufferId = ChaosGpuPoseArena.getBufferId();
        int boneCount = mesh.getIndexedBones().size();
        if (arenaBufferId < 0 || boneCount <= 0) {
            return;
        }

        MeshState meshState = getOrCreateMeshState(mesh);
        PayloadState payloadState = getOrCreatePayloadState(payload);
        BatchGroupState groupState = getOrCreateBatchGroupState(mesh, payload);
        BatchStrides strides = uploadBatchState(groupState, requests, boneCount);

        int previousProgram = GL11.glGetInteger(GL20.GL_CURRENT_PROGRAM);
        GL20.glUseProgram(computeProgram);
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.dispatchGroup.glUseProgram");
        try {
            if (!bindComputeState(payloadState, meshState, groupState, strides, boneCount, requests.size())) {
                return;
            }

            GL30.glBindBufferBase(GL43.GL_SHADER_STORAGE_BUFFER, 0, arenaBufferId);
            GL30.glBindBufferBase(GL43.GL_SHADER_STORAGE_BUFFER, 1, groupState.requestBufferId());
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.dispatchGroup.glBindBufferBase");
            GL43.glDispatchCompute(
                    Math.max(1, (boneCount + WORKGROUP_SIZE - 1) / WORKGROUP_SIZE),
                    requests.size(),
                    1
            );
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.dispatchGroup.glDispatchCompute");
            GL42.glMemoryBarrier(GL43.GL_SHADER_STORAGE_BARRIER_BIT
                    | GL43.GL_TEXTURE_FETCH_BARRIER_BIT
                    | GL42.GL_TEXTURE_UPDATE_BARRIER_BIT
                    | GL42.GL_BUFFER_UPDATE_BARRIER_BIT);
            ChaosGlDebug.failIfErrored("ChaosGpuAnimationPoseStorage.dispatchGroup.dispatch");
        } finally {
            GL30.glBindBufferBase(GL43.GL_SHADER_STORAGE_BUFFER, 0, 0);
            GL30.glBindBufferBase(GL43.GL_SHADER_STORAGE_BUFFER, 1, 0);
            unbindInternalSamplers();
            GL20.glUseProgram(previousProgram);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.dispatchGroup.restoreProgram");
        }
    }

    private static BatchStrides uploadBatchState(
            BatchGroupState groupState,
            List<ChaosGpuAnimationBatchScheduler.PendingRequest> requests,
            int boneCount) {
        int maxActiveStates = 1;
        int maxControllerStates = 1;
        int maxRuntimeTexels = 1;
        for (ChaosGpuAnimationBatchScheduler.PendingRequest request : requests) {
            ActiveStateCollection collection = (ActiveStateCollection) request.activeStateCollection();
            maxActiveStates = Math.max(maxActiveStates, collection.clipStates().size());
            maxControllerStates = Math.max(maxControllerStates, collection.controllerStates().size());
            maxRuntimeTexels = Math.max(maxRuntimeTexels, collection.runtimeChannelData().length / 4);
        }

        int transitionStride = maxControllerStates * boneCount * 3;
        int requestCount = requests.size();
        float[] activeStateData = new float[requestCount * maxActiveStates * 4];
        float[] controllerStateData = new float[requestCount * maxControllerStates * 4];
        float[] transitionPoseData = new float[requestCount * transitionStride * 4];
        float[] runtimeChannelData = new float[requestCount * maxRuntimeTexels * 4];
        int[] requestData = new int[requestCount * 4];

        for (int requestIndex = 0; requestIndex < requestCount; requestIndex++) {
            ChaosGpuAnimationBatchScheduler.PendingRequest request = requests.get(requestIndex);
            ActiveStateCollection collection = (ActiveStateCollection) request.activeStateCollection();

            List<ActiveClipState> clipStates = collection.clipStates();
            int activeStateOffset = requestIndex * maxActiveStates * 4;
            for (int i = 0; i < clipStates.size(); i++) {
                ActiveClipState state = clipStates.get(i);
                int offset = activeStateOffset + i * 4;
                activeStateData[offset] = state.clipIndex();
                activeStateData[offset + 1] = state.localTimeSeconds();
                activeStateData[offset + 2] = state.weight();
                activeStateData[offset + 3] = state.runtimeSampleStart();
            }

            List<ControllerState> controllerStates = collection.controllerStates();
            int controllerStateOffset = requestIndex * maxControllerStates * 4;
            for (int i = 0; i < controllerStates.size(); i++) {
                ControllerState state = controllerStates.get(i);
                int offset = controllerStateOffset + i * 4;
                controllerStateData[offset] = state.stateStart();
                controllerStateData[offset + 1] = state.stateCount();
                controllerStateData[offset + 2] = state.overrideBlend() ? 1.0f : 0.0f;
                controllerStateData[offset + 3] = 0.0f;
            }

            float[] transitionChunk = collection.transitionPoseData();
            System.arraycopy(
                    transitionChunk,
                    0,
                    transitionPoseData,
                    requestIndex * transitionStride * 4,
                    Math.min(transitionChunk.length, transitionStride * 4)
            );

            float[] runtimeChunk = collection.runtimeChannelData();
            System.arraycopy(
                    runtimeChunk,
                    0,
                    runtimeChannelData,
                    requestIndex * maxRuntimeTexels * 4,
                    Math.min(runtimeChunk.length, maxRuntimeTexels * 4)
            );

            requestData[requestIndex * 4] = request.poseBase();
            requestData[requestIndex * 4 + 1] = controllerStates.size();
        }

        groupState.uploadStates(activeStateData, controllerStateData, transitionPoseData, runtimeChannelData, requestData);
        return new BatchStrides(maxActiveStates, maxControllerStates, transitionStride, maxRuntimeTexels);
    }

    private static BatchGroupState getOrCreateBatchGroupState(ChaosGpuGeoMesh mesh, ChaosGpuAnimationPayload payload) {
        return getOrCreateBatchGroupState(new BatchGroupKey(mesh, payload));
    }

    private static BatchGroupState getOrCreateBatchGroupState(Object groupKey) {
        return BATCH_GROUP_STATES.computeIfAbsent(groupKey, ignored -> new BatchGroupState());
    }

    private record BatchStrides(
            int activeStateStride,
            int controllerStateStride,
            int transitionPoseStride,
            int runtimeChannelStride
    ) {
    }

    private record BatchGroupKey(ChaosGpuGeoMesh mesh, ChaosGpuAnimationPayload payload) {
    }

    private record FramePoseKey(ChaosGpuGeoMesh mesh, Object animationKey) {
    }

    private static BackendMode backendMode() {
        return switch (ChaosGpuRuntimePolicy.getAnimationBackendMode()) {
            case COMPUTE -> BackendMode.COMPUTE;
            case TRANSFORM_FEEDBACK -> BackendMode.TRANSFORM_FEEDBACK;
            case NONE -> BackendMode.NONE;
        };
    }

    private static boolean ensureProgram(BackendMode backendMode) {
        return switch (backendMode) {
            case COMPUTE -> ensureComputeProgram();
            case TRANSFORM_FEEDBACK -> ensureTransformFeedbackProgram();
            case NONE -> false;
        };
    }

    private static boolean dispatchCompute(PayloadState payloadState, MeshState meshState, CachedPose cachedPose, ActiveStateCollection activeStateCollection, int boneCount) {
        return dispatchCompute(payloadState, meshState, cachedPose.bufferId(), 0, activeStateCollection, boneCount);
    }

    private static boolean dispatchCompute(PayloadState payloadState, MeshState meshState, int outputBufferId, int poseBase, ActiveStateCollection activeStateCollection, int boneCount) {
        BatchGroupState groupState = getOrCreateBatchGroupState(SINGLE_DISPATCH_GROUP_KEY);
        BatchStrides strides = uploadBatchState(
                groupState,
                List.of(new ChaosGpuAnimationBatchScheduler.PendingRequest(poseBase, activeStateCollection)),
                boneCount
        );

        int previousProgram = GL11.glGetInteger(GL20.GL_CURRENT_PROGRAM);
        GL20.glUseProgram(computeProgram);
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.dispatchCompute.glUseProgram");
        try {
            if (!bindComputeState(payloadState, meshState, groupState, strides, boneCount, 1)) {
                return false;
            }

            GL30.glBindBufferBase(GL43.GL_SHADER_STORAGE_BUFFER, 0, outputBufferId);
            GL30.glBindBufferBase(GL43.GL_SHADER_STORAGE_BUFFER, 1, groupState.requestBufferId());
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.dispatchCompute.glBindBufferBase");
            GL43.glDispatchCompute(Math.max(1, (boneCount + WORKGROUP_SIZE - 1) / WORKGROUP_SIZE), 1, 1);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.dispatchCompute.glDispatchCompute");
            GL42.glMemoryBarrier(GL43.GL_SHADER_STORAGE_BARRIER_BIT
                    | GL43.GL_TEXTURE_FETCH_BARRIER_BIT
                    | GL42.GL_TEXTURE_UPDATE_BARRIER_BIT
                    | GL42.GL_BUFFER_UPDATE_BARRIER_BIT);
            return !ChaosGlDebug.failIfErrored("ChaosGpuAnimationPoseStorage.dispatchCompute.dispatch");
        } finally {
            GL30.glBindBufferBase(GL43.GL_SHADER_STORAGE_BUFFER, 0, 0);
            GL30.glBindBufferBase(GL43.GL_SHADER_STORAGE_BUFFER, 1, 0);
            unbindInternalSamplers();
            GL20.glUseProgram(previousProgram);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.dispatchCompute.cleanup");
        }
    }

    private static boolean bindComputeState(
            PayloadState payloadState,
            MeshState meshState,
            BatchGroupState groupState,
            BatchStrides strides,
            int boneCount,
            int requestCount) {
        ActiveStateTextureSet stateTextures = groupState.stateTextures();
        bindTextureToUnit(CLIP_TEXTURE_UNIT, payloadState.clipTextureId);
        bindTextureToUnit(CHANNEL_TEXTURE_UNIT, payloadState.channelTextureId);
        bindTextureToUnit(KEYFRAME_TEXTURE_UNIT, payloadState.keyframeTextureId);
        bindTextureToUnit(BONE_DEFINITION_TEXTURE_UNIT, meshState.definitionTextureId);
        bindTextureToUnit(ACTIVE_STATE_TEXTURE_UNIT, stateTextures.activeStateTextureId);
        bindTextureToUnit(TRANSITION_POSE_TEXTURE_UNIT, stateTextures.transitionPoseTextureId);
        bindTextureToUnit(RUNTIME_CHANNEL_TEXTURE_UNIT, stateTextures.runtimeChannelTextureId);
        bindTextureToUnit(CONTROLLER_STATE_TEXTURE_UNIT, stateTextures.controllerStateTextureId);

        GL20.glUniform1i(computeClipSamplerLocation, CLIP_TEXTURE_UNIT);
        GL20.glUniform1i(computeChannelSamplerLocation, CHANNEL_TEXTURE_UNIT);
        GL20.glUniform1i(computeKeyframeSamplerLocation, KEYFRAME_TEXTURE_UNIT);
        GL20.glUniform1i(computeBoneDefinitionSamplerLocation, BONE_DEFINITION_TEXTURE_UNIT);
        GL20.glUniform1i(computeActiveStateSamplerLocation, ACTIVE_STATE_TEXTURE_UNIT);
        GL20.glUniform1i(computeTransitionPoseSamplerLocation, TRANSITION_POSE_TEXTURE_UNIT);
        GL20.glUniform1i(computeRuntimeChannelSamplerLocation, RUNTIME_CHANNEL_TEXTURE_UNIT);
        GL20.glUniform1i(computeControllerStateSamplerLocation, CONTROLLER_STATE_TEXTURE_UNIT);
        GL20.glUniform1i(computeBoneCountLocation, boneCount);
        GL20.glUniform1i(computeRequestCountLocation, requestCount);
        GL20.glUniform1i(computeActiveStateStrideLocation, strides.activeStateStride());
        GL20.glUniform1i(computeControllerStateStrideLocation, strides.controllerStateStride());
        GL20.glUniform1i(computeTransitionPoseStrideLocation, strides.transitionPoseStride());
        GL20.glUniform1i(computeRuntimeChannelStrideLocation, strides.runtimeChannelStride());
        return !ChaosGlDebug.failIfErrored("ChaosGpuAnimationPoseStorage.bindComputeState");
    }

    private static boolean dispatchTransformFeedback(PayloadState payloadState, MeshState meshState, CachedPose cachedPose, ActiveStateCollection activeStateCollection, int boneCount) {
        ActiveStateTextureSet scratch = getOrCreateScratchActiveStateTextures();
        uploadActiveStateResources(activeStateCollection, scratch);

        GL20.glUseProgram(transformFeedbackProgram);
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.dispatchTransformFeedback.glUseProgram");
        try {
            bindTextureToUnit(CLIP_TEXTURE_UNIT, payloadState.clipTextureId);
            bindTextureToUnit(CHANNEL_TEXTURE_UNIT, payloadState.channelTextureId);
            bindTextureToUnit(KEYFRAME_TEXTURE_UNIT, payloadState.keyframeTextureId);
            bindTextureToUnit(BONE_DEFINITION_TEXTURE_UNIT, meshState.definitionTextureId);
            bindTextureToUnit(ACTIVE_STATE_TEXTURE_UNIT, scratch.activeStateTextureId);
            bindTextureToUnit(TRANSITION_POSE_TEXTURE_UNIT, scratch.transitionPoseTextureId);
            bindTextureToUnit(RUNTIME_CHANNEL_TEXTURE_UNIT, scratch.runtimeChannelTextureId);
            bindTextureToUnit(CONTROLLER_STATE_TEXTURE_UNIT, scratch.controllerStateTextureId);
            GL20.glUniform1i(tfClipSamplerLocation, CLIP_TEXTURE_UNIT);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.dispatchTransformFeedback.glUniform1i.ClipSampler");
            GL20.glUniform1i(tfChannelSamplerLocation, CHANNEL_TEXTURE_UNIT);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.dispatchTransformFeedback.glUniform1i.ChannelSampler");
            GL20.glUniform1i(tfKeyframeSamplerLocation, KEYFRAME_TEXTURE_UNIT);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.dispatchTransformFeedback.glUniform1i.KeyframeSampler");
            GL20.glUniform1i(tfBoneDefinitionSamplerLocation, BONE_DEFINITION_TEXTURE_UNIT);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.dispatchTransformFeedback.glUniform1i.BoneDefinitionSampler");
            GL20.glUniform1i(tfActiveStateSamplerLocation, ACTIVE_STATE_TEXTURE_UNIT);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.dispatchTransformFeedback.glUniform1i.ActiveStateSampler");
            GL20.glUniform1i(tfTransitionPoseSamplerLocation, TRANSITION_POSE_TEXTURE_UNIT);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.dispatchTransformFeedback.glUniform1i.TransitionPoseSampler");
            GL20.glUniform1i(tfRuntimeChannelSamplerLocation, RUNTIME_CHANNEL_TEXTURE_UNIT);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.dispatchTransformFeedback.glUniform1i.RuntimeChannelSampler");
            GL20.glUniform1i(tfControllerStateSamplerLocation, CONTROLLER_STATE_TEXTURE_UNIT);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.dispatchTransformFeedback.glUniform1i.ControllerStateSampler");
            GL20.glUniform1i(tfBoneCountLocation, boneCount);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.dispatchTransformFeedback.glUniform1i.BoneCount");
            GL20.glUniform1i(tfControllerStateCountLocation, activeStateCollection.controllerStates().size());
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.dispatchTransformFeedback.glUniform1i.ControllerStateCount");
            if (ChaosGlDebug.failIfErrored("ChaosGpuAnimationPoseStorage.dispatchTransformFeedback.uniforms")) {
                return false;
            }

            GL11.glEnable(GL30.GL_RASTERIZER_DISCARD);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.dispatchTransformFeedback.glEnable.RASTERIZER_DISCARD");
            GL30.glBindVertexArray(meshState.vertexArrayId);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.dispatchTransformFeedback.glBindVertexArray");
            GL30.glBindBufferBase(GL30.GL_TRANSFORM_FEEDBACK_BUFFER, 0, cachedPose.bufferId());
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.dispatchTransformFeedback.glBindBufferBase.transformFeedback");
            GL30.glBeginTransformFeedback(GL11.GL_POINTS);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.dispatchTransformFeedback.glBeginTransformFeedback");
            GL11.glDrawArrays(GL11.GL_POINTS, 0, boneCount);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.dispatchTransformFeedback.glDrawArrays");
            GL30.glEndTransformFeedback();
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.dispatchTransformFeedback.glEndTransformFeedback");
            GL30.glBindBufferBase(GL30.GL_TRANSFORM_FEEDBACK_BUFFER, 0, 0);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.dispatchTransformFeedback.glBindBufferBase.0");
            GL30.glBindVertexArray(0);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.dispatchTransformFeedback.glBindVertexArray.0");
            GL11.glDisable(GL30.GL_RASTERIZER_DISCARD);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.dispatchTransformFeedback.glDisable.RASTERIZER_DISCARD");
            ensureTransformFeedbackWritesVisible();
            return !ChaosGlDebug.failIfErrored("ChaosGpuAnimationPoseStorage.dispatchTransformFeedback.draw");
        } finally {
            unbindInternalSamplers();
            GL20.glUseProgram(0);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.dispatchTransformFeedback.cleanup.glUseProgram.0");
        }
    }

    private static void uploadActiveStateResources(
            ActiveStateCollection activeStateCollection,
            ActiveStateTextureSet scratch
    ) {
        List<ActiveClipState> activeStates = activeStateCollection.clipStates();
        float[] activeStateData = scratch.prepareActiveStateBuffer(activeStates.size() * 4);
        int activeStateHash = 1;
        for (int i = 0; i < activeStates.size(); i++) {
            ActiveClipState state = activeStates.get(i);
            int offset = i * 4;
            activeStateData[offset] = state.clipIndex();
            activeStateData[offset + 1] = state.localTimeSeconds();
            activeStateData[offset + 2] = state.weight();
            activeStateData[offset + 3] = state.runtimeSampleStart();
            activeStateHash = 31 * activeStateHash + Float.floatToIntBits(activeStateData[offset]);
            activeStateHash = 31 * activeStateHash + Float.floatToIntBits(activeStateData[offset + 1]);
            activeStateHash = 31 * activeStateHash + Float.floatToIntBits(activeStateData[offset + 2]);
            activeStateHash = 31 * activeStateHash + Float.floatToIntBits(activeStateData[offset + 3]);
        }
        scratch.uploadActiveState(activeStateData, activeStates.size() * 4, activeStateHash);
        scratch.uploadTransitionPose(activeStateCollection.transitionPoseData(), activeStateCollection.transitionPoseHash());
        scratch.uploadRuntimeChannels(activeStateCollection.runtimeChannelData(), activeStateCollection.runtimeChannelHash());

        List<ControllerState> controllerStates = activeStateCollection.controllerStates();
        float[] controllerStateData = scratch.prepareControllerStateBuffer(controllerStates.size() * 4);
        int controllerStateHash = 1;
        for (int i = 0; i < controllerStates.size(); i++) {
            ControllerState state = controllerStates.get(i);
            int offset = i * 4;
            controllerStateData[offset] = state.stateStart();
            controllerStateData[offset + 1] = state.stateCount();
            controllerStateData[offset + 2] = state.overrideBlend() ? 1.0f : 0.0f;
            controllerStateData[offset + 3] = 0.0f;
            controllerStateHash = 31 * controllerStateHash + Float.floatToIntBits(controllerStateData[offset]);
            controllerStateHash = 31 * controllerStateHash + Float.floatToIntBits(controllerStateData[offset + 1]);
            controllerStateHash = 31 * controllerStateHash + Float.floatToIntBits(controllerStateData[offset + 2]);
            controllerStateHash = 31 * controllerStateHash + Float.floatToIntBits(controllerStateData[offset + 3]);
        }
        scratch.uploadControllerStates(controllerStateData, controllerStates.size() * 4, controllerStateHash);
    }

    private static ActiveStateKey activeStateKey(ActiveStateCollection activeStateCollection) {
        List<ControllerState> controllerStates = activeStateCollection.controllerStates();
        List<ActiveClipState> activeStates = activeStateCollection.clipStates();
        int[] controllerKey = new int[controllerStates.size() * 3];
        for (int i = 0; i < controllerStates.size(); i++) {
            ControllerState state = controllerStates.get(i);
            int offset = i * 3;
            controllerKey[offset] = Math.round(state.stateStart());
            controllerKey[offset + 1] = Math.round(state.stateCount());
            controllerKey[offset + 2] = state.overrideBlend() ? 1 : 0;
        }

        int[] clipKey = new int[activeStates.size() * 4];
        for (int i = 0; i < activeStates.size(); i++) {
            ActiveClipState state = activeStates.get(i);
            int offset = i * 4;
            clipKey[offset] = Math.round(state.clipIndex());
            clipKey[offset + 1] = Math.round(state.localTimeSeconds() * 1000.0f);
            clipKey[offset + 2] = Math.round(state.weight() * 1000.0f);
            clipKey[offset + 3] = Math.round(state.runtimeSampleStart());
        }
        return new ActiveStateKey(
                controllerKey,
                clipKey,
                activeStateCollection.transitionPoseHash(),
                activeStateCollection.runtimeChannelHash()
        );
    }

    private static <T extends GeoAnimatable> ActiveStateCollection collectActiveStates(
            @Nullable GeoAnimationData animationData,
            ChaosGpuAnimationPayload payload,
            Iterable<? extends AnimationPlaybackController<T>> controllers,
            double animationTick,
            @Nullable AnimationState<T> animationState,
            Function<String, Optional<GeoBone>> boneResolver,
            ChaosGpuGeoMesh mesh,
            @Nullable GpuProceduralPoseLayer proceduralLayer
    ) {
        ArrayList<AnimationPlaybackController<T>> orderedControllers = new ArrayList<>();
        for (AnimationPlaybackController<T> controller : controllers) {
            orderedControllers.add(controller);
        }
        if (orderedControllers.size() > 1) {
            orderedControllers.sort(Comparator.comparingInt(AnimationPlaybackController::getPriority));
        }

        boolean proceduralPoseActive = proceduralLayer != null && !proceduralLayer.isEmpty();
        int boneCount = mesh.getIndexedBones().size();
        int controllerLayerCount = orderedControllers.size() + (proceduralPoseActive ? 1 : 0);
        ArrayList<ControllerState> controllerStates = new ArrayList<>(controllerLayerCount);
        ArrayList<ActiveClipState> states = new ArrayList<>();
        float[] transitionPoseData = new float[controllerLayerCount * boneCount * 12];
        ArrayList<Float> runtimeChannelData = new ArrayList<>();
        for (int controllerIndex = 0; controllerIndex < orderedControllers.size(); controllerIndex++) {
            AnimationPlaybackController<T> controller = orderedControllers.get(controllerIndex);
            int stateStart = states.size();
            double accumulatedAnimationTick = controller.getAccumulatedAnimationTick();
            boolean hasTransitionPose = controller.getTransitionLengthTicks() > 0 && !controller.getTransitionBonePoses().isEmpty();
            boolean transitioning = controller.getPreviousAnimation() != null;
            double currentTick = transitioning
                    ? controller.getCurrentAnimationFrozenTick()
                    : accumulatedAnimationTick;
            ControllerSample current = animationData == null
                    ? null
                    : sampleRawAnimation(animationData, payload, controller.getCurrentAnimation(), controller.getAnimationStartedTick(), currentTick);
            ControllerSample previous = hasTransitionPose
                    ? null
                    : (animationData == null
                       ? null
                       : sampleRawAnimation(animationData, payload, controller.getPreviousAnimation(), controller.getPreviousAnimationStartedTick(), controller.getPreviousAnimationFrozenTick()));
            float transition = (float) controller.getTransitionProgress(animationTick);

            float currentWeight = transitioning
                    ? transition
                    : (current == null ? 0.0f : 1.0f);
            float previousWeight = transitioning
                    ? 1.0f - transition
                    : 0.0f;

            if (current != null && currentWeight > 1.0e-4f) {
                int runtimeBase = appendRuntimeSamples(runtimeChannelData, animationData, payload, current.clipIndex(), current.localTimeSeconds(), animationTick, animationState, controller, boneResolver);
                states.add(new ActiveClipState(current.clipIndex(), current.localTimeSeconds(), currentWeight, runtimeBase));
            }
            if (previous != null && previousWeight > 1.0e-4f) {
                int runtimeBase = appendRuntimeSamples(runtimeChannelData, animationData, payload, previous.clipIndex(), previous.localTimeSeconds(), animationTick, animationState, controller, boneResolver);
                states.add(new ActiveClipState(previous.clipIndex(), previous.localTimeSeconds(), previousWeight, runtimeBase));
            }
            if (hasTransitionPose) {
                accumulateTransitionPose(mesh, controllerIndex, controller, previousWeight, transitionPoseData);
            }
            if (animationData != null && currentWeight > 1.0e-4f && previousWeight > 1.0e-4f) {
                accumulateTransitionBaseFallback(
                        mesh,
                        controllerIndex,
                        animationData,
                        payload,
                        controller,
                        current,
                        currentWeight,
                        previous,
                        previousWeight,
                        hasTransitionPose,
                        transitionPoseData
                );
            }

            controllerStates.add(new ControllerState(stateStart, states.size() - stateStart, controller.getBlendMode() == AnimationPlaybackController.BlendMode.OVERRIDE));
        }

        if (proceduralPoseActive) {
            int controllerIndex = orderedControllers.size();
            accumulateProceduralPose(mesh, controllerIndex, proceduralLayer, transitionPoseData);
            controllerStates.add(new ControllerState(states.size(), 0, proceduralLayer.blendMode() == AnimationPlaybackController.BlendMode.OVERRIDE));
        }

        float[] runtimeChannelArray = toFloatArray(runtimeChannelData);
        return new ActiveStateCollection(
                controllerStates,
                states,
                transitionPoseData,
                runtimeChannelArray,
                sparsePoseHash(transitionPoseData),
                Arrays.hashCode(runtimeChannelArray)
        );
    }

    /**
     * Content hash of a pose-data array that only visits non-zero slots. The pose payload is dominated by
     * zeros (only posed bones write values), so a full {@link Arrays#hashCode(float[])} spent most of its
     * time hashing zeros. This stays a strict equality surrogate (it is compared directly in
     * {@link ActiveStateKey#equals}): each contributing slot folds in both its index and its value, so two
     * different poses still hash differently while identical poses hash identically. Zero and -0.0f are
     * treated as equal, which is correct because both encode the identity contribution for that slot.
     */
    private static int sparsePoseHash(float[] poseData) {
        int hash = 1;
        for (int i = 0; i < poseData.length; i++) {
            float value = poseData[i];
            if (value != 0.0f) {
                hash = 31 * hash + i;
                hash = 31 * hash + Float.floatToIntBits(value);
            }
        }
        return hash;
    }

    private static void accumulateTransitionPose(ChaosGpuGeoMesh mesh, int controllerIndex, AnimationPlaybackController<?> controller, float weight, float[] transitionPoseData) {
        if (weight <= 1.0e-4f) {
            return;
        }

        Map<String, AnimationPlaybackController.TransitionBonePose> poses = controller.getTransitionBonePoses();
        for (int boneIndex = 0; boneIndex < mesh.getIndexedBones().size(); boneIndex++) {
            GeoBone bone = mesh.getIndexedBones().get(boneIndex);
            AnimationPlaybackController.TransitionBonePose pose = poses.get(bone.getName());
            if (pose == null) {
                continue;
            }

            int base = ((controllerIndex * mesh.getIndexedBones().size()) + boneIndex) * 12;
            if (pose.hasPosition()) {
                transitionPoseData[base] += pose.posX() * weight;
                transitionPoseData[base + 1] += pose.posY() * weight;
                transitionPoseData[base + 2] += pose.posZ() * weight;
                transitionPoseData[base + 3] += weight;
            }

            if (pose.hasRotation()) {
                transitionPoseData[base + 4] += pose.rotX() * weight;
                transitionPoseData[base + 5] += pose.rotY() * weight;
                transitionPoseData[base + 6] += pose.rotZ() * weight;
                transitionPoseData[base + 7] += weight;
            }

            if (pose.hasScale()) {
                transitionPoseData[base + 8] += (pose.scaleX() - 1.0f) * weight;
                transitionPoseData[base + 9] += (pose.scaleY() - 1.0f) * weight;
                transitionPoseData[base + 10] += (pose.scaleZ() - 1.0f) * weight;
                transitionPoseData[base + 11] += weight;
            }
        }
    }

    private static void accumulateTransitionBaseFallback(
            ChaosGpuGeoMesh mesh,
            int controllerIndex,
            GeoAnimationData animationData,
            ChaosGpuAnimationPayload payload,
            AnimationPlaybackController<?> controller,
            @Nullable ControllerSample current,
            float currentWeight,
            @Nullable ControllerSample previous,
            float previousWeight,
            boolean hasTransitionPose,
            float[] transitionPoseData
    ) {
        Map<String, AnimationPlaybackController.TransitionBonePose> transitionPoses = hasTransitionPose
                ? controller.getTransitionBonePoses()
                : Map.of();
        for (int boneIndex = 0; boneIndex < mesh.getIndexedBones().size(); boneIndex++) {
            GeoBone bone = mesh.getIndexedBones().get(boneIndex);
            String boneName = bone.getName();

            boolean currentHasPosition = clipHasChannel(animationData, payload, current, boneName, ChannelTarget.POSITION);
            boolean currentHasRotation = clipHasChannel(animationData, payload, current, boneName, ChannelTarget.ROTATION);
            boolean currentHasScale = clipHasChannel(animationData, payload, current, boneName, ChannelTarget.SCALE);

            AnimationPlaybackController.TransitionBonePose transitionPose = transitionPoses.get(boneName);
            boolean previousHasPosition = hasTransitionPose
                    ? transitionPose != null && transitionPose.hasPosition()
                    : clipHasChannel(animationData, payload, previous, boneName, ChannelTarget.POSITION);
            boolean previousHasRotation = hasTransitionPose
                    ? transitionPose != null && transitionPose.hasRotation()
                    : clipHasChannel(animationData, payload, previous, boneName, ChannelTarget.ROTATION);
            boolean previousHasScale = hasTransitionPose
                    ? transitionPose != null && transitionPose.hasScale()
                    : clipHasChannel(animationData, payload, previous, boneName, ChannelTarget.SCALE);

            int base = ((controllerIndex * mesh.getIndexedBones().size()) + boneIndex) * 12;
            if (previousHasPosition && !currentHasPosition) {
                transitionPoseData[base + 3] += currentWeight;
            }
            if (currentHasPosition && !previousHasPosition) {
                transitionPoseData[base + 3] += previousWeight;
            }

            if (previousHasRotation && !currentHasRotation) {
                transitionPoseData[base + 4] += bone.getInitialRotX() * currentWeight;
                transitionPoseData[base + 5] += bone.getInitialRotY() * currentWeight;
                transitionPoseData[base + 6] += bone.getInitialRotZ() * currentWeight;
                transitionPoseData[base + 7] += currentWeight;
            }
            if (currentHasRotation && !previousHasRotation) {
                transitionPoseData[base + 4] += bone.getInitialRotX() * previousWeight;
                transitionPoseData[base + 5] += bone.getInitialRotY() * previousWeight;
                transitionPoseData[base + 6] += bone.getInitialRotZ() * previousWeight;
                transitionPoseData[base + 7] += previousWeight;
            }

            if (previousHasScale && !currentHasScale) {
                transitionPoseData[base + 11] += currentWeight;
            }
            if (currentHasScale && !previousHasScale) {
                transitionPoseData[base + 11] += previousWeight;
            }
        }
    }

    private static boolean clipHasChannel(
            GeoAnimationData animationData,
            ChaosGpuAnimationPayload payload,
            @Nullable ControllerSample sample,
            String boneName,
            ChannelTarget target
    ) {
        if (sample == null) {
            return false;
        }

        GeoAnimationData.AnimationClip clip = animationData.get(payload.runtimeClip(sample.clipIndex()).clipName());
        if (clip == null) {
            return false;
        }

        GeoAnimationData.BoneAnimation boneAnimation = clip.bones().get(boneName);
        if (boneAnimation == null) {
            return false;
        }

        GeoAnimationData.Channel channel = switch (target) {
            case POSITION -> boneAnimation.position();
            case ROTATION -> boneAnimation.rotation();
            case SCALE -> boneAnimation.scale();
        };
        return channel != null && !channel.isEmpty();
    }

    private static void accumulateProceduralPose(ChaosGpuGeoMesh mesh, int controllerIndex, GpuProceduralPoseLayer layer, float[] transitionPoseData) {
        float weight = layer.weight();
        if (weight <= 1.0e-4f) {
            return;
        }

        int boneCount = mesh.getIndexedBones().size();
        for (Map.Entry<String, GpuProceduralPoseLayer.BonePose> entry : layer.bones().entrySet()) {
            GpuProceduralPoseLayer.BonePose pose = entry.getValue();
            if (!pose.hasPosition() && !pose.hasRotation() && !pose.hasScale()) {
                continue;
            }
            int boneIndex = mesh.getBoneIndexByName(entry.getKey());
            if (boneIndex < 0) {
                continue;
            }

            int base = ((controllerIndex * boneCount) + boneIndex) * 12;
            if (pose.hasPosition()) {
                transitionPoseData[base] += pose.posX() * weight;
                transitionPoseData[base + 1] += pose.posY() * weight;
                transitionPoseData[base + 2] += pose.posZ() * weight;
                transitionPoseData[base + 3] += weight;
            }
            if (pose.hasRotation()) {
                transitionPoseData[base + 4] += pose.rotX() * weight;
                transitionPoseData[base + 5] += pose.rotY() * weight;
                transitionPoseData[base + 6] += pose.rotZ() * weight;
                transitionPoseData[base + 7] += weight;
            }
            if (pose.hasScale()) {
                transitionPoseData[base + 8] += (pose.scaleX() - 1.0f) * weight;
                transitionPoseData[base + 9] += (pose.scaleY() - 1.0f) * weight;
                transitionPoseData[base + 10] += (pose.scaleZ() - 1.0f) * weight;
                transitionPoseData[base + 11] += weight;
            }
        }
    }

    private static <T extends GeoAnimatable> int appendRuntimeSamples(
            List<Float> runtimeChannelData,
            GeoAnimationData animationData,
            ChaosGpuAnimationPayload payload,
            int clipIndex,
            float localTimeSeconds,
            double animationTick,
            @Nullable AnimationState<T> animationState,
            AnimationPlaybackController<T> controller,
            Function<String, Optional<GeoBone>> boneResolver
    ) {
        ChaosGpuAnimationPayload.ClipRuntime clipRuntime = payload.runtimeClip(clipIndex);
        if (clipRuntime.dynamicChannelCount() <= 0) {
            return -1;
        }

        int base = runtimeChannelData.size() / 4;
        for (ChaosGpuAnimationPayload.DynamicChannel dynamicChannel : clipRuntime.dynamicChannels()) {
            Vector3f sampled = GeoAnimationRuntime.sampleChannelValue(
                    animationData,
                    dynamicChannel.channel(),
                    dynamicChannel.boneName(),
                    localTimeSeconds,
                    animationTick,
                    animationState,
                    controller,
                    boneResolver
            );
            if (sampled == null) {
                runtimeChannelData.add(0.0f);
                runtimeChannelData.add(0.0f);
                runtimeChannelData.add(0.0f);
                runtimeChannelData.add(0.0f);
            } else {
                runtimeChannelData.add(sampled.x);
                runtimeChannelData.add(sampled.y);
                runtimeChannelData.add(sampled.z);
                runtimeChannelData.add(1.0f);
            }
        }
        return base;
    }

    private static @Nullable ControllerSample sampleRawAnimation(
            GeoAnimationData animationData,
            ChaosGpuAnimationPayload payload,
            @Nullable RawAnimation rawAnimation,
            double startedTick,
            double animationTick
    ) {
        if (rawAnimation == null || rawAnimation.isEmpty()) {
            return null;
        }

        double elapsedSeconds = Math.max(0.0d, (animationTick - startedTick) / 20.0d);
        for (RawAnimation.Stage stage : rawAnimation.getStages()) {
            GeoAnimationData.AnimationClip clip = animationData.get(stage.animationName());
            int clipIndex = payload.clipIndex(stage.animationName());
            if (clip == null || clipIndex < 0) {
                continue;
            }

            double length = Math.max(clip.lengthSeconds(), 0.0f);
            if (stage.playbackMode() == RawAnimation.PlaybackMode.LOOP || clip.loop()) {
                double localTime = length <= 0.0d ? elapsedSeconds : elapsedSeconds % length;
                return new ControllerSample(clipIndex, (float) localTime);
            }
            if (elapsedSeconds <= length) {
                return new ControllerSample(clipIndex, (float) elapsedSeconds);
            }

            elapsedSeconds -= length;
            if (stage.playbackMode() == RawAnimation.PlaybackMode.PLAY_AND_HOLD) {
                return new ControllerSample(clipIndex, (float) length);
            }
        }

        RawAnimation.Stage lastStage = rawAnimation.getStages().get(rawAnimation.getStages().size() - 1);
        GeoAnimationData.AnimationClip lastClip = animationData.get(lastStage.animationName());
        int clipIndex = payload.clipIndex(lastStage.animationName());
        return lastClip == null || clipIndex < 0 ? null : new ControllerSample(clipIndex, lastClip.lengthSeconds());
    }

    private static PayloadState createPayloadState(ChaosGpuAnimationPayload payload) {
        TextureBufferHandle clip = createTextureBuffer(payload.clipData(), GL15.GL_STATIC_DRAW);
        TextureBufferHandle channel = createTextureBuffer(payload.channelData(), GL15.GL_STATIC_DRAW);
        TextureBufferHandle keyframe = createTextureBuffer(payload.keyframeData(), GL15.GL_STATIC_DRAW);
        return new PayloadState(clip, channel, keyframe);
    }

    private static MeshState createMeshState(ChaosGpuGeoMesh mesh) {
        float[] combined = new float[mesh.getIndexedBones().size() * 16];
        for (int i = 0; i < mesh.getIndexedBones().size(); i++) {
            GeoBone bone = mesh.getIndexedBones().get(i);
            int offset = i * 16;
            combined[offset] = bone.getPosX();
            combined[offset + 1] = bone.getPosY();
            combined[offset + 2] = bone.getPosZ();
            combined[offset + 3] = mesh.getParentIndex(i);
            combined[offset + 4] = bone.getPivotX();
            combined[offset + 5] = bone.getPivotY();
            combined[offset + 6] = bone.getPivotZ();
            combined[offset + 7] = 0.0f;
            combined[offset + 8] = bone.getInitialRotX();
            combined[offset + 9] = bone.getInitialRotY();
            combined[offset + 10] = bone.getInitialRotZ();
            combined[offset + 11] = 0.0f;
            combined[offset + 12] = 1.0f;
            combined[offset + 13] = 1.0f;
            combined[offset + 14] = 1.0f;
            combined[offset + 15] = 0.0f;
        }
        return new MeshState(createTextureBuffer(combined, GL15.GL_STATIC_DRAW), mesh.getIndexedBones().size());
    }

    private static PayloadState getOrCreatePayloadState(ChaosGpuAnimationPayload payload) {
        PayloadState state = PAYLOAD_CACHE.get(payload);
        if (state != null) {
            return state;
        }

        state = createPayloadState(payload);
        PAYLOAD_CACHE.put(payload, state);
        return state;
    }

    private static MeshState getOrCreateMeshState(ChaosGpuGeoMesh mesh) {
        MeshState state = MESH_CACHE.get(mesh);
        if (state != null) {
            return state;
        }

        state = createMeshState(mesh);
        MESH_CACHE.put(mesh, state);
        return state;
    }

    private static ActiveStateTextureSet getOrCreateScratchActiveStateTextures() {
        if (scratchActiveStateTextures == null) {
            scratchActiveStateTextures = new ActiveStateTextureSet();
        }

        return scratchActiveStateTextures;
    }

    private static TextureBufferHandle createTextureBuffer(float[] data, int usage) {
        int bufferId = GL15.glGenBuffers();
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.createTextureBuffer.glGenBuffers");
        int textureId = GL11.glGenTextures();
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.createTextureBuffer.glGenTextures");
        uploadTextureBuffer(bufferId, textureId, data, usage);
        return new TextureBufferHandle(bufferId, textureId);
    }

    private static void uploadTextureBuffer(int bufferId, int textureId, float[] data, int usage) {
        uploadTextureBuffer(bufferId, textureId, data, data.length, usage);
    }

    private static void uploadTextureBuffer(int bufferId, int textureId, float[] data, int length, int usage) {
        float[] uploadData;
        if (length <= 0) {
            uploadData = EMPTY_TEXTURE_BUFFER_UPLOAD;
        } else if (length == data.length) {
            uploadData = data;
        } else {
            uploadData = Arrays.copyOf(data, length);
        }
        FloatBuffer upload = FLOAT_UPLOAD_BUFFER.get().prepare(uploadData);
        GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, bufferId);
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.uploadTextureBuffer.glBindBuffer");
        GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, upload, usage);
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.uploadTextureBuffer.glBufferData");
        attachTextureBuffer(textureId, GL30.GL_RGBA32F, bufferId);
        GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, 0);
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.uploadTextureBuffer.glBindBuffer.0");
    }

    private static boolean ensureComputeProgram() {
        if (computeProgram != -1) {
            return true;
        }

        int shader = GL20.glCreateShader(GL43.GL_COMPUTE_SHADER);
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureComputeProgram.glCreateShader");
        GL20.glShaderSource(shader, COMPUTE_SHADER);
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureComputeProgram.glShaderSource");
        GL20.glCompileShader(shader);
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureComputeProgram.glCompileShader");
        if (GL20.glGetShaderi(shader, GL20.GL_COMPILE_STATUS) == GL11.GL_FALSE) {
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureComputeProgram.glGetShaderi.COMPILE_STATUS");
            String log = GL20.glGetShaderInfoLog(shader);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureComputeProgram.glGetShaderInfoLog");
            GL20.glDeleteShader(shader);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureComputeProgram.glDeleteShader.failed");
            throw new IllegalStateException("Failed to compile Chaos GPU animation compute shader: " + log);
        }
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureComputeProgram.glGetShaderi.COMPILE_STATUS");

        int glProgram = GL20.glCreateProgram();
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureComputeProgram.glCreateProgram");
        GL20.glAttachShader(glProgram, shader);
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureComputeProgram.glAttachShader");
        GL20.glLinkProgram(glProgram);
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureComputeProgram.glLinkProgram");
        GL20.glDetachShader(glProgram, shader);
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureComputeProgram.glDetachShader");
        GL20.glDeleteShader(shader);
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureComputeProgram.glDeleteShader");
        if (GL20.glGetProgrami(glProgram, GL20.GL_LINK_STATUS) == GL11.GL_FALSE) {
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureComputeProgram.glGetProgrami.LINK_STATUS");
            String log = GL20.glGetProgramInfoLog(glProgram);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureComputeProgram.glGetProgramInfoLog");
            GL20.glDeleteProgram(glProgram);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureComputeProgram.glDeleteProgram.failed");
            throw new IllegalStateException("Failed to link Chaos GPU animation compute program: " + log);
        }
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureComputeProgram.glGetProgrami.LINK_STATUS");

        computeProgram = glProgram;
        computeClipSamplerLocation = GL20.glGetUniformLocation(glProgram, "ClipSampler");
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureComputeProgram.glGetUniformLocation.ClipSampler");
        computeChannelSamplerLocation = GL20.glGetUniformLocation(glProgram, "ChannelSampler");
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureComputeProgram.glGetUniformLocation.ChannelSampler");
        computeKeyframeSamplerLocation = GL20.glGetUniformLocation(glProgram, "KeyframeSampler");
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureComputeProgram.glGetUniformLocation.KeyframeSampler");
        computeBoneDefinitionSamplerLocation = GL20.glGetUniformLocation(glProgram, "BoneDefinitionSampler");
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureComputeProgram.glGetUniformLocation.BoneDefinitionSampler");
        computeActiveStateSamplerLocation = GL20.glGetUniformLocation(glProgram, "ActiveStateSampler");
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureComputeProgram.glGetUniformLocation.ActiveStateSampler");
        computeTransitionPoseSamplerLocation = GL20.glGetUniformLocation(glProgram, "TransitionPoseSampler");
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureComputeProgram.glGetUniformLocation.TransitionPoseSampler");
        computeRuntimeChannelSamplerLocation = GL20.glGetUniformLocation(glProgram, "RuntimeChannelSampler");
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureComputeProgram.glGetUniformLocation.RuntimeChannelSampler");
        computeControllerStateSamplerLocation = GL20.glGetUniformLocation(glProgram, "ControllerStateSampler");
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureComputeProgram.glGetUniformLocation.ControllerStateSampler");
        computeBoneCountLocation = GL20.glGetUniformLocation(glProgram, "BoneCount");
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureComputeProgram.glGetUniformLocation.BoneCount");
        computeRequestCountLocation = GL20.glGetUniformLocation(glProgram, "RequestCount");
        computeActiveStateStrideLocation = GL20.glGetUniformLocation(glProgram, "ActiveStateStride");
        computeControllerStateStrideLocation = GL20.glGetUniformLocation(glProgram, "ControllerStateStride");
        computeTransitionPoseStrideLocation = GL20.glGetUniformLocation(glProgram, "TransitionPoseStride");
        computeRuntimeChannelStrideLocation = GL20.glGetUniformLocation(glProgram, "RuntimeChannelStride");
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureComputeProgram.glGetUniformLocation.batch");
        return true;
    }

    private static boolean ensureTransformFeedbackProgram() {
        if (transformFeedbackProgram != -1) {
            return true;
        }

        int vertexShader = GL20.glCreateShader(GL20.GL_VERTEX_SHADER);
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glCreateShader");
        GL20.glShaderSource(vertexShader, TRANSFORM_FEEDBACK_SHADER);
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glShaderSource");
        GL20.glCompileShader(vertexShader);
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glCompileShader");
        if (GL20.glGetShaderi(vertexShader, GL20.GL_COMPILE_STATUS) == GL11.GL_FALSE) {
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glGetShaderi.COMPILE_STATUS");
            String log = GL20.glGetShaderInfoLog(vertexShader);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glGetShaderInfoLog");
            GL20.glDeleteShader(vertexShader);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glDeleteShader.failed");
            throw new IllegalStateException("Failed to compile Chaos GPU animation TF shader: " + log);
        }
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glGetShaderi.COMPILE_STATUS");

        int fragmentShader = GL20.glCreateShader(GL20.GL_FRAGMENT_SHADER);
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glCreateShader.fragment");
        GL20.glShaderSource(fragmentShader, TRANSFORM_FEEDBACK_FRAGMENT_SHADER);
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glShaderSource.fragment");
        GL20.glCompileShader(fragmentShader);
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glCompileShader.fragment");
        if (GL20.glGetShaderi(fragmentShader, GL20.GL_COMPILE_STATUS) == GL11.GL_FALSE) {
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glGetShaderi.COMPILE_STATUS.fragment");
            String log = GL20.glGetShaderInfoLog(fragmentShader);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glGetShaderInfoLog.fragment");
            GL20.glDeleteShader(vertexShader);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glDeleteShader.vertex.failed");
            GL20.glDeleteShader(fragmentShader);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glDeleteShader.fragment.failed");
            throw new IllegalStateException("Failed to compile Chaos GPU animation TF fragment shader: " + log);
        }
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glGetShaderi.COMPILE_STATUS.fragment");

        int glProgram = GL20.glCreateProgram();
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glCreateProgram");
        GL20.glAttachShader(glProgram, vertexShader);
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glAttachShader.vertex");
        GL20.glAttachShader(glProgram, fragmentShader);
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glAttachShader.fragment");
        GL30.glTransformFeedbackVaryings(glProgram, new CharSequence[]{"TfPose0", "TfPose1", "TfPose2", "TfPose3"}, GL30.GL_INTERLEAVED_ATTRIBS);
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glTransformFeedbackVaryings");
        GL20.glLinkProgram(glProgram);
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glLinkProgram");
        GL20.glDetachShader(glProgram, vertexShader);
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glDetachShader.vertex");
        GL20.glDetachShader(glProgram, fragmentShader);
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glDetachShader.fragment");
        GL20.glDeleteShader(vertexShader);
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glDeleteShader.vertex");
        GL20.glDeleteShader(fragmentShader);
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glDeleteShader.fragment");
        if (GL20.glGetProgrami(glProgram, GL20.GL_LINK_STATUS) == GL11.GL_FALSE) {
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glGetProgrami.LINK_STATUS");
            String log = GL20.glGetProgramInfoLog(glProgram);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glGetProgramInfoLog");
            GL20.glDeleteProgram(glProgram);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glDeleteProgram.failed");
            throw new IllegalStateException("Failed to link Chaos GPU animation TF program: " + log);
        }
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glGetProgrami.LINK_STATUS");

        transformFeedbackProgram = glProgram;
        tfClipSamplerLocation = GL20.glGetUniformLocation(glProgram, "ClipSampler");
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glGetUniformLocation.ClipSampler");
        tfChannelSamplerLocation = GL20.glGetUniformLocation(glProgram, "ChannelSampler");
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glGetUniformLocation.ChannelSampler");
        tfKeyframeSamplerLocation = GL20.glGetUniformLocation(glProgram, "KeyframeSampler");
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glGetUniformLocation.KeyframeSampler");
        tfBoneDefinitionSamplerLocation = GL20.glGetUniformLocation(glProgram, "BoneDefinitionSampler");
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glGetUniformLocation.BoneDefinitionSampler");
        tfActiveStateSamplerLocation = GL20.glGetUniformLocation(glProgram, "ActiveStateSampler");
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glGetUniformLocation.ActiveStateSampler");
        tfTransitionPoseSamplerLocation = GL20.glGetUniformLocation(glProgram, "TransitionPoseSampler");
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glGetUniformLocation.TransitionPoseSampler");
        tfRuntimeChannelSamplerLocation = GL20.glGetUniformLocation(glProgram, "RuntimeChannelSampler");
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glGetUniformLocation.RuntimeChannelSampler");
        tfControllerStateSamplerLocation = GL20.glGetUniformLocation(glProgram, "ControllerStateSampler");
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glGetUniformLocation.ControllerStateSampler");
        tfBoneCountLocation = GL20.glGetUniformLocation(glProgram, "BoneCount");
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glGetUniformLocation.BoneCount");
        tfControllerStateCountLocation = GL20.glGetUniformLocation(glProgram, "ControllerStateCount");
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackProgram.glGetUniformLocation.ControllerStateCount");
        return true;
    }

    private static void ensureTransformFeedbackWritesVisible() {
        if (GL.getCapabilities().OpenGL42) {
            GL42.glMemoryBarrier(GL42.GL_TRANSFORM_FEEDBACK_BARRIER_BIT | GL42.GL_TEXTURE_FETCH_BARRIER_BIT | GL42.GL_BUFFER_UPDATE_BARRIER_BIT);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackWritesVisible.glMemoryBarrier");
            return;
        }
        GL11.glFinish();
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ensureTransformFeedbackWritesVisible.glFinish");
    }

    private static void bindTextureToUnit(int textureUnit, int textureId) {
        int activeTexture = GlStateManager._getActiveTexture();
        RenderSystem.activeTexture(GL13.GL_TEXTURE0 + textureUnit);
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, textureId);
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.bindTextureToUnit.glBindTexture." + textureUnit);
        GlStateManager._activeTexture(activeTexture);
    }

    private static void unbindInternalSamplers() {
        int activeTexture = GlStateManager._getActiveTexture();
        int[] units = {
                CLIP_TEXTURE_UNIT,
                CHANNEL_TEXTURE_UNIT,
                KEYFRAME_TEXTURE_UNIT,
                BONE_DEFINITION_TEXTURE_UNIT,
                ACTIVE_STATE_TEXTURE_UNIT,
                TRANSITION_POSE_TEXTURE_UNIT,
                RUNTIME_CHANNEL_TEXTURE_UNIT,
                CONTROLLER_STATE_TEXTURE_UNIT
        };
        for (int unit : units) {
            RenderSystem.activeTexture(GL13.GL_TEXTURE0 + unit);
            GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, 0);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.unbindInternalSamplers.glBindTexture.0." + unit);
        }
        GlStateManager._activeTexture(activeTexture);
    }

    private static void attachTextureBuffer(int textureId, int internalFormat, int bufferId) {
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, textureId);
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.attachTextureBuffer.glBindTexture");
        if (GL.getCapabilities().OpenGL31) {
            GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, internalFormat, bufferId);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.attachTextureBuffer.glTexBuffer");
        } else {
            ARBTextureBufferObject.glTexBufferARB(ARBTextureBufferObject.GL_TEXTURE_BUFFER_ARB, internalFormat, bufferId);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.attachTextureBuffer.glTexBufferARB");
        }
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, 0);
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.attachTextureBuffer.glBindTexture.0");
    }

    private static float[] toFloatArray(List<Float> values) {
        float[] array = new float[values.size()];
        for (int i = 0; i < values.size(); i++) {
            array[i] = values.get(i);
        }
        return array;
    }

    private enum BackendMode {
        COMPUTE,
        TRANSFORM_FEEDBACK,
        NONE
    }

    private enum ChannelTarget {
        POSITION,
        ROTATION,
        SCALE
    }

    private record ControllerSample(int clipIndex, float localTimeSeconds) {
    }

    private record ControllerState(float stateStart, float stateCount, boolean overrideBlend) {
    }

    private record ActiveClipState(float clipIndex, float localTimeSeconds, float weight, float runtimeSampleStart) {
    }

    private static final class AnimationPoseKey {
        private final BackendMode backendMode;
        private final ChaosGpuAnimationPayload payload;
        private final Object activeStateKey;
        private final int hashCode;

        private AnimationPoseKey(BackendMode backendMode, ChaosGpuAnimationPayload payload, Object activeStateKey) {
            this.backendMode = backendMode;
            this.payload = payload;
            this.activeStateKey = activeStateKey;
            int result = backendMode.ordinal();
            result = 31 * result + System.identityHashCode(payload);
            result = 31 * result + activeStateKey.hashCode();
            this.hashCode = result;
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof AnimationPoseKey key)) {
                return false;
            }
            return this.backendMode == key.backendMode
                    && this.payload == key.payload
                    && this.activeStateKey.equals(key.activeStateKey);
        }

        @Override
        public int hashCode() {
            return this.hashCode;
        }
    }

    private static final class ActiveStateKey {
        private final int[] controllerKey;
        private final int[] clipKey;
        private final int transitionPoseHash;
        private final int runtimeChannelHash;
        private final int hashCode;

        private ActiveStateKey(int[] controllerKey, int[] clipKey, int transitionPoseHash, int runtimeChannelHash) {
            this.controllerKey = controllerKey;
            this.clipKey = clipKey;
            this.transitionPoseHash = transitionPoseHash;
            this.runtimeChannelHash = runtimeChannelHash;
            int result = Arrays.hashCode(controllerKey);
            result = 31 * result + Arrays.hashCode(clipKey);
            result = 31 * result + transitionPoseHash;
            result = 31 * result + runtimeChannelHash;
            this.hashCode = result;
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof ActiveStateKey key)) {
                return false;
            }
            return this.transitionPoseHash == key.transitionPoseHash
                    && this.runtimeChannelHash == key.runtimeChannelHash
                    && Arrays.equals(this.controllerKey, key.controllerKey)
                    && Arrays.equals(this.clipKey, key.clipKey);
        }

        @Override
        public int hashCode() {
            return this.hashCode;
        }
    }

    private record ActiveStateCollection(
            List<ControllerState> controllerStates,
            List<ActiveClipState> clipStates,
            float[] transitionPoseData,
            float[] runtimeChannelData,
            int transitionPoseHash,
            int runtimeChannelHash
    ) {
        private boolean hasTransitionPoseData() {
            if (this.transitionPoseData.length == 0) {
                return false;
            }
            for (float value : this.transitionPoseData) {
                if (Math.abs(value) > 1.0e-6f) {
                    return true;
                }
            }
            return false;
        }
    }

    private static final class PayloadState implements AutoCloseable {
        private final int clipBufferId;
        private final int clipTextureId;
        private final int channelBufferId;
        private final int channelTextureId;
        private final int keyframeBufferId;
        private final int keyframeTextureId;

        private PayloadState(TextureBufferHandle clip, TextureBufferHandle channel, TextureBufferHandle keyframe) {
            this.clipBufferId = clip.bufferId();
            this.clipTextureId = clip.textureId();
            this.channelBufferId = channel.bufferId();
            this.channelTextureId = channel.textureId();
            this.keyframeBufferId = keyframe.bufferId();
            this.keyframeTextureId = keyframe.textureId();
        }

        @Override
        public void close() {
            GL15.glDeleteBuffers(this.clipBufferId);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.PayloadState.close.glDeleteBuffers.clip");
            GL11.glDeleteTextures(this.clipTextureId);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.PayloadState.close.glDeleteTextures.clip");
            GL15.glDeleteBuffers(this.channelBufferId);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.PayloadState.close.glDeleteBuffers.channel");
            GL11.glDeleteTextures(this.channelTextureId);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.PayloadState.close.glDeleteTextures.channel");
            GL15.glDeleteBuffers(this.keyframeBufferId);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.PayloadState.close.glDeleteBuffers.keyframe");
            GL11.glDeleteTextures(this.keyframeTextureId);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.PayloadState.close.glDeleteTextures.keyframe");
        }
    }

    private static final class MeshState implements AutoCloseable {
        private final int definitionBufferId;
        private final int definitionTextureId;
        private final int vertexArrayId;
        private final ArrayDeque<CachedPose> availablePoses = new ArrayDeque<>();
        private final Map<Object, CachedPose> cache = new HashMap<>();
        private final ArrayDeque<Object> cacheOrder = new ArrayDeque<>();
        private final Map<Object, OwnedPose> ownedUploadedCache = new HashMap<>();
        private final ArrayDeque<Object> ownedUploadedOrder = new ArrayDeque<>();

        private MeshState(TextureBufferHandle definition, int boneCount) {
            this.definitionBufferId = definition.bufferId();
            this.definitionTextureId = definition.textureId();
            this.vertexArrayId = GL30.glGenVertexArrays();
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.MeshState.glGenVertexArrays");
            for (int i = 0; i < MAX_CACHED_POSES_PER_STATE; i++) {
                this.availablePoses.addLast(createPose(boneCount));
            }
        }

        private CachedPose acquirePose(Object cacheKey, int boneCount) {
            int frameId = ChaosBlockEntityRenderFrameClock.frameId();
            CachedPose existing = this.cache.get(cacheKey);
            if (existing != null) {
                existing.markUsed(frameId);
                this.cacheOrder.remove(cacheKey);
                this.cacheOrder.addLast(cacheKey);
                return existing;
            }

            CachedPose pose = this.availablePoses.pollFirst();
            if (pose == null) {
                pose = this.evictIdleCachedPose(frameId);
            }
            if (pose == null) {
                pose = this.createPose(boneCount);
            }

            pose.markUsed(frameId);
            this.cache.put(cacheKey, pose);
            this.cacheOrder.addLast(cacheKey);
            return pose;
        }

        private @Nullable CachedPose evictIdleCachedPose(int frameId) {
            for (Iterator<Object> iterator = this.cacheOrder.iterator(); iterator.hasNext(); ) {
                Object cacheKey = iterator.next();
                CachedPose candidate = this.cache.get(cacheKey);
                if (candidate == null) {
                    iterator.remove();
                    continue;
                }
                if (candidate.lastUsedFrame() == frameId) {
                    continue;
                }

                iterator.remove();
                this.cache.remove(cacheKey);
                ChaosGpuBoneResolveDispatcher.invalidateLocalPose(candidate.handle(), candidate.textureId());
                candidate.refreshHandle();
                return candidate;
            }
            return null;
        }

        private OwnedPose acquireOwnedUploadedPose(Object ownerKey, int boneCount) {
            int frameId = ChaosBlockEntityRenderFrameClock.frameId();
            OwnedPose existing = this.ownedUploadedCache.get(ownerKey);
            if (existing != null) {
                existing.markUsed(frameId);
                this.ownedUploadedOrder.remove(ownerKey);
                this.ownedUploadedOrder.addLast(ownerKey);
                return existing;
            }

            CachedPose pose = this.availablePoses.pollFirst();
            if (pose == null) {
                pose = this.evictIdleOwnedPose(frameId);
            }
            if (pose == null) {
                pose = this.createPose(boneCount);
            }

            OwnedPose ownedPose = new OwnedPose(pose);
            ownedPose.markUsed(frameId);
            this.ownedUploadedCache.put(ownerKey, ownedPose);
            this.ownedUploadedOrder.addLast(ownerKey);
            return ownedPose;
        }

        private @Nullable CachedPose evictIdleOwnedPose(int frameId) {
            for (Iterator<Object> iterator = this.ownedUploadedOrder.iterator(); iterator.hasNext(); ) {
                Object ownerKey = iterator.next();
                OwnedPose candidate = this.ownedUploadedCache.get(ownerKey);
                if (candidate == null) {
                    iterator.remove();
                    continue;
                }
                if (candidate.lastUsedFrame() == frameId) {
                    continue;
                }

                iterator.remove();
                this.ownedUploadedCache.remove(ownerKey);
                ChaosGpuBoneResolveDispatcher.invalidateLocalPose(candidate.pose().handle(), candidate.pose().textureId());
                candidate.pose().refreshHandle();
                candidate.clearPoseKey();
                return candidate.pose();
            }
            return null;
        }

        private @Nullable CachedPose cachedPose(Object cacheKey) {
            CachedPose pose = this.cache.get(cacheKey);
            if (pose != null) {
                pose.markUsed(ChaosBlockEntityRenderFrameClock.frameId());
                this.cacheOrder.remove(cacheKey);
                this.cacheOrder.addLast(cacheKey);
            }
            return pose;
        }

        private CachedPose createPose(int boneCount) {
            int bufferId = GL15.glGenBuffers();
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.MeshState.createPose.glGenBuffers");
            int textureId = GL11.glGenTextures();
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.MeshState.createPose.glGenTextures");
            long byteSize = (long) boneCount * 16L * Float.BYTES;
            GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, bufferId);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.MeshState.createPose.glBindBuffer");
            GL15.glBufferData(GL15.GL_ARRAY_BUFFER, byteSize, GL15.GL_DYNAMIC_DRAW);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.MeshState.createPose.glBufferData");
            GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, 0);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.MeshState.createPose.glBindBuffer.0");
            attachTextureBuffer(textureId, GL30.GL_RGBA32F, bufferId);
            return new CachedPose(bufferId, textureId);
        }

        @Override
        public void close() {
            GL15.glDeleteBuffers(this.definitionBufferId);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.MeshState.close.glDeleteBuffers.definition");
            GL11.glDeleteTextures(this.definitionTextureId);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.MeshState.close.glDeleteTextures.definition");
            GL30.glDeleteVertexArrays(this.vertexArrayId);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.MeshState.close.glDeleteVertexArrays");
            for (CachedPose pose : this.cache.values()) {
                pose.close();
            }
            for (OwnedPose pose : this.ownedUploadedCache.values()) {
                pose.pose().close();
            }
            this.cache.clear();
            this.cacheOrder.clear();
            this.ownedUploadedCache.clear();
            this.ownedUploadedOrder.clear();
        }
    }

    private static final class OwnedPose {
        private final CachedPose pose;
        private Object poseKey;
        private int lastUsedFrame;

        private OwnedPose(CachedPose pose) {
            this.pose = pose;
        }

        private void markUsed(int frameId) {
            this.lastUsedFrame = frameId;
        }

        private int lastUsedFrame() {
            return this.lastUsedFrame;
        }

        private CachedPose pose() {
            return this.pose;
        }

        private boolean matches(Object poseKey) {
            return this.poseKey != null && this.poseKey.equals(poseKey);
        }

        private void updatePoseKey(Object poseKey) {
            this.poseKey = poseKey;
        }

        private void clearPoseKey() {
            this.poseKey = null;
        }
    }

    private record UploadedPoseCacheKey(Object poseCacheKey) {
    }

    private enum RestPoseCacheKey {
        INSTANCE
    }

    private static final class CachedPose implements AutoCloseable {
        private final int bufferId;
        private final int textureId;
        private LocalPoseHandle handle;
        private int lastUsedFrame;

        private CachedPose(int bufferId, int textureId) {
            this.bufferId = bufferId;
            this.textureId = textureId;
            this.handle = new LocalPoseHandle(bufferId, textureId);
        }

        private int bufferId() {
            return this.bufferId;
        }

        private int textureId() {
            return this.textureId;
        }

        private LocalPoseHandle handle() {
            return this.handle;
        }

        private void refreshHandle() {
            this.handle = new LocalPoseHandle(this.bufferId, this.textureId);
        }

        private void markUsed(int frameId) {
            this.lastUsedFrame = frameId;
        }

        private int lastUsedFrame() {
            return this.lastUsedFrame;
        }

        @Override
        public void close() {
            GL15.glDeleteBuffers(this.bufferId);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.CachedPose.close.glDeleteBuffers");
            GL11.glDeleteTextures(this.textureId);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.CachedPose.close.glDeleteTextures");
        }
    }

    private record TextureBufferHandle(int bufferId, int textureId) {
    }

    private static final class BatchGroupState implements AutoCloseable {
        private final ActiveStateTextureSet stateTextures = new ActiveStateTextureSet();
        private int requestBufferId = -1;

        private ActiveStateTextureSet stateTextures() {
            return this.stateTextures;
        }

        private int requestBufferId() {
            return this.requestBufferId;
        }

        private void uploadStates(
                float[] activeStateData,
                float[] controllerStateData,
                float[] transitionPoseData,
                float[] runtimeChannelData,
                int[] requestData) {
            this.stateTextures.uploadActiveState(activeStateData, activeStateData.length, ++batchUploadTag);
            this.stateTextures.uploadControllerStates(controllerStateData, controllerStateData.length, ++batchUploadTag);
            this.stateTextures.uploadTransitionPose(transitionPoseData, ++batchUploadTag);
            this.stateTextures.uploadRuntimeChannels(runtimeChannelData, ++batchUploadTag);

            if (this.requestBufferId == -1) {
                this.requestBufferId = GL15.glGenBuffers();
            }

            IntBuffer buffer = REQUEST_UPLOAD_BUFFER.get().prepare(requestData);
            GL15.glBindBuffer(GL43.GL_SHADER_STORAGE_BUFFER, this.requestBufferId);
            GL15.glBufferData(GL43.GL_SHADER_STORAGE_BUFFER, buffer, GL15.GL_DYNAMIC_DRAW);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.BatchGroupState.uploadStates.glBufferData");
            GL15.glBindBuffer(GL43.GL_SHADER_STORAGE_BUFFER, 0);
        }

        @Override
        public void close() {
            this.stateTextures.close();
            if (this.requestBufferId != -1) {
                GL15.glDeleteBuffers(this.requestBufferId);
                this.requestBufferId = -1;
            }
        }
    }

    private static final class RequestUploadBuffer {
        private IntBuffer buffer = MemoryUtil.memAllocInt(16);

        private IntBuffer prepare(int[] source) {
            if (this.buffer.capacity() < source.length) {
                MemoryUtil.memFree(this.buffer);
                this.buffer = MemoryUtil.memAllocInt(source.length);
            }
            this.buffer.clear();
            this.buffer.put(source);
            this.buffer.flip();
            return this.buffer;
        }
    }

    private static final class ActiveStateTextureSet implements AutoCloseable {
        private final int activeStateBufferId;
        private final int activeStateTextureId;
        private final int transitionPoseBufferId;
        private final int transitionPoseTextureId;
        private final int runtimeChannelBufferId;
        private final int runtimeChannelTextureId;
        private final int controllerStateBufferId;
        private final int controllerStateTextureId;
        private float[] activeStateScratch = new float[16];
        private float[] controllerStateScratch = new float[16];
        private int lastActiveStateHash = Integer.MIN_VALUE;
        private int lastActiveStateLength = -1;
        private int lastTransitionPoseHash = Integer.MIN_VALUE;
        private int lastTransitionPoseLength = -1;
        private int lastRuntimeChannelHash = Integer.MIN_VALUE;
        private int lastRuntimeChannelLength = -1;
        private int lastControllerStateHash = Integer.MIN_VALUE;
        private int lastControllerStateLength = -1;

        private ActiveStateTextureSet() {
            this.activeStateBufferId = GL15.glGenBuffers();
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ActiveStateTextureSet.glGenBuffers.activeState");
            this.activeStateTextureId = GL11.glGenTextures();
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ActiveStateTextureSet.glGenTextures.activeState");
            this.transitionPoseBufferId = GL15.glGenBuffers();
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ActiveStateTextureSet.glGenBuffers.transitionPose");
            this.transitionPoseTextureId = GL11.glGenTextures();
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ActiveStateTextureSet.glGenTextures.transitionPose");
            this.runtimeChannelBufferId = GL15.glGenBuffers();
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ActiveStateTextureSet.glGenBuffers.runtimeChannel");
            this.runtimeChannelTextureId = GL11.glGenTextures();
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ActiveStateTextureSet.glGenTextures.runtimeChannel");
            this.controllerStateBufferId = GL15.glGenBuffers();
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ActiveStateTextureSet.glGenBuffers.controllerState");
            this.controllerStateTextureId = GL11.glGenTextures();
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ActiveStateTextureSet.glGenTextures.controllerState");
        }

        private float[] prepareActiveStateBuffer(int requiredLength) {
            if (this.activeStateScratch.length < requiredLength) {
                this.activeStateScratch = new float[requiredLength];
            }
            return this.activeStateScratch;
        }

        private float[] prepareControllerStateBuffer(int requiredLength) {
            if (this.controllerStateScratch.length < requiredLength) {
                this.controllerStateScratch = new float[requiredLength];
            }
            return this.controllerStateScratch;
        }

        private void uploadActiveState(float[] data, int length, int hash) {
            if (this.lastActiveStateHash == hash && this.lastActiveStateLength == length) {
                return;
            }
            uploadTextureBuffer(this.activeStateBufferId, this.activeStateTextureId, data, length, GL15.GL_DYNAMIC_DRAW);
            this.lastActiveStateHash = hash;
            this.lastActiveStateLength = length;
        }

        private void uploadTransitionPose(float[] data, int hash) {
            if (this.lastTransitionPoseHash == hash && this.lastTransitionPoseLength == data.length) {
                return;
            }
            uploadTextureBuffer(this.transitionPoseBufferId, this.transitionPoseTextureId, data, data.length, GL15.GL_DYNAMIC_DRAW);
            this.lastTransitionPoseHash = hash;
            this.lastTransitionPoseLength = data.length;
        }

        private void uploadRuntimeChannels(float[] data, int hash) {
            if (this.lastRuntimeChannelHash == hash && this.lastRuntimeChannelLength == data.length) {
                return;
            }
            uploadTextureBuffer(this.runtimeChannelBufferId, this.runtimeChannelTextureId, data, data.length, GL15.GL_DYNAMIC_DRAW);
            this.lastRuntimeChannelHash = hash;
            this.lastRuntimeChannelLength = data.length;
        }

        private void uploadControllerStates(float[] data, int length, int hash) {
            if (this.lastControllerStateHash == hash && this.lastControllerStateLength == length) {
                return;
            }
            uploadTextureBuffer(this.controllerStateBufferId, this.controllerStateTextureId, data, length, GL15.GL_DYNAMIC_DRAW);
            this.lastControllerStateHash = hash;
            this.lastControllerStateLength = length;
        }

        @Override
        public void close() {
            GL15.glDeleteBuffers(this.activeStateBufferId);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ActiveStateTextureSet.close.glDeleteBuffers.activeState");
            GL11.glDeleteTextures(this.activeStateTextureId);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ActiveStateTextureSet.close.glDeleteTextures.activeState");
            GL15.glDeleteBuffers(this.transitionPoseBufferId);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ActiveStateTextureSet.close.glDeleteBuffers.transitionPose");
            GL11.glDeleteTextures(this.transitionPoseTextureId);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ActiveStateTextureSet.close.glDeleteTextures.transitionPose");
            GL15.glDeleteBuffers(this.runtimeChannelBufferId);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ActiveStateTextureSet.close.glDeleteBuffers.runtimeChannel");
            GL11.glDeleteTextures(this.runtimeChannelTextureId);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ActiveStateTextureSet.close.glDeleteTextures.runtimeChannel");
            GL15.glDeleteBuffers(this.controllerStateBufferId);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ActiveStateTextureSet.close.glDeleteBuffers.controllerState");
            GL11.glDeleteTextures(this.controllerStateTextureId);
            ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.ActiveStateTextureSet.close.glDeleteTextures.controllerState");
        }
    }

    private static void uploadLocalPoseData(int bufferId, float[] localPoseData) {
        FloatBuffer upload = FLOAT_UPLOAD_BUFFER.get().prepare(localPoseData);
        GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, bufferId);
        GL15.glBufferSubData(GL31.GL_TEXTURE_BUFFER, 0L, upload);
        GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, 0);
        ChaosGlDebug.check("ChaosGpuAnimationPoseStorage.uploadLocalPoseData");
    }

    private static void uploadStaticPoseData(ChaosGpuGeoMesh mesh, Map<String, StaticGeoBonePose> staticBonePoses, int bufferId) {
        float[] poseData = new float[mesh.getIndexedBones().size() * 16];
        for (int boneIndex = 0; boneIndex < mesh.getIndexedBones().size(); boneIndex++) {
            GeoBone bone = mesh.getIndexedBones().get(boneIndex);
            StaticGeoBonePose pose = staticBonePoses.getOrDefault(bone.getName(), StaticGeoBonePose.IDENTITY);
            int offset = boneIndex * 16;
            poseData[offset] = bone.getPosX() + pose.posX();
            poseData[offset + 1] = bone.getPosY() + pose.posY();
            poseData[offset + 2] = bone.getPosZ() + pose.posZ();
            poseData[offset + 3] = mesh.getParentIndex(boneIndex);
            poseData[offset + 4] = bone.getPivotX();
            poseData[offset + 5] = bone.getPivotY();
            poseData[offset + 6] = bone.getPivotZ();
            poseData[offset + 7] = 0.0f;
            poseData[offset + 8] = bone.getRotX() + pose.rotX();
            poseData[offset + 9] = bone.getRotY() + pose.rotY();
            poseData[offset + 10] = bone.getRotZ() + pose.rotZ();
            poseData[offset + 11] = 0.0f;

            float scaleX = bone.getScaleX() * pose.scaleX();
            float scaleY = bone.getScaleY() * pose.scaleY();
            float scaleZ = bone.getScaleZ() * pose.scaleZ();
            if (pose.hidden()) {
                scaleX = 0.0f;
                scaleY = 0.0f;
                scaleZ = 0.0f;
            }

            poseData[offset + 12] = scaleX;
            poseData[offset + 13] = scaleY;
            poseData[offset + 14] = scaleZ;
            poseData[offset + 15] = 0.0f;
        }

        uploadLocalPoseData(bufferId, poseData);
    }

    private static final class UploadBuffer {
        private FloatBuffer buffer = MemoryUtil.memAllocFloat(16);

        private FloatBuffer prepare(float[] source) {
            if (this.buffer.capacity() < source.length) {
                MemoryUtil.memFree(this.buffer);
                this.buffer = MemoryUtil.memAllocFloat(source.length);
            }
            this.buffer.clear();
            this.buffer.put(source);
            this.buffer.flip();
            return this.buffer;
        }
    }
}
