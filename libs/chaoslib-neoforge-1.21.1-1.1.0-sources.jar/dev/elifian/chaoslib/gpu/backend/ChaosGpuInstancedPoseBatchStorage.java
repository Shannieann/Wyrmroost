package dev.elifian.chaoslib.gpu.backend;

import dev.elifian.chaoslib.gpu.debug.ChaosGlDebug;
import dev.elifian.chaoslib.gpu.mesh.ChaosGpuGeoMesh;

import dev.elifian.chaoslib.platform.ClientOnly;
import org.lwjgl.opengl.*;
import org.lwjgl.system.MemoryUtil;

import java.nio.FloatBuffer;
import java.util.HashMap;
import java.util.Map;

@ClientOnly
public final class ChaosGpuInstancedPoseBatchStorage {
    private static final ThreadLocal<UploadBuffer> UPLOAD_BUFFER = ThreadLocal.withInitial(UploadBuffer::new);
    private static final ThreadLocal<Map<Long, Integer>> POSE_BUFFER_SLOTS = ThreadLocal.withInitial(HashMap::new);
    private static int poseBufferId = -1;
    private static int poseTextureId = -1;
    private static long poseBufferCapacity;
    private static boolean poseTextureAttached;

    private ChaosGpuInstancedPoseBatchStorage() {
    }

    public static boolean isSupported() {
        return ChaosGpuRuntimePolicy.isTextureBufferSupported();
    }

    public static void invalidateAll() {
        if (poseTextureId != -1) {
            GL11.glDeleteTextures(poseTextureId);
            ChaosGlDebug.check("ChaosGpuInstancedPoseBatchStorage.invalidateAll.glDeleteTextures");
            poseTextureId = -1;
        }
        if (poseBufferId != -1) {
            GL15.glDeleteBuffers(poseBufferId);
            ChaosGlDebug.check("ChaosGpuInstancedPoseBatchStorage.invalidateAll.glDeleteBuffers");
            poseBufferId = -1;
        }
        poseBufferCapacity = 0L;
        poseTextureAttached = false;
    }

    public static boolean buildLocalPoseBatch(ChaosGpuGeoMesh mesh, Object[] poseChunk, int count, int[] poseBaseOutput) {
        if (!isSupported()) {
            return false;
        }


        ensureInitialized();
        int floatsPerPose = mesh.getIndexedBones().size() * 16;
        int texelsPerPose = mesh.getIndexedBones().size() * 4;
        long bytesPerPose = (long) floatsPerPose * Float.BYTES;
        long totalBytes = bytesPerPose * count;
        ensureCapacity(totalBytes);

        Map<Long, Integer> bufferSlots = POSE_BUFFER_SLOTS.get();
        bufferSlots.clear();
        int nextSlot = 0;
        long lastSourceKey = -1L;
        int lastTexelBase = 0;

        boolean copiedAnyGpuPose = false;
        GL15.glBindBuffer(GL31.GL_COPY_WRITE_BUFFER, poseBufferId);
        ChaosGlDebug.check("ChaosGpuInstancedPoseBatchStorage.buildLocalPoseBatch.glBindBuffer.copyWrite");
        GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, poseBufferId);
        ChaosGlDebug.check("ChaosGpuInstancedPoseBatchStorage.buildLocalPoseBatch.glBindBuffer.texture");
        int boundReadBufferId = -1;
        for (int i = 0; i < count; i++) {
            Object poseData = poseChunk[i];
            int sourceBufferId = ChaosGpuAnimationPoseStorage.bufferIdFor(poseData);
            if (sourceBufferId >= 0) {
                int sourcePoseBase = ChaosGpuAnimationPoseStorage.poseBaseFor(poseData);
                long sourceKey = ((long) sourceBufferId << 32) | (sourcePoseBase & 0xFFFFFFFFL);
                if (sourceKey == lastSourceKey) {
                    poseBaseOutput[i] = lastTexelBase;
                    continue;
                }
                Integer existing = bufferSlots.get(sourceKey);
                if (existing != null) {
                    poseBaseOutput[i] = existing;
                    lastSourceKey = sourceKey;
                    lastTexelBase = existing;
                    continue;
                }

                int texelBase = nextSlot * texelsPerPose;
                long byteOffset = bytesPerPose * nextSlot;
                nextSlot++;
                poseBaseOutput[i] = texelBase;
                bufferSlots.put(sourceKey, texelBase);
                lastSourceKey = sourceKey;
                lastTexelBase = texelBase;

                copiedAnyGpuPose = true;
                if (boundReadBufferId != sourceBufferId) {
                    GL15.glBindBuffer(GL31.GL_COPY_READ_BUFFER, sourceBufferId);
                    ChaosGlDebug.check("ChaosGpuInstancedPoseBatchStorage.buildLocalPoseBatch.glBindBuffer.copyRead");
                    boundReadBufferId = sourceBufferId;
                }
                long sourceByteOffset = (long) sourcePoseBase * 4 * Float.BYTES;
                GL31.glCopyBufferSubData(GL31.GL_COPY_READ_BUFFER, GL31.GL_COPY_WRITE_BUFFER, sourceByteOffset, byteOffset, bytesPerPose);
                ChaosGlDebug.check("ChaosGpuInstancedPoseBatchStorage.buildLocalPoseBatch.glCopyBufferSubData");
                continue;
            }

            int texelBase = nextSlot * texelsPerPose;
            long byteOffset = bytesPerPose * nextSlot;
            nextSlot++;
            poseBaseOutput[i] = texelBase;
            lastSourceKey = -1L;

            if (!(poseData instanceof float[] rawPoseData) || rawPoseData.length != floatsPerPose) {
                GL15.glBindBuffer(GL31.GL_COPY_READ_BUFFER, 0);
                ChaosGlDebug.check("ChaosGpuInstancedPoseBatchStorage.buildLocalPoseBatch.failure.glBindBuffer.copyRead.0");
                GL15.glBindBuffer(GL31.GL_COPY_WRITE_BUFFER, 0);
                ChaosGlDebug.check("ChaosGpuInstancedPoseBatchStorage.buildLocalPoseBatch.failure.glBindBuffer.copyWrite.0");
                GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, 0);
                ChaosGlDebug.check("ChaosGpuInstancedPoseBatchStorage.buildLocalPoseBatch.failure.glBindBuffer.texture.0");
                return false;
            }

            FloatBuffer upload = UPLOAD_BUFFER.get().prepare(rawPoseData);
            GL15.glBufferSubData(GL31.GL_TEXTURE_BUFFER, byteOffset, upload);
            ChaosGlDebug.check("ChaosGpuInstancedPoseBatchStorage.buildLocalPoseBatch.glBufferSubData");
        }

        GL15.glBindBuffer(GL31.GL_COPY_READ_BUFFER, 0);
        ChaosGlDebug.check("ChaosGpuInstancedPoseBatchStorage.buildLocalPoseBatch.cleanup.glBindBuffer.copyRead.0");
        GL15.glBindBuffer(GL31.GL_COPY_WRITE_BUFFER, 0);
        ChaosGlDebug.check("ChaosGpuInstancedPoseBatchStorage.buildLocalPoseBatch.cleanup.glBindBuffer.copyWrite.0");
        GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, 0);
        ChaosGlDebug.check("ChaosGpuInstancedPoseBatchStorage.buildLocalPoseBatch.cleanup.glBindBuffer.texture.0");

        if (copiedAnyGpuPose) {
            ensureWritesVisible();
        }
        return true;
    }

    public static int getPoseTextureId() {
        return poseTextureId;
    }

    public static boolean bindPoseTexture(float[] emissiveMaskData) {
        return bindPoseTexture(emissiveMaskData, emissiveMaskData.length);
    }

    public static boolean bindPoseTexture(float[] emissiveMaskData, int emissiveMaskLength) {
        if (!isSupported() || poseTextureId < 0) {
            return false;
        }

        return ChaosGpuBoneDataStorage.bindPoseTextureForInstancedShaders(poseTextureId, emissiveMaskData, emissiveMaskLength);
    }

    private static void ensureInitialized() {
        if (poseBufferId != -1) {
            return;
        }

        poseBufferId = GL15.glGenBuffers();
        ChaosGlDebug.check("ChaosGpuInstancedPoseBatchStorage.ensureInitialized.glGenBuffers");
        poseTextureId = GL11.glGenTextures();
        ChaosGlDebug.check("ChaosGpuInstancedPoseBatchStorage.ensureInitialized.glGenTextures");
    }

    private static void ensureCapacity(long totalBytes) {
        if (poseBufferCapacity >= totalBytes && poseTextureAttached) {
            return;
        }

        if (poseBufferCapacity < totalBytes) {
            poseBufferCapacity = Math.max(totalBytes, Math.max(1024L, poseBufferCapacity << 1));
            GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, poseBufferId);
            ChaosGlDebug.check("ChaosGpuInstancedPoseBatchStorage.ensureCapacity.glBindBuffer");
            GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, poseBufferCapacity, GL15.GL_DYNAMIC_DRAW);
            ChaosGlDebug.check("ChaosGpuInstancedPoseBatchStorage.ensureCapacity.glBufferData");
            GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, 0);
            ChaosGlDebug.check("ChaosGpuInstancedPoseBatchStorage.ensureCapacity.glBindBuffer.0");
        }

        if (!poseTextureAttached) {
            attachTextureBuffer(poseTextureId, GL30.GL_RGBA32F, poseBufferId);
            poseTextureAttached = true;
        }
    }

    private static void ensureWritesVisible() {
        if (GL.getCapabilities().OpenGL42) {
            GL42.glMemoryBarrier(GL42.GL_BUFFER_UPDATE_BARRIER_BIT | GL42.GL_TEXTURE_FETCH_BARRIER_BIT);
            ChaosGlDebug.check("ChaosGpuInstancedPoseBatchStorage.ensureWritesVisible.glMemoryBarrier");
        }
    }

    private static void attachTextureBuffer(int textureId, int internalFormat, int bufferId) {
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, textureId);
        ChaosGlDebug.check("ChaosGpuInstancedPoseBatchStorage.attachTextureBuffer.glBindTexture");
        if (GL.getCapabilities().OpenGL31) {
            GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, internalFormat, bufferId);
            ChaosGlDebug.check("ChaosGpuInstancedPoseBatchStorage.attachTextureBuffer.glTexBuffer");
        } else {
            ARBTextureBufferObject.glTexBufferARB(ARBTextureBufferObject.GL_TEXTURE_BUFFER_ARB, internalFormat, bufferId);
            ChaosGlDebug.check("ChaosGpuInstancedPoseBatchStorage.attachTextureBuffer.glTexBufferARB");
        }
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, 0);
        ChaosGlDebug.check("ChaosGpuInstancedPoseBatchStorage.attachTextureBuffer.glBindTexture.0");
    }

    private static final class UploadBuffer {
        private FloatBuffer buffer = MemoryUtil.memAllocFloat(16);

        private FloatBuffer prepare(float[] source) {
            if (this.buffer.capacity() < source.length) {
                MemoryUtil.memFree(this.buffer);
                this.buffer = MemoryUtil.memAllocFloat(source.length);
            }

            this.buffer.clear();
            this.buffer.put(source);
            this.buffer.flip();
            return this.buffer;
        }
    }
}
