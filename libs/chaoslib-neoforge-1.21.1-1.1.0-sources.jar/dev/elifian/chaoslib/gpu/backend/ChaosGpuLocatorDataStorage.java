package dev.elifian.chaoslib.gpu.backend;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.elifian.chaoslib.cache.object.GeoLocator;
import dev.elifian.chaoslib.gpu.debug.ChaosGlDebug;
import dev.elifian.chaoslib.gpu.mesh.ChaosGpuGeoMesh;
import dev.elifian.chaoslib.gpu.shader.ChaosGpuShaderSources;

import dev.elifian.chaoslib.platform.ClientOnly;
import org.lwjgl.opengl.*;
import org.lwjgl.system.MemoryUtil;

import java.nio.FloatBuffer;
import java.util.ArrayDeque;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Map;

@ClientOnly
public final class ChaosGpuLocatorDataStorage {
    public static final int LOCATOR_TEXTURE_UNIT = 7;
    private static final int DEFINITION_TEXTURE_UNIT = 8;
    private static final int WORKGROUP_SIZE = 64;
    private static final int MAX_CACHED_LOCATOR_POSES_PER_MESH = 16;
    private static final String COMPUTE_SHADER = ChaosGpuShaderSources.load("assets/chaoslib/shaders/internal/locator_resolve/compute.comp");
    private static final Map<ChaosGpuGeoMesh, MeshState> CACHE = Collections.synchronizedMap(new IdentityHashMap<>());
    private static final ThreadLocal<UploadBuffer> DEFINITION_UPLOAD_BUFFER = ThreadLocal.withInitial(UploadBuffer::new);
    private static int program = -1;
    private static int resolvedBoneSamplerLocation = -1;
    private static int locatorDefinitionSamplerLocation = -1;
    private static int locatorCountLocation = -1;

    private ChaosGpuLocatorDataStorage() {
    }

    public static boolean isSupported() {
        return ChaosGpuBoneResolveDispatcher.isSupported() && (GL.getCapabilities().OpenGL43 || GL.getCapabilities().GL_ARB_compute_shader);
    }

    public static void invalidateAll() {
        synchronized (CACHE) {
            for (MeshState state : CACHE.values()) {
                state.close();
            }
            CACHE.clear();
        }
        if (program != -1) {
            GL20.glDeleteProgram(program);
            ChaosGlDebug.check("ChaosGpuLocatorDataStorage.invalidateAll.glDeleteProgram");
            program = -1;
            resolvedBoneSamplerLocation = -1;
            locatorDefinitionSamplerLocation = -1;
            locatorCountLocation = -1;
        }
    }

    public static boolean bindLocatorMatrices(ChaosGpuGeoMesh mesh, Object localPoseData) {
        if (!isSupported() || mesh.getIndexedLocators().isEmpty()) {
            return false;
        }

        ensureProgram();
        if (program == -1 || resolvedBoneSamplerLocation == -1 || locatorDefinitionSamplerLocation == -1 || locatorCountLocation == -1) {
            return false;
        }

        int resolvedBoneTextureId = ChaosGpuBoneResolveDispatcher.resolveAndBind(mesh, localPoseData);
        if (resolvedBoneTextureId < 0) {
            return false;
        }

        MeshState state = CACHE.computeIfAbsent(mesh, ChaosGpuLocatorDataStorage::buildMeshState);
        CachedLocatorPose cached = state.cacheByPoseRef.get(localPoseData);
        if (cached == null) {
            cached = state.acquirePose(localPoseData);
            dispatchResolve(state, resolvedBoneTextureId, cached.textureId());
        }

        bindTextureToUnit(LOCATOR_TEXTURE_UNIT, cached.textureId());
        return true;
    }

    public static void unbindSampler() {
        int activeTexture = GlStateManager._getActiveTexture();
        RenderSystem.activeTexture(GL13.GL_TEXTURE0 + LOCATOR_TEXTURE_UNIT);
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, 0);
        ChaosGlDebug.check("ChaosGpuLocatorDataStorage.unbindSampler.glBindTexture.0");
        GlStateManager._activeTexture(activeTexture);
    }

    private static void dispatchResolve(MeshState state, int resolvedBoneTextureId, int outputTextureId) {
        GL20.glUseProgram(program);
        ChaosGlDebug.check("ChaosGpuLocatorDataStorage.dispatchResolve.glUseProgram");
        try {
            bindTextureToUnit(ChaosGpuBoneDataStorage.BONE_TEXTURE_UNIT, resolvedBoneTextureId);
            bindTextureToUnit(DEFINITION_TEXTURE_UNIT, state.definitionTextureId);
            GL20.glUniform1i(resolvedBoneSamplerLocation, ChaosGpuBoneDataStorage.BONE_TEXTURE_UNIT);
            ChaosGlDebug.check("ChaosGpuLocatorDataStorage.dispatchResolve.glUniform1i.ResolvedBoneSampler");
            GL20.glUniform1i(locatorDefinitionSamplerLocation, DEFINITION_TEXTURE_UNIT);
            ChaosGlDebug.check("ChaosGpuLocatorDataStorage.dispatchResolve.glUniform1i.LocatorDefinitionSampler");
            GL20.glUniform1i(locatorCountLocation, state.locatorCount);
            ChaosGlDebug.check("ChaosGpuLocatorDataStorage.dispatchResolve.glUniform1i.LocatorCount");
            GL30.glBindBufferBase(GL43.GL_SHADER_STORAGE_BUFFER, 0, state.outputBufferIdByTexture.get(outputTextureId));
            ChaosGlDebug.check("ChaosGpuLocatorDataStorage.dispatchResolve.glBindBufferBase.output");
            GL43.glDispatchCompute(Math.max(1, (state.locatorCount + WORKGROUP_SIZE - 1) / WORKGROUP_SIZE), 1, 1);
            ChaosGlDebug.check("ChaosGpuLocatorDataStorage.dispatchResolve.glDispatchCompute");
            GL42.glMemoryBarrier(GL43.GL_SHADER_STORAGE_BARRIER_BIT | GL43.GL_TEXTURE_FETCH_BARRIER_BIT);
            ChaosGlDebug.check("ChaosGpuLocatorDataStorage.dispatchResolve.glMemoryBarrier");
        } finally {
            GL30.glBindBufferBase(GL43.GL_SHADER_STORAGE_BUFFER, 0, 0);
            ChaosGlDebug.check("ChaosGpuLocatorDataStorage.dispatchResolve.cleanup.glBindBufferBase.0");
            unbindInternalSamplers();
            GL20.glUseProgram(0);
            ChaosGlDebug.check("ChaosGpuLocatorDataStorage.dispatchResolve.cleanup.glUseProgram.0");
        }
    }

    private static MeshState buildMeshState(ChaosGpuGeoMesh mesh) {
        float[] definitionData = new float[mesh.getIndexedLocators().size() * 8];
        for (int i = 0; i < mesh.getIndexedLocators().size(); i++) {
            ChaosGpuGeoMesh.IndexedLocator indexedLocator = mesh.getIndexedLocators().get(i);
            GeoLocator locator = indexedLocator.locator();
            int offset = i * 8;
            definitionData[offset] = indexedLocator.boneIndex();
            definitionData[offset + 1] = locator.getOffsetX();
            definitionData[offset + 2] = locator.getOffsetY();
            definitionData[offset + 3] = locator.getOffsetZ();
            definitionData[offset + 4] = locator.getRotX();
            definitionData[offset + 5] = locator.getRotY();
            definitionData[offset + 6] = locator.getRotZ();
            definitionData[offset + 7] = 0.0f;
        }

        int definitionBufferId = GL15.glGenBuffers();
        ChaosGlDebug.check("ChaosGpuLocatorDataStorage.buildMeshState.glGenBuffers.definition");
        int definitionTextureId = GL11.glGenTextures();
        ChaosGlDebug.check("ChaosGpuLocatorDataStorage.buildMeshState.glGenTextures.definition");
        FloatBuffer upload = DEFINITION_UPLOAD_BUFFER.get().prepare(definitionData);
        GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, definitionBufferId);
        ChaosGlDebug.check("ChaosGpuLocatorDataStorage.buildMeshState.glBindBuffer.definition");
        GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, upload, GL15.GL_STATIC_DRAW);
        ChaosGlDebug.check("ChaosGpuLocatorDataStorage.buildMeshState.glBufferData.definition");
        attachTextureBuffer(definitionTextureId, GL30.GL_RGBA32F, definitionBufferId);
        GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, 0);
        ChaosGlDebug.check("ChaosGpuLocatorDataStorage.buildMeshState.glBindBuffer.0");
        return new MeshState(mesh.getIndexedLocators().size(), definitionBufferId, definitionTextureId);
    }

    private static void ensureProgram() {
        if (program != -1) {
            return;
        }

        int shader = GL20.glCreateShader(GL43.GL_COMPUTE_SHADER);
        ChaosGlDebug.check("ChaosGpuLocatorDataStorage.ensureProgram.glCreateShader");
        GL20.glShaderSource(shader, COMPUTE_SHADER);
        ChaosGlDebug.check("ChaosGpuLocatorDataStorage.ensureProgram.glShaderSource");
        GL20.glCompileShader(shader);
        ChaosGlDebug.check("ChaosGpuLocatorDataStorage.ensureProgram.glCompileShader");
        if (GL20.glGetShaderi(shader, GL20.GL_COMPILE_STATUS) == GL11.GL_FALSE) {
            ChaosGlDebug.check("ChaosGpuLocatorDataStorage.ensureProgram.glGetShaderi.COMPILE_STATUS");
            String log = GL20.glGetShaderInfoLog(shader);
            ChaosGlDebug.check("ChaosGpuLocatorDataStorage.ensureProgram.glGetShaderInfoLog");
            GL20.glDeleteShader(shader);
            ChaosGlDebug.check("ChaosGpuLocatorDataStorage.ensureProgram.glDeleteShader.failed");
            throw new IllegalStateException("Failed to compile Chaos GPU locator compute shader: " + log);
        }
        ChaosGlDebug.check("ChaosGpuLocatorDataStorage.ensureProgram.glGetShaderi.COMPILE_STATUS");

        int glProgram = GL20.glCreateProgram();
        ChaosGlDebug.check("ChaosGpuLocatorDataStorage.ensureProgram.glCreateProgram");
        GL20.glAttachShader(glProgram, shader);
        ChaosGlDebug.check("ChaosGpuLocatorDataStorage.ensureProgram.glAttachShader");
        GL20.glLinkProgram(glProgram);
        ChaosGlDebug.check("ChaosGpuLocatorDataStorage.ensureProgram.glLinkProgram");
        GL20.glDetachShader(glProgram, shader);
        ChaosGlDebug.check("ChaosGpuLocatorDataStorage.ensureProgram.glDetachShader");
        GL20.glDeleteShader(shader);
        ChaosGlDebug.check("ChaosGpuLocatorDataStorage.ensureProgram.glDeleteShader");
        if (GL20.glGetProgrami(glProgram, GL20.GL_LINK_STATUS) == GL11.GL_FALSE) {
            ChaosGlDebug.check("ChaosGpuLocatorDataStorage.ensureProgram.glGetProgrami.LINK_STATUS");
            String log = GL20.glGetProgramInfoLog(glProgram);
            ChaosGlDebug.check("ChaosGpuLocatorDataStorage.ensureProgram.glGetProgramInfoLog");
            GL20.glDeleteProgram(glProgram);
            ChaosGlDebug.check("ChaosGpuLocatorDataStorage.ensureProgram.glDeleteProgram.failed");
            throw new IllegalStateException("Failed to link Chaos GPU locator compute program: " + log);
        }
        ChaosGlDebug.check("ChaosGpuLocatorDataStorage.ensureProgram.glGetProgrami.LINK_STATUS");

        program = glProgram;
        resolvedBoneSamplerLocation = GL20.glGetUniformLocation(glProgram, "ResolvedBoneSampler");
        ChaosGlDebug.check("ChaosGpuLocatorDataStorage.ensureProgram.glGetUniformLocation.ResolvedBoneSampler");
        locatorDefinitionSamplerLocation = GL20.glGetUniformLocation(glProgram, "LocatorDefinitionSampler");
        ChaosGlDebug.check("ChaosGpuLocatorDataStorage.ensureProgram.glGetUniformLocation.LocatorDefinitionSampler");
        locatorCountLocation = GL20.glGetUniformLocation(glProgram, "LocatorCount");
        ChaosGlDebug.check("ChaosGpuLocatorDataStorage.ensureProgram.glGetUniformLocation.LocatorCount");
    }

    private static void bindTextureToUnit(int textureUnit, int textureId) {
        int activeTexture = GlStateManager._getActiveTexture();
        RenderSystem.activeTexture(GL13.GL_TEXTURE0 + textureUnit);
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, textureId);
        ChaosGlDebug.check("ChaosGpuLocatorDataStorage.bindTextureToUnit.glBindTexture." + textureUnit);
        GlStateManager._activeTexture(activeTexture);
    }

    private static void unbindInternalSamplers() {
        int activeTexture = GlStateManager._getActiveTexture();
        RenderSystem.activeTexture(GL13.GL_TEXTURE0 + ChaosGpuBoneDataStorage.BONE_TEXTURE_UNIT);
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, 0);
        ChaosGlDebug.check("ChaosGpuLocatorDataStorage.unbindInternalSamplers.glBindTexture.bone.0");
        RenderSystem.activeTexture(GL13.GL_TEXTURE0 + DEFINITION_TEXTURE_UNIT);
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, 0);
        ChaosGlDebug.check("ChaosGpuLocatorDataStorage.unbindInternalSamplers.glBindTexture.definition.0");
        GlStateManager._activeTexture(activeTexture);
    }

    private static void attachTextureBuffer(int textureId, int internalFormat, int bufferId) {
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, textureId);
        ChaosGlDebug.check("ChaosGpuLocatorDataStorage.attachTextureBuffer.glBindTexture");
        if (GL.getCapabilities().OpenGL31) {
            GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, internalFormat, bufferId);
            ChaosGlDebug.check("ChaosGpuLocatorDataStorage.attachTextureBuffer.glTexBuffer");
        } else {
            ARBTextureBufferObject.glTexBufferARB(ARBTextureBufferObject.GL_TEXTURE_BUFFER_ARB, internalFormat, bufferId);
            ChaosGlDebug.check("ChaosGpuLocatorDataStorage.attachTextureBuffer.glTexBufferARB");
        }
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, 0);
        ChaosGlDebug.check("ChaosGpuLocatorDataStorage.attachTextureBuffer.glBindTexture.0");
    }

    private static final class MeshState implements AutoCloseable {
        private final int locatorCount;
        private final int definitionBufferId;
        private final int definitionTextureId;
        private final IdentityHashMap<Object, CachedLocatorPose> cacheByPoseRef = new IdentityHashMap<>();
        private final ArrayDeque<Object> cacheOrder = new ArrayDeque<>();
        private final Map<Integer, Integer> outputBufferIdByTexture = new IdentityHashMap<>();

        private MeshState(int locatorCount, int definitionBufferId, int definitionTextureId) {
            this.locatorCount = locatorCount;
            this.definitionBufferId = definitionBufferId;
            this.definitionTextureId = definitionTextureId;
        }

        private CachedLocatorPose acquirePose(Object poseDataRef) {
            CachedLocatorPose cached = this.cacheByPoseRef.get(poseDataRef);
            if (cached != null) {
                return cached;
            }

            CachedLocatorPose pose;
            if (this.cacheOrder.size() >= MAX_CACHED_LOCATOR_POSES_PER_MESH) {
                Object oldestRef = this.cacheOrder.removeFirst();
                CachedLocatorPose oldest = this.cacheByPoseRef.remove(oldestRef);
                if (oldest != null) {
                    pose = oldest;
                } else {
                    pose = this.createPose();
                }
            } else {
                pose = this.createPose();
            }
            this.cacheByPoseRef.put(poseDataRef, pose);
            this.cacheOrder.addLast(poseDataRef);
            this.outputBufferIdByTexture.put(pose.textureId(), pose.bufferId());
            return pose;
        }

        private CachedLocatorPose createPose() {
            int bufferId = GL15.glGenBuffers();
            ChaosGlDebug.check("ChaosGpuLocatorDataStorage.MeshState.createPose.glGenBuffers");
            int textureId = GL11.glGenTextures();
            ChaosGlDebug.check("ChaosGpuLocatorDataStorage.MeshState.createPose.glGenTextures");
            long byteSize = (long) this.locatorCount * 16L * Float.BYTES;
            GL15.glBindBuffer(GL43.GL_SHADER_STORAGE_BUFFER, bufferId);
            ChaosGlDebug.check("ChaosGpuLocatorDataStorage.MeshState.createPose.glBindBuffer");
            GL15.glBufferData(GL43.GL_SHADER_STORAGE_BUFFER, byteSize, GL15.GL_DYNAMIC_DRAW);
            ChaosGlDebug.check("ChaosGpuLocatorDataStorage.MeshState.createPose.glBufferData");
            GL15.glBindBuffer(GL43.GL_SHADER_STORAGE_BUFFER, 0);
            ChaosGlDebug.check("ChaosGpuLocatorDataStorage.MeshState.createPose.glBindBuffer.0");
            attachTextureBuffer(textureId, GL30.GL_RGBA32F, bufferId);
            return new CachedLocatorPose(bufferId, textureId);
        }

        @Override
        public void close() {
            GL15.glDeleteBuffers(this.definitionBufferId);
            ChaosGlDebug.check("ChaosGpuLocatorDataStorage.MeshState.close.glDeleteBuffers.definition");
            GL11.glDeleteTextures(this.definitionTextureId);
            ChaosGlDebug.check("ChaosGpuLocatorDataStorage.MeshState.close.glDeleteTextures.definition");
            for (CachedLocatorPose pose : this.cacheByPoseRef.values()) {
                pose.close();
            }
            this.cacheByPoseRef.clear();
            this.cacheOrder.clear();
            this.outputBufferIdByTexture.clear();
        }
    }

    private record CachedLocatorPose(int bufferId, int textureId) implements AutoCloseable {
        @Override
        public void close() {
            GL15.glDeleteBuffers(this.bufferId);
            ChaosGlDebug.check("ChaosGpuLocatorDataStorage.CachedLocatorPose.close.glDeleteBuffers");
            GL11.glDeleteTextures(this.textureId);
            ChaosGlDebug.check("ChaosGpuLocatorDataStorage.CachedLocatorPose.close.glDeleteTextures");
        }
    }

    private static final class UploadBuffer {
        private FloatBuffer buffer = MemoryUtil.memAllocFloat(16);

        private FloatBuffer prepare(float[] source) {
            if (this.buffer.capacity() < source.length) {
                MemoryUtil.memFree(this.buffer);
                this.buffer = MemoryUtil.memAllocFloat(source.length);
            }
            this.buffer.clear();
            this.buffer.put(source);
            this.buffer.flip();
            return this.buffer;
        }
    }
}
