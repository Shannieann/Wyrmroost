package dev.elifian.chaoslib.gpu.backend;

import net.minecraft.client.multiplayer.ClientLevel;

import dev.elifian.chaoslib.platform.ClientOnly;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

@ClientOnly
public final class ChaosGpuWorldLightUpdateDispatcher {
    @FunctionalInterface
    public interface SectionListener {
        void onSectionLightDirty(ClientLevel world, long sectionPos, int lightMask);
    }

    @FunctionalInterface
    public interface ColumnListener {
        void onColumnLightDirty(ClientLevel world, long chunkPos, int lightMask);
    }

    private static final List<SectionListener> SECTION_LISTENERS = new CopyOnWriteArrayList<>();
    private static final List<ColumnListener> COLUMN_LISTENERS = new CopyOnWriteArrayList<>();

    private ChaosGpuWorldLightUpdateDispatcher() {
    }

    public static void registerSectionListener(SectionListener listener) {
        SECTION_LISTENERS.add(listener);
    }

    public static void registerColumnListener(ColumnListener listener) {
        COLUMN_LISTENERS.add(listener);
    }

    public static void postSectionDirty(ClientLevel world, long sectionPos, int lightMask) {
        if (world == null || lightMask == 0) {
            return;
        }

        for (SectionListener listener : SECTION_LISTENERS) {
            listener.onSectionLightDirty(world, sectionPos, lightMask);
        }
    }

    public static void postColumnDirty(ClientLevel world, long chunkPos, int lightMask) {
        if (world == null || lightMask == 0) {
            return;
        }

        for (ColumnListener listener : COLUMN_LISTENERS) {
            listener.onColumnLightDirty(world, chunkPos, lightMask);
        }
    }
}
