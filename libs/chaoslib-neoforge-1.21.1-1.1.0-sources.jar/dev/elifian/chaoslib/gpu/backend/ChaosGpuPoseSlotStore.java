package dev.elifian.chaoslib.gpu.backend;

import dev.elifian.chaoslib.gpu.mesh.ChaosGpuGeoMesh;

import dev.elifian.chaoslib.platform.ClientOnly;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

@ClientOnly
public final class ChaosGpuPoseSlotStore {
    private static final int SLOT_RETENTION_FRAMES = 60;

    private static final Map<SlotKey, Slot> SLOTS = new HashMap<>();

    private static int frameId;

    private ChaosGpuPoseSlotStore() {
    }

    public static boolean isSupported() {
        return ChaosGpuPoseArena.isSupported()
                && ChaosGpuRuntimePolicy.getAnimationBackendMode() == ChaosGpuRuntimePolicy.AnimationBackendMode.COMPUTE;
    }

    public static void beginFrame() {
        frameId++;
        if (frameId == 0) {
            frameId = 1;
        }

        for (Iterator<Map.Entry<SlotKey, Slot>> iterator = SLOTS.entrySet().iterator(); iterator.hasNext(); ) {
            Slot slot = iterator.next().getValue();
            if (frameId - slot.lastUsedFrame < SLOT_RETENTION_FRAMES) {
                continue;
            }

            iterator.remove();
            ChaosGpuPoseArena.free(slot.poseBase, slot.boneCount);
        }
    }

    public static @Nullable Slot acquire(ChaosGpuGeoMesh mesh, Object owner, int boneCount) {
        SlotKey slotKey = new SlotKey(mesh, owner);
        Slot slot = SLOTS.get(slotKey);
        if (slot != null && slot.boneCount == boneCount) {
            slot.lastUsedFrame = frameId;
            return slot;
        }

        if (slot != null) {
            SLOTS.remove(slotKey);
            ChaosGpuPoseArena.free(slot.poseBase, slot.boneCount);
        }

        int poseBase = ChaosGpuPoseArena.allocate(boneCount);
        if (poseBase < 0) {
            return null;
        }

        Slot created = new Slot(poseBase, boneCount, frameId);
        SLOTS.put(slotKey, created);
        return created;
    }

    public static void invalidateAll() {
        SLOTS.clear();
        ChaosGpuPoseArena.invalidateAll();
    }

    public static final class Slot {
        private final int poseBase;
        private final int boneCount;
        private int lastUsedFrame;
        private @Nullable Object animationKey;
        private @Nullable Object poseHandle;

        private Slot(int poseBase, int boneCount, int lastUsedFrame) {
            this.poseBase = poseBase;
            this.boneCount = boneCount;
            this.lastUsedFrame = lastUsedFrame;
        }

        public int poseBase() {
            return this.poseBase;
        }

        public boolean holds(Object animationKey) {
            return this.animationKey != null && this.animationKey.equals(animationKey) && this.poseHandle != null;
        }

        public @Nullable Object poseHandle() {
            return this.poseHandle;
        }

        public void update(Object animationKey, Object poseHandle) {
            this.animationKey = animationKey;
            this.poseHandle = poseHandle;
        }
    }

    private record SlotKey(ChaosGpuGeoMesh mesh, Object owner) {
    }
}
