package dev.elifian.chaoslib.gpu.backend;

import dev.elifian.chaoslib.gpu.debug.ChaosGlDebug;

import dev.elifian.chaoslib.platform.ClientOnly;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL31;
import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;

@ClientOnly
public final class ChaosGpuStreamingTextureBuffer implements AutoCloseable {
    private static final int RING_SIZE = 3;

    private final int internalFormat;
    private final int[] bufferIds = new int[RING_SIZE];
    private final int[] textureIds = new int[RING_SIZE];
    private final long[] capacities = new long[RING_SIZE];

    private int ringIndex;
    private ByteBuffer staging = MemoryUtil.memAlloc(1024);

    public ChaosGpuStreamingTextureBuffer(int internalFormat) {
        this.internalFormat = internalFormat;
        for (int i = 0; i < RING_SIZE; i++) {
            this.bufferIds[i] = GL15.glGenBuffers();
            this.textureIds[i] = GL11.glGenTextures();
        }
    }

    public int upload(float[] data, int length) {
        FloatBuffer buffer = this.staging(length * Float.BYTES).asFloatBuffer();
        buffer.put(data, 0, length);
        buffer.flip();
        return this.uploadStaging((long) length * Float.BYTES);
    }

    public int upload(int[] data, int length) {
        IntBuffer buffer = this.staging(length * Integer.BYTES).asIntBuffer();
        buffer.put(data, 0, length);
        buffer.flip();
        return this.uploadStaging((long) length * Integer.BYTES);
    }

    public int currentTextureId() {
        return this.textureIds[this.ringIndex];
    }

    @Override
    public void close() {
        for (int i = 0; i < RING_SIZE; i++) {
            if (this.textureIds[i] != 0) {
                GL11.glDeleteTextures(this.textureIds[i]);
                this.textureIds[i] = 0;
            }
            if (this.bufferIds[i] != 0) {
                GL15.glDeleteBuffers(this.bufferIds[i]);
                this.bufferIds[i] = 0;
            }
            this.capacities[i] = 0L;
        }

        if (this.staging != null) {
            MemoryUtil.memFree(this.staging);
            this.staging = null;
        }
    }

    private ByteBuffer staging(int byteSize) {
        if (this.staging.capacity() < byteSize) {
            MemoryUtil.memFree(this.staging);
            this.staging = MemoryUtil.memAlloc(byteSize);
        }

        this.staging.clear();
        this.staging.limit(byteSize);
        return this.staging;
    }

    private int uploadStaging(long byteSize) {
        this.ringIndex = (this.ringIndex + 1) % RING_SIZE;
        int bufferId = this.bufferIds[this.ringIndex];
        int textureId = this.textureIds[this.ringIndex];

        this.staging.position(0);
        this.staging.limit((int) byteSize);

        GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, bufferId);
        if (this.capacities[this.ringIndex] < byteSize) {
            GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, this.staging, GL15.GL_STREAM_DRAW);
            ChaosGlDebug.check("ChaosGpuStreamingTextureBuffer.uploadStaging.glBufferData");
            GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, textureId);
            GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, this.internalFormat, bufferId);
            ChaosGlDebug.check("ChaosGpuStreamingTextureBuffer.uploadStaging.glTexBuffer");
            GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, 0);
            this.capacities[this.ringIndex] = byteSize;
        } else {
            GL15.glBufferSubData(GL31.GL_TEXTURE_BUFFER, 0L, this.staging);
            ChaosGlDebug.check("ChaosGpuStreamingTextureBuffer.uploadStaging.glBufferSubData");
        }
        GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, 0);

        return textureId;
    }
}
