package dev.elifian.chaoslib.gpu.backend;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.elifian.chaoslib.gpu.debug.ChaosGlDebug;
import dev.elifian.chaoslib.gpu.mesh.ChaosGpuGeoMesh;

import dev.elifian.chaoslib.platform.ClientOnly;
import org.lwjgl.opengl.*;
import org.lwjgl.system.MemoryUtil;

import java.nio.FloatBuffer;

@ClientOnly
public final class ChaosGpuBoneDataStorage {
    public static final int BONE_TEXTURE_UNIT = 3;
    public static final int EMISSIVE_TEXTURE_UNIT = 4;
    private static final ThreadLocal<UploadBuffer> BONE_UPLOAD_BUFFER = ThreadLocal.withInitial(UploadBuffer::new);
    private static final ThreadLocal<UploadBuffer> EMISSIVE_UPLOAD_BUFFER = ThreadLocal.withInitial(UploadBuffer::new);
    private static int boneBufferId = -1;
    private static int boneTextureId = -1;
    private static int emissiveBufferId = -1;
    private static int emissiveTextureId = -1;
    private static long boneBufferCapacity;
    private static long emissiveBufferCapacity;
    private static boolean boneTextureAttached;
    private static boolean emissiveTextureAttached;
    private static float[] lastUploadedBonePoseData;
    private static float[] lastUploadedEmissiveMaskData;

    private ChaosGpuBoneDataStorage() {
    }

    public static boolean usesResolvedBoneBackend() {
        return ChaosGpuBoneResolveDispatcher.usesResolvedBackend();
    }

    public static boolean isSupported() {
        return ChaosGpuRuntimePolicy.isTextureBufferSupported();
    }

    public static boolean isInstancingSupported() {
        return ChaosGpuRuntimePolicy.isInstancingSupported();
    }

    public static void invalidateAll() {
        if (boneTextureId != -1) {
            GL11.glDeleteTextures(boneTextureId);
            ChaosGlDebug.check("ChaosGpuBoneDataStorage.invalidateAll.glDeleteTextures.bone");
            boneTextureId = -1;
        }
        if (boneBufferId != -1) {
            GL15.glDeleteBuffers(boneBufferId);
            ChaosGlDebug.check("ChaosGpuBoneDataStorage.invalidateAll.glDeleteBuffers.bone");
            boneBufferId = -1;
        }
        if (emissiveTextureId != -1) {
            GL11.glDeleteTextures(emissiveTextureId);
            ChaosGlDebug.check("ChaosGpuBoneDataStorage.invalidateAll.glDeleteTextures.emissive");
            emissiveTextureId = -1;
        }
        if (emissiveBufferId != -1) {
            GL15.glDeleteBuffers(emissiveBufferId);
            ChaosGlDebug.check("ChaosGpuBoneDataStorage.invalidateAll.glDeleteBuffers.emissive");
            emissiveBufferId = -1;
        }
        lastUploadedBonePoseData = null;
        lastUploadedEmissiveMaskData = null;
        boneBufferCapacity = 0L;
        emissiveBufferCapacity = 0L;
        boneTextureAttached = false;
        emissiveTextureAttached = false;
    }

    public static boolean bindForStandardShaders(ChaosGpuGeoMesh mesh, Object localPoseData, float[] emissiveMaskData) {
        if (!isSupported()) {
            return false;
        }

        if (!bindPoseForStandardShaders(mesh, localPoseData)) {
            return false;
        }

        uploadEmissiveMaskDataIfNeeded(emissiveMaskData);
        bindTextureToUnit(EMISSIVE_TEXTURE_UNIT, emissiveTextureId);
        return true;
    }

    public static boolean bindPoseForStandardShaders(ChaosGpuGeoMesh mesh, Object localPoseData) {
        if (!isSupported()) {
            return false;
        }


        ensureInitialized();
        if (usesResolvedBoneBackend()) {
            int resolvedTextureId = ChaosGpuBoneResolveDispatcher.resolveAndBind(mesh, localPoseData);
            if (resolvedTextureId < 0) {
                return false;
            }
        } else {
            int poseTextureId = ChaosGpuAnimationPoseStorage.textureIdFor(localPoseData);
            if (poseTextureId >= 0) {
                bindTextureToUnit(BONE_TEXTURE_UNIT, poseTextureId);
            } else {
                if (!(localPoseData instanceof float[] rawLocalPoseData)) {
                    return false;
                }
                uploadBonePoseDataIfNeeded(rawLocalPoseData);
                bindTextureToUnit(BONE_TEXTURE_UNIT, boneTextureId);
            }
        }
        return true;
    }

    public static boolean bindRawForInstancedShaders(float[] batchedLocalPoseData, float[] batchedEmissiveMaskData) {
        return bindRawForInstancedShaders(batchedLocalPoseData, batchedLocalPoseData.length, batchedEmissiveMaskData, batchedEmissiveMaskData.length);
    }

    public static boolean bindRawForInstancedShaders(float[] batchedLocalPoseData, int bonePoseLength, float[] batchedEmissiveMaskData, int emissiveMaskLength) {
        if (!isSupported()) {
            return false;
        }

        ensureInitialized();
        uploadBonePoseData(batchedLocalPoseData, bonePoseLength, false);
        uploadEmissiveMaskData(batchedEmissiveMaskData, emissiveMaskLength, false);
        int activeTexture = GlStateManager._getActiveTexture();
        bindTextureToUnitRaw(BONE_TEXTURE_UNIT, boneTextureId);
        bindTextureToUnitRaw(EMISSIVE_TEXTURE_UNIT, emissiveTextureId);
        GlStateManager._activeTexture(activeTexture);
        return true;
    }

    public static boolean bindPoseTextureForInstancedShaders(int poseTextureId, float[] batchedEmissiveMaskData) {
        return bindPoseTextureForInstancedShaders(poseTextureId, batchedEmissiveMaskData, batchedEmissiveMaskData.length);
    }

    public static boolean bindPoseTextureForInstancedShaders(int poseTextureId, float[] batchedEmissiveMaskData, int emissiveMaskLength) {
        if (!isSupported()) {
            return false;
        }

        ensureInitialized();
        uploadEmissiveMaskData(batchedEmissiveMaskData, emissiveMaskLength, false);
        int activeTexture = GlStateManager._getActiveTexture();
        bindTextureToUnitRaw(BONE_TEXTURE_UNIT, poseTextureId);
        bindTextureToUnitRaw(EMISSIVE_TEXTURE_UNIT, emissiveTextureId);
        GlStateManager._activeTexture(activeTexture);
        return true;
    }

    public static void unbindSamplers() {
        int activeTexture = GlStateManager._getActiveTexture();
        RenderSystem.activeTexture(GL13.GL_TEXTURE0 + BONE_TEXTURE_UNIT);
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, 0);
        ChaosGlDebug.check("ChaosGpuBoneDataStorage.unbindSamplers.glBindTexture.bone.0");
        RenderSystem.activeTexture(GL13.GL_TEXTURE0 + EMISSIVE_TEXTURE_UNIT);
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, 0);
        ChaosGlDebug.check("ChaosGpuBoneDataStorage.unbindSamplers.glBindTexture.emissive.0");
        GlStateManager._activeTexture(activeTexture);
    }

    private static void ensureInitialized() {
        if (boneBufferId == -1) {
            boneBufferId = GL15.glGenBuffers();
            ChaosGlDebug.check("ChaosGpuBoneDataStorage.ensureInitialized.glGenBuffers.bone");
            boneTextureId = GL11.glGenTextures();
            ChaosGlDebug.check("ChaosGpuBoneDataStorage.ensureInitialized.glGenTextures.bone");
        }

        if (emissiveBufferId != -1) {
            return;
        }

        emissiveBufferId = GL15.glGenBuffers();
        ChaosGlDebug.check("ChaosGpuBoneDataStorage.ensureInitialized.glGenBuffers.emissive");
        emissiveTextureId = GL11.glGenTextures();
        ChaosGlDebug.check("ChaosGpuBoneDataStorage.ensureInitialized.glGenTextures.emissive");
    }

    private static void uploadBonePoseDataIfNeeded(float[] bonePoseData) {
        if (bonePoseData == lastUploadedBonePoseData) {
            return;
        }
        uploadBonePoseData(bonePoseData, bonePoseData.length, true);
        lastUploadedBonePoseData = bonePoseData;
    }

    private static void uploadEmissiveMaskDataIfNeeded(float[] emissiveMaskData) {
        if (emissiveMaskData == lastUploadedEmissiveMaskData) {
            return;
        }
        uploadEmissiveMaskData(emissiveMaskData, emissiveMaskData.length, true);
        lastUploadedEmissiveMaskData = emissiveMaskData;
    }

    private static void uploadBonePoseData(float[] bonePoseData, int length, boolean cacheByReference) {
        FloatBuffer buffer = BONE_UPLOAD_BUFFER.get().prepare(bonePoseData, length);
        long requiredBytes = (long) length * Float.BYTES;
        GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, boneBufferId);
        ChaosGlDebug.check("ChaosGpuBoneDataStorage.uploadBonePoseData.glBindBuffer");
        if (boneBufferCapacity < requiredBytes) {
            boneBufferCapacity = Math.max(requiredBytes, Math.max(1024L, boneBufferCapacity << 1));
            GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, boneBufferCapacity, GL15.GL_DYNAMIC_DRAW);
            ChaosGlDebug.check("ChaosGpuBoneDataStorage.uploadBonePoseData.glBufferData.capacity");
            if (!boneTextureAttached) {
                boneTextureAttached = true;
            }
            attachTextureBuffer(boneTextureId, GL30.GL_RGBA32F, boneBufferId);
        }
        GL15.glBufferSubData(GL31.GL_TEXTURE_BUFFER, 0L, buffer);
        ChaosGlDebug.check("ChaosGpuBoneDataStorage.uploadBonePoseData.glBufferSubData");
        GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, 0);
        ChaosGlDebug.check("ChaosGpuBoneDataStorage.uploadBonePoseData.glBindBuffer.0");
        if (!cacheByReference) {
            lastUploadedBonePoseData = null;
        }
    }

    private static void uploadEmissiveMaskData(float[] emissiveMaskData, int length, boolean cacheByReference) {
        FloatBuffer buffer = EMISSIVE_UPLOAD_BUFFER.get().prepare(emissiveMaskData, length);
        long requiredBytes = (long) length * Float.BYTES;
        GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, emissiveBufferId);
        ChaosGlDebug.check("ChaosGpuBoneDataStorage.uploadEmissiveMaskData.glBindBuffer");
        if (emissiveBufferCapacity < requiredBytes) {
            emissiveBufferCapacity = Math.max(requiredBytes, Math.max(256L, emissiveBufferCapacity << 1));
            GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, emissiveBufferCapacity, GL15.GL_DYNAMIC_DRAW);
            ChaosGlDebug.check("ChaosGpuBoneDataStorage.uploadEmissiveMaskData.glBufferData.capacity");
            if (!emissiveTextureAttached) {
                emissiveTextureAttached = true;
            }
            attachTextureBuffer(emissiveTextureId, GL30.GL_R32F, emissiveBufferId);
        }
        GL15.glBufferSubData(GL31.GL_TEXTURE_BUFFER, 0L, buffer);
        ChaosGlDebug.check("ChaosGpuBoneDataStorage.uploadEmissiveMaskData.glBufferSubData");
        GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, 0);
        ChaosGlDebug.check("ChaosGpuBoneDataStorage.uploadEmissiveMaskData.glBindBuffer.0");
        if (!cacheByReference) {
            lastUploadedEmissiveMaskData = null;
        }
    }

    private static void bindTextureToUnit(int textureUnit, int textureId) {
        int activeTexture = GlStateManager._getActiveTexture();
        bindTextureToUnitRaw(textureUnit, textureId);
        GlStateManager._activeTexture(activeTexture);
    }

    private static void bindTextureToUnitRaw(int textureUnit, int textureId) {
        RenderSystem.activeTexture(GL13.GL_TEXTURE0 + textureUnit);
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, textureId);
        ChaosGlDebug.check("ChaosGpuBoneDataStorage.bindTextureToUnit.glBindTexture." + textureUnit);
    }

    private static void attachTextureBuffer(int textureId, int internalFormat, int bufferId) {
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, textureId);
        ChaosGlDebug.check("ChaosGpuBoneDataStorage.attachTextureBuffer.glBindTexture");
        if (GL.getCapabilities().OpenGL31) {
            GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, internalFormat, bufferId);
            ChaosGlDebug.check("ChaosGpuBoneDataStorage.attachTextureBuffer.glTexBuffer");
        } else {
            ARBTextureBufferObject.glTexBufferARB(ARBTextureBufferObject.GL_TEXTURE_BUFFER_ARB, internalFormat, bufferId);
            ChaosGlDebug.check("ChaosGpuBoneDataStorage.attachTextureBuffer.glTexBufferARB");
        }
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, 0);
        ChaosGlDebug.check("ChaosGpuBoneDataStorage.attachTextureBuffer.glBindTexture.0");
    }

    private static final class UploadBuffer {
        private FloatBuffer buffer = MemoryUtil.memAllocFloat(16);

        private FloatBuffer prepare(float[] source) {
            return prepare(source, source.length);
        }

        private FloatBuffer prepare(float[] source, int length) {
            if (this.buffer.capacity() < length) {
                MemoryUtil.memFree(this.buffer);
                this.buffer = MemoryUtil.memAllocFloat(length);
            }

            this.buffer.clear();
            this.buffer.put(source, 0, length);
            this.buffer.flip();
            return this.buffer;
        }
    }
}
