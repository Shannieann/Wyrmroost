package dev.elifian.chaoslib.gpu.backend;

import dev.elifian.chaoslib.gpu.animation.ChaosGpuAnimationPayload;
import dev.elifian.chaoslib.gpu.mesh.ChaosGpuGeoMesh;

import dev.elifian.chaoslib.platform.ClientOnly;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@ClientOnly
public final class ChaosGpuAnimationBatchScheduler {
    private static final Map<GroupKey, List<PendingRequest>> PENDING = new LinkedHashMap<>();

    private static boolean flushing;

    private ChaosGpuAnimationBatchScheduler() {
    }

    public static void submit(
            ChaosGpuGeoMesh mesh,
            ChaosGpuAnimationPayload payload,
            int poseBase,
            Object activeStateCollection) {
        PENDING.computeIfAbsent(new GroupKey(mesh, payload), ignored -> new ArrayList<>())
                .add(new PendingRequest(poseBase, activeStateCollection));
    }

    public static boolean hasPendingWork() {
        return !PENDING.isEmpty();
    }

    public static void flush(GroupDispatcher dispatcher) {
        if (PENDING.isEmpty() || flushing) {
            return;
        }

        flushing = true;
        try {
            for (Map.Entry<GroupKey, List<PendingRequest>> group : PENDING.entrySet()) {
                List<PendingRequest> requests = group.getValue();
                if (!requests.isEmpty()) {
                    dispatcher.dispatch(group.getKey().mesh(), group.getKey().payload(), requests);
                }
            }
        } finally {
            PENDING.clear();
            flushing = false;
        }
    }

    public static void discardPending() {
        PENDING.clear();
    }

    public interface GroupDispatcher {
        void dispatch(ChaosGpuGeoMesh mesh, ChaosGpuAnimationPayload payload, List<PendingRequest> requests);
    }

    public record PendingRequest(int poseBase, Object activeStateCollection) {
    }

    private record GroupKey(ChaosGpuGeoMesh mesh, ChaosGpuAnimationPayload payload) {
    }
}
