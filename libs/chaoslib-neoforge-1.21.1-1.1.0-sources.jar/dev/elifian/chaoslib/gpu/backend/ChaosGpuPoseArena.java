package dev.elifian.chaoslib.gpu.backend;

import dev.elifian.chaoslib.gpu.debug.ChaosGlDebug;

import dev.elifian.chaoslib.platform.ClientOnly;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GL31;
import org.lwjgl.opengl.GL42;
import org.lwjgl.opengl.GL43;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Map;

@ClientOnly
public final class ChaosGpuPoseArena {
    private static final int TEXELS_PER_BONE = 4;
    private static final int INITIAL_TEXEL_CAPACITY = 65536;

    private static final Map<Integer, ArrayDeque<Integer>> FREE_SLOTS = new HashMap<>();

    private static int bufferId = -1;
    private static int textureId = -1;
    private static int texelCapacity;
    private static int usedTexels;

    private ChaosGpuPoseArena() {
    }

    public static boolean isSupported() {
        return ChaosGpuRuntimePolicy.isTextureBufferSupported();
    }

    public static int getBufferId() {
        ensureInitialized();
        return bufferId;
    }

    public static int getTextureId() {
        ensureInitialized();
        return textureId;
    }

    public static int allocate(int boneCount) {
        int texels = boneCount * TEXELS_PER_BONE;
        if (texels <= 0) {
            return -1;
        }

        ArrayDeque<Integer> freeSlots = FREE_SLOTS.get(texels);
        if (freeSlots != null && !freeSlots.isEmpty()) {
            return freeSlots.pollFirst();
        }

        if (!ensureCapacity(usedTexels + texels)) {
            return -1;
        }

        int poseBase = usedTexels;
        usedTexels += texels;
        return poseBase;
    }

    public static void free(int poseBase, int boneCount) {
        int texels = boneCount * TEXELS_PER_BONE;
        if (poseBase < 0 || texels <= 0) {
            return;
        }

        FREE_SLOTS.computeIfAbsent(texels, ignored -> new ArrayDeque<>()).addLast(poseBase);
    }

    public static void invalidateAll() {
        if (textureId != -1) {
            GL11.glDeleteTextures(textureId);
            ChaosGlDebug.check("ChaosGpuPoseArena.invalidateAll.glDeleteTextures");
            textureId = -1;
        }
        if (bufferId != -1) {
            GL15.glDeleteBuffers(bufferId);
            ChaosGlDebug.check("ChaosGpuPoseArena.invalidateAll.glDeleteBuffers");
            bufferId = -1;
        }

        FREE_SLOTS.clear();
        texelCapacity = 0;
        usedTexels = 0;
    }

    private static boolean ensureCapacity(int requiredTexels) {
        ensureInitialized();
        if (bufferId == -1) {
            return false;
        }
        if (texelCapacity >= requiredTexels) {
            return true;
        }

        int grownCapacity = Math.max(requiredTexels, Math.max(INITIAL_TEXEL_CAPACITY, texelCapacity * 2));
        int grownBufferId = GL15.glGenBuffers();
        GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, grownBufferId);
        GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, (long) grownCapacity * 4 * Float.BYTES, GL15.GL_DYNAMIC_DRAW);
        if (ChaosGlDebug.failIfErrored("ChaosGpuPoseArena.ensureCapacity.glBufferData")) {
            GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, 0);
            GL15.glDeleteBuffers(grownBufferId);
            return false;
        }

        if (usedTexels > 0) {
            GL42.glMemoryBarrier(GL43.GL_SHADER_STORAGE_BARRIER_BIT | GL42.GL_BUFFER_UPDATE_BARRIER_BIT);
            ChaosGlDebug.check("ChaosGpuPoseArena.ensureCapacity.glMemoryBarrier");
            GL15.glBindBuffer(GL31.GL_COPY_READ_BUFFER, bufferId);
            GL15.glBindBuffer(GL31.GL_COPY_WRITE_BUFFER, grownBufferId);
            GL31.glCopyBufferSubData(
                    GL31.GL_COPY_READ_BUFFER,
                    GL31.GL_COPY_WRITE_BUFFER,
                    0L,
                    0L,
                    (long) usedTexels * 4 * Float.BYTES
            );
            ChaosGlDebug.check("ChaosGpuPoseArena.ensureCapacity.glCopyBufferSubData");
            GL15.glBindBuffer(GL31.GL_COPY_READ_BUFFER, 0);
            GL15.glBindBuffer(GL31.GL_COPY_WRITE_BUFFER, 0);
        }

        GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, 0);
        GL15.glDeleteBuffers(bufferId);
        bufferId = grownBufferId;

        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, textureId);
        GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, GL30.GL_RGBA32F, bufferId);
        ChaosGlDebug.check("ChaosGpuPoseArena.ensureCapacity.glTexBuffer");
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, 0);

        texelCapacity = grownCapacity;
        return true;
    }

    private static void ensureInitialized() {
        if (bufferId != -1 || !isSupported()) {
            return;
        }

        bufferId = GL15.glGenBuffers();
        ChaosGlDebug.check("ChaosGpuPoseArena.ensureInitialized.glGenBuffers");
        textureId = GL11.glGenTextures();
        ChaosGlDebug.check("ChaosGpuPoseArena.ensureInitialized.glGenTextures");
        ensureCapacity(INITIAL_TEXEL_CAPACITY);
    }
}
