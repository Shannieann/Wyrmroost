package dev.elifian.chaoslib.gpu.backend;

import dev.elifian.chaoslib.gpu.mesh.ChaosGpuGeoMesh;

import dev.elifian.chaoslib.platform.ClientOnly;

@ClientOnly
interface ChaosGpuBoneResolveBackend {
    boolean isSupported();

    void invalidateAll();

    void invalidateLocalPose(Object localPoseData, int localPoseTextureId);

    int resolveAndBind(ChaosGpuGeoMesh mesh, Object localPoseData);

    float[] resolveAndRead(ChaosGpuGeoMesh mesh, Object localPoseData);
}
