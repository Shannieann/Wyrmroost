package dev.elifian.chaoslib.gpu.backend;

import dev.elifian.chaoslib.config.ChaosAmdRenderingSafetyMode;
import dev.elifian.chaoslib.config.ChaosLibClientConfig;

import dev.elifian.chaoslib.platform.ClientOnly;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GLCapabilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@ClientOnly
public final class ChaosGpuRuntimePolicy {
    private static final Logger LOGGER = LoggerFactory.getLogger(ChaosGpuRuntimePolicy.class);
    public enum AnimationBackendMode {
        COMPUTE,
        TRANSFORM_FEEDBACK,
        NONE
    }

    public enum ResolvedBackendMode {
        COMPUTE,
        TRANSFORM_FEEDBACK,
        NONE
    }

    private static boolean initialized;
    private static boolean computeCapable;
    private static boolean animationTransformFeedbackCapable;
    private static boolean resolvedTransformFeedbackCapable;

    private ChaosGpuRuntimePolicy() {
    }

    public static synchronized void initialize() {
        if (initialized) {
            return;
        }

        initialized = true;
        GLCapabilities capabilities = GL.getCapabilities();
        boolean textureBuffers = isTextureBufferSupported(capabilities);
        computeCapable = textureBuffers && supportsComputeShaders(capabilities);
        animationTransformFeedbackCapable = textureBuffers && capabilities.OpenGL31;
        resolvedTransformFeedbackCapable = textureBuffers && supportsGlsl150(capabilities);

        // Only the hardware-fixed capability flags are cached here. The actual backend is
        // resolved lazily in the getters so the configurable AMD safety mode can be toggled at
        // runtime (Sodium/Chloride video settings) without a restart. AMD/ATI OpenGL drivers
        // (atio6axx.dll) crash in the compute + SSBO path, hence the safety gate below.
        LOGGER.info("[ChaosLib GPU] vendor='{}' renderer='{}' version='{}' amdAtiRadeon={} computeCapable={} -> animationBackend={} resolvedBackend={}",
                GL11.glGetString(GL11.GL_VENDOR),
                GL11.glGetString(GL11.GL_RENDERER),
                GL11.glGetString(GL11.GL_VERSION),
                ChaosGpuDriverInfo.isAmdAtiRadeon(),
                computeCapable,
                getAnimationBackendMode(),
                getResolvedBackendMode());
    }

    public static AnimationBackendMode getAnimationBackendMode() {
        initialize();
        if (computeCapable && !shouldUseAmdSafeBackend()) {
            return AnimationBackendMode.COMPUTE;
        }
        return animationTransformFeedbackCapable ? AnimationBackendMode.TRANSFORM_FEEDBACK : AnimationBackendMode.NONE;
    }

    public static ResolvedBackendMode getResolvedBackendMode() {
        initialize();
        if (computeCapable && !shouldUseAmdSafeBackend()) {
            return ResolvedBackendMode.COMPUTE;
        }
        return resolvedTransformFeedbackCapable ? ResolvedBackendMode.TRANSFORM_FEEDBACK : ResolvedBackendMode.NONE;
    }

    /**
     * Resolves whether the AMD-safe (non-compute) backend should be used. Driven by the
     * configurable {@link ChaosAmdRenderingSafetyMode}: {@code FORCE_DEFAULT} keeps the
     * capability-based choice (compute when supported), {@code FORCE_AMD_SAFE} always avoids
     * compute, and {@code AUTO} avoids compute only on detected AMD/ATI/Radeon adapters.
     */
    public static boolean shouldUseAmdSafeBackend() {
        return switch (ChaosLibClientConfig.rendering().amdRenderingSafetyMode) {
            case FORCE_DEFAULT -> false;
            case FORCE_AMD_SAFE -> true;
            case AUTO -> ChaosGpuDriverInfo.isAmdAtiRadeon();
        };
    }

    public static boolean isTextureBufferSupported() {
        return isTextureBufferSupported(GL.getCapabilities());
    }

    public static boolean isInstancingSupported() {
        GLCapabilities capabilities = GL.getCapabilities();
        return (capabilities.OpenGL31 || capabilities.GL_ARB_draw_instanced)
                && (capabilities.OpenGL33 || capabilities.GL_ARB_instanced_arrays);
    }

    public static boolean isCoreGpuShaderSupported() {
        return supportsGlsl150(GL.getCapabilities());
    }

    public static boolean isShaderPackTransformFeedbackSupported() {
        GLCapabilities capabilities = GL.getCapabilities();
        return isTextureBufferSupported(capabilities) && supportsGlsl150(capabilities);
    }

    private static boolean isTextureBufferSupported(GLCapabilities capabilities) {
        return capabilities.OpenGL31 || capabilities.GL_ARB_texture_buffer_object;
    }

    private static boolean supportsComputeShaders(GLCapabilities capabilities) {
        return capabilities.OpenGL43 || (capabilities.GL_ARB_compute_shader && capabilities.GL_ARB_shader_storage_buffer_object);
    }

    private static boolean supportsGlsl150(GLCapabilities capabilities) {
        return capabilities.OpenGL32;
    }
}
