package dev.elifian.chaoslib.gpu.backend;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.elifian.chaoslib.gpu.debug.ChaosGlDebug;
import org.jetbrains.annotations.Nullable;

import dev.elifian.chaoslib.platform.ClientOnly;
import org.lwjgl.opengl.ARBTextureBufferObject;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GL31;
import org.lwjgl.system.MemoryUtil;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;

@ClientOnly
public final class ChaosGpuInstanceDataStorage {
    public static final int PACKED_LIGHT_TEXTURE_UNIT = 5;
    public static final int EMISSIVE_STRENGTH_TEXTURE_UNIT = 6;
    public static final int POSE_BASE_TEXTURE_UNIT = 7;
    public static final int EMISSIVE_BASE_TEXTURE_UNIT = 8;
    public static final int BONE_LIGHT_TEXTURE_UNIT = 9;
    public static final int LIGHT_BASE_TEXTURE_UNIT = 10;
    public static final int INSTANCE_MATRIX_TEXTURE_UNIT = 13;
    public static final int INSTANCE_COLOR_TEXTURE_UNIT = 14;
    private static ChaosGpuStreamingTextureBuffer packedLightStream;
    private static int packedLightTextureId = -1;
    private static ChaosGpuStreamingTextureBuffer emissiveStrengthStream;
    private static int emissiveStrengthTextureId = -1;
    private static ChaosGpuStreamingTextureBuffer poseBaseStream;
    private static int poseBaseTextureId = -1;
    private static ChaosGpuStreamingTextureBuffer emissiveBaseStream;
    private static int emissiveBaseTextureId = -1;
    private static ChaosGpuStreamingTextureBuffer boneLightStream;
    private static int boneLightTextureId = -1;
    private static ChaosGpuStreamingTextureBuffer lightBaseStream;
    private static int lightBaseTextureId = -1;
    private static ChaosGpuStreamingTextureBuffer instanceMatrixStream;
    private static int instanceMatrixTextureId = -1;
    private static ChaosGpuStreamingTextureBuffer instanceColorStream;
    private static int instanceColorTextureId = -1;
    private static int[] lastUploadedPackedLight;
    private static int lastUploadedPackedLightCount;
    private static float[] lastUploadedEmissiveStrength;
    private static int lastUploadedEmissiveStrengthCount;
    private static int[] lastUploadedPoseBase;
    private static int lastUploadedPoseBaseCount;
    private static int[] lastUploadedEmissiveBase;
    private static int lastUploadedEmissiveBaseCount;
    private static int[] lastUploadedBoneLight;
    private static int lastUploadedBoneLightCount;
    private static int[] lastUploadedLightBase;
    private static int lastUploadedLightBaseCount;
    private static float[] lastUploadedInstanceMatrices;
    private static int lastUploadedInstanceMatrixCount;
    private static float[] lastUploadedInstanceColors;
    private static int lastUploadedInstanceColorCount;

    private ChaosGpuInstanceDataStorage() {
    }

    public static boolean isSupported() {
        return ChaosGpuRuntimePolicy.isTextureBufferSupported();
    }

    public static void invalidateAll() {
        if (packedLightStream != null) {
            packedLightStream.close();
            packedLightStream = null;
        }
        packedLightTextureId = -1;
        lastUploadedPackedLight = null;
        lastUploadedPackedLightCount = 0;
        if (emissiveStrengthStream != null) {
            emissiveStrengthStream.close();
            emissiveStrengthStream = null;
        }
        emissiveStrengthTextureId = -1;
        lastUploadedEmissiveStrength = null;
        lastUploadedEmissiveStrengthCount = 0;
        if (poseBaseStream != null) {
            poseBaseStream.close();
            poseBaseStream = null;
        }
        poseBaseTextureId = -1;
        lastUploadedPoseBase = null;
        lastUploadedPoseBaseCount = 0;
        if (emissiveBaseStream != null) {
            emissiveBaseStream.close();
            emissiveBaseStream = null;
        }
        emissiveBaseTextureId = -1;
        lastUploadedEmissiveBase = null;
        lastUploadedEmissiveBaseCount = 0;
        if (boneLightStream != null) {
            boneLightStream.close();
            boneLightStream = null;
        }
        boneLightTextureId = -1;
        lastUploadedBoneLight = null;
        lastUploadedBoneLightCount = 0;
        if (lightBaseStream != null) {
            lightBaseStream.close();
            lightBaseStream = null;
        }
        lightBaseTextureId = -1;
        lastUploadedLightBase = null;
        lastUploadedLightBaseCount = 0;
        if (instanceMatrixStream != null) {
            instanceMatrixStream.close();
            instanceMatrixStream = null;
        }
        instanceMatrixTextureId = -1;
        lastUploadedInstanceMatrices = null;
        lastUploadedInstanceMatrixCount = 0;
        if (instanceColorStream != null) {
            instanceColorStream.close();
            instanceColorStream = null;
        }
        instanceColorTextureId = -1;
        lastUploadedInstanceColors = null;
        lastUploadedInstanceColorCount = 0;
    }

    public static @Nullable InstanceTextures uploadForInstancedShaders(
            int[] packedLightData,
            int packedLightCount,
            int[] poseBaseData,
            int poseBaseCount,
            int[] boneLightData,
            int boneLightCount,
            int[] lightBaseData,
            int lightBaseCount,
            float[] instanceMatrixData,
            int matrixFloatCount) {
        if (!isSupported()) {
            return null;
        }

        ensureInitialized();
        uploadPackedLightIfNeeded(packedLightData, packedLightCount);
        uploadPoseBaseIfNeeded(poseBaseData, poseBaseCount);
        uploadBoneLightIfNeeded(boneLightData, boneLightCount);
        uploadLightBaseIfNeeded(lightBaseData, lightBaseCount);
        uploadInstanceMatricesIfNeeded(instanceMatrixData, matrixFloatCount);
        return new InstanceTextures(
                packedLightTextureId,
                poseBaseTextureId,
                boneLightTextureId,
                lightBaseTextureId,
                instanceMatrixTextureId
        );
    }

    public record InstanceTextures(
            int packedLightTextureId,
            int poseBaseTextureId,
            int boneLightTextureId,
            int lightBaseTextureId,
            int instanceMatrixTextureId
    ) {
    }

    public static boolean bindInstanceMatrices(float[] instanceMatrixData, int matrixFloatCount) {
        if (!isSupported()) {
            return false;
        }

        ensureInitialized();
        uploadInstanceMatricesIfNeeded(instanceMatrixData, matrixFloatCount);
        bindTextureToUnit(INSTANCE_MATRIX_TEXTURE_UNIT, instanceMatrixTextureId);
        return true;
    }

    public static boolean bindForInstancedShaders(
            int[] packedLightData,
            int packedLightCount,
            float[] emissiveStrengthData,
            int emissiveStrengthCount,
            int[] poseBaseData,
            int poseBaseCount,
            int[] emissiveBaseData,
            int emissiveBaseCount,
            int[] boneLightData,
            int boneLightCount,
            int[] lightBaseData) {
        return bindForInstancedShaders(
                packedLightData,
                packedLightCount,
                emissiveStrengthData,
                emissiveStrengthCount,
                poseBaseData,
                poseBaseCount,
                emissiveBaseData,
                emissiveBaseCount,
                boneLightData,
                boneLightCount,
                lightBaseData,
                lightBaseData.length
        );
    }

    public static boolean bindForInstancedShaders(
            int[] packedLightData,
            int packedLightCount,
            float[] emissiveStrengthData,
            int emissiveStrengthCount,
            int[] poseBaseData,
            int poseBaseCount,
            int[] emissiveBaseData,
            int emissiveBaseCount,
            int[] boneLightData,
            int boneLightCount,
            int[] lightBaseData,
            int lightBaseCount) {
        return bindForInstancedShaders(
                packedLightData,
                packedLightCount,
                emissiveStrengthData,
                emissiveStrengthCount,
                poseBaseData,
                poseBaseCount,
                emissiveBaseData,
                emissiveBaseCount,
                boneLightData,
                boneLightCount,
                lightBaseData,
                lightBaseCount,
                EMPTY_INSTANCE_COLOR_DATA,
                0
        );
    }

    public static boolean bindForInstancedShaders(
            int[] packedLightData,
            int packedLightCount,
            float[] emissiveStrengthData,
            int emissiveStrengthCount,
            int[] poseBaseData,
            int poseBaseCount,
            int[] emissiveBaseData,
            int emissiveBaseCount,
            int[] boneLightData,
            int boneLightCount,
            int[] lightBaseData,
            int lightBaseCount,
            float[] instanceColorData,
            int instanceColorFloatCount) {
        if (!isSupported()) {
            return false;
        }

        ensureInitialized();
        uploadPackedLightIfNeeded(packedLightData, packedLightCount);
        uploadEmissiveStrengthIfNeeded(emissiveStrengthData, emissiveStrengthCount);
        uploadPoseBaseIfNeeded(poseBaseData, poseBaseCount);
        uploadEmissiveBaseIfNeeded(emissiveBaseData, emissiveBaseCount);
        uploadBoneLightIfNeeded(boneLightData, boneLightCount);
        uploadLightBaseIfNeeded(lightBaseData, lightBaseCount);
        uploadInstanceColorsIfNeeded(instanceColorData, instanceColorFloatCount);
        int activeTexture = GlStateManager._getActiveTexture();
        bindTextureToUnitRaw(PACKED_LIGHT_TEXTURE_UNIT, packedLightTextureId);
        bindTextureToUnitRaw(EMISSIVE_STRENGTH_TEXTURE_UNIT, emissiveStrengthTextureId);
        bindTextureToUnitRaw(POSE_BASE_TEXTURE_UNIT, poseBaseTextureId);
        bindTextureToUnitRaw(EMISSIVE_BASE_TEXTURE_UNIT, emissiveBaseTextureId);
        bindTextureToUnitRaw(BONE_LIGHT_TEXTURE_UNIT, boneLightTextureId);
        bindTextureToUnitRaw(LIGHT_BASE_TEXTURE_UNIT, lightBaseTextureId);
        bindTextureToUnitRaw(INSTANCE_COLOR_TEXTURE_UNIT, instanceColorTextureId);
        GlStateManager._activeTexture(activeTexture);
        return true;
    }

    public static void unbindSamplers() {
        int activeTexture = GlStateManager._getActiveTexture();
        unbindTexture(PACKED_LIGHT_TEXTURE_UNIT);
        unbindTexture(EMISSIVE_STRENGTH_TEXTURE_UNIT);
        unbindTexture(POSE_BASE_TEXTURE_UNIT);
        unbindTexture(EMISSIVE_BASE_TEXTURE_UNIT);
        unbindTexture(BONE_LIGHT_TEXTURE_UNIT);
        unbindTexture(LIGHT_BASE_TEXTURE_UNIT);
        unbindTexture(INSTANCE_MATRIX_TEXTURE_UNIT);
        unbindTexture(INSTANCE_COLOR_TEXTURE_UNIT);
        GlStateManager._activeTexture(activeTexture);
    }

    private static void ensureInitialized() {
        if (packedLightStream == null) {
            packedLightStream = new ChaosGpuStreamingTextureBuffer(GL30.GL_R32I);
        }
        if (emissiveStrengthStream == null) {
            emissiveStrengthStream = new ChaosGpuStreamingTextureBuffer(GL30.GL_R32F);
        }
        if (poseBaseStream == null) {
            poseBaseStream = new ChaosGpuStreamingTextureBuffer(GL30.GL_R32I);
        }
        if (emissiveBaseStream == null) {
            emissiveBaseStream = new ChaosGpuStreamingTextureBuffer(GL30.GL_R32I);
        }
        if (boneLightStream == null) {
            boneLightStream = new ChaosGpuStreamingTextureBuffer(GL30.GL_R32I);
        }
        if (lightBaseStream == null) {
            lightBaseStream = new ChaosGpuStreamingTextureBuffer(GL30.GL_R32I);
        }
        if (instanceMatrixStream == null) {
            instanceMatrixStream = new ChaosGpuStreamingTextureBuffer(GL30.GL_RGBA32F);
        }
        if (instanceColorStream == null) {
            instanceColorStream = new ChaosGpuStreamingTextureBuffer(GL30.GL_RGBA32F);
        }
    }

    private static void uploadPackedLightIfNeeded(int[] packedLightData, int packedLightCount) {
        if (matches(lastUploadedPackedLight, lastUploadedPackedLightCount, packedLightData, packedLightCount)) {
            return;
        }

        packedLightTextureId = packedLightStream.upload(packedLightData, packedLightCount);
        lastUploadedPackedLight = copy(lastUploadedPackedLight, packedLightData, packedLightCount);
        lastUploadedPackedLightCount = packedLightCount;
    }

    private static void uploadEmissiveStrengthIfNeeded(float[] emissiveStrengthData, int emissiveStrengthCount) {
        if (matches(lastUploadedEmissiveStrength, lastUploadedEmissiveStrengthCount, emissiveStrengthData, emissiveStrengthCount)) {
            return;
        }

        emissiveStrengthTextureId = emissiveStrengthStream.upload(emissiveStrengthData, emissiveStrengthCount);
        lastUploadedEmissiveStrength = copy(lastUploadedEmissiveStrength, emissiveStrengthData, emissiveStrengthCount);
        lastUploadedEmissiveStrengthCount = emissiveStrengthCount;
    }

    private static void uploadPoseBaseIfNeeded(int[] poseBaseData, int poseBaseCount) {
        if (matches(lastUploadedPoseBase, lastUploadedPoseBaseCount, poseBaseData, poseBaseCount)) {
            return;
        }

        poseBaseTextureId = poseBaseStream.upload(poseBaseData, poseBaseCount);
        lastUploadedPoseBase = copy(lastUploadedPoseBase, poseBaseData, poseBaseCount);
        lastUploadedPoseBaseCount = poseBaseCount;
    }

    private static void uploadEmissiveBaseIfNeeded(int[] emissiveBaseData, int emissiveBaseCount) {
        if (matches(lastUploadedEmissiveBase, lastUploadedEmissiveBaseCount, emissiveBaseData, emissiveBaseCount)) {
            return;
        }

        emissiveBaseTextureId = emissiveBaseStream.upload(emissiveBaseData, emissiveBaseCount);
        lastUploadedEmissiveBase = copy(lastUploadedEmissiveBase, emissiveBaseData, emissiveBaseCount);
        lastUploadedEmissiveBaseCount = emissiveBaseCount;
    }

    private static void uploadBoneLightIfNeeded(int[] boneLightData, int boneLightCount) {
        if (matches(lastUploadedBoneLight, lastUploadedBoneLightCount, boneLightData, boneLightCount)) {
            return;
        }

        boneLightTextureId = boneLightStream.upload(boneLightData, boneLightCount);
        lastUploadedBoneLight = copy(lastUploadedBoneLight, boneLightData, boneLightCount);
        lastUploadedBoneLightCount = boneLightCount;
    }

    private static void uploadLightBaseIfNeeded(int[] lightBaseData, int lightBaseCount) {
        if (matches(lastUploadedLightBase, lastUploadedLightBaseCount, lightBaseData, lightBaseCount)) {
            return;
        }

        lightBaseTextureId = lightBaseStream.upload(lightBaseData, lightBaseCount);
        lastUploadedLightBase = copy(lastUploadedLightBase, lightBaseData, lightBaseCount);
        lastUploadedLightBaseCount = lightBaseCount;
    }

    private static void uploadInstanceMatricesIfNeeded(float[] instanceMatrixData, int matrixFloatCount) {
        if (matches(lastUploadedInstanceMatrices, lastUploadedInstanceMatrixCount, instanceMatrixData, matrixFloatCount)) {
            return;
        }

        instanceMatrixTextureId = instanceMatrixStream.upload(instanceMatrixData, matrixFloatCount);
        lastUploadedInstanceMatrices = copy(lastUploadedInstanceMatrices, instanceMatrixData, matrixFloatCount);
        lastUploadedInstanceMatrixCount = matrixFloatCount;
    }

    private static void uploadInstanceColorsIfNeeded(float[] instanceColorData, int instanceColorFloatCount) {
        if (matches(lastUploadedInstanceColors, lastUploadedInstanceColorCount, instanceColorData, instanceColorFloatCount)) {
            return;
        }

        instanceColorTextureId = instanceColorStream.upload(instanceColorData, instanceColorFloatCount);
        lastUploadedInstanceColors = copy(lastUploadedInstanceColors, instanceColorData, instanceColorFloatCount);
        lastUploadedInstanceColorCount = instanceColorFloatCount;
    }

    private static final float[] EMPTY_INSTANCE_COLOR_DATA = new float[0];

    private static boolean matches(int[] current, int currentCount, int[] incoming, int incomingCount) {
        if (current == null || currentCount != incomingCount) {
            return false;
        }
        for (int i = 0; i < incomingCount; i++) {
            if (current[i] != incoming[i]) {
                return false;
            }
        }
        return true;
    }

    private static boolean matches(float[] current, int currentCount, float[] incoming, int incomingCount) {
        if (current == null || currentCount != incomingCount) {
            return false;
        }
        for (int i = 0; i < incomingCount; i++) {
            if (Float.floatToIntBits(current[i]) != Float.floatToIntBits(incoming[i])) {
                return false;
            }
        }
        return true;
    }

    private static int[] copy(int[] target, int[] source, int count) {
        if (target == null || target.length < count) {
            target = new int[count];
        }
        System.arraycopy(source, 0, target, 0, count);
        return target;
    }

    private static float[] copy(float[] target, float[] source, int count) {
        if (target == null || target.length < count) {
            target = new float[count];
        }
        System.arraycopy(source, 0, target, 0, count);
        return target;
    }

    private static void bindTextureToUnit(int textureUnit, int textureId) {
        int activeTexture = GlStateManager._getActiveTexture();
        bindTextureToUnitRaw(textureUnit, textureId);
        GlStateManager._activeTexture(activeTexture);
    }

    private static void bindTextureToUnitRaw(int textureUnit, int textureId) {
        RenderSystem.activeTexture(GL13.GL_TEXTURE0 + textureUnit);
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, textureId);
        ChaosGlDebug.check("ChaosGpuInstanceDataStorage.bindTextureToUnit.glBindTexture." + textureUnit);
    }

    private static void unbindTexture(int textureUnit) {
        RenderSystem.activeTexture(GL13.GL_TEXTURE0 + textureUnit);
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, 0);
        ChaosGlDebug.check("ChaosGpuInstanceDataStorage.unbindTexture.glBindTexture.0." + textureUnit);
    }


    private static void deleteTextureAndBuffer(int textureId, int bufferId) {
        if (textureId != -1) {
            GL11.glDeleteTextures(textureId);
            ChaosGlDebug.check("ChaosGpuInstanceDataStorage.deleteTextureAndBuffer.glDeleteTextures");
        }
        if (bufferId != -1) {
            GL15.glDeleteBuffers(bufferId);
            ChaosGlDebug.check("ChaosGpuInstanceDataStorage.deleteTextureAndBuffer.glDeleteBuffers");
        }
    }


}
