package dev.elifian.chaoslib.gpu.mesh;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.elifian.chaoslib.cache.object.*;
import dev.elifian.chaoslib.gpu.debug.ChaosGlDebug;
import dev.elifian.chaoslib.platform.ClientOnly;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.opengl.*;
import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.*;

@ClientOnly
public final class ChaosGpuGeoMesh implements AutoCloseable {
    private static final Object FULL_SELECTION = new Object();
    private static final Map<BakedGeoModel, Map<Object, ChaosGpuGeoMesh>> CACHE = Collections.synchronizedMap(new IdentityHashMap<>());
    private static final int POSITION_OFFSET = 0;
    private static final int COLOR_OFFSET = POSITION_OFFSET + 3 * Float.BYTES;
    private static final int UV0_OFFSET = COLOR_OFFSET + Integer.BYTES;
    private static final int BONE_INDEX_OFFSET = UV0_OFFSET + 2 * Float.BYTES;
    private static final int NORMAL_OFFSET = BONE_INDEX_OFFSET + Integer.BYTES;
    private static final int MID_TEX_COORD_OFFSET = NORMAL_OFFSET + Integer.BYTES;
    private static final int TANGENT_OFFSET = MID_TEX_COORD_OFFSET + 2 * Float.BYTES;
    private static final int VERTEX_STRIDE = TANGENT_OFFSET + Integer.BYTES;
    private static final byte COLOR_WHITE = (byte) 0xFF;
    private static BakedGeoModel lastModel;
    private static Object lastSelectionKey;
    private static ChaosGpuGeoMesh lastMesh;
    private static Set<String> lastRawIncludedBones;
    private static boolean lastRawNormalizeUvToBounds;
    private static Object lastRawSelectionKey;
    private static final Map<Set<String>, Object> RAW_SELECTION_KEYS = new IdentityHashMap<>();
    private static final Map<Set<String>, Object> RAW_NORMALIZED_SELECTION_KEYS = new IdentityHashMap<>();

    private final int vertexArrayId;
    private final int vertexBufferId;
    private final int vertexCount;
    private final List<GeoBone> indexedBones;
    private final List<IndexedLocator> indexedLocators;
    private final Map<GeoBone, Integer> boneIndices;
    private Map<String, Integer> boneIndexByName;
    private int boneIndexBufferId = -1;
    private int boneIndexTextureId = -1;
    private final int[] parentIndices;
    private final int[] boneDepths;
    private final float minU;
    private final float minV;
    private final float maxU;
    private final float maxV;

    private ChaosGpuGeoMesh(
            int vertexArrayId,
            int vertexBufferId,
            int vertexCount,
            List<GeoBone> indexedBones,
            List<IndexedLocator> indexedLocators,
            Map<GeoBone, Integer> boneIndices,
            int[] parentIndices,
            int[] boneDepths,
            float minU,
            float minV,
            float maxU,
            float maxV) {
        this.vertexArrayId = vertexArrayId;
        this.vertexBufferId = vertexBufferId;
        this.vertexCount = vertexCount;
        this.indexedBones = indexedBones;
        this.indexedLocators = indexedLocators;
        this.boneIndices = boneIndices;
        this.parentIndices = parentIndices;
        this.boneDepths = boneDepths;
        this.minU = minU;
        this.minV = minV;
        this.maxU = maxU;
        this.maxV = maxV;
    }

    public static ChaosGpuGeoMesh getOrCreate(BakedGeoModel model) {
        return getOrCreate(model, null);
    }

    public static ChaosGpuGeoMesh getOrCreate(BakedGeoModel model, Set<String> includedBones) {
        return getOrCreate(model, includedBones, false);
    }

    public static ChaosGpuGeoMesh getOrCreate(BakedGeoModel model, Set<String> includedBones, boolean normalizeUvToBounds) {
        Object selectionKey = canonicalSelectionKey(includedBones, normalizeUvToBounds);
        if (model == lastModel && selectionKey.equals(lastSelectionKey) && lastMesh != null) {
            return lastMesh;
        }

        Map<Object, ChaosGpuGeoMesh> modelMeshes = CACHE.get(model);
        ChaosGpuGeoMesh mesh = modelMeshes != null ? modelMeshes.get(selectionKey) : null;
        if (mesh != null) {
            lastModel = model;
            lastSelectionKey = selectionKey;
            lastMesh = mesh;
            return mesh;
        }

        synchronized (CACHE) {
            modelMeshes = CACHE.computeIfAbsent(model, ignored -> new HashMap<>());
            mesh = modelMeshes.get(selectionKey);
            if (mesh == null) {
                mesh = build(model, includedBones, normalizeUvToBounds);
                modelMeshes.put(selectionKey, mesh);
            }
        }

        lastModel = model;
        lastSelectionKey = selectionKey;
        lastMesh = mesh;
        return mesh;
    }

    public static void invalidateAll() {
        for (Map<Object, ChaosGpuGeoMesh> modelMeshes : CACHE.values()) {
            for (ChaosGpuGeoMesh mesh : modelMeshes.values()) {
                mesh.close();
            }
        }

        CACHE.clear();
        lastModel = null;
        lastSelectionKey = null;
        lastMesh = null;
        lastRawIncludedBones = null;
        lastRawNormalizeUvToBounds = false;
        lastRawSelectionKey = null;
        RAW_SELECTION_KEYS.clear();
        RAW_NORMALIZED_SELECTION_KEYS.clear();
    }

    public List<GeoBone> getIndexedBones() {
        return this.indexedBones;
    }

    public List<IndexedLocator> getIndexedLocators() {
        return this.indexedLocators;
    }

    public boolean hasInstancedGeometry() {
        return this.vertexCount > 0;
    }

    public int getInstancedVertexCount() {
        return this.vertexCount;
    }

    public int getVertexBufferId() {
        return this.vertexBufferId;
    }

    public int getVertexStride() {
        return VERTEX_STRIDE;
    }

    public int getPositionOffset() {
        return POSITION_OFFSET;
    }

    public int getColorOffset() {
        return COLOR_OFFSET;
    }

    public int getUv0Offset() {
        return UV0_OFFSET;
    }

    public int getNormalOffset() {
        return NORMAL_OFFSET;
    }

    public int getMidTexCoordOffset() {
        return MID_TEX_COORD_OFFSET;
    }

    public int getTangentOffset() {
        return TANGENT_OFFSET;
    }

    public int getBoneIndexTextureId() {
        if (this.boneIndexTextureId != -1) {
            return this.boneIndexTextureId;
        }
        if (this.vertexCount <= 0 || this.vertexBufferId == -1) {
            return -1;
        }

        ByteBuffer vertexData = MemoryUtil.memAlloc(this.vertexCount * VERTEX_STRIDE).order(ByteOrder.nativeOrder());
        ByteBuffer boneIndexData = MemoryUtil.memAlloc(this.vertexCount * Integer.BYTES).order(ByteOrder.nativeOrder());
        try {
            GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, this.vertexBufferId);
            ChaosGlDebug.check("ChaosGpuGeoMesh.getBoneIndexTextureId.glBindBuffer");
            GL15.glGetBufferSubData(GL15.GL_ARRAY_BUFFER, 0L, vertexData);
            ChaosGlDebug.check("ChaosGpuGeoMesh.getBoneIndexTextureId.glGetBufferSubData");
            GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, 0);

            for (int vertex = 0; vertex < this.vertexCount; vertex++) {
                boneIndexData.putInt(vertex * Integer.BYTES, vertexData.getInt(vertex * VERTEX_STRIDE + BONE_INDEX_OFFSET));
            }

            this.boneIndexBufferId = GL15.glGenBuffers();
            GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, this.boneIndexBufferId);
            GL15.glBufferData(GL31.GL_TEXTURE_BUFFER, boneIndexData, GL15.GL_STATIC_DRAW);
            ChaosGlDebug.check("ChaosGpuGeoMesh.getBoneIndexTextureId.glBufferData");

            this.boneIndexTextureId = GL11.glGenTextures();
            GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, this.boneIndexTextureId);
            GL31.glTexBuffer(GL31.GL_TEXTURE_BUFFER, GL30.GL_R32I, this.boneIndexBufferId);
            ChaosGlDebug.check("ChaosGpuGeoMesh.getBoneIndexTextureId.glTexBuffer");
            GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, 0);
            GL15.glBindBuffer(GL31.GL_TEXTURE_BUFFER, 0);
        } finally {
            MemoryUtil.memFree(boneIndexData);
            MemoryUtil.memFree(vertexData);
        }

        return this.boneIndexTextureId;
    }

    public void bindInstancedGeometry() {
        GlStateManager._glBindVertexArray(this.vertexArrayId);
        ChaosGlDebug.check("ChaosGpuGeoMesh.bindInstancedGeometry._glBindVertexArray");
    }

    public void bindGeometry() {
        GlStateManager._glBindVertexArray(this.vertexArrayId);
        ChaosGlDebug.check("ChaosGpuGeoMesh.bindGeometry._glBindVertexArray");
    }

    public void drawGeometry() {
        GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, this.vertexCount);
        ChaosGlDebug.check("ChaosGpuGeoMesh.drawGeometry.glDrawArrays");
    }

    public int getBoneIndex(GeoBone bone) {
        return this.boneIndices.getOrDefault(bone, 0);
    }

    /**
     * Returns the index of the bone with the given name, or {@code -1} if absent. Backed by a lazily
     * built name-&gt;index map so procedural pose accumulation can iterate only the posed bones instead of
     * scanning every bone of the mesh each frame.
     */
    public int getBoneIndexByName(String name) {
        Map<String, Integer> map = this.boneIndexByName;
        if (map == null) {
            map = new HashMap<>(this.indexedBones.size() * 2);
            for (int i = 0; i < this.indexedBones.size(); i++) {
                map.putIfAbsent(this.indexedBones.get(i).getName(), i);
            }
            this.boneIndexByName = map;
        }
        return map.getOrDefault(name, -1);
    }

    public int getParentIndex(int boneIndex) {
        return boneIndex < 0 || boneIndex >= this.parentIndices.length ? -1 : this.parentIndices[boneIndex];
    }

    public int getBoneDepth(int boneIndex) {
        return boneIndex < 0 || boneIndex >= this.boneDepths.length ? 0 : this.boneDepths[boneIndex];
    }

    public int getMaxBoneDepth() {
        int maxDepth = 0;
        for (int depth : this.boneDepths) {
            if (depth > maxDepth) {
                maxDepth = depth;
            }
        }
        return maxDepth;
    }

    public UvRegion getUvRegion() {
        float width = this.maxU - this.minU;
        float height = this.maxV - this.minV;
        if (!(width > 1.0e-6f) || !(height > 1.0e-6f)) {
            return UvRegion.FULL;
        }

        return new UvRegion(this.minU, this.minV, width, height);
    }

    @Override
    public void close() {
        if (this.boneIndexTextureId != -1) {
            GL11.glDeleteTextures(this.boneIndexTextureId);
            ChaosGlDebug.check("ChaosGpuGeoMesh.close.glDeleteTextures.boneIndex");
            this.boneIndexTextureId = -1;
        }
        if (this.boneIndexBufferId != -1) {
            RenderSystem.glDeleteBuffers(this.boneIndexBufferId);
            ChaosGlDebug.check("ChaosGpuGeoMesh.close.glDeleteBuffers.boneIndex");
            this.boneIndexBufferId = -1;
        }
        if (this.vertexBufferId != -1) {
            RenderSystem.glDeleteBuffers(this.vertexBufferId);
            ChaosGlDebug.check("ChaosGpuGeoMesh.close.glDeleteBuffers");
        }
        if (this.vertexArrayId != -1) {
            RenderSystem.glDeleteVertexArrays(this.vertexArrayId);
            ChaosGlDebug.check("ChaosGpuGeoMesh.close.glDeleteVertexArrays");
        }
    }

    private static Object canonicalSelectionKey(Set<String> includedBones, boolean normalizeUvToBounds) {
        if (includedBones == null && !normalizeUvToBounds) {
            return FULL_SELECTION;
        }
        if (includedBones == lastRawIncludedBones && normalizeUvToBounds == lastRawNormalizeUvToBounds && lastRawSelectionKey != null) {
            return lastRawSelectionKey;
        }

        Map<Set<String>, Object> rawKeys = normalizeUvToBounds ? RAW_NORMALIZED_SELECTION_KEYS : RAW_SELECTION_KEYS;
        Object selectionKey = rawKeys.get(includedBones);
        if (selectionKey == null) {
            selectionKey = new SelectionKey(Set.copyOf(includedBones), normalizeUvToBounds);
            rawKeys.put(includedBones, selectionKey);
        }
        lastRawIncludedBones = includedBones;
        lastRawNormalizeUvToBounds = normalizeUvToBounds;
        lastRawSelectionKey = selectionKey;
        return selectionKey;
    }

    private static ChaosGpuGeoMesh build(BakedGeoModel model, Set<String> includedBones, boolean normalizeUvToBounds) {
        List<GeoBone> indexedBones = new ArrayList<>();
        Map<GeoBone, Integer> boneIndices = new IdentityHashMap<>();
        indexBones(model.topLevelBones(), indexedBones, boneIndices);

        int[] parentIndices = buildParentIndices(indexedBones, boneIndices);
        int[] boneDepths = buildBoneDepths(parentIndices);
        List<IndexedLocator> indexedLocators = buildIndexedLocators(indexedBones, boneIndices);

        UvRegion normalizedUvRegion = normalizeUvToBounds ? collectUvRegion(indexedBones, boneIndices, includedBones) : null;
        GeometryBufferBuilder geometry = new GeometryBufferBuilder(16_384);
        for (GeoBone bone : indexedBones) {
            int boneIndex = boneIndices.get(bone);
            if (includedBones != null && !includedBones.contains(bone.getName())) {
                continue;
            }

            for (GeoCube cube : bone.getCubes()) {
                emitCube(geometry, cube, boneIndex, normalizedUvRegion);
            }
        }

        UploadedGeometry uploaded = uploadGeometry(geometry.build());
        return new ChaosGpuGeoMesh(
                uploaded.vertexArrayId(),
                uploaded.vertexBufferId(),
                uploaded.vertexCount(),
                Collections.unmodifiableList(indexedBones),
                Collections.unmodifiableList(indexedLocators),
                Map.copyOf(boneIndices),
                parentIndices,
                boneDepths,
                geometry.minU(),
                geometry.minV(),
                geometry.maxU(),
                geometry.maxV()
        );
    }

    private static UvRegion collectUvRegion(List<GeoBone> indexedBones, Map<GeoBone, Integer> boneIndices, Set<String> includedBones) {
        GeometryBufferBuilder bounds = new GeometryBufferBuilder(0);
        for (GeoBone bone : indexedBones) {
            if (includedBones != null && !includedBones.contains(bone.getName())) {
                continue;
            }

            int boneIndex = boneIndices.get(bone);
            for (GeoCube cube : bone.getCubes()) {
                emitCube(bounds, cube, boneIndex, null);
            }
        }
        UvRegion region = new UvRegion(bounds.minU(), bounds.minV(), bounds.maxU() - bounds.minU(), bounds.maxV() - bounds.minV());
        bounds.close();
        return region.isFullCoverage() ? null : region;
    }

    private static List<IndexedLocator> buildIndexedLocators(List<GeoBone> indexedBones, Map<GeoBone, Integer> boneIndices) {
        ArrayList<IndexedLocator> locators = new ArrayList<>();
        for (GeoBone bone : indexedBones) {
            int boneIndex = boneIndices.getOrDefault(bone, -1);
            if (boneIndex < 0) {
                continue;
            }
            for (GeoLocator locator : bone.getLocators()) {
                locators.add(new IndexedLocator(locator.getName(), locator, boneIndex));
            }
        }
        return locators;
    }

    private static int[] buildParentIndices(List<GeoBone> indexedBones, Map<GeoBone, Integer> boneIndices) {
        int[] parentIndices = new int[indexedBones.size()];
        for (int i = 0; i < indexedBones.size(); i++) {
            GeoBone parent = indexedBones.get(i).getParent();
            parentIndices[i] = parent == null ? -1 : boneIndices.getOrDefault(parent, -1);
        }
        return parentIndices;
    }

    private static int[] buildBoneDepths(int[] parentIndices) {
        int[] boneDepths = new int[parentIndices.length];
        Arrays.fill(boneDepths, -1);
        for (int i = 0; i < parentIndices.length; i++) {
            computeBoneDepth(i, parentIndices, boneDepths);
        }
        return boneDepths;
    }

    private static int computeBoneDepth(int boneIndex, int[] parentIndices, int[] boneDepths) {
        if (boneDepths[boneIndex] >= 0) {
            return boneDepths[boneIndex];
        }

        int parentIndex = parentIndices[boneIndex];
        int depth = parentIndex < 0 ? 0 : computeBoneDepth(parentIndex, parentIndices, boneDepths) + 1;
        boneDepths[boneIndex] = depth;
        return depth;
    }

    private static void indexBones(List<GeoBone> bones, List<GeoBone> indexedBones, Map<GeoBone, Integer> boneIndices) {
        for (GeoBone bone : bones) {
            boneIndices.put(bone, indexedBones.size());
            indexedBones.add(bone);
            indexBones(bone.getChildBones(), indexedBones, boneIndices);
        }
    }

    private static void emitCube(GeometryBufferBuilder builder, GeoCube cube, int boneIndex, UvRegion normalizedUvRegion) {
        Matrix4f cubeMatrix = new Matrix4f()
                .translate((float) cube.pivot().x() / 16.0f, (float) cube.pivot().y() / 16.0f, (float) cube.pivot().z() / 16.0f)
                .rotateZ((float) cube.rotation().z())
                .rotateY((float) cube.rotation().y())
                .rotateX((float) cube.rotation().x())
                .translate((float) -cube.pivot().x() / 16.0f, (float) -cube.pivot().y() / 16.0f, (float) -cube.pivot().z() / 16.0f);
        Matrix3f normalMatrix = new Matrix3f()
                .rotateZ((float) cube.rotation().z())
                .rotateY((float) cube.rotation().y())
                .rotateX((float) cube.rotation().x());
        for (GeoQuad quad : cube.quads()) {
            if (quad == null) {
                continue;
            }

            GeoVertex[] vertices = quad.vertices();
            Vector4f[] transformedPositions = new Vector4f[vertices.length];
            for (int i = 0; i < vertices.length; i++) {
                transformedPositions[i] = cubeMatrix.transform(new Vector4f(vertices[i].x(), vertices[i].y(), vertices[i].z(), 1.0f));
            }

            Vector3f transformedNormal = normalMatrix.transform(new Vector3f(quad.normalX(), quad.normalY(), quad.normalZ())).normalize();
            float[] midTexCoord = computeMidTexCoord(vertices, normalizedUvRegion);
            byte[] tangent = computePackedTangent(
                    transformedPositions[0],
                    transformedPositions[1],
                    transformedPositions[2],
                    vertices[0],
                    vertices[1],
                    vertices[2],
                    transformedNormal,
                    normalizedUvRegion
            );

            emitTriangle(builder, transformedPositions, vertices, boneIndex, transformedNormal, midTexCoord, tangent, normalizedUvRegion, 0, 1, 2);
            emitTriangle(builder, transformedPositions, vertices, boneIndex, transformedNormal, midTexCoord, tangent, normalizedUvRegion, 2, 3, 0);
        }
    }

    private static void emitTriangle(
            GeometryBufferBuilder builder,
            Vector4f[] transformedPositions,
            GeoVertex[] vertices,
            int boneIndex,
            Vector3f transformedNormal,
            float[] midTexCoord,
            byte[] tangent,
            UvRegion normalizedUvRegion,
            int firstIndex,
            int secondIndex,
            int thirdIndex
    ) {
        if (!hasTriangleArea(transformedPositions[firstIndex], transformedPositions[secondIndex], transformedPositions[thirdIndex])) {
            return;
        }

        emitVertex(builder, transformedPositions[firstIndex], transformedNormal, vertices[firstIndex], boneIndex, midTexCoord, tangent, normalizedUvRegion);
        emitVertex(builder, transformedPositions[secondIndex], transformedNormal, vertices[secondIndex], boneIndex, midTexCoord, tangent, normalizedUvRegion);
        emitVertex(builder, transformedPositions[thirdIndex], transformedNormal, vertices[thirdIndex], boneIndex, midTexCoord, tangent, normalizedUvRegion);
    }

    private static boolean hasTriangleArea(Vector4f first, Vector4f second, Vector4f third) {
        float edge1X = second.x() - first.x();
        float edge1Y = second.y() - first.y();
        float edge1Z = second.z() - first.z();
        float edge2X = third.x() - first.x();
        float edge2Y = third.y() - first.y();
        float edge2Z = third.z() - first.z();
        float crossX = edge1Y * edge2Z - edge1Z * edge2Y;
        float crossY = edge1Z * edge2X - edge1X * edge2Z;
        float crossZ = edge1X * edge2Y - edge1Y * edge2X;
        return crossX * crossX + crossY * crossY + crossZ * crossZ > 1.0e-12f;
    }

    private static void emitVertex(GeometryBufferBuilder builder, Vector4f transformed, Vector3f transformedNormal, GeoVertex vertex, int boneIndex, float[] midTexCoord, byte[] tangent, UvRegion normalizedUvRegion) {
        float u = vertex.texU();
        float v = vertex.texV();
        if (normalizedUvRegion != null && !normalizedUvRegion.isFullCoverage()) {
            u = (u - normalizedUvRegion.minU()) / normalizedUvRegion.width();
            v = (v - normalizedUvRegion.minV()) / normalizedUvRegion.height();
        }

        builder.putVertex(
                transformed.x(),
                transformed.y(),
                transformed.z(),
                COLOR_WHITE,
                COLOR_WHITE,
                COLOR_WHITE,
                COLOR_WHITE,
                u,
                v,
                boneIndex,
                encodeNormalComponent(transformedNormal.x()),
                encodeNormalComponent(transformedNormal.y()),
                encodeNormalComponent(transformedNormal.z()),
                midTexCoord[0],
                midTexCoord[1],
                tangent[0],
                tangent[1],
                tangent[2],
                tangent[3]
        );
    }

    private static float[] computeMidTexCoord(GeoVertex[] vertices, @Nullable UvRegion normalizedUvRegion) {
        float midU = 0.0f;
        float midV = 0.0f;
        for (GeoVertex vertex : vertices) {
            midU += normalizeU(vertex.texU(), normalizedUvRegion);
            midV += normalizeV(vertex.texV(), normalizedUvRegion);
        }

        if (vertices.length == 0) {
            return new float[]{0.0f, 0.0f};
        }

        return new float[]{midU / vertices.length, midV / vertices.length};
    }

    private static byte[] computePackedTangent(
            Vector4f firstPosition,
            Vector4f secondPosition,
            Vector4f thirdPosition,
            GeoVertex first,
            GeoVertex second,
            GeoVertex third,
            Vector3f normal,
            @Nullable UvRegion normalizedUvRegion
    ) {
        float edge1X = secondPosition.x() - firstPosition.x();
        float edge1Y = secondPosition.y() - firstPosition.y();
        float edge1Z = secondPosition.z() - firstPosition.z();
        float edge2X = thirdPosition.x() - firstPosition.x();
        float edge2Y = thirdPosition.y() - firstPosition.y();
        float edge2Z = thirdPosition.z() - firstPosition.z();

        float firstU = normalizeU(first.texU(), normalizedUvRegion);
        float firstV = normalizeV(first.texV(), normalizedUvRegion);
        float secondU = normalizeU(second.texU(), normalizedUvRegion);
        float secondV = normalizeV(second.texV(), normalizedUvRegion);
        float thirdU = normalizeU(third.texU(), normalizedUvRegion);
        float thirdV = normalizeV(third.texV(), normalizedUvRegion);

        float deltaU1 = secondU - firstU;
        float deltaV1 = secondV - firstV;
        float deltaU2 = thirdU - firstU;
        float deltaV2 = thirdV - firstV;
        float determinant = deltaU1 * deltaV2 - deltaU2 * deltaV1;
        float inverseDeterminant = determinant == 0.0f ? 1.0f : 1.0f / determinant;

        float tangentX = inverseDeterminant * (deltaV2 * edge1X - deltaV1 * edge2X);
        float tangentY = inverseDeterminant * (deltaV2 * edge1Y - deltaV1 * edge2Y);
        float tangentZ = inverseDeterminant * (deltaV2 * edge1Z - deltaV1 * edge2Z);
        float tangentInverseLength = inverseSqrt(tangentX * tangentX + tangentY * tangentY + tangentZ * tangentZ);
        tangentX *= tangentInverseLength;
        tangentY *= tangentInverseLength;
        tangentZ *= tangentInverseLength;

        float bitangentX = inverseDeterminant * (-deltaU2 * edge1X + deltaU1 * edge2X);
        float bitangentY = inverseDeterminant * (-deltaU2 * edge1Y + deltaU1 * edge2Y);
        float bitangentZ = inverseDeterminant * (-deltaU2 * edge1Z + deltaU1 * edge2Z);
        float bitangentInverseLength = inverseSqrt(bitangentX * bitangentX + bitangentY * bitangentY + bitangentZ * bitangentZ);
        bitangentX *= bitangentInverseLength;
        bitangentY *= bitangentInverseLength;
        bitangentZ *= bitangentInverseLength;

        float crossX = tangentY * normal.z() - tangentZ * normal.y();
        float crossY = tangentZ * normal.x() - tangentX * normal.z();
        float crossZ = tangentX * normal.y() - tangentY * normal.x();
        float handedness = bitangentX * crossX + bitangentY * crossY + bitangentZ * crossZ < 0.0f ? -1.0f : 1.0f;

        return new byte[]{
                encodeNormalComponent(tangentX),
                encodeNormalComponent(tangentY),
                encodeNormalComponent(tangentZ),
                encodeNormalComponent(handedness)
        };
    }

    private static float inverseSqrt(float value) {
        if (value == 0.0f) {
            return 1.0f;
        }
        return (float) (1.0d / Math.sqrt(value));
    }

    private static float normalizeU(float u, @Nullable UvRegion normalizedUvRegion) {
        if (normalizedUvRegion == null || normalizedUvRegion.isFullCoverage()) {
            return u;
        }
        return (u - normalizedUvRegion.minU()) / normalizedUvRegion.width();
    }

    private static float normalizeV(float v, @Nullable UvRegion normalizedUvRegion) {
        if (normalizedUvRegion == null || normalizedUvRegion.isFullCoverage()) {
            return v;
        }
        return (v - normalizedUvRegion.minV()) / normalizedUvRegion.height();
    }

    private static byte encodeNormalComponent(float value) {
        return (byte) Math.round(Math.max(-1.0f, Math.min(1.0f, value)) * 127.0f);
    }

    private static UploadedGeometry uploadGeometry(ByteBuffer vertexData) {
        int vertexArrayId = GlStateManager._glGenVertexArrays();
        ChaosGlDebug.check("ChaosGpuGeoMesh.uploadGeometry._glGenVertexArrays");
        int vertexBufferId = GlStateManager._glGenBuffers();
        ChaosGlDebug.check("ChaosGpuGeoMesh.uploadGeometry._glGenBuffers");
        int vertexCount = vertexData.remaining() / VERTEX_STRIDE;

        try {
            GlStateManager._glBindVertexArray(vertexArrayId);
            ChaosGlDebug.check("ChaosGpuGeoMesh.uploadGeometry._glBindVertexArray");
            GlStateManager._glBindBuffer(GL15.GL_ARRAY_BUFFER, vertexBufferId);
            ChaosGlDebug.check("ChaosGpuGeoMesh.uploadGeometry._glBindBuffer.vertexBuffer");
            RenderSystem.glBufferData(GL15.GL_ARRAY_BUFFER, vertexData, GL15.GL_STATIC_DRAW);
            ChaosGlDebug.check("ChaosGpuGeoMesh.uploadGeometry.glBufferData");
            GL20.glEnableVertexAttribArray(0);
            ChaosGlDebug.check("ChaosGpuGeoMesh.uploadGeometry.glEnableVertexAttribArray.0");
            GL20.glVertexAttribPointer(0, 3, GL11.GL_FLOAT, false, VERTEX_STRIDE, POSITION_OFFSET);
            ChaosGlDebug.check("ChaosGpuGeoMesh.uploadGeometry.glVertexAttribPointer.0");
            GL20.glEnableVertexAttribArray(1);
            ChaosGlDebug.check("ChaosGpuGeoMesh.uploadGeometry.glEnableVertexAttribArray.1");
            GL20.glVertexAttribPointer(1, 4, GL11.GL_UNSIGNED_BYTE, true, VERTEX_STRIDE, COLOR_OFFSET);
            ChaosGlDebug.check("ChaosGpuGeoMesh.uploadGeometry.glVertexAttribPointer.1");
            GL20.glEnableVertexAttribArray(2);
            ChaosGlDebug.check("ChaosGpuGeoMesh.uploadGeometry.glEnableVertexAttribArray.2");
            GL20.glVertexAttribPointer(2, 2, GL11.GL_FLOAT, false, VERTEX_STRIDE, UV0_OFFSET);
            ChaosGlDebug.check("ChaosGpuGeoMesh.uploadGeometry.glVertexAttribPointer.2");
            GL20.glEnableVertexAttribArray(3);
            ChaosGlDebug.check("ChaosGpuGeoMesh.uploadGeometry.glEnableVertexAttribArray.3");
            GL30.glVertexAttribIPointer(3, 1, GL11.GL_INT, VERTEX_STRIDE, BONE_INDEX_OFFSET);
            ChaosGlDebug.check("ChaosGpuGeoMesh.uploadGeometry.glVertexAttribIPointer.3");
            GL20.glEnableVertexAttribArray(4);
            ChaosGlDebug.check("ChaosGpuGeoMesh.uploadGeometry.glEnableVertexAttribArray.4");
            GL20.glVertexAttribPointer(4, 4, GL11.GL_BYTE, true, VERTEX_STRIDE, NORMAL_OFFSET);
            ChaosGlDebug.check("ChaosGpuGeoMesh.uploadGeometry.glVertexAttribPointer.4");
            GL20.glEnableVertexAttribArray(5);
            ChaosGlDebug.check("ChaosGpuGeoMesh.uploadGeometry.glEnableVertexAttribArray.5");
            GL20.glVertexAttribPointer(5, 2, GL11.GL_FLOAT, false, VERTEX_STRIDE, MID_TEX_COORD_OFFSET);
            ChaosGlDebug.check("ChaosGpuGeoMesh.uploadGeometry.glVertexAttribPointer.5");
            GL20.glEnableVertexAttribArray(6);
            ChaosGlDebug.check("ChaosGpuGeoMesh.uploadGeometry.glEnableVertexAttribArray.6");
            GL20.glVertexAttribPointer(6, 4, GL11.GL_BYTE, true, VERTEX_STRIDE, TANGENT_OFFSET);
            ChaosGlDebug.check("ChaosGpuGeoMesh.uploadGeometry.glVertexAttribPointer.6");
            return new UploadedGeometry(vertexArrayId, vertexBufferId, vertexCount);
        } finally {
            GlStateManager._glBindBuffer(GL15.GL_ARRAY_BUFFER, 0);
            ChaosGlDebug.check("ChaosGpuGeoMesh.uploadGeometry.cleanup._glBindBuffer.0");
            GlStateManager._glBindVertexArray(0);
            ChaosGlDebug.check("ChaosGpuGeoMesh.uploadGeometry.cleanup._glBindVertexArray.0");
            MemoryUtil.memFree(vertexData);
        }
    }

    private record UploadedGeometry(int vertexArrayId, int vertexBufferId, int vertexCount) {
    }

    public record IndexedLocator(String name, GeoLocator locator, int boneIndex) {
    }

    public record UvRegion(float minU, float minV, float width, float height) {
        public static final UvRegion FULL = new UvRegion(0.0f, 0.0f, 1.0f, 1.0f);

        public boolean isFullCoverage() {
            return Math.abs(this.minU) <= 1.0e-6f
                    && Math.abs(this.minV) <= 1.0e-6f
                    && Math.abs(this.width - 1.0f) <= 1.0e-6f
                    && Math.abs(this.height - 1.0f) <= 1.0e-6f;
        }
    }

    private static final class SelectionKey {
        private final @Nullable Set<String> includedBones;
        private final boolean normalizeUvToBounds;
        private final int hashCode;

        private SelectionKey(@Nullable Set<String> includedBones, boolean normalizeUvToBounds) {
            this.includedBones = includedBones;
            this.normalizeUvToBounds = normalizeUvToBounds;
            this.hashCode = 31 * Objects.hashCode(includedBones) + Boolean.hashCode(normalizeUvToBounds);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof SelectionKey key)) {
                return false;
            }
            return this.normalizeUvToBounds == key.normalizeUvToBounds
                    && Objects.equals(this.includedBones, key.includedBones);
        }

        @Override
        public int hashCode() {
            return this.hashCode;
        }
    }

    private static final class GeometryBufferBuilder {
        private ByteBuffer buffer;
        private int vertexCount;
        private float minU = Float.POSITIVE_INFINITY;
        private float minV = Float.POSITIVE_INFINITY;
        private float maxU = Float.NEGATIVE_INFINITY;
        private float maxV = Float.NEGATIVE_INFINITY;

        private GeometryBufferBuilder(int initialBytes) {
            this.buffer = MemoryUtil.memAlloc(initialBytes).order(ByteOrder.nativeOrder());
        }

        private void putVertex(
                float x,
                float y,
                float z,
                byte red,
                byte green,
                byte blue,
                byte alpha,
                float u,
                float v,
                int boneIndex,
                byte normalX,
                byte normalY,
                byte normalZ,
                float midU,
                float midV,
                byte tangentX,
                byte tangentY,
                byte tangentZ,
                byte tangentW) {
            ensureCapacity(VERTEX_STRIDE);
            this.buffer.putFloat(x);
            this.buffer.putFloat(y);
            this.buffer.putFloat(z);
            this.buffer.put(red);
            this.buffer.put(green);
            this.buffer.put(blue);
            this.buffer.put(alpha);
            this.buffer.putFloat(u);
            this.buffer.putFloat(v);
            this.buffer.putInt(boneIndex);
            this.buffer.put(normalX);
            this.buffer.put(normalY);
            this.buffer.put(normalZ);
            this.buffer.put((byte) 0);
            this.buffer.putFloat(midU);
            this.buffer.putFloat(midV);
            this.buffer.put(tangentX);
            this.buffer.put(tangentY);
            this.buffer.put(tangentZ);
            this.buffer.put(tangentW);
            this.vertexCount++;
            this.minU = Math.min(this.minU, u);
            this.minV = Math.min(this.minV, v);
            this.maxU = Math.max(this.maxU, u);
            this.maxV = Math.max(this.maxV, v);
        }

        private ByteBuffer build() {
            this.buffer.flip();
            return this.buffer;
        }

        private void ensureCapacity(int bytesNeeded) {
            if (this.buffer.remaining() >= bytesNeeded) {
                return;
            }

            int newCapacity = Math.max(this.buffer.capacity() << 1, this.buffer.capacity() + bytesNeeded);
            ByteBuffer newBuffer = MemoryUtil.memAlloc(newCapacity).order(ByteOrder.nativeOrder());
            this.buffer.flip();
            newBuffer.put(this.buffer);
            MemoryUtil.memFree(this.buffer);
            this.buffer = newBuffer;
        }

        private void close() {
            MemoryUtil.memFree(this.buffer);
            this.buffer = null;
        }

        private float minU() {
            return this.vertexCount > 0 ? this.minU : 0.0f;
        }

        private float minV() {
            return this.vertexCount > 0 ? this.minV : 0.0f;
        }

        private float maxU() {
            return this.vertexCount > 0 ? this.maxU : 1.0f;
        }

        private float maxV() {
            return this.vertexCount > 0 ? this.maxV : 1.0f;
        }
    }
}
