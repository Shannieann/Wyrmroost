package dev.elifian.chaoslib.gpu.shader;


import dev.elifian.chaoslib.platform.ClientOnly;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Set;

@ClientOnly
public final class ChaosGpuShaderSources {
    private ChaosGpuShaderSources() {
    }

    public static String load(String resourcePath) {
        return load(resourcePath, new HashSet<>());
    }

    private static String load(String resourcePath, Set<String> includeStack) {
        if (!includeStack.add(resourcePath)) {
            throw new IllegalStateException("Recursive ChaosLib shader include detected: " + resourcePath);
        }

        try (InputStream stream = ChaosGpuShaderSources.class.getClassLoader().getResourceAsStream(resourcePath)) {
            if (stream == null) {
                throw new IllegalStateException("Missing ChaosLib shader resource: " + resourcePath);
            }

            String source = new String(stream.readAllBytes(), StandardCharsets.UTF_8);
            return resolveIncludes(resourcePath, source, includeStack);
        } catch (IOException exception) {
            throw new IllegalStateException("Failed to load ChaosLib shader resource: " + resourcePath, exception);
        } finally {
            includeStack.remove(resourcePath);
        }
    }

    private static String resolveIncludes(String resourcePath, String source, Set<String> includeStack) {
        StringBuilder resolved = new StringBuilder(source.length() + 256);
        String baseDirectory = resourceDirectory(resourcePath);
        String[] lines = source.split("\n", -1);
        for (String line : lines) {
            String trimmed = line.trim();
            if (trimmed.startsWith("#include \"") && trimmed.endsWith("\"")) {
                String includePath = trimmed.substring("#include \"".length(), trimmed.length() - 1);
                String resolvedPath = resolvePath(baseDirectory, includePath);
                resolved.append(load(resolvedPath, includeStack));
            } else {
                resolved.append(line).append('\n');
            }
        }
        return resolved.toString();
    }

    private static String resourceDirectory(String resourcePath) {
        int separator = resourcePath.lastIndexOf('/');
        return separator < 0 ? "" : resourcePath.substring(0, separator + 1);
    }

    private static String resolvePath(String baseDirectory, String includePath) {
        if (includePath.startsWith("/")) {
            return includePath.substring(1);
        }
        return baseDirectory + includePath;
    }
}
