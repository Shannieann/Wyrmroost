package dev.elifian.chaoslib.gpu.shader;

import dev.elifian.chaoslib.ChaosLib;
import net.minecraft.client.renderer.ShaderInstance;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;

import dev.elifian.chaoslib.platform.ClientOnly;
import dev.elifian.chaoslib.platform.render.ChaosShaderRegistry;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Owns ChaosLib's GUI-side core shaders, kept separate from the geo/instancing GPU pipeline
 * ({@link ChaosGpuShaderManager}) since they have an unrelated lifecycle and vertex format.
 */
@ClientOnly
public final class ChaosGuiShaderManager {
    private static final Logger LOGGER = LoggerFactory.getLogger("ChaosLib/GuiShaders");
    private static ShaderInstance guiBlurShader;

    private ChaosGuiShaderManager() {
    }

    public static void registerShaders(ChaosShaderRegistry registry) {
        try {
            registry.register(ChaosLib.id("gui_blur"), DefaultVertexFormat.POSITION_TEX, shader -> guiBlurShader = shader);
        } catch (Exception exception) {
            guiBlurShader = null;
            LOGGER.warn("Failed to register ChaosLib GUI blur shader; the overlay will use a plain background", exception);
        }
    }

    public static @Nullable ShaderInstance getGuiBlurShader() {
        return guiBlurShader;
    }
}
