package dev.elifian.chaoslib.gpu.shader;

import dev.elifian.chaoslib.ChaosLib;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuAnimationPoseStorage;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuBoneDataStorage;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuBoneResolveDispatcher;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuInstanceDataStorage;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuInstancedPoseBatchStorage;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuLocatorDataStorage;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuWorldLightVolumeStorage;
import dev.elifian.chaoslib.gpu.animation.ChaosGpuAnimationPayloadCache;
import dev.elifian.chaoslib.gpu.mesh.ChaosGpuGeoMesh;
import dev.elifian.chaoslib.gpu.render.ChaosGpuPoseDataCache;
import dev.elifian.chaoslib.gpu.render.ChaosGpuShaderPackRenderer;
import dev.elifian.chaoslib.gpu.render.ChaosGpuWorldRenderDispatcher;
import net.minecraft.client.renderer.ShaderInstance;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;

import dev.elifian.chaoslib.platform.ClientOnly;
import dev.elifian.chaoslib.platform.render.ChaosShaderRegistry;

import java.io.IOException;

@ClientOnly
public final class ChaosGpuShaderManager {
    private static ShaderInstance geoShader;
    private static ShaderInstance geoInstancedShader;

    private ChaosGpuShaderManager() {
    }

    public static void invalidateRuntimeCaches() {
        ChaosGpuAnimationPayloadCache.clear();
        ChaosGpuGeoMesh.invalidateAll();
        ChaosGpuPoseDataCache.clear();
        ChaosGpuShaderPackRenderer.invalidateAll();
        ChaosGpuBoneResolveDispatcher.invalidateAll();
        ChaosGpuBoneDataStorage.invalidateAll();
        ChaosGpuInstanceDataStorage.invalidateAll();
        ChaosGpuInstancedPoseBatchStorage.invalidateAll();
        ChaosGpuAnimationPoseStorage.invalidateAll();
        ChaosGpuLocatorDataStorage.invalidateAll();
        ChaosGpuWorldLightVolumeStorage.invalidateAll();
        ChaosGpuWorldRenderDispatcher.invalidateQueuedBatches();
    }

    public static void registerShaders(ChaosShaderRegistry registry) {
        invalidateRuntimeCaches();

        registry.register(ChaosLib.id("geo_dynamic"), DefaultVertexFormat.NEW_ENTITY, shader -> geoShader = shader);
        registry.register(ChaosLib.id("geo_dynamic_instanced"), DefaultVertexFormat.NEW_ENTITY, shader -> geoInstancedShader = shader);
    }

    public static ShaderInstance getGeoShader() {
        return geoShader;
    }

    public static ShaderInstance getGeoInstancedShader() {
        return geoInstancedShader;
    }
}
