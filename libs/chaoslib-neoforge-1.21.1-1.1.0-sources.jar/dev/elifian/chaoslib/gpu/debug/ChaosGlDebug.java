package dev.elifian.chaoslib.gpu.debug;

import dev.elifian.chaoslib.ChaosLib;

import dev.elifian.chaoslib.platform.ClientOnly;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@ClientOnly
public final class ChaosGlDebug {
    private static final Set<String> LOGGED_ERRORS = Collections.synchronizedSet(new HashSet<>());
    private static final Set<String> LOGGED_VERTEX_ARRAY_WARNINGS = Collections.synchronizedSet(new HashSet<>());
    private static volatile boolean glDebugReflectionResolved;
    private static volatile Class<?> glDebugClass;
    private static volatile Field glDebugEnabledField;
    private static volatile Field glDebugLastEntryField;
    private static volatile Method glDebugIsEnabledMethod;
    private static volatile Method glDebugGetMessagesMethod;
    private static volatile Method glDebugSourceToStringMethod;
    private static volatile Method glDebugTypeToStringMethod;
    private static volatile Method glDebugSeverityToStringMethod;
    private static volatile String lastCallbackFingerprint;
    private static volatile int lastCallbackCount;
    private static volatile boolean callbackEntryFieldsResolved;
    private static volatile Field callbackIdField;
    private static volatile Field callbackSourceField;
    private static volatile Field callbackTypeField;
    private static volatile Field callbackSeverityField;
    private static volatile Field callbackMessageField;
    private static volatile Field callbackCountField;

    private ChaosGlDebug() {
    }

    public static void clearLoggedErrors() {
        LOGGED_ERRORS.clear();
        lastCallbackFingerprint = null;
        lastCallbackCount = 0;
    }

    public static void check(String stage) {
        if (useVanillaDebugCallback()) {
            return;
        }
        drainErrors(stage);
    }

    public static boolean failIfErrored(String stage) {
        if (useVanillaDebugCallback()) {
            return drainCallbackErrors(stage);
        }
        return drainErrors(stage) > 0;
    }

    public static int captureVertexArrayBinding(String stage) {
        int currentVertexArray = GL11.glGetInteger(GL30.GL_VERTEX_ARRAY_BINDING);
        if (currentVertexArray == 0 || GL30.glIsVertexArray(currentVertexArray)) {
            return currentVertexArray;
        }

        logInvalidVertexArray(stage, currentVertexArray);
        GL30.glBindVertexArray(0);
        check(stage + ".sanitize.glBindVertexArray.0");
        return 0;
    }

    public static void restoreVertexArrayBinding(int vertexArrayId, String stage) {
        if (vertexArrayId != 0 && !GL30.glIsVertexArray(vertexArrayId)) {
            logInvalidVertexArray(stage, vertexArrayId);
            vertexArrayId = 0;
        }

        GL30.glBindVertexArray(vertexArrayId);
        check(stage + ".glBindVertexArray");
    }

    private static int drainErrors(String stage) {
        int errorCount = 0;
        int error = GL11.glGetError();
        while (error != GL11.GL_NO_ERROR) {
            errorCount++;
            int currentProgram = GL11.glGetInteger(GL20.GL_CURRENT_PROGRAM);
            String key = stage + "-" + error + "-" + currentProgram;
            if (LOGGED_ERRORS.add(key)) {
                ChaosLib.LOGGER.warn(
                        "Chaos GL error after {}: {} ({}) currentProgram={}",
                        stage,
                        errorName(error),
                        String.format("0x%04X", error),
                        currentProgram
                );
            }
            error = GL11.glGetError();
        }
        return errorCount;
    }

    private static boolean useVanillaDebugCallback() {
        try {
            resolveGlDebugReflection();
            if (glDebugEnabledField != null) {
                return glDebugEnabledField.getBoolean(null);
            }

            Method method = glDebugIsEnabledMethod;
            return method != null && Boolean.TRUE.equals(method.invoke(null));
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static boolean drainCallbackErrors(String stage) {
        CallbackDebugMessage message = latestCallbackMessage();
        if (message == null) {
            return false;
        }

        boolean isNewMessage = !message.fingerprint().equals(lastCallbackFingerprint) || message.count() != lastCallbackCount;
        lastCallbackFingerprint = message.fingerprint();
        lastCallbackCount = message.count();
        if (!isNewMessage || !message.isError()) {
            return false;
        }

        String key = stage + "-" + message.fingerprint() + "-" + message.count();
        if (LOGGED_ERRORS.add(key)) {
            ChaosLib.LOGGER.warn(
                    "Chaos GL debug callback near {}: id={}, source={}, type={}, severity={}, message='{}'",
                    stage,
                    message.id(),
                    message.source(),
                    message.type(),
                    message.severity(),
                    message.message()
            );
        }
        return true;
    }

    private static CallbackDebugMessage latestCallbackMessage() {
        try {
            resolveGlDebugReflection();

            Object lastMessage = null;
            if (glDebugLastEntryField != null) {
                lastMessage = glDebugLastEntryField.get(null);
            }

            if (lastMessage == null) {
                Method method = glDebugGetMessagesMethod;
                if (method == null) {
                    return null;
                }
                Object value = method.invoke(null);
                if (!(value instanceof List<?> listValue) || listValue.isEmpty()) {
                    return null;
                }
                lastMessage = listValue.get(listValue.size() - 1);
            }

            if (lastMessage == null) {
                return null;
            }
            if (lastMessage instanceof String rawMessage) {
                return new CallbackDebugMessage(
                        "?",
                        "?",
                        rawMessage.contains("type=ERROR") ? "ERROR" : "?",
                        "?",
                        rawMessage,
                        rawMessage,
                        1
                );
            }

            resolveCallbackEntryFields(lastMessage.getClass());
            if (callbackMessageField == null) {
                String fallback = String.valueOf(lastMessage);
                return new CallbackDebugMessage(
                        "?",
                        "?",
                        fallback.contains("ERROR") ? "ERROR" : "?",
                        "?",
                        fallback,
                        fallback,
                        1
                );
            }

            int id = callbackIdField != null ? callbackIdField.getInt(lastMessage) : -1;
            int source = callbackSourceField != null ? callbackSourceField.getInt(lastMessage) : -1;
            int type = callbackTypeField != null ? callbackTypeField.getInt(lastMessage) : -1;
            int severity = callbackSeverityField != null ? callbackSeverityField.getInt(lastMessage) : -1;
            int count = callbackCountField != null ? callbackCountField.getInt(lastMessage) : 1;
            String text = String.valueOf(callbackMessageField.get(lastMessage));
            String sourceName = source >= 0 ? invokeDebugStringMethod(glDebugSourceToStringMethod(), source) : "?";
            String typeName = type >= 0 ? invokeDebugStringMethod(glDebugTypeToStringMethod(), type) : "?";
            String severityName = severity >= 0 ? invokeDebugStringMethod(glDebugSeverityToStringMethod(), severity) : "?";
            String fingerprint = id + "|" + source + "|" + type + "|" + severity + "|" + text;
            return new CallbackDebugMessage(
                    id >= 0 ? Integer.toString(id) : "?",
                    sourceName,
                    typeName,
                    severityName,
                    text,
                    fingerprint,
                    Math.max(count, 1)
            );
        } catch (Throwable ignored) {
            return null;
        }
    }

    private static Method glDebugIsEnabledMethod() {
        resolveGlDebugReflection();
        return glDebugIsEnabledMethod;
    }

    private static Method glDebugGetMessagesMethod() {
        resolveGlDebugReflection();
        return glDebugGetMessagesMethod;
    }

    private static Method glDebugSourceToStringMethod() {
        resolveGlDebugReflection();
        return glDebugSourceToStringMethod;
    }

    private static Method glDebugTypeToStringMethod() {
        resolveGlDebugReflection();
        return glDebugTypeToStringMethod;
    }

    private static Method glDebugSeverityToStringMethod() {
        resolveGlDebugReflection();
        return glDebugSeverityToStringMethod;
    }

    private static synchronized void resolveGlDebugReflection() {
        if (glDebugReflectionResolved) {
            return;
        }
        glDebugReflectionResolved = true;
        glDebugClass = loadGlDebugClass();
        if (glDebugClass == null) {
            return;
        }

        glDebugEnabledField = findStaticField(glDebugClass, boolean.class, "debugEnabled", "g");
        glDebugLastEntryField = findLastEntryField(glDebugClass);
        glDebugIsEnabledMethod = findStaticMethod(glDebugClass, boolean.class, new Class<?>[0], "isDebugEnabled", "method_36479", "m_166226_", "b");
        glDebugGetMessagesMethod = findStaticMethod(glDebugClass, List.class, new Class<?>[0], "getLastOpenGlDebugMessages", "method_36478", "m_166225_", "a");
        glDebugSourceToStringMethod = findStaticMethod(glDebugClass, String.class, new Class<?>[]{int.class}, "sourceToString", "method_4222", "m_84055_", "a");
        glDebugTypeToStringMethod = findStaticMethod(glDebugClass, String.class, new Class<?>[]{int.class}, "typeToString", "method_4228", "m_84057_", "b");
        glDebugSeverityToStringMethod = findStaticMethod(glDebugClass, String.class, new Class<?>[]{int.class}, "severityToString", "method_4226", "m_84059_", "c");
    }

    private static Class<?> loadGlDebugClass() {
        for (String className : new String[]{"com.mojang.blaze3d.platform.GlDebug", "com.mojang.blaze3d.platform.GlDebug"}) {
            try {
                return Class.forName(className);
            } catch (ClassNotFoundException ignored) {
            }
        }
        return null;
    }

    private static Method findStaticMethod(Class<?> owner, Class<?> returnType, Class<?>[] parameterTypes, String... candidates) {
        for (String candidate : candidates) {
            try {
                Method method = owner.getDeclaredMethod(candidate, parameterTypes);
                if (method.getReturnType() != returnType) {
                    continue;
                }
                method.setAccessible(true);
                return method;
            } catch (ReflectiveOperationException ignored) {
            }
        }

        for (Method method : owner.getDeclaredMethods()) {
            if (method.getReturnType() != returnType) {
                continue;
            }
            if (!java.lang.reflect.Modifier.isStatic(method.getModifiers())) {
                continue;
            }
            if (!java.util.Arrays.equals(method.getParameterTypes(), parameterTypes)) {
                continue;
            }
            method.setAccessible(true);
            return method;
        }

        return null;
    }

    private static Field findStaticField(Class<?> owner, Class<?> type, String... candidates) {
        for (String candidate : candidates) {
            try {
                Field field = owner.getDeclaredField(candidate);
                if (field.getType() != type || !java.lang.reflect.Modifier.isStatic(field.getModifiers())) {
                    continue;
                }
                field.setAccessible(true);
                return field;
            } catch (ReflectiveOperationException ignored) {
            }
        }

        for (Field field : owner.getDeclaredFields()) {
            if (field.getType() != type || !java.lang.reflect.Modifier.isStatic(field.getModifiers())) {
                continue;
            }
            field.setAccessible(true);
            return field;
        }

        return null;
    }

    private static Field findLastEntryField(Class<?> owner) {
        for (String candidate : new String[]{"lastEntry", "d"}) {
            try {
                Field field = owner.getDeclaredField(candidate);
                if (!java.lang.reflect.Modifier.isStatic(field.getModifiers())) {
                    continue;
                }
                field.setAccessible(true);
                return field;
            } catch (ReflectiveOperationException ignored) {
            }
        }

        for (Field field : owner.getDeclaredFields()) {
            if (!java.lang.reflect.Modifier.isStatic(field.getModifiers())) {
                continue;
            }
            if (!field.getType().getSimpleName().contains("LogEntry")) {
                continue;
            }
            field.setAccessible(true);
            return field;
        }

        return null;
    }

    private static String invokeDebugStringMethod(Method method, int value) {
        if (method == null) {
            return "?";
        }
        try {
            Object result = method.invoke(null, value);
            return result instanceof String string ? string : "?";
        } catch (ReflectiveOperationException ignored) {
            return "?";
        }
    }

    private static synchronized void resolveCallbackEntryFields(Class<?> entryClass) {
        if (callbackEntryFieldsResolved) {
            return;
        }
        callbackEntryFieldsResolved = true;
        callbackIdField = findIntField(entryClass, "id");
        callbackSourceField = findIntField(entryClass, "source");
        callbackTypeField = findIntField(entryClass, "type");
        callbackSeverityField = findIntField(entryClass, "severity");
        callbackCountField = findIntField(entryClass, "count");
        callbackMessageField = findField(entryClass, "message", String.class);

        if (callbackIdField == null || callbackSourceField == null || callbackTypeField == null
                || callbackSeverityField == null || callbackMessageField == null || callbackCountField == null) {
            List<Field> instanceFields = java.util.Arrays.stream(entryClass.getDeclaredFields())
                    .filter(field -> !java.lang.reflect.Modifier.isStatic(field.getModifiers()))
                    .toList();
            if (callbackIdField == null && instanceFields.size() > 0 && instanceFields.get(0).getType() == int.class) {
                callbackIdField = makeAccessible(instanceFields.get(0));
            }
            if (callbackSourceField == null && instanceFields.size() > 1 && instanceFields.get(1).getType() == int.class) {
                callbackSourceField = makeAccessible(instanceFields.get(1));
            }
            if (callbackTypeField == null && instanceFields.size() > 2 && instanceFields.get(2).getType() == int.class) {
                callbackTypeField = makeAccessible(instanceFields.get(2));
            }
            if (callbackSeverityField == null && instanceFields.size() > 3 && instanceFields.get(3).getType() == int.class) {
                callbackSeverityField = makeAccessible(instanceFields.get(3));
            }
            if (callbackMessageField == null && instanceFields.size() > 4 && instanceFields.get(4).getType() == String.class) {
                callbackMessageField = makeAccessible(instanceFields.get(4));
            }
            if (callbackCountField == null && instanceFields.size() > 5 && instanceFields.get(5).getType() == int.class) {
                callbackCountField = makeAccessible(instanceFields.get(5));
            }
        }
    }

    private static Field findIntField(Class<?> owner, String name) {
        return findField(owner, name, int.class);
    }

    private static Field findField(Class<?> owner, String name, Class<?> type) {
        try {
            Field field = owner.getDeclaredField(name);
            if (field.getType() != type) {
                return null;
            }
            return makeAccessible(field);
        } catch (ReflectiveOperationException ignored) {
            return null;
        }
    }

    private static Field makeAccessible(Field field) {
        field.setAccessible(true);
        return field;
    }

    private static void logInvalidVertexArray(String stage, int vertexArrayId) {
        String key = stage + "-" + vertexArrayId;
        if (LOGGED_VERTEX_ARRAY_WARNINGS.add(key)) {
            ChaosLib.LOGGER.warn("Chaos invalid VAO binding detected at {}: vao={}", stage, vertexArrayId);
        }
    }

    public static String errorName(int error) {
        return switch (error) {
            case GL11.GL_INVALID_ENUM -> "GL_INVALID_ENUM";
            case GL11.GL_INVALID_VALUE -> "GL_INVALID_VALUE";
            case GL11.GL_INVALID_OPERATION -> "GL_INVALID_OPERATION";
            case GL30.GL_INVALID_FRAMEBUFFER_OPERATION -> "GL_INVALID_FRAMEBUFFER_OPERATION";
            case GL11.GL_OUT_OF_MEMORY -> "GL_OUT_OF_MEMORY";
            default -> "GL_ERROR_" + error;
        };
    }

    private record CallbackDebugMessage(
            String id,
            String source,
            String type,
            String severity,
            String message,
            String fingerprint,
            int count) {
        private boolean isError() {
            return "ERROR".equalsIgnoreCase(this.type);
        }
    }
}
