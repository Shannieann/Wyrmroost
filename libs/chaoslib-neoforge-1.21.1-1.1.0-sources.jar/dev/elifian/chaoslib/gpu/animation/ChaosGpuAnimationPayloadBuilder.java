package dev.elifian.chaoslib.gpu.animation;

import dev.elifian.chaoslib.client.animation.GeoAnimationData;
import dev.elifian.chaoslib.gpu.mesh.ChaosGpuGeoMesh;
import dev.elifian.chaoslib.molang.MolangRuntime;

import dev.elifian.chaoslib.platform.ClientOnly;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Locale;

@ClientOnly
public final class ChaosGpuAnimationPayloadBuilder {
    private static final int CLIP_STRIDE = 4;
    private static final int CHANNEL_STRIDE = 12;
    private static final int KEYFRAME_STRIDE = 20;

    private ChaosGpuAnimationPayloadBuilder() {
    }

    public static ChaosGpuAnimationPayload build(ChaosGpuGeoMesh mesh, GeoAnimationData animationData) {
        ArrayList<Float> clipData = new ArrayList<>();
        ArrayList<Float> channelData = new ArrayList<>();
        ArrayList<Float> keyframeData = new ArrayList<>();
        LinkedHashMap<String, Integer> clipIndices = new LinkedHashMap<>();
        ArrayList<ChaosGpuAnimationPayload.ClipRuntime> runtimeClips = new ArrayList<>();
        int clipIndex = 0;
        int channelIndex = 0;

        for (Map.Entry<String, GeoAnimationData.AnimationClip> clipEntry : animationData.animations().entrySet()) {
            String clipName = clipEntry.getKey();
            GeoAnimationData.AnimationClip clip = clipEntry.getValue();
            int clipChannelStart = channelIndex;
            clipIndices.put(clipName, clipIndex);
            ArrayList<ChaosGpuAnimationPayload.DynamicChannel> dynamicChannels = new ArrayList<>();
            int dynamicSlot = 0;

            for (Map.Entry<String, GeoAnimationData.BoneAnimation> boneEntry : clip.bones().entrySet()) {
                String boneName = boneEntry.getKey();
                GeoAnimationData.BoneAnimation boneAnimation = boneEntry.getValue();
                int boneIndex = indexOfBone(mesh, boneName);
                if (boneIndex < 0) {
                    continue;
                }

                channelIndex = appendChannel(
                        channelData,
                        keyframeData,
                        channelIndex,
                        boneIndex,
                        0,
                        boneAnimation.position(),
                        boneAnimation.relativeTo().position(),
                        boneName,
                        dynamicChannels,
                        dynamicSlot
                );
                dynamicSlot = dynamicChannels.size();

                channelIndex = appendChannel(
                        channelData,
                        keyframeData,
                        channelIndex,
                        boneIndex,
                        1,
                        boneAnimation.rotation(),
                        boneAnimation.relativeTo().rotation(),
                        boneName,
                        dynamicChannels,
                        dynamicSlot
                );
                dynamicSlot = dynamicChannels.size();

                channelIndex = appendChannel(
                        channelData,
                        keyframeData,
                        channelIndex,
                        boneIndex,
                        2,
                        boneAnimation.scale(),
                        boneAnimation.relativeTo().scale(),
                        boneName,
                        dynamicChannels,
                        dynamicSlot
                );
                dynamicSlot = dynamicChannels.size();
            }

            clipData.add((float) clipChannelStart);
            clipData.add((float) (channelIndex - clipChannelStart));
            clipData.add(clip.lengthSeconds());
            clipData.add(clip.loop() ? 1.0f : 0.0f);
            runtimeClips.add(new ChaosGpuAnimationPayload.ClipRuntime(clipName, dynamicChannels));
            clipIndex++;
        }

        return new ChaosGpuAnimationPayload(
                mesh.getIndexedBones().size(),
                clipIndex,
                channelIndex,
                keyframeData.size() / KEYFRAME_STRIDE,
                false,
                Map.copyOf(clipIndices),
                List.copyOf(runtimeClips),
                toFloatArray(clipData),
                toFloatArray(channelData),
                toFloatArray(keyframeData)
        );
    }

    private static int appendChannel(
            List<Float> channelData,
            List<Float> keyframeData,
            int channelIndex,
            int boneIndex,
            int target,
            GeoAnimationData.Channel channel,
            GeoAnimationData.Space relativeToSpace,
            String boneName,
            List<ChaosGpuAnimationPayload.DynamicChannel> dynamicChannels,
            int dynamicSlot
    ) {
        if (channel == null || channel.isEmpty()) {
            return channelIndex;
        }

        if (!isStaticChannel(channel)) {
            dynamicChannels.add(new ChaosGpuAnimationPayload.DynamicChannel(boneName, channel));
            appendChannelRecord(
                    channelData,
                    boneIndex,
                    target,
                    0,
                    0,
                    0.0f,
                    0.0f,
                    0.0f,
                    false,
                    relativeToSpace,
                    dynamicSlot
            );
            return channelIndex + 1;
        }

        ConstantVector constantVector = channel.isConstant() ? constantVector(channel.constantValue()) : ConstantVector.ZERO;
        int keyframeStart = keyframeData.size() / KEYFRAME_STRIDE;
        int keyframeCount = 0;
        if (!channel.isConstant()) {
            for (GeoAnimationData.Keyframe keyframe : channel.keyframes()) {
                appendKeyframe(keyframeData, keyframe);
            }
            keyframeCount = channel.keyframes().size();
        }

        appendChannelRecord(
                channelData,
                boneIndex,
                target,
                keyframeStart,
                keyframeCount,
                constantVector.x(),
                constantVector.y(),
                constantVector.z(),
                channel.isConstant(),
                relativeToSpace,
                -1
        );
        return channelIndex + 1;
    }

    private static void appendChannelRecord(
            List<Float> channelData,
            int boneIndex,
            int target,
            int keyframeStart,
            int keyframeCount,
            float constantX,
            float constantY,
            float constantZ,
            boolean constant,
            GeoAnimationData.Space relativeToSpace,
            int dynamicSlot
    ) {
        channelData.add((float) boneIndex);
        channelData.add((float) target);
        channelData.add((float) keyframeStart);
        channelData.add((float) keyframeCount);
        channelData.add(constantX);
        channelData.add(constantY);
        channelData.add(constantZ);
        channelData.add(constant ? 1.0f : 0.0f);
        channelData.add((float) relativeToSpace.ordinal());
        channelData.add((float) dynamicSlot);
        channelData.add(0.0f);
        channelData.add(0.0f);
    }

    private static void appendKeyframe(List<Float> data, GeoAnimationData.Keyframe keyframe) {
        ConstantVector pre = constantVector(keyframe.pre());
        ConstantVector post = constantVector(keyframe.post());
        ConstantVector leftBezier = constantVector(keyframe.leftBezier());
        ConstantVector rightBezier = constantVector(keyframe.rightBezier());
        if (pre == null || post == null || leftBezier == null || rightBezier == null) {
            throw new IllegalStateException("Static GPU keyframe was built from a non-static vector");
        }
        float easingCode = keyframe.easing() == null ? -1.0f : easingTypeCode(keyframe.easing().type());
        float easingArg = easingArg(keyframe.easing());

        data.add(keyframe.timeSeconds());
        data.add((float) keyframe.lerpMode().ordinal());
        data.add(easingCode);
        data.add(easingArg);

        appendVector(data, pre);
        appendVector(data, post);
        appendVector(data, leftBezier);
        appendVector(data, rightBezier);
    }

    private static boolean isStaticChannel(GeoAnimationData.Channel channel) {
        if (channel == null || channel.isEmpty()) {
            return true;
        }
        if (channel.isConstant()) {
            return constantVector(channel.constantValue()) != null;
        }

        for (GeoAnimationData.Keyframe keyframe : channel.keyframes()) {
            if (!isStaticKeyframe(keyframe)) {
                return false;
            }
        }
        return true;
    }

    private static boolean isStaticKeyframe(GeoAnimationData.Keyframe keyframe) {
        return constantVector(keyframe.pre()) != null
                && constantVector(keyframe.post()) != null
                && constantVector(keyframe.leftBezier()) != null
                && constantVector(keyframe.rightBezier()) != null
                && isStaticEasing(keyframe.easing());
    }

    private static boolean isStaticEasing(GeoAnimationData.Easing easing) {
        if (easing == null) {
            return true;
        }
        for (MolangRuntime.MolangExpression arg : easing.args()) {
            if (constantNumber(arg) == null) {
                return false;
            }
        }
        return true;
    }

    private static float easingTypeCode(String rawType) {
        return switch (normalizeEasingType(rawType)) {
            case "none", "linear" -> 0.0f;
            case "step" -> 1.0f;
            case "catmullrom" -> 2.0f;
            case "easeinsine" -> 3.0f;
            case "easeoutsine" -> 4.0f;
            case "easeinoutsine" -> 5.0f;
            case "easeinquad" -> 6.0f;
            case "easeoutquad" -> 7.0f;
            case "easeinoutquad" -> 8.0f;
            case "easeincubic" -> 9.0f;
            case "easeoutcubic" -> 10.0f;
            case "easeinoutcubic" -> 11.0f;
            case "easeinquart" -> 12.0f;
            case "easeoutquart" -> 13.0f;
            case "easeinoutquart" -> 14.0f;
            case "easeinquint" -> 15.0f;
            case "easeoutquint" -> 16.0f;
            case "easeinoutquint" -> 17.0f;
            case "easeinexpo" -> 18.0f;
            case "easeoutexpo" -> 19.0f;
            case "easeinoutexpo" -> 20.0f;
            case "easeincirc" -> 21.0f;
            case "easeoutcirc" -> 22.0f;
            case "easeinoutcirc" -> 23.0f;
            case "easeinback" -> 24.0f;
            case "easeoutback" -> 25.0f;
            case "easeinoutback" -> 26.0f;
            case "easeinelastic" -> 27.0f;
            case "easeoutelastic" -> 28.0f;
            case "easeinoutelastic" -> 29.0f;
            case "easeinbounce" -> 30.0f;
            case "easeoutbounce" -> 31.0f;
            case "easeinoutbounce" -> 32.0f;
            default -> 0.0f;
        };
    }

    private static float easingArg(GeoAnimationData.Easing easing) {
        if (easing == null || easing.args().isEmpty()) {
            return Float.NaN;
        }
        Float value = constantNumber(easing.args().get(0));
        return value == null ? Float.NaN : value;
    }

    private static void appendVector(List<Float> data, ConstantVector vector) {
        data.add(vector.x());
        data.add(vector.y());
        data.add(vector.z());
        data.add(0.0f);
    }

    private static ConstantVector constantVector(GeoAnimationData.VectorExpression vector) {
        Float x = constantNumber(vector.x());
        Float y = constantNumber(vector.y());
        Float z = constantNumber(vector.z());
        return x == null || y == null || z == null ? null : new ConstantVector(x, y, z);
    }

    private static Float constantNumber(MolangRuntime.MolangExpression expression) {
        if (!MolangRuntime.isConstant(expression)) {
            return null;
        }

        MolangRuntime.MolangValue value = MolangRuntime.constantValue(expression);
        if (value.type() != MolangRuntime.MolangValue.Type.NUMBER) {
            return null;
        }
        return (float) value.asNumber();
    }

    private static String normalizeEasingType(String rawType) {
        return rawType == null ? "linear" : rawType.toLowerCase(Locale.ROOT);
    }

    private static int indexOfBone(ChaosGpuGeoMesh mesh, String boneName) {
        for (int i = 0; i < mesh.getIndexedBones().size(); i++) {
            if (mesh.getIndexedBones().get(i).getName().equals(boneName)) {
                return i;
            }
        }
        return -1;
    }

    private static float[] toFloatArray(List<Float> values) {
        float[] array = new float[values.size()];
        for (int i = 0; i < values.size(); i++) {
            array[i] = values.get(i);
        }
        return array;
    }

    private record ConstantVector(float x, float y, float z) {
        private static final ConstantVector ZERO = new ConstantVector(0.0f, 0.0f, 0.0f);

        private ConstantVector lerp(ConstantVector target, float alpha) {
            return new ConstantVector(
                    this.x + (target.x - this.x) * alpha,
                    this.y + (target.y - this.y) * alpha,
                    this.z + (target.z - this.z) * alpha
            );
        }
    }
}
