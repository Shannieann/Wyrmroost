package dev.elifian.chaoslib.gpu.animation;

import dev.elifian.chaoslib.client.animation.GeoAnimationData;
import dev.elifian.chaoslib.gpu.mesh.ChaosGpuGeoMesh;

import dev.elifian.chaoslib.platform.ClientOnly;

import java.util.IdentityHashMap;
import java.util.Map;
import java.util.WeakHashMap;

@ClientOnly
public final class ChaosGpuAnimationPayloadCache {
    private static final Map<ChaosGpuGeoMesh, Map<GeoAnimationData, ChaosGpuAnimationPayload>> CACHE = new WeakHashMap<>();

    private ChaosGpuAnimationPayloadCache() {
    }

    public static ChaosGpuAnimationPayload getOrCreate(ChaosGpuGeoMesh mesh, GeoAnimationData animationData) {
        synchronized (CACHE) {
            return CACHE.computeIfAbsent(mesh, ignored -> new IdentityHashMap<>())
                    .computeIfAbsent(animationData, ignored -> ChaosGpuAnimationPayloadBuilder.build(mesh, animationData));
        }
    }

    public static void clear() {
        synchronized (CACHE) {
            CACHE.clear();
        }
    }
}
