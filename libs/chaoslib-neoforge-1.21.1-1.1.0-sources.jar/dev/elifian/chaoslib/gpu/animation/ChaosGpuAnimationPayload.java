package dev.elifian.chaoslib.gpu.animation;

import dev.elifian.chaoslib.client.animation.GeoAnimationData;

import dev.elifian.chaoslib.platform.ClientOnly;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@ClientOnly
public record ChaosGpuAnimationPayload(
        int boneCount,
        int clipCount,
        int channelCount,
        int keyframeCount,
        boolean requiresCpuPoseSampling,
        Map<String, Integer> clipIndices,
        List<ClipRuntime> runtimeClips,
        float[] clipData,
        float[] channelData,
        float[] keyframeData
) {
    private static final Map<Integer, ChaosGpuAnimationPayload> EMPTY_CACHE = new HashMap<>();

    public static ChaosGpuAnimationPayload empty(int boneCount) {
        ChaosGpuAnimationPayload cached = EMPTY_CACHE.get(boneCount);
        if (cached != null) {
            return cached;
        }

        ChaosGpuAnimationPayload payload = new ChaosGpuAnimationPayload(
                boneCount,
                0,
                0,
                0,
                false,
                Map.of(),
                List.of(),
                new float[0],
                new float[0],
                new float[0]
        );
        EMPTY_CACHE.put(boneCount, payload);
        return payload;
    }

    public ChaosGpuAnimationPayload {
        runtimeClips = List.copyOf(runtimeClips);
    }

    public boolean isEmpty() {
        return this.clipCount <= 0 || this.channelCount <= 0;
    }

    public int clipIndex(String clipName) {
        return this.clipIndices.getOrDefault(clipName, -1);
    }

    public ClipRuntime runtimeClip(int clipIndex) {
        return clipIndex < 0 || clipIndex >= this.runtimeClips.size()
                ? ClipRuntime.EMPTY
                : this.runtimeClips.get(clipIndex);
    }

    public record ClipRuntime(String clipName, List<DynamicChannel> dynamicChannels) {
        private static final ClipRuntime EMPTY = new ClipRuntime("", List.of());

        public ClipRuntime {
            dynamicChannels = List.copyOf(dynamicChannels);
        }

        public int dynamicChannelCount() {
            return this.dynamicChannels.size();
        }
    }

    public record DynamicChannel(String boneName, GeoAnimationData.Channel channel) {
    }
}
