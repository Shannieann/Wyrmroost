package dev.elifian.chaoslib.gpu.render;

import dev.elifian.chaoslib.cache.object.BakedGeoModel;
import dev.elifian.chaoslib.cache.object.GeoBone;
import dev.elifian.chaoslib.gpu.mesh.ChaosGpuGeoMesh;
import dev.elifian.chaoslib.model.baked.StaticGeoBonePose;

import dev.elifian.chaoslib.platform.ClientOnly;

import java.util.*;

@ClientOnly
public final class ChaosGpuPoseDataCache {
    private static final int MAX_POSE_CACHE_ENTRIES_PER_MODEL = 256;
    private static final int MAX_EMISSIVE_MASK_ENTRIES_PER_MESH = 64;
    private static final int MAX_TOTAL_POSE_CACHE_ENTRIES = 1024;
    private static final int MAX_TOTAL_STATIC_POSE_CACHE_ENTRIES = 1024;
    private static final int MAX_TOTAL_EMISSIVE_MASK_CACHE_ENTRIES = 512;
    private static final ThreadLocal<float[]> EMISSIVE_MASK_BUFFER = ThreadLocal.withInitial(() -> new float[16]);
    private static final Map<BakedGeoModel, Map<Object, float[]>> POSE_CACHE = new WeakHashMap<>();
    private static final Map<ChaosGpuGeoMesh, Map<Object, float[]>> STATIC_POSE_CACHE = new WeakHashMap<>();
    private static final Map<ChaosGpuGeoMesh, Map<Object, float[]>> EMISSIVE_MASK_CACHE = new WeakHashMap<>();
    private static BakedGeoModel lastPoseModel;
    private static Object lastPoseKey;
    private static float[] lastPoseData;
    private static ChaosGpuGeoMesh lastStaticPoseMesh;
    private static Object lastStaticPoseKey;
    private static float[] lastStaticPoseData;
    private static ChaosGpuGeoMesh lastEmissiveMesh;
    private static Object lastEmissiveKey;
    private static float[] lastEmissiveData;

    private ChaosGpuPoseDataCache() {
    }

    public static float[] prepareBonePoseData(Object animatableCacheKey, BakedGeoModel model, ChaosGpuGeoMesh mesh) {
        if (model == lastPoseModel && animatableCacheKey.equals(lastPoseKey) && lastPoseData != null) {
            return lastPoseData;
        }

        Map<Object, float[]> modelPoseCache = POSE_CACHE.get(model);
        if (modelPoseCache != null) {
            float[] cached = modelPoseCache.get(animatableCacheKey);
            if (cached != null) {
                lastPoseModel = model;
                lastPoseKey = animatableCacheKey;
                lastPoseData = cached;
                return cached;
            }
        }

        float[] cachedCopy = createIdentityBonePoseData(mesh.getIndexedBones().size());
        writeBonePoseData(model, mesh, cachedCopy);
        POSE_CACHE.computeIfAbsent(model, ignored -> newPoseCache(MAX_POSE_CACHE_ENTRIES_PER_MODEL)).put(animatableCacheKey, cachedCopy);
        trimCachesIfNeeded();
        lastPoseModel = model;
        lastPoseKey = animatableCacheKey;
        lastPoseData = cachedCopy;
        return cachedCopy;
    }

    public static float[] createBonePoseData(BakedGeoModel model, ChaosGpuGeoMesh mesh) {
        float[] poseData = createIdentityBonePoseData(mesh.getIndexedBones().size());
        writeBonePoseData(model, mesh, poseData);
        return poseData;
    }

    public static float[] prepareStaticBonePoseData(ChaosGpuGeoMesh mesh, Map<String, StaticGeoBonePose> staticBonePoses, Object poseCacheKey) {
        if (mesh == lastStaticPoseMesh && poseCacheKey.equals(lastStaticPoseKey) && lastStaticPoseData != null) {
            return lastStaticPoseData;
        }

        Map<Object, float[]> meshPoseCache = STATIC_POSE_CACHE.get(mesh);
        if (meshPoseCache != null) {
            float[] cached = meshPoseCache.get(poseCacheKey);
            if (cached != null) {
                lastStaticPoseMesh = mesh;
                lastStaticPoseKey = poseCacheKey;
                lastStaticPoseData = cached;
                return cached;
            }
        }

        float[] cachedCopy = createIdentityBonePoseData(mesh.getIndexedBones().size());
        writeStaticBonePoseData(mesh, staticBonePoses, cachedCopy);
        STATIC_POSE_CACHE.computeIfAbsent(mesh, ignored -> newPoseCache(MAX_POSE_CACHE_ENTRIES_PER_MODEL)).put(poseCacheKey, cachedCopy);
        trimCachesIfNeeded();
        lastStaticPoseMesh = mesh;
        lastStaticPoseKey = poseCacheKey;
        lastStaticPoseData = cachedCopy;
        return cachedCopy;
    }

    public static float[] prepareEmissiveMaskData(ChaosGpuGeoMesh mesh, Set<String> emissiveBones) {
        int boneCount = mesh.getIndexedBones().size();
        if (emissiveBones == null) {
            return EMISSIVE_MASK_CACHE.computeIfAbsent(mesh, ignored -> newPoseCache(MAX_EMISSIVE_MASK_ENTRIES_PER_MESH))
                    .computeIfAbsent(FullEmissiveMaskKey.INSTANCE, ignored -> createFilledEmissiveMask(boneCount, 1.0f));
        }
        if (emissiveBones.isEmpty()) {
            return EMISSIVE_MASK_CACHE.computeIfAbsent(mesh, ignored -> newPoseCache(MAX_EMISSIVE_MASK_ENTRIES_PER_MESH))
                    .computeIfAbsent(EmptyEmissiveMaskKey.INSTANCE, ignored -> createFilledEmissiveMask(boneCount, 0.0f));
        }

        if (mesh == lastEmissiveMesh && emissiveBones == lastEmissiveKey && lastEmissiveData != null) {
            return lastEmissiveData;
        }

        Map<Object, float[]> meshMaskCache = EMISSIVE_MASK_CACHE.get(mesh);
        if (meshMaskCache != null) {
            float[] cached = meshMaskCache.get(emissiveBones);
            if (cached != null) {
                lastEmissiveMesh = mesh;
                lastEmissiveKey = emissiveBones;
                lastEmissiveData = cached;
                return cached;
            }
        }

        float[] maskData = getEmissiveMaskBuffer(boneCount);
        Arrays.fill(maskData, 0, boneCount, 0.0f);
        for (int boneIndex = 0; boneIndex < boneCount; boneIndex++) {
            if (emissiveBones.contains(mesh.getIndexedBones().get(boneIndex).getName())) {
                maskData[boneIndex] = 1.0f;
            }
        }

        float[] cachedCopy = Arrays.copyOf(maskData, boneCount);
        EMISSIVE_MASK_CACHE.computeIfAbsent(mesh, ignored -> newPoseCache(MAX_EMISSIVE_MASK_ENTRIES_PER_MESH)).put(emissiveBones, cachedCopy);
        trimCachesIfNeeded();
        lastEmissiveMesh = mesh;
        lastEmissiveKey = emissiveBones;
        lastEmissiveData = cachedCopy;
        return cachedCopy;
    }

    public static void clear() {
        POSE_CACHE.clear();
        STATIC_POSE_CACHE.clear();
        EMISSIVE_MASK_CACHE.clear();
        lastPoseModel = null;
        lastPoseKey = null;
        lastPoseData = null;
        lastStaticPoseMesh = null;
        lastStaticPoseKey = null;
        lastStaticPoseData = null;
        lastEmissiveMesh = null;
        lastEmissiveKey = null;
        lastEmissiveData = null;
    }

    public static int totalEntries() {
        int total = 0;
        for (Map<Object, float[]> cache : POSE_CACHE.values()) {
            total += cache.size();
        }
        for (Map<Object, float[]> cache : STATIC_POSE_CACHE.values()) {
            total += cache.size();
        }
        for (Map<Object, float[]> cache : EMISSIVE_MASK_CACHE.values()) {
            total += cache.size();
        }
        return total;
    }

    private static float[] createIdentityBonePoseData(int boneCount) {
        float[] poseData = new float[boneCount * 16];
        Arrays.fill(poseData, 0.0f);
        for (int i = 0; i < boneCount; i++) {
            int offset = i * 16;
            poseData[offset + 3] = -1.0f;
            poseData[offset + 12] = 1.0f;
            poseData[offset + 13] = 1.0f;
            poseData[offset + 14] = 1.0f;
        }
        return poseData;
    }

    private static float[] createFilledEmissiveMask(int boneCount, float value) {
        float[] mask = new float[boneCount];
        Arrays.fill(mask, value);
        return mask;
    }

    private static float[] getEmissiveMaskBuffer(int boneCount) {
        float[] maskData = EMISSIVE_MASK_BUFFER.get();
        if (maskData.length < boneCount) {
            maskData = new float[boneCount];
            EMISSIVE_MASK_BUFFER.set(maskData);
        }
        return maskData;
    }

    private static void writeBonePoseData(BakedGeoModel model, ChaosGpuGeoMesh mesh, float[] poseData) {
        for (int boneIndex = 0; boneIndex < mesh.getIndexedBones().size(); boneIndex++) {
            GeoBone meshBone = mesh.getIndexedBones().get(boneIndex);
            GeoBone bone = model.getBone(meshBone.getName()).orElse(meshBone);
            float scaleX = bone.getScaleX();
            float scaleY = bone.getScaleY();
            float scaleZ = bone.getScaleZ();
            if (bone.isHidden()) {
                scaleX = 0.0f;
                scaleY = 0.0f;
                scaleZ = 0.0f;
            }
            int offset = boneIndex * 16;
            poseData[offset] = bone.getPosX();
            poseData[offset + 1] = bone.getPosY();
            poseData[offset + 2] = bone.getPosZ();
            poseData[offset + 3] = mesh.getParentIndex(boneIndex);
            poseData[offset + 4] = bone.getPivotX();
            poseData[offset + 5] = bone.getPivotY();
            poseData[offset + 6] = bone.getPivotZ();
            poseData[offset + 7] = 0.0f;
            poseData[offset + 8] = bone.getRotX();
            poseData[offset + 9] = bone.getRotY();
            poseData[offset + 10] = bone.getRotZ();
            poseData[offset + 11] = 0.0f;
            poseData[offset + 12] = scaleX;
            poseData[offset + 13] = scaleY;
            poseData[offset + 14] = scaleZ;
            poseData[offset + 15] = 0.0f;
        }
    }

    private static void writeStaticBonePoseData(ChaosGpuGeoMesh mesh, Map<String, StaticGeoBonePose> staticBonePoses, float[] poseData) {
        for (int boneIndex = 0; boneIndex < mesh.getIndexedBones().size(); boneIndex++) {
            GeoBone bone = mesh.getIndexedBones().get(boneIndex);
            StaticGeoBonePose pose = staticBonePoses.getOrDefault(bone.getName(), StaticGeoBonePose.IDENTITY);
            int offset = boneIndex * 16;
            poseData[offset] = bone.getPosX() + pose.posX();
            poseData[offset + 1] = bone.getPosY() + pose.posY();
            poseData[offset + 2] = bone.getPosZ() + pose.posZ();
            poseData[offset + 3] = mesh.getParentIndex(boneIndex);
            poseData[offset + 4] = bone.getPivotX();
            poseData[offset + 5] = bone.getPivotY();
            poseData[offset + 6] = bone.getPivotZ();
            poseData[offset + 7] = 0.0f;
            poseData[offset + 8] = bone.getRotX() + pose.rotX();
            poseData[offset + 9] = bone.getRotY() + pose.rotY();
            poseData[offset + 10] = bone.getRotZ() + pose.rotZ();
            poseData[offset + 11] = 0.0f;

            float scaleX = bone.getScaleX() * pose.scaleX();
            float scaleY = bone.getScaleY() * pose.scaleY();
            float scaleZ = bone.getScaleZ() * pose.scaleZ();
            if (pose.hidden()) {
                scaleX = 0.0f;
                scaleY = 0.0f;
                scaleZ = 0.0f;
            }

            poseData[offset + 12] = scaleX;
            poseData[offset + 13] = scaleY;
            poseData[offset + 14] = scaleZ;
            poseData[offset + 15] = 0.0f;
        }
    }

    private static Map<Object, float[]> newPoseCache(int maxEntries) {
        return new LinkedHashMap<>(64, 0.75f, true) {
            @Override
            protected boolean removeEldestEntry(Map.Entry<Object, float[]> eldest) {
                return size() > maxEntries;
            }
        };
    }

    private static void trimCachesIfNeeded() {
        trimOuterCache(POSE_CACHE, MAX_TOTAL_POSE_CACHE_ENTRIES);
        trimOuterCache(STATIC_POSE_CACHE, MAX_TOTAL_STATIC_POSE_CACHE_ENTRIES);
        trimOuterCache(EMISSIVE_MASK_CACHE, MAX_TOTAL_EMISSIVE_MASK_CACHE_ENTRIES);
    }

    private static void trimOuterCache(Map<?, Map<Object, float[]>> outerCache, int maxEntries) {
        while (countEntries(outerCache) > maxEntries) {
            if (!dropOneLeastRecentEntry(outerCache)) {
                break;
            }
        }
    }

    private static int countEntries(Map<?, Map<Object, float[]>> outerCache) {
        int total = 0;
        for (Map<Object, float[]> cache : outerCache.values()) {
            total += cache.size();
        }
        return total;
    }

    private static boolean dropOneLeastRecentEntry(Map<?, Map<Object, float[]>> outerCache) {
        for (Map<Object, float[]> cache : outerCache.values()) {
            if (cache.isEmpty()) {
                continue;
            }

            Object eldestKey = cache.keySet().iterator().next();
            cache.remove(eldestKey);
            return true;
        }

        return false;
    }

    private enum FullEmissiveMaskKey {
        INSTANCE
    }

    private enum EmptyEmissiveMaskKey {
        INSTANCE
    }
}
