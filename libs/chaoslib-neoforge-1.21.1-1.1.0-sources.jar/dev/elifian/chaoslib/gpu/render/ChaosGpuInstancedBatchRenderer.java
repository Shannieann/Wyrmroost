package dev.elifian.chaoslib.gpu.render;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuBoneDataStorage;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuInstanceDataStorage;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuInstancedPoseBatchStorage;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuWorldLightVolumeStorage;
import dev.elifian.chaoslib.gpu.debug.ChaosGlDebug;
import dev.elifian.chaoslib.gpu.mesh.ChaosGpuGeoMesh;
import dev.elifian.chaoslib.gpu.shader.ChaosGpuShaderManager;
import net.minecraft.client.Minecraft;
import com.mojang.blaze3d.shaders.Uniform;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;

import dev.elifian.chaoslib.platform.ClientOnly;
import org.joml.Matrix4f;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.ARBDrawInstanced;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GL31;
import org.lwjgl.opengl.GLCapabilities;

import java.nio.IntBuffer;
import java.util.IdentityHashMap;
import java.util.Map;

@ClientOnly
public final class ChaosGpuInstancedBatchRenderer {
    private static final int MAX_INSTANCES_PER_BATCH = 4096;
    private static final String[] SHADER_SAMPLER_NAMES = {
            "Sampler0",
            "Sampler1",
            "Sampler2",
            "Sampler3",
            "Sampler4",
            "Sampler5",
            "Sampler6",
            "Sampler7",
            "Sampler8",
            "Sampler9",
            "Sampler10",
            "Sampler11"
    };
    private static final ThreadLocal<float[]> INSTANCE_MATRIX_BUFFER = ThreadLocal.withInitial(() -> new float[MAX_INSTANCES_PER_BATCH * 16]);
    private static final ThreadLocal<float[]> INSTANCE_EMISSIVE_STRENGTH_BUFFER = ThreadLocal.withInitial(() -> new float[MAX_INSTANCES_PER_BATCH]);
    private static final ThreadLocal<float[]> INSTANCE_COLOR_BUFFER = ThreadLocal.withInitial(() -> new float[MAX_INSTANCES_PER_BATCH * 4]);
    private static final ThreadLocal<int[]> INSTANCE_POSE_BASE_BUFFER = ThreadLocal.withInitial(() -> new int[MAX_INSTANCES_PER_BATCH]);
    private static final ThreadLocal<int[]> INSTANCE_EMISSIVE_BASE_BUFFER = ThreadLocal.withInitial(() -> new int[MAX_INSTANCES_PER_BATCH]);
    private static final ThreadLocal<int[]> INSTANCE_LIGHT_BASE_BUFFER = ThreadLocal.withInitial(() -> new int[MAX_INSTANCES_PER_BATCH]);
    private static final ThreadLocal<IntBuffer> UNIFORM_META_BUFFER = ThreadLocal.withInitial(() -> BufferUtils.createIntBuffer(1));
    private static final ThreadLocal<float[]> BATCHED_EMISSIVE_BUFFER = ThreadLocal.withInitial(() -> new float[16]);
    private static final ThreadLocal<int[]> BATCHED_BONE_LIGHT_BUFFER = ThreadLocal.withInitial(() -> new int[16]);
    private static final int[] EMPTY_INT_ARRAY = new int[]{0};
    private static final float[] EMPTY_FLOAT_ARRAY = new float[]{0.0f};
    private static final LightBatchBuffers EMPTY_LIGHT_BATCH = new LightBatchBuffers(EMPTY_INT_ARRAY, 1);
    private static final Map<ShaderInstance, InstancedShaderBindings> SHADER_BINDINGS = new IdentityHashMap<>();
    private static Boolean openGl31Supported;

    private ChaosGpuInstancedBatchRenderer() {
    }

    static void resetDebugFrameStats() {
    }

    static String summarizeDebugFailures() {
        return "none";
    }

    public static boolean isWorldDrawAvailable() {
        return ChaosGpuShaderManager.getGeoInstancedShader() != null
                && ChaosGpuRenderRuntime.isInstancedWorldDrawSupported()
                && ChaosGpuRenderRuntime.isGpuPathSupported();
    }

    public static boolean draw(Batch batch, Matrix4f projectionMatrix) {
        return draw(
                batch.renderLayer(),
                batch.mesh(),
                batch.texture(),
                batch.emissiveTexture(),
                batch.modelViewMatrixChunks(),
                batch.packedLightChunks(),
                batch.boneLightChunks(),
                batch.emissiveStrengthChunks(),
                batch.shaderColorChunks(),
                batch.bonePoseDataChunks(),
                batch.emissiveMaskDataChunks(),
                batch.instanceCount(),
                projectionMatrix
        );
    }

    public static boolean draw(
            RenderType renderLayer,
            ChaosGpuGeoMesh mesh,
            ResourceLocation texture,
            ResourceLocation emissiveTexture,
            float[][] modelViewMatrixChunks,
            int[][] packedLightChunks,
            int[][][] boneLightChunks,
            float[][] emissiveStrengthChunks,
            float[][] instanceColorChunks,
            Object[][] bonePoseDataChunks,
            float[][][] emissiveMaskDataChunks,
            int instanceCount,
            Matrix4f projectionMatrix) {
        ShaderInstance shader = ChaosGpuShaderManager.getGeoInstancedShader();

        if (shader == null) {
            logFailure("shader-null", mesh, 0, "instanced shader is null");
            return false;
        }
        if (!mesh.hasInstancedGeometry()) {
            logFailure("mesh-no-instanced-geometry", mesh, shader.getId(), "mesh has no instanced geometry");
            return false;
        }
        if (instanceCount < 1) {
            logFailure("empty-batch", mesh, shader.getId(), "batch has no instances");
            return false;
        }
        if (!ChaosGpuRenderRuntime.isInstancedWorldDrawSupported()) {
            logFailure("instancing-unsupported", mesh, shader.getId(), "instanced world draw is not supported");
            return false;
        }
        if (!ChaosGpuRenderRuntime.isGpuPathSupported()) {
            logFailure("gpu-path-unsupported", mesh, shader.getId(), "gpu path is not supported");
            return false;
        }
        InstancedShaderBindings bindings = shaderBindings(shader);
        if (!bindings.complete()) {
            logFailure(
                    "missing-core-uniforms",
                    mesh,
                    shader.getId(),
                    "missing core uniforms boneCount=%s boneDataResolved=%s useBoneLightSampler=%s useWorldLightVolume=%s useEmissiveLayer=%s".formatted(
                            bindings.boneCount() != null,
                            bindings.boneDataResolved() != null,
                            bindings.useBoneLightSampler() != null,
                            bindings.useWorldLightVolume() != null,
                            bindings.useEmissiveLayer() != null
                    )
            );
            return false;
        }

        if (!ChaosGpuGeoRenderer.prepareRenderState(shader)) {
            ChaosGpuGeoRenderer.finishRenderState();
            return false;
        }
        int previousVertexArray = ChaosGlDebug.captureVertexArrayBinding("ChaosGpuInstancedBatchRenderer.draw.captureVertexArray");

        try {
            renderLayer.setupRenderState();
            shader.apply();
            bindings.boneCount().set(mesh.getIndexedBones().size());
            bindings.boneDataResolved().set(0);
            ChaosGpuGeoRenderer.bindTextures(texture, emissiveTexture);
            boolean useEmissiveLayer = emissiveTexture != null;
            bindings.useEmissiveLayer().set(useEmissiveLayer ? 1 : 0);
            setupCommonShaderUniforms(shader, projectionMatrix);
            boolean useWorldLightVolume = ChaosGpuWorldLightVolumeStorage.bindCurrentVolume(shader);
            boolean useBoneLightSampler = !useWorldLightVolume && hasCompleteBoneLightData(boneLightChunks, instanceCount);
            bindings.useWorldLightVolume().set(useWorldLightVolume ? 1 : 0);
            bindings.useBoneLightSampler().set(useBoneLightSampler ? 1 : 0);
            shader.apply();
            mesh.bindInstancedGeometry();
            if (ChaosGlDebug.failIfErrored("ChaosGpuInstancedBatchRenderer.draw.setup")) {
                return false;
            }
            return drawBatches(
                    mesh,
                    modelViewMatrixChunks,
                    packedLightChunks,
                    boneLightChunks,
                    emissiveStrengthChunks,
                    instanceColorChunks,
                    bonePoseDataChunks,
                    emissiveMaskDataChunks,
                    instanceCount,
                    useWorldLightVolume,
                    useBoneLightSampler,
                    useEmissiveLayer
            );
        } finally {
            renderLayer.clearRenderState();
            shader.clear();
            ChaosGlDebug.check("ChaosGpuInstancedBatchRenderer.draw.shader.unbind");
            ChaosGlDebug.restoreVertexArrayBinding(previousVertexArray, "ChaosGpuInstancedBatchRenderer.draw.restore");
            ChaosGpuGeoRenderer.finishRenderState();
        }
    }

    private static void setupCommonShaderUniforms(ShaderInstance shader, Matrix4f projectionMatrix) {
        for (int i = 0; i < SHADER_SAMPLER_NAMES.length; i++) {
            shader.setSampler(SHADER_SAMPLER_NAMES[i], RenderSystem.getShaderTexture(i));
        }

        if (shader.PROJECTION_MATRIX != null) {
            shader.PROJECTION_MATRIX.set(projectionMatrix);
        }
        ChaosViewRotation.apply(shader);
        if (shader.TEXTURE_MATRIX != null) {
            shader.TEXTURE_MATRIX.set(RenderSystem.getTextureMatrix());
        }
        if (shader.COLOR_MODULATOR != null) {
            shader.COLOR_MODULATOR.set(1.0f, 1.0f, 1.0f, 1.0f);
        }
        if (shader.FOG_START != null) {
            shader.FOG_START.set(RenderSystem.getShaderFogStart());
        }
        if (shader.FOG_END != null) {
            shader.FOG_END.set(RenderSystem.getShaderFogEnd());
        }
        if (shader.FOG_COLOR != null) {
            shader.FOG_COLOR.set(RenderSystem.getShaderFogColor());
        }
        if (shader.FOG_SHAPE != null) {
            shader.FOG_SHAPE.set(RenderSystem.getShaderFogShape().getIndex());
        }
        if (shader.SCREEN_SIZE != null) {
            Minecraft client = Minecraft.getInstance();
            shader.SCREEN_SIZE.set(client.getWindow().getWidth(), client.getWindow().getHeight());
        }
    }

    private static boolean drawBatches(
            ChaosGpuGeoMesh mesh,
            float[][] matrixChunks,
            int[][] packedLightChunks,
            int[][][] boneLightChunks,
            float[][] emissiveStrengthChunks,
            float[][] instanceColorChunks,
            Object[][] bonePoseDataChunks,
            float[][][] emissiveMaskDataChunks,
            int instanceCount,
            boolean useWorldLightVolume,
            boolean useBoneLightSampler,
            boolean useEmissiveLayer) {
        float[] matrixBuffer = INSTANCE_MATRIX_BUFFER.get();
        float[] emissiveStrengthBuffer = INSTANCE_EMISSIVE_STRENGTH_BUFFER.get();
        float[] instanceColorBuffer = INSTANCE_COLOR_BUFFER.get();
        int[] poseBaseBuffer = INSTANCE_POSE_BASE_BUFFER.get();
        int[] emissiveBaseBuffer = INSTANCE_EMISSIVE_BASE_BUFFER.get();
        int[] lightBaseBuffer = INSTANCE_LIGHT_BASE_BUFFER.get();
        float[] batchedEmissiveBuffer = BATCHED_EMISSIVE_BUFFER.get();
        int[] batchedBoneLightBuffer = BATCHED_BONE_LIGHT_BUFFER.get();

        for (int offset = 0; offset < instanceCount; offset += MAX_INSTANCES_PER_BATCH) {
            int count = Math.min(MAX_INSTANCES_PER_BATCH, instanceCount - offset);
            int floatCount = count * 16;
            int chunkIndex = offset / MAX_INSTANCES_PER_BATCH;
            if (matrixBuffer.length < floatCount) {
                matrixBuffer = new float[floatCount];
                INSTANCE_MATRIX_BUFFER.set(matrixBuffer);
            }
            if (emissiveStrengthBuffer.length < count) {
                emissiveStrengthBuffer = new float[count];
                INSTANCE_EMISSIVE_STRENGTH_BUFFER.set(emissiveStrengthBuffer);
            }
            if (instanceColorBuffer.length < count * 4) {
                instanceColorBuffer = new float[count * 4];
                INSTANCE_COLOR_BUFFER.set(instanceColorBuffer);
            }
            if (poseBaseBuffer.length < count) {
                poseBaseBuffer = new int[count];
                INSTANCE_POSE_BASE_BUFFER.set(poseBaseBuffer);
            }
            if (emissiveBaseBuffer.length < count) {
                emissiveBaseBuffer = new int[count];
                INSTANCE_EMISSIVE_BASE_BUFFER.set(emissiveBaseBuffer);
            }
            if (lightBaseBuffer.length < count) {
                lightBaseBuffer = new int[count];
                INSTANCE_LIGHT_BASE_BUFFER.set(lightBaseBuffer);
            }
            System.arraycopy(matrixChunks[chunkIndex], 0, matrixBuffer, 0, floatCount);
            System.arraycopy(emissiveStrengthChunks[chunkIndex], 0, emissiveStrengthBuffer, 0, count);
            System.arraycopy(instanceColorChunks[chunkIndex], 0, instanceColorBuffer, 0, count * 4);
            LightBatchBuffers lightBatchBuffers = !useBoneLightSampler || useWorldLightVolume
                    ? EMPTY_LIGHT_BATCH
                    : packBoneLightData(
                            boneLightChunks[chunkIndex],
                            count,
                            lightBaseBuffer,
                            batchedBoneLightBuffer
                    );
            if (lightBatchBuffers == null) {
                int currentProgram = GL11.glGetInteger(GL20.GL_CURRENT_PROGRAM);
                ChaosGlDebug.check("ChaosGpuInstancedBatchRenderer.drawBatches.lightBatch.glGetInteger.CURRENT_PROGRAM");
                logFailure("bind-bone-light-batch-failed", mesh, currentProgram, "missing per-bone light data");
                return false;
            }
            batchedBoneLightBuffer = lightBatchBuffers.boneLightData();
            BATCHED_BONE_LIGHT_BUFFER.set(batchedBoneLightBuffer);
            BatchBuffers batchBuffers = packPoseData(
                    mesh,
                    bonePoseDataChunks[chunkIndex],
                    emissiveMaskDataChunks[chunkIndex],
                    count,
                    poseBaseBuffer,
                    emissiveBaseBuffer,
                    batchedEmissiveBuffer,
                    useEmissiveLayer
            );
            batchedEmissiveBuffer = batchBuffers.emissiveData();
            BATCHED_EMISSIVE_BUFFER.set(batchedEmissiveBuffer);
            if (!batchBuffers.bindPoseData()) {
                int currentProgram = GL11.glGetInteger(GL20.GL_CURRENT_PROGRAM);
                ChaosGlDebug.check("ChaosGpuInstancedBatchRenderer.drawBatches.poseBatch.glGetInteger.CURRENT_PROGRAM");
                logFailure("bind-pose-batch-failed", mesh, currentProgram, "bindPoseData returned false");
                return false;
            }
            int[] packedLightData = packedLightChunks[chunkIndex];
            float[] emissiveStrengthData = useEmissiveLayer ? emissiveStrengthBuffer : EMPTY_FLOAT_ARRAY;
            int emissiveStrengthCount = useEmissiveLayer ? count : 1;
            int[] emissiveBaseData = useEmissiveLayer ? emissiveBaseBuffer : EMPTY_INT_ARRAY;
            int emissiveBaseCount = useEmissiveLayer ? count : 1;
            if (!ChaosGpuInstanceDataStorage.bindForInstancedShaders(
                    packedLightData,
                    count,
                    emissiveStrengthData,
                    emissiveStrengthCount,
                    poseBaseBuffer,
                    count,
                    emissiveBaseData,
                    emissiveBaseCount,
                    lightBatchBuffers.boneLightData(),
                    lightBatchBuffers.lightCount(),
                    useBoneLightSampler ? lightBaseBuffer : EMPTY_INT_ARRAY,
                    useBoneLightSampler ? count : 1,
                    instanceColorBuffer,
                    count * 4)) {
                int currentProgram = GL11.glGetInteger(GL20.GL_CURRENT_PROGRAM);
                ChaosGlDebug.check("ChaosGpuInstancedBatchRenderer.drawBatches.instanceData.glGetInteger.CURRENT_PROGRAM");
                logFailure("bind-instance-data-failed", mesh, currentProgram, "bindForInstancedShaders returned false");
                return false;
            }
            if (!ChaosGpuInstanceDataStorage.bindInstanceMatrices(matrixBuffer, floatCount)) {
                int currentProgram = GL11.glGetInteger(GL20.GL_CURRENT_PROGRAM);
                ChaosGlDebug.check("ChaosGpuInstancedBatchRenderer.drawBatches.instanceMatrices.glGetInteger.CURRENT_PROGRAM");
                logFailure("bind-instance-matrices-failed", mesh, currentProgram, "bindInstanceMatrices returned false");
                return false;
            }
            drawArraysInstanced(mesh.getInstancedVertexCount(), count);
            if (ChaosGlDebug.failIfErrored("ChaosGpuInstancedBatchRenderer.drawBatches.drawArraysInstanced")) {
                return false;
            }
        }

        return true;
    }

    private static BatchBuffers packPoseData(
            ChaosGpuGeoMesh mesh,
            Object[] bonePoseChunk,
            float[][] emissiveMaskChunk,
            int count,
            int[] poseBaseOutput,
            int[] emissiveBaseOutput,
            float[] emissiveBuffer,
            boolean useEmissiveLayer) {
        if (!useEmissiveLayer) {
            boolean gpuBatch = ChaosGpuInstancedPoseBatchStorage.buildLocalPoseBatch(mesh, bonePoseChunk, count, poseBaseOutput);
            return new BatchBuffers(gpuBatch, null, EMPTY_FLOAT_ARRAY, 1);
        }

        int emissiveFloatOffset = 0;
        for (int i = 0; i < count; i++) {
            float[] emissiveData = emissiveMaskChunk[i];
            emissiveBaseOutput[i] = emissiveFloatOffset;
            emissiveFloatOffset += emissiveData.length;
        }

        if (emissiveBuffer.length < emissiveFloatOffset) {
            emissiveBuffer = new float[emissiveFloatOffset];
        }

        int emissiveWrite = 0;
        for (int i = 0; i < count; i++) {
            float[] emissiveData = emissiveMaskChunk[i];
            System.arraycopy(emissiveData, 0, emissiveBuffer, emissiveWrite, emissiveData.length);
            emissiveWrite += emissiveData.length;
        }

        boolean gpuBatch = ChaosGpuInstancedPoseBatchStorage.buildLocalPoseBatch(mesh, bonePoseChunk, count, poseBaseOutput);
        if (!gpuBatch) {
            return new BatchBuffers(
                    false,
                    null,
                    emissiveBuffer,
                    emissiveFloatOffset
            );
        }

        return new BatchBuffers(
                true,
                null,
                emissiveBuffer,
                emissiveFloatOffset
        );
    }

    private static LightBatchBuffers packBoneLightData(
            int[][] boneLightChunk,
            int count,
            int[] lightBaseOutput,
            int[] boneLightBuffer
    ) {
        if (boneLightChunk == null) {
            return null;
        }

        int lightOffset = 0;
        for (int i = 0; i < count; i++) {
            int[] boneLights = boneLightChunk[i];
            if (boneLights == null) {
                return null;
            }
            lightBaseOutput[i] = lightOffset;
            lightOffset += boneLights.length;
        }

        if (boneLightBuffer.length < lightOffset) {
            boneLightBuffer = new int[lightOffset];
        }

        int write = 0;
        for (int i = 0; i < count; i++) {
            int[] boneLights = boneLightChunk[i];
            System.arraycopy(boneLights, 0, boneLightBuffer, write, boneLights.length);
            write += boneLights.length;
        }

        return new LightBatchBuffers(boneLightBuffer, lightOffset);
    }

    private static boolean hasCompleteBoneLightData(int[][][] boneLightChunks, int instanceCount) {
        int remaining = instanceCount;
        for (int[][] chunk : boneLightChunks) {
            if (remaining <= 0) {
                break;
            }
            if (chunk == null) {
                return false;
            }

            int instancesInChunk = Math.min(MAX_INSTANCES_PER_BATCH, remaining);
            for (int i = 0; i < instancesInChunk; i++) {
                if (chunk[i] == null) {
                    return false;
                }
            }
            remaining -= instancesInChunk;
        }
        return true;
    }

    private static void logFailure(String key, ChaosGpuGeoMesh mesh, int programId, String message) {
    }

    private static String dumpActiveUniforms(int programId) {
        int uniformCount = GL20.glGetProgrami(programId, GL20.GL_ACTIVE_UNIFORMS);
        ChaosGlDebug.check("ChaosGpuInstancedBatchRenderer.dumpActiveUniforms.glGetProgrami.ACTIVE_UNIFORMS");
        StringBuilder builder = new StringBuilder("[");
        IntBuffer sizeBuffer = UNIFORM_META_BUFFER.get();
        IntBuffer typeBuffer = BufferUtils.createIntBuffer(1);

        for (int i = 0; i < uniformCount; i++) {
            if (i > 0) {
                builder.append(", ");
            }
            sizeBuffer.clear();
            typeBuffer.clear();
            builder.append(GL20.glGetActiveUniform(programId, i, 256, sizeBuffer, typeBuffer));
            ChaosGlDebug.check("ChaosGpuInstancedBatchRenderer.dumpActiveUniforms.glGetActiveUniform");
        }

        return builder.append(']').toString();
    }

    private static void drawArraysInstanced(int vertexCount, int instanceCount) {
        if (isOpenGl31Supported()) {
            GL31.glDrawArraysInstanced(GL11.GL_TRIANGLES, 0, vertexCount, instanceCount);
            ChaosGlDebug.check("ChaosGpuInstancedBatchRenderer.drawArraysInstanced.glDrawArraysInstanced");
            return;
        }

        ARBDrawInstanced.glDrawArraysInstancedARB(GL11.GL_TRIANGLES, 0, vertexCount, instanceCount);
        ChaosGlDebug.check("ChaosGpuInstancedBatchRenderer.drawArraysInstanced.glDrawArraysInstancedARB");
    }

    private static boolean isOpenGl31Supported() {
        Boolean supported = openGl31Supported;
        if (supported == null) {
            GLCapabilities capabilities = GL.getCapabilities();
            supported = capabilities.OpenGL31;
            openGl31Supported = supported;
        }
        return supported;
    }

    private static InstancedShaderBindings shaderBindings(ShaderInstance shader) {
        InstancedShaderBindings bindings = SHADER_BINDINGS.get(shader);
        if (bindings != null) {
            return bindings;
        }

        bindings = new InstancedShaderBindings(
                shader.getUniform("BoneCount"),
                shader.getUniform("BoneDataResolved"),
                shader.getUniform("UseBoneLightSampler"),
                shader.getUniform("UseWorldLightVolume"),
                shader.getUniform("UseEmissiveLayer")
        );
        SHADER_BINDINGS.put(shader, bindings);
        return bindings;
    }

    public record Batch(
            RenderType renderLayer,
            ChaosGpuGeoMesh mesh,
            ResourceLocation texture,
            ResourceLocation emissiveTexture,
            float[][] modelViewMatrixChunks,
            int[][] packedLightChunks,
            int[][][] boneLightChunks,
            float[][] emissiveStrengthChunks,
            float[][] shaderColorChunks,
            Object[][] bonePoseDataChunks,
            float[][][] emissiveMaskDataChunks,
            int instanceCount) {
    }

    private record BatchBuffers(boolean gpuBatch, float[] poseData, float[] emissiveData, int emissiveLength) {
        private boolean bindPoseData() {
            if (this.gpuBatch) {
                return ChaosGpuInstancedPoseBatchStorage.bindPoseTexture(this.emissiveData, this.emissiveLength);
            }
            return this.poseData != null && ChaosGpuBoneDataStorage.bindRawForInstancedShaders(this.poseData, this.poseData.length, this.emissiveData, this.emissiveLength);
        }
    }

    private record LightBatchBuffers(int[] boneLightData, int lightCount) {
    }

    private record InstancedShaderBindings(
            Uniform boneCount,
            Uniform boneDataResolved,
            Uniform useBoneLightSampler,
            Uniform useWorldLightVolume,
            Uniform useEmissiveLayer
    ) {
        private boolean complete() {
            return this.boneCount != null
                    && this.boneDataResolved != null
                    && this.useBoneLightSampler != null
                    && this.useWorldLightVolume != null
                    && this.useEmissiveLayer != null;
        }
    }
}
