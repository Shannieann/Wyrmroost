package dev.elifian.chaoslib.gpu.render;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.elifian.chaoslib.compat.iris.IrisCompatInternal;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuAnimationPoseStorage;
import dev.elifian.chaoslib.gpu.debug.ChaosGlDebug;
import dev.elifian.chaoslib.gpu.mesh.ChaosGpuGeoMesh;
import dev.elifian.chaoslib.gpu.shader.ChaosGpuShaderManager;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;

import dev.elifian.chaoslib.platform.ClientOnly;
import dev.elifian.chaoslib.platform.Services;
import dev.elifian.chaoslib.platform.render.ChaosWorldRenderContext;
import dev.elifian.chaoslib.platform.render.ChaosWorldRenderStage;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

import java.util.*;

@ClientOnly
public final class ChaosGpuWorldRenderDispatcher {
    private static final Map<BatchKey, BatchAccumulator> BATCHES = new LinkedHashMap<>();
    private static final EnumMap<ShaderPackPassTarget, Map<BatchKey, BatchAccumulator>> SHADERPACK_BATCHES = new EnumMap<>(ShaderPackPassTarget.class);
    private static final Map<BatchKey, Integer> BATCH_COUNTS = new LinkedHashMap<>();
    private static final EnumMap<ShaderPackPassTarget, Map<BatchKey, Integer>> SHADERPACK_BATCH_COUNTS = new EnumMap<>(ShaderPackPassTarget.class);
    private static final Map<RenderType, String> RENDER_LAYER_KEYS = Collections.synchronizedMap(new IdentityHashMap<>());
    private static final Map<RenderType, Boolean> RENDER_LAYER_TRANSLUCENCY = Collections.synchronizedMap(new IdentityHashMap<>());
    private static final List<BatchAccumulator> ORDERED_BATCHES = new ArrayList<>();
    private static final EnumMap<ShaderPackPassTarget, List<BatchAccumulator>> SHADERPACK_ORDERED_BATCHES = new EnumMap<>(ShaderPackPassTarget.class);
    private static final Deque<BatchAccumulator> BATCH_POOL = new ArrayDeque<>();
    private static final EnumMap<ShaderPackPassTarget, BatchAccumulator> LAST_SHADERPACK_BATCHES = new EnumMap<>(ShaderPackPassTarget.class);
    private static final ThreadLocal<Matrix4f> PREVIOUS_TEXTURE_MATRIX = ThreadLocal.withInitial(Matrix4f::new);
    private static boolean registered;
    // Two-slot most-recently-used cache for the committed batch. Block entities that draw more than one
    // pass (e.g. a base pass plus an emissive pass) enqueue alternating batch keys, which thrashed a
    // single-slot cache and forced a LinkedHashMap.get + BatchKey allocation on every call. Two slots
    // absorb that alternation; more passes than that fall back to the map lookup.
    private static BatchAccumulator lastBatch;
    private static BatchAccumulator lastBatch2;

    static {
        for (ShaderPackPassTarget target : ShaderPackPassTarget.values()) {
            SHADERPACK_BATCHES.put(target, new LinkedHashMap<>());
            SHADERPACK_BATCH_COUNTS.put(target, new LinkedHashMap<>());
            SHADERPACK_ORDERED_BATCHES.put(target, new ArrayList<>());
        }
    }

    private ChaosGpuWorldRenderDispatcher() {
    }

    public static void register() {
        if (registered) {
            return;
        }

        registered = true;
        Services.RENDER_EVENTS.registerWorldRenderStageListener(ChaosGpuWorldRenderDispatcher::onWorldRenderStage);
    }

    public static boolean enqueue(RenderType renderLayer, ChaosGpuGeoMesh mesh, ResourceLocation texture, ResourceLocation emissiveTexture, Matrix4f modelViewMatrix, int packedLight, int[] boneLightData, Object boneMatrixData, float[] emissiveMaskData, float emissiveStrength) {
        return enqueue(renderLayer, mesh, texture, emissiveTexture, modelViewMatrix, packedLight, boneLightData, boneMatrixData, emissiveMaskData, emissiveStrength, OverlayTexture.NO_OVERLAY, ChaosShaderRenderPhase.NONE, 1.0f);
    }

    public static boolean enqueue(RenderType renderLayer, ChaosGpuGeoMesh mesh, ResourceLocation texture, ResourceLocation emissiveTexture, Matrix4f modelViewMatrix, int packedLight, int[] boneLightData, Object boneMatrixData, float[] emissiveMaskData, float emissiveStrength, ChaosShaderRenderPhase phase, float shaderColorScale) {
        return enqueue(renderLayer, mesh, texture, emissiveTexture, modelViewMatrix, packedLight, boneLightData, boneMatrixData, emissiveMaskData, emissiveStrength, OverlayTexture.NO_OVERLAY, phase, shaderColorScale);
    }

    public static boolean enqueue(RenderType renderLayer, ChaosGpuGeoMesh mesh, ResourceLocation texture, ResourceLocation emissiveTexture, Matrix4f poseMatrix, int packedLight, int[] boneLightData, Object boneMatrixData, float[] emissiveMaskData, float emissiveStrength, int packedOverlay, ChaosShaderRenderPhase phase, float shaderColorScale) {
        Matrix4f modelViewMatrix = new Matrix4f(RenderSystem.getModelViewMatrix()).mul(poseMatrix);
        boolean shaderPackPipelineActive = ChaosGpuRenderRuntime.isShaderPackPipelineActive();
        if (ChaosGpuShaderManager.getGeoShader() == null) {
            if (!shaderPackPipelineActive) {
                return false;
            }
        }
        if (mesh == null || mesh.getInstancedVertexCount() <= 0) {
            return true;
        }

        float[] currentShaderColor = RenderSystem.getShaderColor();
        float shaderColorRed = currentShaderColor[0] * shaderColorScale;
        float shaderColorGreen = currentShaderColor[1] * shaderColorScale;
        float shaderColorBlue = currentShaderColor[2] * shaderColorScale;
        float shaderColorAlpha = currentShaderColor[3];
        if (shaderPackPipelineActive) {
            int renderedEntityId = IrisCompatInternal.currentRenderedEntityId();
            int renderedBlockEntityId = IrisCompatInternal.currentRenderedBlockEntityId();
            int renderedItemId = IrisCompatInternal.currentRenderedItemId();
            ShaderPackPassTarget target = resolveShaderPackTarget(renderLayer, phase);
            Map<BatchKey, BatchAccumulator> batches = SHADERPACK_BATCHES.get(target);
            Map<BatchKey, Integer> batchCounts = SHADERPACK_BATCH_COUNTS.get(target);
            List<BatchAccumulator> orderedBatches = SHADERPACK_ORDERED_BATCHES.get(target);
            if (batches == null || batchCounts == null || orderedBatches == null) {
                return false;
            }
            Matrix4f currentTextureMatrix = RenderSystem.getTextureMatrix();
            BatchAccumulator lastShaderPackBatch = LAST_SHADERPACK_BATCHES.get(target);
            if (lastShaderPackBatch != null && lastShaderPackBatch.matches(renderLayer, mesh, texture, emissiveTexture, phase, shaderColorScale, currentTextureMatrix)) {
                lastShaderPackBatch.add(modelViewMatrix, packedLight, packedOverlay, boneLightData, boneMatrixData, emissiveMaskData, emissiveStrength, shaderColorRed, shaderColorGreen, shaderColorBlue, shaderColorAlpha, renderedEntityId, renderedBlockEntityId, renderedItemId);
                return true;
            }

            Matrix4f textureMatrix = new Matrix4f(RenderSystem.getTextureMatrix());
            BatchKey key = new BatchKey(renderLayer, mesh, texture, emissiveTexture, phase, shaderColorScale, textureMatrix);
            int batchThreshold = batchingThresholdFor(mesh, boneLightData, boneMatrixData, emissiveMaskData);
            if (batchThreshold > 1 && batchCounts.merge(key, 1, Integer::sum) < batchThreshold) {
                BatchAccumulator batch = acquireBatch(renderLayer, mesh, texture, emissiveTexture, phase, shaderColorScale, textureMatrix);
                batch.add(modelViewMatrix, packedLight, packedOverlay, boneLightData, boneMatrixData, emissiveMaskData, emissiveStrength, shaderColorRed, shaderColorGreen, shaderColorBlue, shaderColorAlpha, renderedEntityId, renderedBlockEntityId, renderedItemId);
                orderedBatches.add(batch);
                LAST_SHADERPACK_BATCHES.remove(target);
                return true;
            }

            BatchAccumulator batch = batches.get(key);
            if (batch == null) {
                batch = acquireBatch(renderLayer, mesh, texture, emissiveTexture, phase, shaderColorScale, textureMatrix);
                batches.put(key, batch);
                orderedBatches.add(batch);
            }

            batch.add(modelViewMatrix, packedLight, packedOverlay, boneLightData, boneMatrixData, emissiveMaskData, emissiveStrength, shaderColorRed, shaderColorGreen, shaderColorBlue, shaderColorAlpha, renderedEntityId, renderedBlockEntityId, renderedItemId);
            LAST_SHADERPACK_BATCHES.put(target, batch);
            return true;
        }

        Matrix4f currentTextureMatrix = RenderSystem.getTextureMatrix();
        if (lastBatch != null && lastBatch.matches(renderLayer, mesh, texture, emissiveTexture, phase, shaderColorScale, currentTextureMatrix)) {
            lastBatch.add(modelViewMatrix, packedLight, packedOverlay, boneLightData, boneMatrixData, emissiveMaskData, emissiveStrength, shaderColorRed, shaderColorGreen, shaderColorBlue, shaderColorAlpha, 0, 0, 0);
            return true;
        }
        if (lastBatch2 != null && lastBatch2.matches(renderLayer, mesh, texture, emissiveTexture, phase, shaderColorScale, currentTextureMatrix)) {
            BatchAccumulator hit = lastBatch2;
            lastBatch2 = lastBatch;
            lastBatch = hit;
            hit.add(modelViewMatrix, packedLight, packedOverlay, boneLightData, boneMatrixData, emissiveMaskData, emissiveStrength, shaderColorRed, shaderColorGreen, shaderColorBlue, shaderColorAlpha, 0, 0, 0);
            return true;
        }

        Matrix4f textureMatrix = new Matrix4f(currentTextureMatrix);
        BatchKey key = new BatchKey(renderLayer, mesh, texture, emissiveTexture, phase, shaderColorScale, textureMatrix);
        int batchThreshold = batchingThresholdFor(mesh, boneLightData, boneMatrixData, emissiveMaskData);
        if (batchThreshold > 1 && BATCH_COUNTS.merge(key, 1, Integer::sum) < batchThreshold) {
            BatchAccumulator batch = acquireBatch(renderLayer, mesh, texture, emissiveTexture, phase, shaderColorScale, textureMatrix);
            batch.add(modelViewMatrix, packedLight, packedOverlay, boneLightData, boneMatrixData, emissiveMaskData, emissiveStrength, shaderColorRed, shaderColorGreen, shaderColorBlue, shaderColorAlpha, 0, 0, 0);
            ORDERED_BATCHES.add(batch);
            lastBatch = null;
            lastBatch2 = null;
            return true;
        }

        BatchAccumulator batch = BATCHES.get(key);
        if (batch == null) {
            batch = acquireBatch(renderLayer, mesh, texture, emissiveTexture, phase, shaderColorScale, textureMatrix);
            BATCHES.put(key, batch);
            ORDERED_BATCHES.add(batch);
        }

        batch.add(modelViewMatrix, packedLight, packedOverlay, boneLightData, boneMatrixData, emissiveMaskData, emissiveStrength, shaderColorRed, shaderColorGreen, shaderColorBlue, shaderColorAlpha, 0, 0, 0);
        lastBatch2 = lastBatch;
        lastBatch = batch;
        return true;
    }

    public static void invalidateQueuedBatches() {
        clearQueuedData();
        for (ShaderPackPassTarget target : ShaderPackPassTarget.values()) {
            clearShaderPackQueuedData(target);
        }
    }

    public static void onWorldRenderStage(ChaosWorldRenderContext context) {
        boolean shaderPackPipelineActive = ChaosGpuRenderRuntime.isShaderPackPipelineActive();
        if (shaderPackPipelineActive) {
            if (context.stage() == ChaosWorldRenderStage.AFTER_ENTITIES) {
                flushShaderPackMain(ChaosShaderRenderPhase.ENTITIES);
            }
            return;
        }

        if (ChaosGpuRenderRuntime.shouldFlushWorldStage(context.stage())) {
            flush(context.projectionMatrix());
        }
    }

    public static void flushShaderPackMain(ChaosShaderRenderPhase phase) {
        if (!ChaosGpuRenderRuntime.isShaderPackPipelineActive()) {
            return;
        }

        switch (phase) {
            case ENTITIES -> flushShaderPackTarget(ShaderPackPassTarget.ENTITY_SOLID);
            case BLOCK_ENTITIES -> flushShaderPackTarget(ShaderPackPassTarget.BLOCK_ENTITY_SOLID);
            default -> {
            }
        }
    }

    public static void flushShaderPackTranslucent() {
        if (!ChaosGpuRenderRuntime.isShaderPackPipelineActive()) {
            return;
        }

        flushShaderPackTarget(ShaderPackPassTarget.ENTITY_TRANSLUCENT);
        flushShaderPackTarget(ShaderPackPassTarget.BLOCK_ENTITY_TRANSLUCENT);
    }

    public static void flushShaderPackShadowSolid() {
        if (!ChaosGpuRenderRuntime.isShaderPackPipelineActive()) {
            return;
        }

        flushShaderPackTarget(ShaderPackPassTarget.SHADOW_ENTITY_SOLID);
        flushShaderPackTarget(ShaderPackPassTarget.SHADOW_BLOCK_ENTITY_SOLID);
    }

    public static void flushShaderPackShadowTranslucent() {
        if (!ChaosGpuRenderRuntime.isShaderPackPipelineActive()) {
            return;
        }

        flushShaderPackTarget(ShaderPackPassTarget.SHADOW_ENTITY_TRANSLUCENT);
        flushShaderPackTarget(ShaderPackPassTarget.SHADOW_BLOCK_ENTITY_TRANSLUCENT);
    }

    private static void flush(Matrix4f projectionMatrix) {
        ChaosGpuAnimationPoseStorage.ensureBatchFlushed();
        if (ORDERED_BATCHES.isEmpty()) {
            return;
        }

        ShaderInstance shader = ChaosGpuShaderManager.getGeoShader();
        if (shader == null) {
            clearQueuedData();
            return;
        }

        boolean instancedWorldDrawAvailable = ChaosGpuInstancedBatchRenderer.isWorldDrawAvailable();
        boolean abortFlush = false;
        try {
            for (BatchAccumulator batch : ORDERED_BATCHES) {
                if (abortFlush) {
                    break;
                }
                Matrix4f previousTextureMatrix = PREVIOUS_TEXTURE_MATRIX.get().set(RenderSystem.getTextureMatrix());
                RenderSystem.setTextureMatrix(batch.textureMatrix());
                try {
                    if (instancedWorldDrawAvailable
                            && ChaosGpuInstancedBatchRenderer.draw(
                            batch.renderLayer,
                            batch.mesh,
                            batch.texture,
                            batch.emissiveTexture,
                            batch.modelViewMatrixChunks,
                            batch.packedLightChunks,
                            batch.boneLightChunks,
                            batch.emissiveStrengthChunks,
                            batch.shaderColorChunks,
                            batch.bonePoseDataChunks,
                            batch.emissiveMaskDataChunks,
                            batch.size,
                            projectionMatrix
                    )) {
                        continue;
                    }

                    float[] previousShaderColor = RenderSystem.getShaderColor();
                    float previousShaderRed = previousShaderColor[0];
                    float previousShaderGreen = previousShaderColor[1];
                    float previousShaderBlue = previousShaderColor[2];
                    float previousShaderAlpha = previousShaderColor[3];
                    int previousVertexArray = ChaosGlDebug.captureVertexArrayBinding("ChaosGpuWorldRenderDispatcher.flush.direct.captureVertexArray");
                    batch.renderLayer().setupRenderState();
                    try {
                        if (!ChaosGpuGeoRenderer.prepareRenderState(shader)) {
                            break;
                        }
                        ChaosGpuGeoRenderer.bindTextures(batch.texture(), batch.emissiveTexture());
                        for (int i = 0; i < batch.size(); i++) {
                            RenderSystem.setShaderColor(
                                    batch.shaderColorRed(i),
                                    batch.shaderColorGreen(i),
                                    batch.shaderColorBlue(i),
                                    batch.shaderColorAlpha(i)
                            );
                            ChaosGpuGeoRenderer.setupFrameShaderState(shader, projectionMatrix);
                            if (!ChaosGpuGeoRenderer.drawPrepared(
                                    batch.mesh(),
                                    batch.texture(),
                                    batch.emissiveTexture(),
                                    batch.modelViewMatrix(i),
                                    batch.packedLight(i),
                                    batch.boneLightData(i),
                                    batch.bonePoseData(i),
                                    batch.emissiveMaskData(i),
                                    batch.emissiveStrength(i),
                                    projectionMatrix,
                                    shader
                            )) {
                                abortFlush = true;
                                break;
                            }
                        }
                    } finally {
                        ChaosGpuGeoRenderer.finishRenderState();
                        ChaosGlDebug.restoreVertexArrayBinding(previousVertexArray, "ChaosGpuWorldRenderDispatcher.flush.direct.restoreVertexArray");
                        batch.renderLayer().clearRenderState();
                        RenderSystem.setShaderColor(previousShaderRed, previousShaderGreen, previousShaderBlue, previousShaderAlpha);
                    }
                } finally {
                    RenderSystem.setTextureMatrix(previousTextureMatrix);
                }
            }
        } finally {
            ChaosGpuRenderRuntime.clearFrameCaches();
            clearQueuedData();
        }
    }

    private static int batchingThresholdFor(ChaosGpuGeoMesh mesh, @Nullable int[] boneLightData, @Nullable Object bonePoseData, @Nullable float[] emissiveMaskData) {
        if (mesh.getInstancedVertexCount() >= 64) {
            return 1;
        }
        if (boneLightData != null || bonePoseData != null || emissiveMaskData != null) {
            return 1;
        }
        return 2;
    }

    private static boolean renderShaderPackBatchInstanced(
            BatchAccumulator batch, RenderType renderLayer, ChaosShaderRenderPhase phase, int size) {
        if (size < 2) {
            return false;
        }

        float colorRed = batch.shaderColorRed(0);
        float colorGreen = batch.shaderColorGreen(0);
        float colorBlue = batch.shaderColorBlue(0);
        float colorAlpha = batch.shaderColorAlpha(0);

        Object[] bonePoseData = new Object[size];
        Matrix4f[] modelViewMatrices = new Matrix4f[size];
        int[] packedLight = new int[size];
        int[][] boneLightData = new int[size][];
        int[] packedOverlay = new int[size];
        int[] renderedEntityIds = new int[size];
        int[] renderedBlockEntityIds = new int[size];
        int[] renderedItemIds = new int[size];

        for (int i = 0; i < size; i++) {
            if (Float.compare(batch.shaderColorRed(i), colorRed) != 0
                    || Float.compare(batch.shaderColorGreen(i), colorGreen) != 0
                    || Float.compare(batch.shaderColorBlue(i), colorBlue) != 0
                    || Float.compare(batch.shaderColorAlpha(i), colorAlpha) != 0) {
                return false;
            }

            bonePoseData[i] = batch.bonePoseData(i);
            modelViewMatrices[i] = new Matrix4f(batch.modelViewMatrix(i));
            packedLight[i] = batch.packedLight(i);
            boneLightData[i] = batch.boneLightData(i);
            packedOverlay[i] = batch.packedOverlay(i);
            renderedEntityIds[i] = batch.renderedEntityId(i);
            renderedBlockEntityIds[i] = batch.renderedBlockEntityId(i);
            renderedItemIds[i] = batch.renderedItemId(i);
        }

        return ChaosGpuShaderPackRenderer.renderInstancedWorldQueuedBatch(
                batch.mesh(),
                renderLayer,
                phase,
                bonePoseData,
                modelViewMatrices,
                packedLight,
                boneLightData,
                packedOverlay,
                renderedEntityIds,
                renderedBlockEntityIds,
                renderedItemIds,
                new float[]{colorRed, colorGreen, colorBlue, colorAlpha},
                size
        );
    }

    private static void flushShaderPackTarget(ShaderPackPassTarget target) {
        ChaosGpuAnimationPoseStorage.ensureBatchFlushed();
        List<BatchAccumulator> orderedBatches = SHADERPACK_ORDERED_BATCHES.get(target);
        if (orderedBatches == null || orderedBatches.isEmpty()) {
            maybeClearFrameCaches();
            return;
        }

        boolean shadowPass = target.shadowPass;
        int previousVertexArray = ChaosGlDebug.captureVertexArrayBinding("ChaosGpuWorldRenderDispatcher.flushShaderPackTarget.captureVertexArray");
        try {
            for (BatchAccumulator batch : orderedBatches) {
                boolean abortFlush = false;
                RenderType renderLayer = batch.renderLayer();
                ChaosShaderRenderPhase phase = batch.phase();
                Matrix4f previousTextureMatrix = PREVIOUS_TEXTURE_MATRIX.get().set(RenderSystem.getTextureMatrix());
                RenderSystem.setTextureMatrix(batch.textureMatrix());
                try {
                    ShaderInstance shader = ChaosGpuShaderPackRenderer.beginWorldQueuedBatch(renderLayer, phase);
                    if (shader == null) {
                        break;
                    }
                    try {
                        int size = batch.size();
                        if (renderShaderPackBatchInstanced(batch, renderLayer, phase, size)) {
                            continue;
                        }
                        for (int i = 0; i < size; i++) {
                            if (!ChaosGpuShaderPackRenderer.renderWorldQueuedPass(
                                    batch.mesh(),
                                    batch.bonePoseData(i),
                                    batch.modelViewMatrix(i),
                                    batch.packedLight(i),
                                    batch.boneLightData(i),
                                    batch.renderedEntityId(i),
                                    batch.renderedBlockEntityId(i),
                                    batch.renderedItemId(i),
                                    renderLayer,
                                    phase,
                                    batch.packedOverlay(i),
                                    batch.shaderColorRed(i),
                                    batch.shaderColorGreen(i),
                                    batch.shaderColorBlue(i),
                                    batch.shaderColorAlpha(i),
                                    shader,
                                    shadowPass
                            )) {
                                abortFlush = true;
                                break;
                            }
                        }
                    } finally {
                        ChaosGpuShaderPackRenderer.endWorldQueuedBatch(renderLayer, shader);
                    }
                } finally {
                    RenderSystem.setTextureMatrix(previousTextureMatrix);
                }
                if (abortFlush) {
                    break;
                }
            }
        } finally {
            ChaosGlDebug.restoreVertexArrayBinding(previousVertexArray, "ChaosGpuWorldRenderDispatcher.flushShaderPackTarget.restoreVertexArray");
            clearShaderPackQueuedData(target);
            maybeClearFrameCaches();
        }
    }

    private static void clearQueuedData() {
        for (BatchAccumulator batch : ORDERED_BATCHES) {
            batch.reset();
            BATCH_POOL.addLast(batch);
        }
        BATCHES.clear();
        BATCH_COUNTS.clear();
        ORDERED_BATCHES.clear();
        lastBatch = null;
        lastBatch2 = null;
    }

    private static void clearShaderPackQueuedData(ShaderPackPassTarget target) {
        Map<BatchKey, BatchAccumulator> batches = SHADERPACK_BATCHES.get(target);
        List<BatchAccumulator> orderedBatches = SHADERPACK_ORDERED_BATCHES.get(target);
        if (batches == null || orderedBatches == null) {
            return;
        }

        for (BatchAccumulator batch : orderedBatches) {
            batch.reset();
            BATCH_POOL.addLast(batch);
        }

        batches.clear();
        Map<BatchKey, Integer> batchCounts = SHADERPACK_BATCH_COUNTS.get(target);
        if (batchCounts != null) {
            batchCounts.clear();
        }
        orderedBatches.clear();
        LAST_SHADERPACK_BATCHES.remove(target);
    }

    private static void maybeClearFrameCaches() {
        if (!BATCHES.isEmpty() || !ORDERED_BATCHES.isEmpty()) {
            return;
        }

        for (List<BatchAccumulator> orderedBatches : SHADERPACK_ORDERED_BATCHES.values()) {
            if (!orderedBatches.isEmpty()) {
                return;
            }
        }

        ChaosGpuRenderRuntime.clearFrameCaches();
    }

    private static BatchAccumulator acquireBatch(RenderType renderLayer, ChaosGpuGeoMesh mesh, ResourceLocation texture, ResourceLocation emissiveTexture, ChaosShaderRenderPhase phase, float shaderColorScale, Matrix4f textureMatrix) {
        BatchAccumulator batch = BATCH_POOL.pollFirst();
        if (batch == null) {
            batch = new BatchAccumulator();
        }
        batch.init(renderLayer, mesh, texture, emissiveTexture, phase, shaderColorScale, textureMatrix);
        return batch;
    }

    private static String renderLayerKey(RenderType renderLayer) {
        if (renderLayer == null) {
            return "<null>";
        }
        return RENDER_LAYER_KEYS.computeIfAbsent(renderLayer, RenderType::toString);
    }

    private static ShaderPackPassTarget resolveShaderPackTarget(RenderType renderLayer, ChaosShaderRenderPhase phase) {
        boolean shadowPass = IrisCompatInternal.isShadowPassActive();
        boolean translucent = isTranslucent(renderLayer);

        return switch (phase) {
            case ENTITIES -> shadowPass
                    ? (translucent ? ShaderPackPassTarget.SHADOW_ENTITY_TRANSLUCENT : ShaderPackPassTarget.SHADOW_ENTITY_SOLID)
                    : (translucent ? ShaderPackPassTarget.ENTITY_TRANSLUCENT : ShaderPackPassTarget.ENTITY_SOLID);
            case BLOCK_ENTITIES, NONE, OUTLINE -> shadowPass
                    ? (translucent ? ShaderPackPassTarget.SHADOW_BLOCK_ENTITY_TRANSLUCENT : ShaderPackPassTarget.SHADOW_BLOCK_ENTITY_SOLID)
                    : (translucent ? ShaderPackPassTarget.BLOCK_ENTITY_TRANSLUCENT : ShaderPackPassTarget.BLOCK_ENTITY_SOLID);
        };
    }

    private static boolean isTranslucent(RenderType renderLayer) {
        return RENDER_LAYER_TRANSLUCENCY.computeIfAbsent(renderLayer, layer -> {
            String key = renderLayerKey(layer).toLowerCase(Locale.ROOT);
            return key.contains("translucent") || key.contains("tripwire");
        });
    }

    private static final class BatchAccumulator {
        private static final int INITIAL_CHUNK_CAPACITY = 4;
        private static final int INSTANCED_BATCH_SIZE = 4096;
        private static final int MATRIX_FLOATS = 16;
        private static final ThreadLocal<Matrix4f> TEMP_MATRIX = ThreadLocal.withInitial(Matrix4f::new);
        private RenderType renderLayer;
        private ChaosGpuGeoMesh mesh;
        private ResourceLocation texture;
        private ResourceLocation emissiveTexture;
        private ChaosShaderRenderPhase phase;
        private float shaderColorScale = 1.0f;
        private final Matrix4f textureMatrix = new Matrix4f();
        private float[][] modelViewMatrixChunks = new float[INITIAL_CHUNK_CAPACITY][];
        private int[][] packedLightChunks = new int[INITIAL_CHUNK_CAPACITY][];
        private int[][] packedOverlayChunks = new int[INITIAL_CHUNK_CAPACITY][];
        private int[][][] boneLightChunks = new int[INITIAL_CHUNK_CAPACITY][][];
        private float[][] emissiveStrengthChunks = new float[INITIAL_CHUNK_CAPACITY][];
        private Object[][] bonePoseDataChunks = new Object[INITIAL_CHUNK_CAPACITY][];
        private float[][][] emissiveMaskDataChunks = new float[INITIAL_CHUNK_CAPACITY][][];
        private float[][] shaderColorChunks = new float[INITIAL_CHUNK_CAPACITY][];
        private int[][] renderedEntityIdChunks = new int[INITIAL_CHUNK_CAPACITY][];
        private int[][] renderedBlockEntityIdChunks = new int[INITIAL_CHUNK_CAPACITY][];
        private int[][] renderedItemIdChunks = new int[INITIAL_CHUNK_CAPACITY][];
        private int size;

        private BatchAccumulator() {
        }

        private void init(RenderType renderLayer, ChaosGpuGeoMesh mesh, ResourceLocation texture, ResourceLocation emissiveTexture, ChaosShaderRenderPhase phase, float shaderColorScale, Matrix4f textureMatrix) {
            this.renderLayer = renderLayer;
            this.mesh = mesh;
            this.texture = texture;
            this.emissiveTexture = emissiveTexture;
            this.phase = phase;
            this.shaderColorScale = shaderColorScale;
            this.textureMatrix.set(textureMatrix);
            this.size = 0;
        }

        private void add(
                Matrix4f modelViewMatrix,
                int packedLight,
                int packedOverlay,
                int[] boneLightData,
                Object bonePoseData,
                float[] emissiveMaskData,
                float emissiveStrength,
                float shaderColorRed,
                float shaderColorGreen,
                float shaderColorBlue,
                float shaderColorAlpha,
                int renderedEntityId,
                int renderedBlockEntityId,
                int renderedItemId
        ) {
            int chunkIndex = this.size / INSTANCED_BATCH_SIZE;
            if (chunkIndex == this.modelViewMatrixChunks.length) {
                this.modelViewMatrixChunks = Arrays.copyOf(this.modelViewMatrixChunks, this.modelViewMatrixChunks.length << 1);
                this.packedLightChunks = Arrays.copyOf(this.packedLightChunks, this.packedLightChunks.length << 1);
                this.packedOverlayChunks = Arrays.copyOf(this.packedOverlayChunks, this.packedOverlayChunks.length << 1);
                this.boneLightChunks = Arrays.copyOf(this.boneLightChunks, this.boneLightChunks.length << 1);
                this.emissiveStrengthChunks = Arrays.copyOf(this.emissiveStrengthChunks, this.emissiveStrengthChunks.length << 1);
                this.bonePoseDataChunks = Arrays.copyOf(this.bonePoseDataChunks, this.bonePoseDataChunks.length << 1);
                this.emissiveMaskDataChunks = Arrays.copyOf(this.emissiveMaskDataChunks, this.emissiveMaskDataChunks.length << 1);
                this.shaderColorChunks = Arrays.copyOf(this.shaderColorChunks, this.shaderColorChunks.length << 1);
                this.renderedEntityIdChunks = Arrays.copyOf(this.renderedEntityIdChunks, this.renderedEntityIdChunks.length << 1);
                this.renderedBlockEntityIdChunks = Arrays.copyOf(this.renderedBlockEntityIdChunks, this.renderedBlockEntityIdChunks.length << 1);
                this.renderedItemIdChunks = Arrays.copyOf(this.renderedItemIdChunks, this.renderedItemIdChunks.length << 1);
            }

            float[] chunk = this.modelViewMatrixChunks[chunkIndex];
            if (chunk == null) {
                chunk = new float[INSTANCED_BATCH_SIZE * MATRIX_FLOATS];
                this.modelViewMatrixChunks[chunkIndex] = chunk;
            }
            int[] packedLightChunk = this.packedLightChunks[chunkIndex];
            if (packedLightChunk == null) {
                packedLightChunk = new int[INSTANCED_BATCH_SIZE];
                this.packedLightChunks[chunkIndex] = packedLightChunk;
            }
            int[] packedOverlayChunk = this.packedOverlayChunks[chunkIndex];
            if (packedOverlayChunk == null) {
                packedOverlayChunk = new int[INSTANCED_BATCH_SIZE];
                this.packedOverlayChunks[chunkIndex] = packedOverlayChunk;
            }
            int[][] boneLightChunk = this.boneLightChunks[chunkIndex];
            if (boneLightChunk == null) {
                boneLightChunk = new int[INSTANCED_BATCH_SIZE][];
                this.boneLightChunks[chunkIndex] = boneLightChunk;
            }
            float[] emissiveStrengthChunk = this.emissiveStrengthChunks[chunkIndex];
            if (emissiveStrengthChunk == null) {
                emissiveStrengthChunk = new float[INSTANCED_BATCH_SIZE];
                this.emissiveStrengthChunks[chunkIndex] = emissiveStrengthChunk;
            }
            Object[] bonePoseChunk = this.bonePoseDataChunks[chunkIndex];
            if (bonePoseChunk == null) {
                bonePoseChunk = new Object[INSTANCED_BATCH_SIZE];
                this.bonePoseDataChunks[chunkIndex] = bonePoseChunk;
            }
            float[][] emissiveMaskChunk = this.emissiveMaskDataChunks[chunkIndex];
            if (emissiveMaskChunk == null) {
                emissiveMaskChunk = new float[INSTANCED_BATCH_SIZE][];
                this.emissiveMaskDataChunks[chunkIndex] = emissiveMaskChunk;
            }
            float[] shaderColorChunk = this.shaderColorChunks[chunkIndex];
            if (shaderColorChunk == null) {
                shaderColorChunk = new float[INSTANCED_BATCH_SIZE * 4];
                this.shaderColorChunks[chunkIndex] = shaderColorChunk;
            }
            int[] renderedEntityIdChunk = this.renderedEntityIdChunks[chunkIndex];
            if (renderedEntityIdChunk == null) {
                renderedEntityIdChunk = new int[INSTANCED_BATCH_SIZE];
                this.renderedEntityIdChunks[chunkIndex] = renderedEntityIdChunk;
            }
            int[] renderedBlockEntityIdChunk = this.renderedBlockEntityIdChunks[chunkIndex];
            if (renderedBlockEntityIdChunk == null) {
                renderedBlockEntityIdChunk = new int[INSTANCED_BATCH_SIZE];
                this.renderedBlockEntityIdChunks[chunkIndex] = renderedBlockEntityIdChunk;
            }
            int[] renderedItemIdChunk = this.renderedItemIdChunks[chunkIndex];
            if (renderedItemIdChunk == null) {
                renderedItemIdChunk = new int[INSTANCED_BATCH_SIZE];
                this.renderedItemIdChunks[chunkIndex] = renderedItemIdChunk;
            }

            int instanceOffset = this.size % INSTANCED_BATCH_SIZE;
            int offset = instanceOffset * MATRIX_FLOATS;
            modelViewMatrix.get(chunk, offset);
            packedLightChunk[instanceOffset] = packedLight;
            packedOverlayChunk[instanceOffset] = packedOverlay;
            boneLightChunk[instanceOffset] = boneLightData;
            emissiveStrengthChunk[instanceOffset] = emissiveStrength;
            bonePoseChunk[instanceOffset] = bonePoseData;
            emissiveMaskChunk[instanceOffset] = emissiveMaskData;
            int colorOffset = instanceOffset * 4;
            shaderColorChunk[colorOffset] = shaderColorRed;
            shaderColorChunk[colorOffset + 1] = shaderColorGreen;
            shaderColorChunk[colorOffset + 2] = shaderColorBlue;
            shaderColorChunk[colorOffset + 3] = shaderColorAlpha;
            renderedEntityIdChunk[instanceOffset] = renderedEntityId;
            renderedBlockEntityIdChunk[instanceOffset] = renderedBlockEntityId;
            renderedItemIdChunk[instanceOffset] = renderedItemId;
            this.size++;
        }

        private void reset() {
            int usedChunks = (this.size + INSTANCED_BATCH_SIZE - 1) / INSTANCED_BATCH_SIZE;
            for (int chunkIndex = 0; chunkIndex < usedChunks; chunkIndex++) {
                int entries = chunkIndex == usedChunks - 1 ? ((this.size - 1) % INSTANCED_BATCH_SIZE) + 1 : INSTANCED_BATCH_SIZE;
                int[][] boneLightChunk = this.boneLightChunks[chunkIndex];
                if (boneLightChunk != null) {
                    Arrays.fill(boneLightChunk, 0, entries, null);
                }
                Object[] bonePoseChunk = this.bonePoseDataChunks[chunkIndex];
                if (bonePoseChunk != null) {
                    Arrays.fill(bonePoseChunk, 0, entries, null);
                }
                float[][] emissiveMaskChunk = this.emissiveMaskDataChunks[chunkIndex];
                if (emissiveMaskChunk != null) {
                    Arrays.fill(emissiveMaskChunk, 0, entries, null);
                }
            }

            this.renderLayer = null;
            this.mesh = null;
            this.texture = null;
            this.emissiveTexture = null;
            this.phase = ChaosShaderRenderPhase.NONE;
            this.shaderColorScale = 1.0f;
            this.textureMatrix.identity();
            this.size = 0;
        }

        private ChaosGpuGeoMesh mesh() {
            return this.mesh;
        }

        private ResourceLocation texture() {
            return this.texture;
        }

        private ResourceLocation emissiveTexture() {
            return this.emissiveTexture;
        }

        private Matrix4f textureMatrix() {
            return this.textureMatrix;
        }

        private boolean matches(RenderType renderLayer, ChaosGpuGeoMesh mesh, ResourceLocation texture, ResourceLocation emissiveTexture, ChaosShaderRenderPhase phase, float shaderColorScale, Matrix4f textureMatrix) {
            return this.renderLayer == renderLayer
                    && this.mesh == mesh
                    && Objects.equals(this.texture, texture)
                    && Objects.equals(this.emissiveTexture, emissiveTexture)
                    && this.phase == phase
                    && Float.compare(this.shaderColorScale, shaderColorScale) == 0
                    && this.textureMatrix.equals(textureMatrix);
        }

        private int size() {
            return this.size;
        }

        private Matrix4f modelViewMatrix(int index) {
            float[] chunk = this.modelViewMatrixChunks[index / INSTANCED_BATCH_SIZE];
            int offset = (index % INSTANCED_BATCH_SIZE) * MATRIX_FLOATS;
            return TEMP_MATRIX.get().set(chunk, offset);
        }

        private int packedLight(int index) {
            int[] chunk = this.packedLightChunks[index / INSTANCED_BATCH_SIZE];
            return chunk[index % INSTANCED_BATCH_SIZE];
        }

        private float emissiveStrength(int index) {
            float[] chunk = this.emissiveStrengthChunks[index / INSTANCED_BATCH_SIZE];
            return chunk[index % INSTANCED_BATCH_SIZE];
        }

        private int packedOverlay(int index) {
            int[] chunk = this.packedOverlayChunks[index / INSTANCED_BATCH_SIZE];
            return chunk[index % INSTANCED_BATCH_SIZE];
        }

        private float shaderColorRed(int index) {
            float[] chunk = this.shaderColorChunks[index / INSTANCED_BATCH_SIZE];
            return chunk[(index % INSTANCED_BATCH_SIZE) * 4];
        }

        private float shaderColorGreen(int index) {
            float[] chunk = this.shaderColorChunks[index / INSTANCED_BATCH_SIZE];
            return chunk[(index % INSTANCED_BATCH_SIZE) * 4 + 1];
        }

        private float shaderColorBlue(int index) {
            float[] chunk = this.shaderColorChunks[index / INSTANCED_BATCH_SIZE];
            return chunk[(index % INSTANCED_BATCH_SIZE) * 4 + 2];
        }

        private float shaderColorAlpha(int index) {
            float[] chunk = this.shaderColorChunks[index / INSTANCED_BATCH_SIZE];
            return chunk[(index % INSTANCED_BATCH_SIZE) * 4 + 3];
        }

        private int[] boneLightData(int index) {
            int[][] chunk = this.boneLightChunks[index / INSTANCED_BATCH_SIZE];
            return chunk[index % INSTANCED_BATCH_SIZE];
        }

        private Object bonePoseData(int index) {
            Object[] chunk = this.bonePoseDataChunks[index / INSTANCED_BATCH_SIZE];
            return chunk[index % INSTANCED_BATCH_SIZE];
        }

        private float[] emissiveMaskData(int index) {
            float[][] chunk = this.emissiveMaskDataChunks[index / INSTANCED_BATCH_SIZE];
            return chunk[index % INSTANCED_BATCH_SIZE];
        }

        private RenderType renderLayer() {
            return this.renderLayer;
        }

        private ChaosShaderRenderPhase phase() {
            return this.phase;
        }

        private int renderedEntityId(int index) {
            int[] chunk = this.renderedEntityIdChunks[index / INSTANCED_BATCH_SIZE];
            return chunk[index % INSTANCED_BATCH_SIZE];
        }

        private int renderedBlockEntityId(int index) {
            int[] chunk = this.renderedBlockEntityIdChunks[index / INSTANCED_BATCH_SIZE];
            return chunk[index % INSTANCED_BATCH_SIZE];
        }

        private int renderedItemId(int index) {
            int[] chunk = this.renderedItemIdChunks[index / INSTANCED_BATCH_SIZE];
            return chunk[index % INSTANCED_BATCH_SIZE];
        }
    }

    private enum ShaderPackPassTarget {
        ENTITY_SOLID(false),
        ENTITY_TRANSLUCENT(false),
        BLOCK_ENTITY_SOLID(false),
        BLOCK_ENTITY_TRANSLUCENT(false),
        SHADOW_ENTITY_SOLID(true),
        SHADOW_ENTITY_TRANSLUCENT(true),
        SHADOW_BLOCK_ENTITY_SOLID(true),
        SHADOW_BLOCK_ENTITY_TRANSLUCENT(true);

        private final boolean shadowPass;

        ShaderPackPassTarget(boolean shadowPass) {
            this.shadowPass = shadowPass;
        }
    }

    private static final class BatchKey {
        private final RenderType renderLayer;
        private final ChaosGpuGeoMesh mesh;
        private final ResourceLocation texture;
        private final ResourceLocation emissiveTexture;
        private final ChaosShaderRenderPhase phase;
        private final float shaderColorScale;
        private final Matrix4f textureMatrix;
        private final int hashCode;

        private BatchKey(RenderType renderLayer, ChaosGpuGeoMesh mesh, ResourceLocation texture, ResourceLocation emissiveTexture, ChaosShaderRenderPhase phase, float shaderColorScale, Matrix4f textureMatrix) {
            this.renderLayer = renderLayer;
            this.mesh = mesh;
            this.texture = texture;
            this.emissiveTexture = emissiveTexture;
            this.phase = phase;
            this.shaderColorScale = shaderColorScale;
            this.textureMatrix = textureMatrix;
            int result = System.identityHashCode(renderLayer);
            result = 31 * result + System.identityHashCode(mesh);
            result = 31 * result + Objects.hashCode(texture);
            result = 31 * result + Objects.hashCode(emissiveTexture);
            result = 31 * result + phase.ordinal();
            result = 31 * result + Float.floatToIntBits(shaderColorScale);
            result = 31 * result + textureMatrix.hashCode();
            this.hashCode = result;
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof BatchKey key)) {
                return false;
            }
            return this.renderLayer == key.renderLayer
                    && this.mesh == key.mesh
                    && Float.compare(this.shaderColorScale, key.shaderColorScale) == 0
                    && this.phase == key.phase
                    && Objects.equals(this.texture, key.texture)
                    && Objects.equals(this.emissiveTexture, key.emissiveTexture)
                    && this.textureMatrix.equals(key.textureMatrix);
        }

        @Override
        public int hashCode() {
            return this.hashCode;
        }
    }
}
