package dev.elifian.chaoslib.gpu.render;

import com.mojang.blaze3d.shaders.Uniform;
import dev.elifian.chaoslib.platform.ClientOnly;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.ShaderInstance;
import org.joml.Matrix3f;

@ClientOnly
public final class ChaosViewRotation {
    private static final String UNIFORM_NAME = "IViewRotMat";

    private ChaosViewRotation() {
    }

    public static Matrix3f inverseViewRotationMatrix() {
        Camera camera = Minecraft.getInstance().gameRenderer.getMainCamera();
        return new Matrix3f().rotation(camera.rotation());
    }

    public static void apply(ShaderInstance shader) {
        Uniform uniform = shader.getUniform(UNIFORM_NAME);
        if (uniform != null) {
            uniform.set(inverseViewRotationMatrix());
        }
    }
}
