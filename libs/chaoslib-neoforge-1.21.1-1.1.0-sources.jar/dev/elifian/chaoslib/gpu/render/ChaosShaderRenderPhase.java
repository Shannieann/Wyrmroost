package dev.elifian.chaoslib.gpu.render;

public enum ChaosShaderRenderPhase {
    NONE,
    ENTITIES,
    BLOCK_ENTITIES,
    OUTLINE
}
