package dev.elifian.chaoslib.gpu.render;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.elifian.chaoslib.api.animatable.GeoAnimatable;
import dev.elifian.chaoslib.api.animation.AnimationState;
import dev.elifian.chaoslib.api.model.GeoModel;
import dev.elifian.chaoslib.cache.object.BakedGeoModel;
import dev.elifian.chaoslib.client.texture.AnimatedTextureSupport;
import dev.elifian.chaoslib.compat.iris.ChaosIrisShaderPackProgramCompiler;
import dev.elifian.chaoslib.compat.iris.IrisCompatInternal;
import com.mojang.blaze3d.platform.GlStateManager;
import dev.elifian.chaoslib.config.ChaosAmdRenderingSafetyMode;
import dev.elifian.chaoslib.config.ChaosLibClientConfig;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuAnimationPoseStorage;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuBoneDataStorage;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuBoneResolveDispatcher;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuDriverInfo;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuInstanceDataStorage;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuInstancedPoseBatchStorage;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuLightDataStorage;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuWorldLightVolumeStorage;
import dev.elifian.chaoslib.gpu.debug.ChaosGlDebug;
import dev.elifian.chaoslib.gpu.mesh.ChaosGpuGeoMesh;
import dev.elifian.chaoslib.gpu.shader.ChaosGpuShaderSources;
import dev.elifian.chaoslib.renderer.block.ChaosBlockEntityRenderFrameClock;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.RenderType;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.resources.ResourceLocation;

import dev.elifian.chaoslib.platform.ClientOnly;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL30;
import org.lwjgl.opengl.GL31;
import org.lwjgl.opengl.GL33;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

@ClientOnly
public final class ChaosGpuShaderPackRenderer {
    private static final Object REST_POSE_CPU_CACHE_KEY = new Object();
    private static final float[] EMPTY_EMISSIVE_MASK = new float[]{0.0f};
    private static final int[] EMPTY_BONE_LIGHT_DATA = new int[]{0};
    private static final int FLOAT_BYTES = Float.BYTES;
    private static final int SOURCE_COLOR_OFFSET = 3 * FLOAT_BYTES;
    private static final int SOURCE_UV0_OFFSET = SOURCE_COLOR_OFFSET + Integer.BYTES;
    private static final int SOURCE_BONE_INDEX_OFFSET = SOURCE_UV0_OFFSET + 2 * FLOAT_BYTES;
    private static final int SOURCE_NORMAL_OFFSET = SOURCE_BONE_INDEX_OFFSET + Integer.BYTES;
    private static final int SOURCE_MID_TEX_COORD_OFFSET = SOURCE_NORMAL_OFFSET + Integer.BYTES;
    private static final int SOURCE_VERTEX_STRIDE = SOURCE_MID_TEX_COORD_OFFSET + 2 * FLOAT_BYTES + Integer.BYTES;
    private static final int TRANSFORMED_POSITION_OFFSET = 0;
    private static final int TRANSFORMED_UV2_OFFSET = TRANSFORMED_POSITION_OFFSET + 3 * FLOAT_BYTES;
    private static final int TRANSFORMED_NORMAL_OFFSET = TRANSFORMED_UV2_OFFSET + Integer.BYTES;
    private static final int TRANSFORMED_TANGENT_OFFSET = TRANSFORMED_NORMAL_OFFSET + Integer.BYTES;
    private static final int TRANSFORMED_VERTEX_STRIDE = TRANSFORMED_TANGENT_OFFSET + Integer.BYTES;
    private static final String TRANSFORM_FEEDBACK_VERTEX_SHADER = ChaosGpuShaderSources.load("assets/chaoslib/shaders/internal/transform_feedback/shaderpack/default.vsh");
    private static final String AMD_TRANSFORM_FEEDBACK_VERTEX_SHADER = ChaosGpuShaderSources.load("assets/chaoslib/shaders/internal/transform_feedback/shaderpack/amd.vsh");
    private static final String TRANSFORM_FEEDBACK_FRAGMENT_SHADER = ChaosGpuShaderSources.load("assets/chaoslib/shaders/internal/transform_feedback/passthrough_150.fsh");
    private static final Map<ChaosGpuGeoMesh, MeshTransformCache> TRANSFORMED_MESH_CACHE = Collections.synchronizedMap(new IdentityHashMap<>());
    private static final int MAX_TRANSFORMED_MESHES_PER_MESH = 32;
    private static final int SKINNED_BONE_POSE_UNIT = 20;
    private static final int SKINNED_BONE_INDEX_UNIT = 21;
    private static final int SKINNED_BONE_LIGHT_UNIT = 22;
    private static final int SKINNED_BLOCK_LIGHT_VOLUME_UNIT = 23;
    private static final int SKINNED_SKY_LIGHT_VOLUME_UNIT = 24;
    private static final int SKINNED_INSTANCE_MATRIX_UNIT = 25;
    private static final int SKINNED_INSTANCE_POSE_BASE_UNIT = 26;
    private static final int SKINNED_INSTANCE_PACKED_LIGHT_UNIT = 27;
    private static final int SKINNED_INSTANCE_LIGHT_BASE_UNIT = 28;
    private static final Map<ChaosGpuGeoMesh, InstancedSourceMesh> INSTANCED_SOURCE_MESH_CACHE =
            Collections.synchronizedMap(new IdentityHashMap<>());
    private static final Map<ChaosGpuGeoMesh, SourceMesh> SOURCE_MESH_CACHE = Collections.synchronizedMap(new IdentityHashMap<>());
    private static final Map<Integer, SkinningUniforms> SKINNING_UNIFORM_CACHE = new HashMap<>();
    private static final ThreadLocal<float[]> MATRIX4_UNIFORM = ThreadLocal.withInitial(() -> new float[16]);
    private static int transformFeedbackProgram = -1;
    private static int bonePoseSamplerUniformLocation = -1;
    private static int boneLightSamplerUniformLocation = -1;
    private static int lightUniformLocation = -1;
    private static int useBoneLightSamplerUniformLocation = -1;
    private static int boneDataResolvedUniformLocation = -1;
    private static int bonePoseBaseUniformLocation = -1;
    private static int modelWorldRelUniformLocation = -1;
    private static int useWorldLightVolumeUniformLocation = -1;
    private static int cameraWorldPosUniformLocation = -1;
    private static int lightVolumeBlockOriginUniformLocation = -1;
    private static int lightVolumeSizeUniformLocation = -1;
    private static int blockLightVolumeSamplerUniformLocation = -1;
    private static int skyLightVolumeSamplerUniformLocation = -1;

    private ChaosGpuShaderPackRenderer() {
    }

    public static void invalidateAll() {
        synchronized (TRANSFORMED_MESH_CACHE) {
            for (MeshTransformCache cache : TRANSFORMED_MESH_CACHE.values()) {
                cache.close();
            }
            TRANSFORMED_MESH_CACHE.clear();
        }

        synchronized (SOURCE_MESH_CACHE) {
            for (SourceMesh sourceMesh : SOURCE_MESH_CACHE.values()) {
                sourceMesh.close();
            }
            SOURCE_MESH_CACHE.clear();
        }

        synchronized (INSTANCED_SOURCE_MESH_CACHE) {
            for (InstancedSourceMesh instancedMesh : INSTANCED_SOURCE_MESH_CACHE.values()) {
                instancedMesh.close();
            }
            INSTANCED_SOURCE_MESH_CACHE.clear();
        }
        SKINNING_UNIFORM_CACHE.clear();

        if (transformFeedbackProgram != -1) {
            GL20.glDeleteProgram(transformFeedbackProgram);
            ChaosGlDebug.check("ChaosGpuShaderPackRenderer.invalidateAll.glDeleteProgram");
            transformFeedbackProgram = -1;
            bonePoseSamplerUniformLocation = -1;
            boneLightSamplerUniformLocation = -1;
            lightUniformLocation = -1;
            useBoneLightSamplerUniformLocation = -1;
            boneDataResolvedUniformLocation = -1;
        bonePoseBaseUniformLocation = -1;
            modelWorldRelUniformLocation = -1;
            useWorldLightVolumeUniformLocation = -1;
            cameraWorldPosUniformLocation = -1;
            lightVolumeBlockOriginUniformLocation = -1;
            lightVolumeSizeUniformLocation = -1;
            blockLightVolumeSamplerUniformLocation = -1;
            skyLightVolumeSamplerUniformLocation = -1;
        }

        ChaosIrisShaderPackProgramCompiler.invalidateAll();
    }

    public static <T extends GeoAnimatable> boolean render(
            PoseStack poseStack,
            T animatable,
            GeoModel<T> geoModel,
            AnimationState<T> animationState,
            ResourceLocation texture,
            ResourceLocation emissiveTexture,
            BakedGeoModel model,
            int packedLight,
            int[] boneLightData,
            Set<String> includedBones,
            Set<String> emissiveBones,
            float emissiveStrength,
            RenderType renderType,
            RenderType emissiveRenderType
    ) {
        return render(
                poseStack,
                animatable,
                geoModel,
                animationState,
                texture,
                emissiveTexture,
                model,
                packedLight,
                boneLightData,
                includedBones,
                emissiveBones,
                emissiveStrength,
                OverlayTexture.NO_OVERLAY,
                renderType,
                emissiveRenderType,
                ChaosShaderRenderPhase.NONE,
                animatable.getPoseKey()
        );
    }

    public static <T extends GeoAnimatable> boolean render(
            PoseStack poseStack,
            T animatable,
            ResourceLocation texture,
            ResourceLocation emissiveTexture,
            BakedGeoModel model,
            int packedLight,
            int[] boneLightData,
            Set<String> includedBones,
            Set<String> emissiveBones,
            float emissiveStrength,
            RenderType renderType,
            RenderType emissiveRenderType,
            ChaosShaderRenderPhase phase,
            Object poseCacheKey
    ) {
        return render(
                poseStack,
                animatable,
                texture,
                emissiveTexture,
                model,
                packedLight,
                boneLightData,
                includedBones,
                emissiveBones,
                emissiveStrength,
                OverlayTexture.NO_OVERLAY,
                renderType,
                emissiveRenderType,
                phase,
                poseCacheKey
        );
    }

    public static <T extends GeoAnimatable> boolean render(
            PoseStack poseStack,
            T animatable,
            ResourceLocation texture,
            ResourceLocation emissiveTexture,
            BakedGeoModel model,
            int packedLight,
            int[] boneLightData,
            Set<String> includedBones,
            Set<String> emissiveBones,
            float emissiveStrength,
            int packedOverlay,
            RenderType renderType,
            RenderType emissiveRenderType,
            ChaosShaderRenderPhase phase,
            Object poseCacheKey
    ) {
        if (!ChaosGpuRenderRuntime.isShaderPackPipelineActive() || !ChaosGpuRenderRuntime.isGpuPathSupported(model)) {
            return false;
        }

        RenderType phasedRenderType = IrisCompatInternal.wrapRenderLayer(renderType, phase);
        RenderType phasedEmissiveRenderType = IrisCompatInternal.wrapRenderLayer(emissiveRenderType, phase);

        ChaosGpuGeoMesh baseMesh = ChaosGpuGeoMesh.getOrCreate(model, includedBones, shouldNormalizeAnimatedTextureUv(texture, includedBones));
        if (baseMesh.getInstancedVertexCount() <= 0) {
            return true;
        }

        ensureTransformFeedbackProgram();
        if (transformFeedbackProgram == -1 || !ChaosGpuRenderRuntime.isGpuPathSupported()) {
            return false;
        }

        Object bonePoseData = ChaosGpuAnimationPoseStorage.prepareRestPoseToken(baseMesh);
        if (bonePoseData == null) {
            float[] poseData = ChaosGpuPoseDataCache.prepareBonePoseData(REST_POSE_CPU_CACHE_KEY, model, baseMesh);
            bonePoseData = ChaosGpuAnimationPoseStorage.prepareUploadedPoseToken(baseMesh, poseData, REST_POSE_CPU_CACHE_KEY, animatable);
            if (bonePoseData == null) {
                bonePoseData = poseData;
            }
        }
        if (!ChaosGpuWorldRenderDispatcher.enqueue(
                phasedRenderType,
                baseMesh,
                texture,
                null,
                poseStack.last().pose(),
                packedLight,
                boneLightData,
                bonePoseData,
                null,
                1.0f,
                packedOverlay,
                phase,
                1.0f
        )) {
            return false;
        }

        if (emissiveTexture == null || emissiveBones == null || emissiveBones.isEmpty() || phasedEmissiveRenderType == null) {
            return true;
        }

        ChaosGpuGeoMesh emissiveMesh = ChaosGpuGeoMesh.getOrCreate(model, emissiveBones, shouldNormalizeAnimatedTextureUv(emissiveTexture, emissiveBones));
        if (emissiveMesh.getInstancedVertexCount() <= 0) {
            return true;
        }

        float scaledEmissiveStrength = Math.max(0.0f, emissiveStrength);
        if (scaledEmissiveStrength <= 0.0f) {
            return true;
        }

        return ChaosGpuWorldRenderDispatcher.enqueue(
                phasedEmissiveRenderType,
                emissiveMesh,
                emissiveTexture,
                null,
                poseStack.last().pose(),
                LightTexture.FULL_BRIGHT,
                null,
                bonePoseData,
                null,
                scaledEmissiveStrength,
                OverlayTexture.NO_OVERLAY,
                phase,
                scaledEmissiveStrength
        );
    }

    public static <T extends GeoAnimatable> boolean render(
            PoseStack poseStack,
            T animatable,
            GeoModel<T> geoModel,
            AnimationState<T> animationState,
            ResourceLocation texture,
            ResourceLocation emissiveTexture,
            BakedGeoModel model,
            int packedLight,
            int[] boneLightData,
            Set<String> includedBones,
            Set<String> emissiveBones,
            float emissiveStrength,
            RenderType renderType,
            RenderType emissiveRenderType,
            ChaosShaderRenderPhase phase,
            Object poseCacheKey
    ) {
        return render(
                poseStack,
                animatable,
                geoModel,
                animationState,
                texture,
                emissiveTexture,
                model,
                packedLight,
                boneLightData,
                includedBones,
                emissiveBones,
                emissiveStrength,
                OverlayTexture.NO_OVERLAY,
                renderType,
                emissiveRenderType,
                phase,
                poseCacheKey
        );
    }

    public static <T extends GeoAnimatable> boolean render(
            PoseStack poseStack,
            T animatable,
            GeoModel<T> geoModel,
            AnimationState<T> animationState,
            ResourceLocation texture,
            ResourceLocation emissiveTexture,
            BakedGeoModel model,
            int packedLight,
            int[] boneLightData,
            Set<String> includedBones,
            Set<String> emissiveBones,
            float emissiveStrength,
            int packedOverlay,
            RenderType renderType,
            RenderType emissiveRenderType,
            ChaosShaderRenderPhase phase,
            Object poseCacheKey
    ) {
        return renderCapture(
                poseStack,
                animatable,
                geoModel,
                animationState,
                texture,
                emissiveTexture,
                model,
                packedLight,
                boneLightData,
                includedBones,
                emissiveBones,
                emissiveStrength,
                packedOverlay,
                renderType,
                emissiveRenderType,
                phase,
                poseCacheKey
        ) != null;
    }

    public static <T extends GeoAnimatable> ChaosGpuRenderCapture renderCapture(
            PoseStack poseStack,
            T animatable,
            GeoModel<T> geoModel,
            AnimationState<T> animationState,
            ResourceLocation texture,
            ResourceLocation emissiveTexture,
            BakedGeoModel model,
            int packedLight,
            int[] boneLightData,
            Set<String> includedBones,
            Set<String> emissiveBones,
            float emissiveStrength,
            RenderType renderType,
            RenderType emissiveRenderType,
            ChaosShaderRenderPhase phase,
            Object poseCacheKey
    ) {
        return renderCapture(
                poseStack,
                animatable,
                geoModel,
                animationState,
                texture,
                emissiveTexture,
                model,
                packedLight,
                boneLightData,
                includedBones,
                emissiveBones,
                emissiveStrength,
                OverlayTexture.NO_OVERLAY,
                renderType,
                emissiveRenderType,
                phase,
                poseCacheKey
        );
    }

    public static <T extends GeoAnimatable> ChaosGpuRenderCapture renderCapture(
            PoseStack poseStack,
            T animatable,
            GeoModel<T> geoModel,
            AnimationState<T> animationState,
            ResourceLocation texture,
            ResourceLocation emissiveTexture,
            BakedGeoModel model,
            int packedLight,
            int[] boneLightData,
            Set<String> includedBones,
            Set<String> emissiveBones,
            float emissiveStrength,
            int packedOverlay,
            RenderType renderType,
            RenderType emissiveRenderType,
            ChaosShaderRenderPhase phase,
            Object poseCacheKey
    ) {
        if (!ChaosGpuRenderRuntime.isShaderPackPipelineActive() || !ChaosGpuRenderRuntime.isGpuPathSupported(model)) {
            return null;
        }

        RenderType phasedRenderType = IrisCompatInternal.wrapRenderLayer(renderType, phase);
        RenderType phasedEmissiveRenderType = IrisCompatInternal.wrapRenderLayer(emissiveRenderType, phase);

        ChaosGpuGeoMesh baseMesh = ChaosGpuGeoMesh.getOrCreate(model, includedBones, shouldNormalizeAnimatedTextureUv(texture, includedBones));
        if (baseMesh.getInstancedVertexCount() <= 0) {
            return ChaosGpuRenderCapture.empty(includedBones);
        }

        ensureTransformFeedbackProgram();
        if (transformFeedbackProgram == -1 || !ChaosGpuRenderRuntime.isGpuPathSupported()) {
            return null;
        }

        Object bonePoseData = geoModel.prepareGpuBonePoseData(animatable, poseMeshForAnimation(model, baseMesh, includedBones), animationState, poseCacheKey);
        if (!ChaosGpuWorldRenderDispatcher.enqueue(
                phasedRenderType,
                baseMesh,
                texture,
                null,
                poseStack.last().pose(),
                packedLight,
                boneLightData,
                bonePoseData,
                null,
                1.0f,
                packedOverlay,
                phase,
                1.0f
        )) {
            return null;
        }

        ChaosGpuRenderCapture capture = new ChaosGpuRenderCapture(baseMesh, bonePoseData, includedBones);

        if (emissiveTexture == null || emissiveBones == null || emissiveBones.isEmpty() || phasedEmissiveRenderType == null) {
            return capture;
        }

        ChaosGpuGeoMesh emissiveMesh = ChaosGpuGeoMesh.getOrCreate(model, emissiveBones, shouldNormalizeAnimatedTextureUv(emissiveTexture, emissiveBones));
        if (emissiveMesh.getInstancedVertexCount() <= 0) {
            return capture;
        }

        float scaledEmissiveStrength = Math.max(0.0f, emissiveStrength);
        if (scaledEmissiveStrength <= 0.0f) {
            return capture;
        }

        ChaosGpuWorldRenderDispatcher.enqueue(
                phasedEmissiveRenderType,
                emissiveMesh,
                emissiveTexture,
                null,
                poseStack.last().pose(),
                LightTexture.FULL_BRIGHT,
                null,
                bonePoseData,
                null,
                scaledEmissiveStrength,
                OverlayTexture.NO_OVERLAY,
                phase,
                scaledEmissiveStrength
        );
        return capture;
    }

    private static ChaosGpuGeoMesh poseMeshForAnimation(BakedGeoModel model, ChaosGpuGeoMesh renderMesh, Set<String> includedBones) {
        return includedBones == null ? renderMesh : ChaosGpuGeoMesh.getOrCreate(model);
    }

    private static boolean renderMeshPass(ChaosGpuGeoMesh mesh, Object bonePoseData, Matrix4f modelViewMatrix, int packedLight, int[] boneLightData, RenderType renderType) {
        float[] shaderColor = RenderSystem.getShaderColor();
        ChaosShaderRenderPhase phase = ChaosShaderRenderPhase.NONE;
        ShaderInstance shader = beginWorldQueuedBatch(renderType, phase);
        if (shader == null) {
            return false;
        }
        try {
            return renderMeshPass(
                    mesh,
                    bonePoseData,
                    modelViewMatrix,
                    packedLight,
                    boneLightData,
                    IrisCompatInternal.currentRenderedEntityId(),
                    IrisCompatInternal.currentRenderedBlockEntityId(),
                    IrisCompatInternal.currentRenderedItemId(),
                    renderType,
                    OverlayTexture.NO_OVERLAY,
                    shaderColor[0],
                    shaderColor[1],
                    shaderColor[2],
                    shaderColor[3],
                    shader,
                    IrisCompatInternal.isShadowPassActive(),
                    phase
            );
        } finally {
            endWorldQueuedBatch(renderType, shader);
        }
    }

    public static boolean renderPreparedMeshPass(
            PoseStack poseStack,
            ChaosGpuGeoMesh mesh,
            Object bonePoseData,
            int packedLight,
            int[] boneLightData,
            RenderType renderType,
            ChaosShaderRenderPhase phase
    ) {
        return renderPreparedMeshPass(poseStack, mesh, bonePoseData, packedLight, boneLightData, renderType, phase, 1.0f);
    }

    public static boolean renderPreparedMeshPass(
            PoseStack poseStack,
            ChaosGpuGeoMesh mesh,
            Object bonePoseData,
            int packedLight,
            int[] boneLightData,
            RenderType renderType,
            ChaosShaderRenderPhase phase,
            float colorScale
    ) {
        if (!ChaosGpuRenderRuntime.isShaderPackPipelineActive() || !ChaosGpuRenderRuntime.isGpuPathSupported()) {
            return false;
        }
        if (mesh == null || mesh.getInstancedVertexCount() <= 0) {
            return true;
        }

        ensureTransformFeedbackProgram();
        if (transformFeedbackProgram == -1) {
            return false;
        }

        return ChaosGpuWorldRenderDispatcher.enqueue(
                IrisCompatInternal.wrapRenderLayer(renderType, phase),
                mesh,
                null,
                null,
                poseStack.last().pose(),
                packedLight,
                boneLightData,
                bonePoseData,
                null,
                colorScale,
                phase,
                colorScale
        );
    }

    public static boolean renderWorldQueuedPass(
            ChaosGpuGeoMesh mesh,
            Object bonePoseData,
            Matrix4f modelViewMatrix,
            int packedLight,
            int[] boneLightData,
            int renderedEntityId,
            int renderedBlockEntityId,
            int renderedItemId,
            RenderType renderType,
            ChaosShaderRenderPhase phase,
            int packedOverlay,
            float shaderColorRed,
            float shaderColorGreen,
            float shaderColorBlue,
            float shaderColorAlpha,
            ShaderInstance shader
    ) {
        if (!ChaosGpuRenderRuntime.isShaderPackPipelineActive() || !ChaosGpuRenderRuntime.isGpuPathSupported()) {
            return false;
        }
        if (mesh == null || mesh.getInstancedVertexCount() <= 0) {
            return true;
        }

        ensureTransformFeedbackProgram();
        if (transformFeedbackProgram == -1 || shader == null || renderType == null) {
            return false;
        }

        return renderMeshPass(
                mesh,
                bonePoseData,
                modelViewMatrix,
                packedLight,
                boneLightData,
                renderedEntityId,
                renderedBlockEntityId,
                renderedItemId,
                renderType,
                packedOverlay,
                shaderColorRed,
                shaderColorGreen,
                shaderColorBlue,
                shaderColorAlpha,
                shader,
                IrisCompatInternal.isShadowPassActive(),
                phase
        );
    }

    public static boolean renderWorldQueuedPass(
            ChaosGpuGeoMesh mesh,
            Object bonePoseData,
            Matrix4f modelViewMatrix,
            int packedLight,
            int[] boneLightData,
            int renderedEntityId,
            int renderedBlockEntityId,
            int renderedItemId,
            RenderType renderType,
            ChaosShaderRenderPhase phase,
            int packedOverlay,
            float shaderColorRed,
            float shaderColorGreen,
            float shaderColorBlue,
            float shaderColorAlpha,
            ShaderInstance shader,
            boolean shadowPass
    ) {
        if (!ChaosGpuRenderRuntime.isShaderPackPipelineActive() || !ChaosGpuRenderRuntime.isGpuPathSupported()) {
            return false;
        }
        if (mesh == null || mesh.getInstancedVertexCount() <= 0) {
            return true;
        }

        ensureTransformFeedbackProgram();
        if (transformFeedbackProgram == -1 || shader == null || renderType == null) {
            return false;
        }

        return renderMeshPass(
                mesh,
                bonePoseData,
                modelViewMatrix,
                packedLight,
                boneLightData,
                renderedEntityId,
                renderedBlockEntityId,
                renderedItemId,
                renderType,
                packedOverlay,
                shaderColorRed,
                shaderColorGreen,
                shaderColorBlue,
                shaderColorAlpha,
                shader,
                shadowPass,
                phase
        );
    }

    public static @Nullable ShaderInstance beginWorldQueuedBatch(RenderType renderType, ChaosShaderRenderPhase phase) {
        if (!ChaosGpuRenderRuntime.isShaderPackPipelineActive() || !ChaosGpuRenderRuntime.isGpuPathSupported() || renderType == null) {
            return null;
        }

        renderType.setupRenderState();
        ShaderInstance shader = ChaosIrisShaderPackProgramCompiler.getShader(phase, renderType);
        if (shader == null) {
            shader = RenderSystem.getShader();
        }
        if (shader == null) {
            renderType.clearRenderState();
        }
        return shader;
    }

    public static void endWorldQueuedBatch(RenderType renderType, @Nullable ShaderInstance shader) {
        if (shader != null) {
            shader.clear();
        }
        if (renderType == null) {
            return;
        }

        renderType.clearRenderState();
    }

    private static boolean renderMeshPass(
            ChaosGpuGeoMesh mesh,
            Object bonePoseData,
            Matrix4f modelViewMatrix,
            int packedLight,
            int[] boneLightData,
            RenderType renderType,
            ChaosShaderRenderPhase phase) {
        float[] shaderColor = RenderSystem.getShaderColor();
        ShaderInstance shader = beginWorldQueuedBatch(renderType, phase);
        if (shader == null) {
            return false;
        }
        try {
            return renderMeshPass(
                    mesh,
                    bonePoseData,
                    modelViewMatrix,
                    packedLight,
                    boneLightData,
                    IrisCompatInternal.currentRenderedEntityId(),
                    IrisCompatInternal.currentRenderedBlockEntityId(),
                    IrisCompatInternal.currentRenderedItemId(),
                    renderType,
                    OverlayTexture.NO_OVERLAY,
                    shaderColor[0],
                    shaderColor[1],
                    shaderColor[2],
                    shaderColor[3],
                    shader,
                    IrisCompatInternal.isShadowPassActive(),
                    phase
            );
        } finally {
            endWorldQueuedBatch(renderType, shader);
        }
    }

    private static boolean renderMeshPass(
            ChaosGpuGeoMesh mesh,
            Object bonePoseData,
            Matrix4f modelViewMatrix,
            int packedLight,
            int[] boneLightData,
            int renderedEntityId,
            int renderedBlockEntityId,
            int renderedItemId,
            RenderType renderType,
            int packedOverlay,
            float shaderColorRed,
            float shaderColorGreen,
            float shaderColorBlue,
            float shaderColorAlpha,
            ShaderInstance shader,
            boolean shadowPass,
            ChaosShaderRenderPhase phase) {
        if (renderType == null) {
            return false;
        }

        Matrix4f worldRelMatrix = resolveWorldRelativeMatrix(modelViewMatrix);
        if (renderSkinnedMeshPass(
                mesh, bonePoseData, modelViewMatrix, worldRelMatrix, packedLight, boneLightData,
                renderedEntityId, renderedBlockEntityId, renderedItemId, renderType, phase, packedOverlay,
                shaderColorRed, shaderColorGreen, shaderColorBlue, shaderColorAlpha)) {
            return true;
        }

        int previousVertexArray = ChaosGlDebug.captureVertexArrayBinding("ChaosGpuShaderPackRenderer.renderMeshPass.captureVertexArray");
        try {
            if (!(shadowPass
                    ? ChaosGpuBoneDataStorage.bindPoseForStandardShaders(mesh, bonePoseData)
                    : ChaosGpuBoneDataStorage.bindForStandardShaders(mesh, bonePoseData, EMPTY_EMISSIVE_MASK))) {
                return false;
            }
            if (ChaosGlDebug.failIfErrored("ChaosGpuShaderPackRenderer.renderMeshPass.bindForStandardShaders")) {
                return false;
            }

            TransformedMesh transformedMesh = acquireTransformedMesh(mesh, bonePoseData, worldRelMatrix, packedLight, boneLightData);
            if (transformedMesh == null) {
                return false;
            }

            RenderSystem.assertOnRenderThread();

            setupShader(shader, modelViewMatrix, shaderColorRed, shaderColorGreen, shaderColorBlue, shaderColorAlpha);
            if (ChaosGlDebug.failIfErrored("ChaosGpuShaderPackRenderer.renderMeshPass.setupShader")) {
                return false;
            }
            forceUseShaderProgram(shader);
            if (ChaosGlDebug.failIfErrored("ChaosGpuShaderPackRenderer.renderMeshPass.forceUseShaderProgram")) {
                return false;
            }
            shader.apply();
            if (ChaosGlDebug.failIfErrored("ChaosGpuShaderPackRenderer.renderMeshPass.shader.bind")) {
                return false;
            }

            if (!transformedMesh.bind(packedOverlay, renderedEntityId, renderedBlockEntityId, renderedItemId)) {
                return false;
            }
            if (ChaosGlDebug.failIfErrored("ChaosGpuShaderPackRenderer.renderMeshPass.transformedMesh.bind")) {
                return false;
            }

            GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, transformedMesh.vertexCount());
            return !ChaosGlDebug.failIfErrored("ChaosGpuShaderPackRenderer.renderMeshPass.glDrawArrays");
        } finally {
            ChaosGlDebug.restoreVertexArrayBinding(previousVertexArray, "ChaosGpuShaderPackRenderer.renderMeshPass.restoreVertexArray");
        }
    }

    public static boolean renderInstancedWorldQueuedBatch(
            ChaosGpuGeoMesh mesh,
            RenderType renderType,
            ChaosShaderRenderPhase phase,
            Object[] bonePoseData,
            Matrix4f[] modelViewMatrices,
            int[] packedLight,
            int[][] boneLightData,
            int[] packedOverlay,
            int[] renderedEntityIds,
            int[] renderedBlockEntityIds,
            int[] renderedItemIds,
            float[] shaderColor,
            int instanceCount) {
        if (instanceCount < 2
                || !ChaosGpuInstancedPoseBatchStorage.isSupported()
                || !ChaosGpuRenderRuntime.isInstancedWorldDrawSupported()) {
            return false;
        }

        int boneIndexTextureId = mesh.getBoneIndexTextureId();
        if (boneIndexTextureId < 0) {
            return false;
        }

        ShaderInstance shader = ChaosIrisShaderPackProgramCompiler.getShader(phase, renderType, true);
        if (shader == null) {
            return false;
        }

        SkinningUniforms uniforms = skinningUniforms(shader);
        if (!uniforms.supportsSkinning() || !uniforms.supportsInstancing()) {
            return false;
        }

        int[] poseBase = new int[instanceCount];
        if (!ChaosGpuInstancedPoseBatchStorage.buildLocalPoseBatch(mesh, bonePoseData, instanceCount, poseBase)) {
            return false;
        }

        BoneLightBatch boneLights = BoneLightBatch.of(boneLightData, instanceCount, mesh.getIndexedBones().size());
        float[] instanceMatrices = packWorldRelativeMatrices(modelViewMatrices, instanceCount);

        ChaosGpuInstanceDataStorage.InstanceTextures instanceTextures = ChaosGpuInstanceDataStorage.uploadForInstancedShaders(
                packedLight,
                instanceCount,
                poseBase,
                instanceCount,
                boneLights.boneLightData(),
                boneLights.boneLightCount(),
                boneLights.lightBase(),
                boneLights.lightBaseCount(),
                instanceMatrices,
                instanceCount * 16
        );
        if (instanceTextures == null) {
            return false;
        }

        int previousVertexArray = ChaosGlDebug.captureVertexArrayBinding("ChaosGpuShaderPackRenderer.renderInstancedWorldQueuedBatch.captureVertexArray");
        try {
            setupShader(shader, new Matrix4f(RenderSystem.getModelViewMatrix()),
                    shaderColor[0], shaderColor[1], shaderColor[2], shaderColor[3]);
            forceUseShaderProgram(shader);
            shader.apply();
            if (ChaosGlDebug.failIfErrored("ChaosGpuShaderPackRenderer.renderInstancedWorldQueuedBatch.shader.bind")) {
                return false;
            }

            bindTextureBufferToUnit(SKINNED_BONE_POSE_UNIT, ChaosGpuInstancedPoseBatchStorage.getPoseTextureId());
            bindTextureBufferToUnit(SKINNED_BONE_INDEX_UNIT, boneIndexTextureId);
            bindTextureBufferToUnit(SKINNED_BONE_LIGHT_UNIT, instanceTextures.boneLightTextureId());
            bindTextureBufferToUnit(SKINNED_INSTANCE_MATRIX_UNIT, instanceTextures.instanceMatrixTextureId());
            bindTextureBufferToUnit(SKINNED_INSTANCE_POSE_BASE_UNIT, instanceTextures.poseBaseTextureId());
            bindTextureBufferToUnit(SKINNED_INSTANCE_PACKED_LIGHT_UNIT, instanceTextures.packedLightTextureId());
            bindTextureBufferToUnit(SKINNED_INSTANCE_LIGHT_BASE_UNIT, instanceTextures.lightBaseTextureId());

            GL20.glUniform1i(uniforms.bonePoseSampler(), SKINNED_BONE_POSE_UNIT);
            GL20.glUniform1i(uniforms.boneIndexSampler(), SKINNED_BONE_INDEX_UNIT);
            GL20.glUniform1i(uniforms.boneDataResolved(), 0);
            if (uniforms.poseBase() != -1) {
                GL20.glUniform1i(uniforms.poseBase(), 0);
            }
            GL20.glUniform1i(uniforms.instanced(), 1);
            GL20.glUniform1i(uniforms.instanceMatrixSampler(), SKINNED_INSTANCE_MATRIX_UNIT);
            GL20.glUniform1i(uniforms.instancePoseBaseSampler(), SKINNED_INSTANCE_POSE_BASE_UNIT);
            GL20.glUniform1i(uniforms.instancePackedLightSampler(), SKINNED_INSTANCE_PACKED_LIGHT_UNIT);
            GL20.glUniform1i(uniforms.instanceLightBaseSampler(), SKINNED_INSTANCE_LIGHT_BASE_UNIT);
            GL20.glUniformMatrix4fv(uniforms.modelWorldRelMatrix(), false, new Matrix4f().get(MATRIX4_UNIFORM.get()));
            if (uniforms.boneLightSampler() != -1) {
                GL20.glUniform1i(uniforms.boneLightSampler(), SKINNED_BONE_LIGHT_UNIT);
            }
            if (uniforms.useBoneLightSampler() != -1) {
                GL20.glUniform1i(uniforms.useBoneLightSampler(), boneLights.complete() ? 1 : 0);
            }
            ChaosGpuWorldLightVolumeStorage.bindCurrentVolumeRaw(
                    packedLight[0],
                    uniforms.useWorldLightVolume(),
                    uniforms.lightVolumeBlockOrigin(),
                    uniforms.lightVolumeSize(),
                    uniforms.cameraWorldPos(),
                    uniforms.blockLightVolumeSampler(),
                    uniforms.skyLightVolumeSampler(),
                    SKINNED_BLOCK_LIGHT_VOLUME_UNIT,
                    SKINNED_SKY_LIGHT_VOLUME_UNIT
            );
            if (ChaosGlDebug.failIfErrored("ChaosGpuShaderPackRenderer.renderInstancedWorldQueuedBatch.uniforms")) {
                return false;
            }

            InstancedSourceMesh instancedMesh = INSTANCED_SOURCE_MESH_CACHE.computeIfAbsent(mesh, InstancedSourceMesh::new);
            instancedMesh.bind(packedOverlay, renderedEntityIds, renderedBlockEntityIds, renderedItemIds, instanceCount);
            GL31.glDrawArraysInstanced(GL11.GL_TRIANGLES, 0, mesh.getInstancedVertexCount(), instanceCount);
            return !ChaosGlDebug.failIfErrored("ChaosGpuShaderPackRenderer.renderInstancedWorldQueuedBatch.glDrawArraysInstanced");
        } finally {
            GL20.glUniform1i(uniforms.instanced(), 0);
            unbindTextureBufferUnit(SKINNED_BONE_POSE_UNIT);
            unbindTextureBufferUnit(SKINNED_BONE_INDEX_UNIT);
            unbindTextureBufferUnit(SKINNED_BONE_LIGHT_UNIT);
            unbindTextureBufferUnit(SKINNED_INSTANCE_MATRIX_UNIT);
            unbindTextureBufferUnit(SKINNED_INSTANCE_POSE_BASE_UNIT);
            unbindTextureBufferUnit(SKINNED_INSTANCE_PACKED_LIGHT_UNIT);
            unbindTextureBufferUnit(SKINNED_INSTANCE_LIGHT_BASE_UNIT);
            ChaosGpuWorldLightVolumeStorage.unbindSamplers(SKINNED_BLOCK_LIGHT_VOLUME_UNIT, SKINNED_SKY_LIGHT_VOLUME_UNIT);
            ChaosGlDebug.restoreVertexArrayBinding(previousVertexArray, "ChaosGpuShaderPackRenderer.renderInstancedWorldQueuedBatch.restoreVertexArray");
        }
    }

    private static float[] packWorldRelativeMatrices(Matrix4f[] modelViewMatrices, int instanceCount) {
        Matrix4f inverseView = new Matrix4f(RenderSystem.getModelViewMatrix()).invert();
        float[] matrices = new float[instanceCount * 16];
        Matrix4f worldRelative = new Matrix4f();
        for (int i = 0; i < instanceCount; i++) {
            inverseView.mul(modelViewMatrices[i], worldRelative).get(matrices, i * 16);
        }
        return matrices;
    }

    private static boolean renderSkinnedMeshPass(
            ChaosGpuGeoMesh mesh,
            Object bonePoseData,
            Matrix4f modelViewMatrix,
            Matrix4f worldRelMatrix,
            int packedLight,
            int[] boneLightData,
            int renderedEntityId,
            int renderedBlockEntityId,
            int renderedItemId,
            RenderType renderType,
            ChaosShaderRenderPhase phase,
            int packedOverlay,
            float shaderColorRed,
            float shaderColorGreen,
            float shaderColorBlue,
            float shaderColorAlpha) {
        int boneIndexTextureId = mesh.getBoneIndexTextureId();
        if (boneIndexTextureId < 0) {
            return false;
        }

        ShaderInstance shader = ChaosIrisShaderPackProgramCompiler.getShader(phase, renderType, true);
        if (shader == null) {
            return false;
        }

        SkinningUniforms uniforms = skinningUniforms(shader);
        if (!uniforms.supportsSkinning()) {
            return false;
        }

        boolean resolvedBoneBackend = ChaosGpuRenderRuntime.isResolvedBoneBackendActive();
        int bonePoseTextureId = resolvedBoneBackend
                ? ChaosGpuBoneResolveDispatcher.resolveAndBind(mesh, bonePoseData)
                : ChaosGpuAnimationPoseStorage.textureIdFor(bonePoseData);
        if (bonePoseTextureId < 0) {
            return false;
        }

        int previousVertexArray = ChaosGlDebug.captureVertexArrayBinding("ChaosGpuShaderPackRenderer.renderSkinnedMeshPass.captureVertexArray");
        try {
            setupShader(shader, modelViewMatrix, shaderColorRed, shaderColorGreen, shaderColorBlue, shaderColorAlpha);
            forceUseShaderProgram(shader);
            shader.apply();
            if (ChaosGlDebug.failIfErrored("ChaosGpuShaderPackRenderer.renderSkinnedMeshPass.shader.bind")) {
                return false;
            }

            bindTextureBufferToUnit(SKINNED_BONE_POSE_UNIT, bonePoseTextureId);
            bindTextureBufferToUnit(SKINNED_BONE_INDEX_UNIT, boneIndexTextureId);
            GL20.glUniform1i(uniforms.bonePoseSampler(), SKINNED_BONE_POSE_UNIT);
            GL20.glUniform1i(uniforms.boneIndexSampler(), SKINNED_BONE_INDEX_UNIT);
            GL20.glUniform1i(uniforms.boneDataResolved(), resolvedBoneBackend ? 1 : 0);
            if (uniforms.poseBase() != -1) {
                GL20.glUniform1i(uniforms.poseBase(), resolvedBoneBackend
                        ? 0
                        : ChaosGpuAnimationPoseStorage.poseBaseFor(bonePoseData));
            }
            GL20.glUniformMatrix4fv(uniforms.modelWorldRelMatrix(), false, worldRelMatrix.get(MATRIX4_UNIFORM.get()));

            if (uniforms.lightUv() != -1) {
                GL20.glUniform2i(uniforms.lightUv(), packedLight & 0xFFFF, packedLight >>> 16 & 0xFFFF);
            }
            if (uniforms.boneLightSampler() != -1) {
                boolean useBoneLightSampler = ChaosGpuLightDataStorage.bindBoneLights(boneLightData, SKINNED_BONE_LIGHT_UNIT);
                GL20.glUniform1i(uniforms.boneLightSampler(), SKINNED_BONE_LIGHT_UNIT);
                if (uniforms.useBoneLightSampler() != -1) {
                    GL20.glUniform1i(uniforms.useBoneLightSampler(), useBoneLightSampler ? 1 : 0);
                }
            }
            ChaosGpuWorldLightVolumeStorage.bindCurrentVolumeRaw(
                    packedLight,
                    uniforms.useWorldLightVolume(),
                    uniforms.lightVolumeBlockOrigin(),
                    uniforms.lightVolumeSize(),
                    uniforms.cameraWorldPos(),
                    uniforms.blockLightVolumeSampler(),
                    uniforms.skyLightVolumeSampler(),
                    SKINNED_BLOCK_LIGHT_VOLUME_UNIT,
                    SKINNED_SKY_LIGHT_VOLUME_UNIT
            );
            if (ChaosGlDebug.failIfErrored("ChaosGpuShaderPackRenderer.renderSkinnedMeshPass.uniforms")) {
                return false;
            }

            SourceMesh sourceMesh = SOURCE_MESH_CACHE.computeIfAbsent(mesh, SourceMesh::new);
            sourceMesh.bind(packedLight, packedOverlay, renderedEntityId, renderedBlockEntityId, renderedItemId);
            GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, mesh.getInstancedVertexCount());
            return !ChaosGlDebug.failIfErrored("ChaosGpuShaderPackRenderer.renderSkinnedMeshPass.glDrawArrays");
        } finally {
            unbindTextureBufferUnit(SKINNED_BONE_POSE_UNIT);
            unbindTextureBufferUnit(SKINNED_BONE_INDEX_UNIT);
            ChaosGpuLightDataStorage.unbindSampler(SKINNED_BONE_LIGHT_UNIT);
            ChaosGpuWorldLightVolumeStorage.unbindSamplers(SKINNED_BLOCK_LIGHT_VOLUME_UNIT, SKINNED_SKY_LIGHT_VOLUME_UNIT);
            ChaosGlDebug.restoreVertexArrayBinding(previousVertexArray, "ChaosGpuShaderPackRenderer.renderSkinnedMeshPass.restoreVertexArray");
        }
    }

    private static SkinningUniforms skinningUniforms(ShaderInstance shader) {
        return SKINNING_UNIFORM_CACHE.computeIfAbsent(shader.getId(), SkinningUniforms::of);
    }

    private static void bindTextureBufferToUnit(int textureUnit, int textureId) {
        int activeTexture = GlStateManager._getActiveTexture();
        RenderSystem.activeTexture(GL13.GL_TEXTURE0 + textureUnit);
        GL11.glBindTexture(GL31.GL_TEXTURE_BUFFER, textureId);
        GlStateManager._activeTexture(activeTexture);
    }

    private static void unbindTextureBufferUnit(int textureUnit) {
        bindTextureBufferToUnit(textureUnit, 0);
    }

    private static @Nullable TransformedMesh acquireTransformedMesh(
            ChaosGpuGeoMesh mesh, Object bonePoseData, Matrix4f worldRelMatrix, int packedLight, int[] boneLightData) {
        TransformKey key = new TransformKey(bonePoseData, packedLight, boneLightData, worldRelMatrix);
        int frameId = ChaosBlockEntityRenderFrameClock.frameId();

        MeshTransformCache cache = TRANSFORMED_MESH_CACHE.computeIfAbsent(mesh, ignored -> new MeshTransformCache());
        TransformedMesh cached = cache.get(key, frameId);
        if (cached != null) {
            return cached;
        }

        TransformedMesh transformedMesh = cache.acquire(mesh, key, frameId);
        if (!runTransformFeedback(mesh, transformedMesh, bonePoseData, worldRelMatrix, packedLight, boneLightData)) {
            cache.discard(key);
            return null;
        }

        return transformedMesh;
    }

    private static Matrix4f resolveWorldRelativeMatrix(Matrix4f modelViewMatrix) {
        return new Matrix4f(RenderSystem.getModelViewMatrix()).invert().mul(modelViewMatrix);
    }

    private static boolean runTransformFeedback(ChaosGpuGeoMesh mesh, TransformedMesh transformedMesh, Object bonePoseData, Matrix4f worldRelMatrix, int packedLight, int[] boneLightData) {
        int previousVertexArray = ChaosGlDebug.captureVertexArrayBinding("ChaosGpuShaderPackRenderer.runTransformFeedback.captureVertexArray");
        GL20.glUseProgram(transformFeedbackProgram);
        if (ChaosGlDebug.failIfErrored("ChaosGpuShaderPackRenderer.runTransformFeedback.glUseProgram")) {
            return false;
        }

        try {
            if (bonePoseSamplerUniformLocation != -1) {
                GL20.glUniform1i(bonePoseSamplerUniformLocation, ChaosGpuBoneDataStorage.BONE_TEXTURE_UNIT);
            }
            if (boneLightSamplerUniformLocation != -1) {
                GL20.glUniform1i(boneLightSamplerUniformLocation, ChaosGpuLightDataStorage.BONE_LIGHT_TEXTURE_UNIT);
            }
            if (lightUniformLocation != -1) {
                GL20.glUniform2i(lightUniformLocation, packedLight & 0xFFFF, packedLight >>> 16 & 0xFFFF);
            }
            boolean useBoneLightSampler = ChaosGpuLightDataStorage.bindBoneLights(boneLightData);
            if (useBoneLightSamplerUniformLocation != -1) {
                GL20.glUniform1i(useBoneLightSamplerUniformLocation, useBoneLightSampler ? 1 : 0);
            }
            boolean resolvedBoneBackend = ChaosGpuRenderRuntime.isResolvedBoneBackendActive();
            if (boneDataResolvedUniformLocation != -1) {
                GL20.glUniform1i(boneDataResolvedUniformLocation, resolvedBoneBackend ? 1 : 0);
            }
            if (bonePoseBaseUniformLocation != -1) {
                GL20.glUniform1i(bonePoseBaseUniformLocation, resolvedBoneBackend
                        ? 0
                        : ChaosGpuAnimationPoseStorage.poseBaseFor(bonePoseData));
            }
            if (modelWorldRelUniformLocation != -1) {
                GL20.glUniformMatrix4fv(modelWorldRelUniformLocation, false, worldRelMatrix.get(MATRIX4_UNIFORM.get()));
            }
            if (useWorldLightVolumeUniformLocation != -1) {
                ChaosGpuWorldLightVolumeStorage.bindCurrentVolumeRaw(
                        packedLight,
                        useWorldLightVolumeUniformLocation,
                        lightVolumeBlockOriginUniformLocation,
                        lightVolumeSizeUniformLocation,
                        cameraWorldPosUniformLocation,
                        blockLightVolumeSamplerUniformLocation,
                        skyLightVolumeSamplerUniformLocation
                );
            }
            if (ChaosGlDebug.failIfErrored("ChaosGpuShaderPackRenderer.runTransformFeedback.uniforms")) {
                return false;
            }

            GL11.glEnable(GL30.GL_RASTERIZER_DISCARD);
            GL30.glBindBufferBase(GL30.GL_TRANSFORM_FEEDBACK_BUFFER, 0, transformedMesh.vertexBufferId());
            mesh.bindInstancedGeometry();
            GL30.glBeginTransformFeedback(GL11.GL_TRIANGLES);
            GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, mesh.getInstancedVertexCount());
            GL30.glEndTransformFeedback();
            return !ChaosGlDebug.failIfErrored("ChaosGpuShaderPackRenderer.runTransformFeedback.draw");
        } finally {
            GL30.glBindBufferBase(GL30.GL_TRANSFORM_FEEDBACK_BUFFER, 0, 0);
            ChaosGlDebug.restoreVertexArrayBinding(previousVertexArray, "ChaosGpuShaderPackRenderer.runTransformFeedback.restoreVertexArray");
            GL11.glDisable(GL30.GL_RASTERIZER_DISCARD);
            ChaosGpuBoneDataStorage.unbindSamplers();
            ChaosGpuLightDataStorage.unbindSampler();
            ChaosGpuWorldLightVolumeStorage.unbindSamplers();
            GL20.glUseProgram(0);
            resetActiveShaderBindingState();
        }
    }

    private static void resetActiveShaderBindingState() {
        ShaderInstance shader = RenderSystem.getShader();
        if (shader != null) {
            shader.clear();
        }
    }

    private static void setupShader(
            ShaderInstance shader,
            Matrix4f modelViewMatrix,
            float shaderColorRed,
            float shaderColorGreen,
            float shaderColorBlue,
            float shaderColorAlpha
    ) {
        for (int i = 0; i < 12; i++) {
            shader.setSampler("Sampler" + i, RenderSystem.getShaderTexture(i));
        }

        if (shader.MODEL_VIEW_MATRIX != null) {
            shader.MODEL_VIEW_MATRIX.set(modelViewMatrix);
        }
        if (shader.PROJECTION_MATRIX != null) {
            shader.PROJECTION_MATRIX.set(RenderSystem.getProjectionMatrix());
        }
        ChaosViewRotation.apply(shader);
        if (shader.TEXTURE_MATRIX != null) {
            shader.TEXTURE_MATRIX.set(RenderSystem.getTextureMatrix());
        }
        if (shader.COLOR_MODULATOR != null) {
            shader.COLOR_MODULATOR.set(shaderColorRed, shaderColorGreen, shaderColorBlue, shaderColorAlpha);
        }
        RenderSystem.setupShaderLights(shader);
        if (shader.FOG_START != null) {
            shader.FOG_START.set(RenderSystem.getShaderFogStart());
        }
        if (shader.FOG_END != null) {
            shader.FOG_END.set(RenderSystem.getShaderFogEnd());
        }
        if (shader.FOG_COLOR != null) {
            shader.FOG_COLOR.set(RenderSystem.getShaderFogColor());
        }
        if (shader.FOG_SHAPE != null) {
            shader.FOG_SHAPE.set(RenderSystem.getShaderFogShape().getIndex());
        }
        if (shader.SCREEN_SIZE != null) {
            Minecraft client = Minecraft.getInstance();
            shader.SCREEN_SIZE.set(client.getWindow().getWidth(), client.getWindow().getHeight());
        }
        if (shader.GAME_TIME != null) {
            shader.GAME_TIME.set(RenderSystem.getShaderGameTime());
        }
        if (shader.LINE_WIDTH != null) {
            shader.LINE_WIDTH.set(RenderSystem.getShaderLineWidth());
        }
        if (shader.CHUNK_OFFSET != null) {
            shader.CHUNK_OFFSET.set(0.0f, 0.0f, 0.0f);
        }
    }

    private static void ensureTransformFeedbackProgram() {
        if (transformFeedbackProgram != -1) {
            return;
        }

        int vertexShader = GL20.glCreateShader(GL20.GL_VERTEX_SHADER);
        GL20.glShaderSource(vertexShader, transformFeedbackVertexShaderSource());
        GL20.glCompileShader(vertexShader);
        if (GL20.glGetShaderi(vertexShader, GL20.GL_COMPILE_STATUS) == GL11.GL_FALSE) {
            String log = GL20.glGetShaderInfoLog(vertexShader);
            GL20.glDeleteShader(vertexShader);
            throw new IllegalStateException("Failed to compile Chaos transform feedback shader: " + log);
        }

        int fragmentShader = GL20.glCreateShader(GL20.GL_FRAGMENT_SHADER);
        GL20.glShaderSource(fragmentShader, TRANSFORM_FEEDBACK_FRAGMENT_SHADER);
        GL20.glCompileShader(fragmentShader);
        if (GL20.glGetShaderi(fragmentShader, GL20.GL_COMPILE_STATUS) == GL11.GL_FALSE) {
            String log = GL20.glGetShaderInfoLog(fragmentShader);
            GL20.glDeleteShader(vertexShader);
            GL20.glDeleteShader(fragmentShader);
            throw new IllegalStateException("Failed to compile Chaos transform feedback fragment shader: " + log);
        }

        int program = GL20.glCreateProgram();
        GL20.glAttachShader(program, vertexShader);
        GL20.glAttachShader(program, fragmentShader);
        GL20.glBindAttribLocation(program, 0, "Position");
        GL20.glBindAttribLocation(program, 1, "Color");
        GL20.glBindAttribLocation(program, 2, "UV0");
        GL20.glBindAttribLocation(program, 3, "BoneIndex");
        GL20.glBindAttribLocation(program, 4, "Normal");
        GL20.glBindAttribLocation(program, 5, "MidUV");
        GL20.glBindAttribLocation(program, 6, "Tangent");
        GL30.glTransformFeedbackVaryings(
                program,
                new CharSequence[]{"TfPosition", "TfUV2Packed", "TfNormalPacked", "TfTangentPacked"},
                GL30.GL_INTERLEAVED_ATTRIBS
        );
        GL20.glLinkProgram(program);
        GL20.glDetachShader(program, vertexShader);
        GL20.glDetachShader(program, fragmentShader);
        GL20.glDeleteShader(vertexShader);
        GL20.glDeleteShader(fragmentShader);

        if (GL20.glGetProgrami(program, GL20.GL_LINK_STATUS) == GL11.GL_FALSE) {
            String log = GL20.glGetProgramInfoLog(program);
            GL20.glDeleteProgram(program);
            throw new IllegalStateException("Failed to link Chaos transform feedback program: " + log);
        }

        transformFeedbackProgram = program;
        bonePoseSamplerUniformLocation = GL20.glGetUniformLocation(program, "BonePoseSampler");
        boneLightSamplerUniformLocation = GL20.glGetUniformLocation(program, "BoneLightSampler");
        lightUniformLocation = GL20.glGetUniformLocation(program, "LightUV");
        useBoneLightSamplerUniformLocation = GL20.glGetUniformLocation(program, "UseBoneLightSampler");
        boneDataResolvedUniformLocation = GL20.glGetUniformLocation(program, "BoneDataResolved");
        bonePoseBaseUniformLocation = GL20.glGetUniformLocation(program, "BonePoseBase");
        modelWorldRelUniformLocation = GL20.glGetUniformLocation(program, "ModelWorldRelMat");
        useWorldLightVolumeUniformLocation = GL20.glGetUniformLocation(program, "UseWorldLightVolume");
        cameraWorldPosUniformLocation = GL20.glGetUniformLocation(program, "CameraWorldPos");
        lightVolumeBlockOriginUniformLocation = GL20.glGetUniformLocation(program, "LightVolumeBlockOrigin");
        lightVolumeSizeUniformLocation = GL20.glGetUniformLocation(program, "LightVolumeSize");
        blockLightVolumeSamplerUniformLocation = GL20.glGetUniformLocation(program, "BlockLightVolumeSampler");
        skyLightVolumeSamplerUniformLocation = GL20.glGetUniformLocation(program, "SkyLightVolumeSampler");
    }

    private static String transformFeedbackVertexShaderSource() {
        if (!ChaosGpuDriverInfo.isAmdAtiRadeon()) {
            return TRANSFORM_FEEDBACK_VERTEX_SHADER;
        }

        ChaosAmdRenderingSafetyMode mode = ChaosLibClientConfig.rendering().amdRenderingSafetyMode;
        return switch (mode) {
            case FORCE_DEFAULT -> TRANSFORM_FEEDBACK_VERTEX_SHADER;
            case AUTO, FORCE_AMD_SAFE -> AMD_TRANSFORM_FEEDBACK_VERTEX_SHADER;
        };
    }

    private record SkinningUniforms(
            int bonePoseSampler,
            int boneIndexSampler,
            int boneDataResolved,
            int modelWorldRelMatrix,
            int boneLightSampler,
            int useBoneLightSampler,
            int lightUv,
            int useWorldLightVolume,
            int lightVolumeBlockOrigin,
            int lightVolumeSize,
            int cameraWorldPos,
            int blockLightVolumeSampler,
            int skyLightVolumeSampler,
            int poseBase,
            int instanced,
            int instanceMatrixSampler,
            int instancePoseBaseSampler,
            int instancePackedLightSampler,
            int instanceLightBaseSampler
    ) {
        private static SkinningUniforms of(int programId) {
            return new SkinningUniforms(
                    GL20.glGetUniformLocation(programId, "chaos_BonePoseSampler"),
                    GL20.glGetUniformLocation(programId, "chaos_BoneIndexSampler"),
                    GL20.glGetUniformLocation(programId, "chaos_BoneDataResolved"),
                    GL20.glGetUniformLocation(programId, "chaos_ModelWorldRelMat"),
                    GL20.glGetUniformLocation(programId, "chaos_BoneLightSampler"),
                    GL20.glGetUniformLocation(programId, "chaos_UseBoneLightSampler"),
                    GL20.glGetUniformLocation(programId, "chaos_LightUV"),
                    GL20.glGetUniformLocation(programId, "chaos_UseWorldLightVolume"),
                    GL20.glGetUniformLocation(programId, "chaos_LightVolumeBlockOrigin"),
                    GL20.glGetUniformLocation(programId, "chaos_LightVolumeSize"),
                    GL20.glGetUniformLocation(programId, "chaos_CameraWorldPos"),
                    GL20.glGetUniformLocation(programId, "chaos_BlockLightVolumeSampler"),
                    GL20.glGetUniformLocation(programId, "chaos_SkyLightVolumeSampler"),
                    GL20.glGetUniformLocation(programId, "chaos_PoseBase"),
                    GL20.glGetUniformLocation(programId, "chaos_Instanced"),
                    GL20.glGetUniformLocation(programId, "chaos_InstanceMatrixSampler"),
                    GL20.glGetUniformLocation(programId, "chaos_InstancePoseBaseSampler"),
                    GL20.glGetUniformLocation(programId, "chaos_InstancePackedLightSampler"),
                    GL20.glGetUniformLocation(programId, "chaos_InstanceLightBaseSampler")
            );
        }

        private boolean supportsSkinning() {
            return this.bonePoseSampler != -1
                    && this.boneIndexSampler != -1
                    && this.boneDataResolved != -1
                    && this.modelWorldRelMatrix != -1;
        }

        private boolean supportsInstancing() {
            return this.instanced != -1
                    && this.instanceMatrixSampler != -1
                    && this.instancePoseBaseSampler != -1;
        }
    }

    private record BoneLightBatch(int[] boneLightData, int boneLightCount, int[] lightBase, int lightBaseCount, boolean complete) {
        private static BoneLightBatch of(int[][] boneLightData, int instanceCount, int boneCount) {
            for (int i = 0; i < instanceCount; i++) {
                if (boneLightData[i] == null || boneLightData[i].length < boneCount) {
                    return new BoneLightBatch(EMPTY_BONE_LIGHT_DATA, 1, EMPTY_BONE_LIGHT_DATA, 1, false);
                }
            }

            int[] batched = new int[instanceCount * boneCount];
            int[] lightBase = new int[instanceCount];
            for (int i = 0; i < instanceCount; i++) {
                lightBase[i] = i * boneCount;
                System.arraycopy(boneLightData[i], 0, batched, i * boneCount, boneCount);
            }
            return new BoneLightBatch(batched, batched.length, lightBase, instanceCount, true);
        }
    }

    private static final class InstancedSourceMesh implements AutoCloseable {
        private static final int INSTANCE_STRIDE = 5 * Integer.BYTES;
        private final int vertexArrayId;
        private final int instanceBufferId;

        private InstancedSourceMesh(ChaosGpuGeoMesh mesh) {
            this.vertexArrayId = GL30.glGenVertexArrays();
            this.instanceBufferId = GL15.glGenBuffers();
            GL30.glBindVertexArray(this.vertexArrayId);

            int stride = mesh.getVertexStride();
            GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, mesh.getVertexBufferId());
            configureFloatAttribute(0, 3, stride, mesh.getPositionOffset());
            configureNormalizedUnsignedByteAttribute(1, 4, stride, mesh.getColorOffset());
            configureFloatAttribute(2, 2, stride, mesh.getUv0Offset());
            configureNormalizedByteAttribute(5, 4, stride, mesh.getNormalOffset());
            configureFloatAttribute(12, 2, stride, mesh.getMidTexCoordOffset());
            configureNormalizedByteAttribute(13, 4, stride, mesh.getTangentOffset());

            GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, this.instanceBufferId);
            configureShortIntegerAttribute(3, 2, INSTANCE_STRIDE, 0);
            GL33.glVertexAttribDivisor(3, 1);
            configureIntegerAttribute(11, 3, INSTANCE_STRIDE, 2 * Integer.BYTES);
            GL33.glVertexAttribDivisor(11, 1);

            GL20.glDisableVertexAttribArray(4);
            GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, 0);
            GL30.glBindVertexArray(0);
        }

        private void bind(int[] packedOverlay, int[] entityIds, int[] blockEntityIds, int[] itemIds, int instanceCount) {
            GL30.glBindVertexArray(this.vertexArrayId);

            int[] instanceData = new int[instanceCount * 5];
            for (int i = 0; i < instanceCount; i++) {
                int base = i * 5;
                instanceData[base] = packedOverlay[i] & 0xFFFF | (packedOverlay[i] >>> 16 & 0xFFFF) << 16;
                instanceData[base + 1] = 0;
                instanceData[base + 2] = entityIds[i];
                instanceData[base + 3] = blockEntityIds[i];
                instanceData[base + 4] = itemIds[i];
            }

            GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, this.instanceBufferId);
            GL15.glBufferData(GL15.GL_ARRAY_BUFFER, instanceData, GL15.GL_DYNAMIC_DRAW);
            GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, 0);
        }

        @Override
        public void close() {
            GL15.glDeleteBuffers(this.instanceBufferId);
            GL30.glDeleteVertexArrays(this.vertexArrayId);
        }
    }

    private static final class SourceMesh implements AutoCloseable {
        private final int vertexArrayId;

        private SourceMesh(ChaosGpuGeoMesh mesh) {
            this.vertexArrayId = GL30.glGenVertexArrays();
            GL30.glBindVertexArray(this.vertexArrayId);

            int stride = mesh.getVertexStride();
            GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, mesh.getVertexBufferId());
            configureFloatAttribute(0, 3, stride, mesh.getPositionOffset());
            configureNormalizedUnsignedByteAttribute(1, 4, stride, mesh.getColorOffset());
            configureFloatAttribute(2, 2, stride, mesh.getUv0Offset());
            configureNormalizedByteAttribute(5, 4, stride, mesh.getNormalOffset());
            configureFloatAttribute(12, 2, stride, mesh.getMidTexCoordOffset());
            configureNormalizedByteAttribute(13, 4, stride, mesh.getTangentOffset());

            GL20.glDisableVertexAttribArray(3);
            GL20.glDisableVertexAttribArray(4);
            GL20.glDisableVertexAttribArray(11);

            GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, 0);
            GL30.glBindVertexArray(0);
        }

        private void bind(int packedLight, int packedOverlay, int renderedEntityId, int renderedBlockEntityId, int renderedItemId) {
            GL30.glBindVertexArray(this.vertexArrayId);
            bindConstantShort2Attribute(3, packedOverlay & 0xFFFF, packedOverlay >>> 16 & 0xFFFF);
            bindConstantShort2Attribute(4, packedLight & 0xFFFF, packedLight >>> 16 & 0xFFFF);
            bindConstantEntityInfoAttribute(11, renderedEntityId, renderedBlockEntityId, renderedItemId);
        }

        @Override
        public void close() {
            GL30.glDeleteVertexArrays(this.vertexArrayId);
        }
    }

    private static final class MeshTransformCache implements AutoCloseable {
        private final Map<TransformKey, Entry> entries = new HashMap<>();
        private final ArrayDeque<TransformKey> order = new ArrayDeque<>();

        private @Nullable TransformedMesh get(TransformKey key, int frameId) {
            Entry entry = this.entries.get(key);
            if (entry == null) {
                return null;
            }

            entry.lastUsedFrame = frameId;
            this.order.remove(key);
            this.order.addLast(key);
            return entry.transformedMesh;
        }

        private TransformedMesh acquire(ChaosGpuGeoMesh mesh, TransformKey key, int frameId) {
            TransformedMesh reused = this.entries.size() < MAX_TRANSFORMED_MESHES_PER_MESH
                    ? null
                    : this.evictIdle(frameId);
            TransformedMesh transformedMesh = reused != null ? reused : new TransformedMesh(mesh);

            this.entries.put(key, new Entry(transformedMesh, frameId));
            this.order.addLast(key);
            return transformedMesh;
        }

        private void discard(TransformKey key) {
            Entry entry = this.entries.remove(key);
            if (entry != null) {
                this.order.remove(key);
                entry.transformedMesh.close();
            }
        }

        private @Nullable TransformedMesh evictIdle(int frameId) {
            for (Iterator<TransformKey> iterator = this.order.iterator(); iterator.hasNext(); ) {
                TransformKey candidateKey = iterator.next();
                Entry candidate = this.entries.get(candidateKey);
                if (candidate == null) {
                    iterator.remove();
                    continue;
                }
                if (candidate.lastUsedFrame == frameId) {
                    continue;
                }

                iterator.remove();
                this.entries.remove(candidateKey);
                return candidate.transformedMesh;
            }

            return null;
        }

        @Override
        public void close() {
            for (Entry entry : this.entries.values()) {
                entry.transformedMesh.close();
            }
            this.entries.clear();
            this.order.clear();
        }

        private static final class Entry {
            private final TransformedMesh transformedMesh;
            private int lastUsedFrame;

            private Entry(TransformedMesh transformedMesh, int lastUsedFrame) {
                this.transformedMesh = transformedMesh;
                this.lastUsedFrame = lastUsedFrame;
            }
        }
    }

    private static final class TransformKey {
        private final Object poseHandle;
        private final float @Nullable [] poseValues;
        private final int packedLight;
        private final int @Nullable [] boneLightData;
        private final float[] worldRelMatrix;
        private final int hash;

        private TransformKey(Object bonePoseData, int packedLight, int @Nullable [] boneLightData, Matrix4f worldRelMatrix) {
            this.poseHandle = bonePoseData;
            this.poseValues = bonePoseData instanceof float[] values ? values.clone() : null;
            this.packedLight = packedLight;
            this.boneLightData = boneLightData == null ? null : boneLightData.clone();
            this.worldRelMatrix = worldRelMatrix.get(new float[16]);
            this.hash = Objects.hash(
                    this.poseValues != null ? Arrays.hashCode(this.poseValues) : System.identityHashCode(this.poseHandle),
                    this.packedLight,
                    Arrays.hashCode(this.boneLightData),
                    Arrays.hashCode(this.worldRelMatrix)
            );
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof TransformKey key) || this.hash != key.hash) {
                return false;
            }

            boolean samePose = this.poseValues != null
                    ? Arrays.equals(this.poseValues, key.poseValues)
                    : this.poseHandle == key.poseHandle;
            return samePose
                    && this.packedLight == key.packedLight
                    && Arrays.equals(this.boneLightData, key.boneLightData)
                    && Arrays.equals(this.worldRelMatrix, key.worldRelMatrix);
        }

        @Override
        public int hashCode() {
            return this.hash;
        }
    }

    private static final class TransformedMesh implements AutoCloseable {
        private final int vertexArrayId;
        private final int vertexBufferId;
        private final int vertexCount;

        private TransformedMesh(ChaosGpuGeoMesh mesh) {
            this.vertexCount = mesh.getInstancedVertexCount();
            this.vertexArrayId = GL30.glGenVertexArrays();
            this.vertexBufferId = GL15.glGenBuffers();

            GL30.glBindVertexArray(this.vertexArrayId);

            GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, this.vertexBufferId);
            GL15.glBufferData(GL15.GL_ARRAY_BUFFER, (long) this.vertexCount * TRANSFORMED_VERTEX_STRIDE, GL15.GL_DYNAMIC_DRAW);
            configureFloatAttribute(0, 3, TRANSFORMED_VERTEX_STRIDE, TRANSFORMED_POSITION_OFFSET);
            configureShortIntegerAttribute(4, 2, TRANSFORMED_VERTEX_STRIDE, TRANSFORMED_UV2_OFFSET);
            configureNormalizedByteAttribute(5, 4, TRANSFORMED_VERTEX_STRIDE, TRANSFORMED_NORMAL_OFFSET);
            configureNormalizedByteAttribute(13, 4, TRANSFORMED_VERTEX_STRIDE, TRANSFORMED_TANGENT_OFFSET);

            GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, mesh.getVertexBufferId());
            configureNormalizedUnsignedByteAttribute(1, 4, SOURCE_VERTEX_STRIDE, SOURCE_COLOR_OFFSET);
            configureFloatAttribute(2, 2, SOURCE_VERTEX_STRIDE, SOURCE_UV0_OFFSET);
            configureFloatAttribute(12, 2, SOURCE_VERTEX_STRIDE, SOURCE_MID_TEX_COORD_OFFSET);

            GL20.glDisableVertexAttribArray(3);
            GL20.glDisableVertexAttribArray(11);

            GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, 0);
            GL30.glBindVertexArray(0);
        }

        private int vertexBufferId() {
            return this.vertexBufferId;
        }

        private int vertexCount() {
            return this.vertexCount;
        }

        private boolean bind(int packedOverlay, int renderedEntityId, int renderedBlockEntityId, int renderedItemId) {
            GL30.glBindVertexArray(this.vertexArrayId);
            bindConstantShort2Attribute(3, packedOverlay & 0xFFFF, packedOverlay >>> 16 & 0xFFFF);
            bindConstantEntityInfoAttribute(11, renderedEntityId, renderedBlockEntityId, renderedItemId);
            return true;
        }

        @Override
        public void close() {
            GL15.glDeleteBuffers(this.vertexBufferId);
            GL30.glDeleteVertexArrays(this.vertexArrayId);
        }
    }

    private static void configureFloatAttribute(int location, int size, int stride, int offset) {
        if (location < 0) {
            return;
        }

        GL20.glEnableVertexAttribArray(location);
        GL20.glVertexAttribPointer(location, size, GL11.GL_FLOAT, false, stride, offset);
    }

    private static void configureNormalizedUnsignedByteAttribute(int location, int size, int stride, int offset) {
        if (location < 0) {
            return;
        }
        GL20.glEnableVertexAttribArray(location);
        GL20.glVertexAttribPointer(location, size, GL11.GL_UNSIGNED_BYTE, true, stride, offset);
    }

    private static void configureNormalizedByteAttribute(int location, int size, int stride, int offset) {
        if (location < 0) {
            return;
        }

        GL20.glEnableVertexAttribArray(location);
        GL20.glVertexAttribPointer(location, size, GL11.GL_BYTE, true, stride, offset);
    }

    private static void configureIntegerAttribute(int location, int size, int stride, int offset) {
        if (location < 0) {
            return;
        }

        GL20.glEnableVertexAttribArray(location);
        GL30.glVertexAttribIPointer(location, size, GL11.GL_INT, stride, offset);
    }

    private static void configureShortIntegerAttribute(int location, int size, int stride, int offset) {
        if (location < 0) {
            return;
        }
        GL20.glEnableVertexAttribArray(location);
        GL30.glVertexAttribIPointer(location, size, GL11.GL_SHORT, stride, offset);
    }

    private static void bindConstantShort2Attribute(int location, int x, int y) {
        if (location < 0) {
            return;
        }

        GL20.glDisableVertexAttribArray(location);
        GL30.glVertexAttribI2i(location, x, y);
    }

    private static void bindConstantEntityInfoAttribute(int location, int entityId, int blockEntityId, int itemId) {
        if (location < 0) {
            return;
        }

        GL20.glDisableVertexAttribArray(location);
        GL30.glVertexAttribI3i(location, entityId, blockEntityId, itemId);
    }

    private static boolean shouldNormalizeAnimatedTextureUv(ResourceLocation texture, Set<String> includedBones) {
        return includedBones != null && !includedBones.isEmpty() && AnimatedTextureSupport.requiresUvNormalization(texture);
    }

    private static void forceUseShaderProgram(ShaderInstance shader) {
        GL20.glUseProgram(shader.getId());
    }
}
