package dev.elifian.chaoslib.gpu.render;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.elifian.chaoslib.api.animatable.GeoAnimatable;
import dev.elifian.chaoslib.api.animation.AnimationState;
import dev.elifian.chaoslib.api.model.GeoModel;
import dev.elifian.chaoslib.cache.object.BakedGeoModel;
import dev.elifian.chaoslib.client.texture.AnimatedTextureSupport;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuAnimationPoseStorage;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuBoneDataStorage;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuInstanceDataStorage;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuLightDataStorage;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuWorldLightVolumeStorage;
import dev.elifian.chaoslib.gpu.debug.ChaosGlDebug;
import dev.elifian.chaoslib.gpu.mesh.ChaosGpuGeoMesh;
import net.minecraft.client.Minecraft;
import com.mojang.blaze3d.shaders.Uniform;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.resources.ResourceLocation;

import dev.elifian.chaoslib.platform.ClientOnly;
import org.joml.Matrix4f;

import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;

@ClientOnly
public final class ChaosGpuGeoRenderer {
    private static final Object REST_POSE_CPU_CACHE_KEY = new Object();
    private static final Map<ShaderInstance, StandardShaderBindings> STANDARD_SHADER_BINDINGS = new IdentityHashMap<>();
    private static final Map<ResourceLocation, Boolean> UV_NORMALIZATION_CACHE = new HashMap<>();

    private ChaosGpuGeoRenderer() {
    }

    public static <T extends GeoAnimatable> boolean render(
            PoseStack poseStack,
            T animatable,
            MultiBufferSource bufferSource,
            ResourceLocation texture,
            BakedGeoModel model,
            int packedLight) {
        return render(poseStack, animatable, bufferSource, RenderType.entityCutoutNoCull(texture), texture, null, model, packedLight, null, null, null, 1.0f);
    }

    public static <T extends GeoAnimatable> boolean render(
            PoseStack poseStack,
            T animatable,
            MultiBufferSource bufferSource,
            ResourceLocation texture,
            BakedGeoModel model,
            int packedLight,
            Set<String> includedBones) {
        return render(poseStack, animatable, bufferSource, RenderType.entityCutoutNoCull(texture), texture, null, model, packedLight, null, includedBones, null, 1.0f);
    }

    public static <T extends GeoAnimatable> boolean render(
            PoseStack poseStack,
            T animatable,
            GeoModel<T> geoModel,
            AnimationState<T> animationState,
            MultiBufferSource bufferSource,
            RenderType renderType,
            ResourceLocation texture,
            ResourceLocation emissiveTexture,
            BakedGeoModel model,
            int packedLight) {
        return render(poseStack, animatable, geoModel, animationState, bufferSource, renderType, texture, emissiveTexture, model, packedLight, null, null, null, 1.0f, animatable.getPoseKey());
    }

    public static <T extends GeoAnimatable> boolean render(
            PoseStack poseStack,
            T animatable,
            MultiBufferSource bufferSource,
            RenderType renderType,
            ResourceLocation texture,
            ResourceLocation emissiveTexture,
            BakedGeoModel model,
            int packedLight,
            Set<String> includedBones) {
        return render(poseStack, animatable, bufferSource, renderType, texture, emissiveTexture, model, packedLight, null, includedBones, null, 1.0f);
    }

    public static <T extends GeoAnimatable> boolean render(
            PoseStack poseStack,
            T animatable,
            MultiBufferSource bufferSource,
            RenderType renderType,
            ResourceLocation texture,
            ResourceLocation emissiveTexture,
            BakedGeoModel model,
            int packedLight,
            int[] boneLightData,
            Set<String> includedBones,
            Set<String> emissiveBones,
            float emissiveStrength) {
        return render(poseStack, animatable, bufferSource, renderType, texture, emissiveTexture, model, packedLight, boneLightData, includedBones, emissiveBones, emissiveStrength, animatable.getPoseKey());
    }

    public static <T extends GeoAnimatable> boolean render(
            PoseStack poseStack,
            T animatable,
            MultiBufferSource bufferSource,
            RenderType renderType,
            ResourceLocation texture,
            ResourceLocation emissiveTexture,
            BakedGeoModel model,
            int packedLight,
            int[] boneLightData,
            Set<String> includedBones,
            Set<String> emissiveBones,
            float emissiveStrength,
            Object poseCacheKey) {
        if (!ChaosGpuRenderRuntime.isGpuPathSupported(model)) {
            return false;
        }

        ChaosGpuGeoMesh mesh = ChaosGpuGeoMesh.getOrCreate(model, includedBones, shouldNormalizeAnimatedTextureUv(texture, includedBones));
        if (mesh.getInstancedVertexCount() <= 0) {
            return true;
        }
        ChaosGpuGeoMesh poseMesh = poseMeshForAnimation(model, mesh, includedBones);
        Object bonePoseData = ChaosGpuAnimationPoseStorage.prepareRestPoseToken(poseMesh);
        if (bonePoseData == null) {
            float[] poseData = ChaosGpuPoseDataCache.prepareBonePoseData(REST_POSE_CPU_CACHE_KEY, model, poseMesh);
            bonePoseData = ChaosGpuAnimationPoseStorage.prepareUploadedPoseToken(poseMesh, poseData, REST_POSE_CPU_CACHE_KEY, animatable);
            if (bonePoseData == null) {
                bonePoseData = poseData;
            }
        }
        float[] emissiveMaskData = ChaosGpuPoseDataCache.prepareEmissiveMaskData(mesh, emissiveBones);

        return ChaosGpuWorldRenderDispatcher.enqueue(renderType, mesh, texture, emissiveTexture, poseStack.last().pose(), packedLight, boneLightData, bonePoseData, emissiveMaskData, emissiveStrength);
    }

    private static boolean shouldNormalizeAnimatedTextureUv(ResourceLocation texture, Set<String> includedBones) {
        return includedBones != null
                && !includedBones.isEmpty()
                && UV_NORMALIZATION_CACHE.computeIfAbsent(texture, AnimatedTextureSupport::requiresUvNormalization);
    }

    public static <T extends GeoAnimatable> boolean render(
            PoseStack poseStack,
            T animatable,
            GeoModel<T> geoModel,
            AnimationState<T> animationState,
            MultiBufferSource bufferSource,
            RenderType renderType,
            ResourceLocation texture,
            ResourceLocation emissiveTexture,
            BakedGeoModel model,
            int packedLight,
            int[] boneLightData,
            Set<String> includedBones,
            Set<String> emissiveBones,
            float emissiveStrength,
            Object poseCacheKey) {
        if (!ChaosGpuRenderRuntime.isGpuPathSupported(model)) {
            return false;
        }

        ChaosGpuGeoMesh mesh = ChaosGpuGeoMesh.getOrCreate(model, includedBones, shouldNormalizeAnimatedTextureUv(texture, includedBones));
        if (mesh.getInstancedVertexCount() <= 0) {
            return true;
        }
        Object bonePoseData = geoModel.prepareGpuBonePoseData(animatable, poseMeshForAnimation(model, mesh, includedBones), animationState, poseCacheKey);
        float[] emissiveMaskData = ChaosGpuPoseDataCache.prepareEmissiveMaskData(mesh, emissiveBones);
        return ChaosGpuWorldRenderDispatcher.enqueue(
                renderType,
                mesh,
                texture,
                emissiveTexture,
                poseStack.last().pose(),
                packedLight,
                boneLightData,
                bonePoseData,
                emissiveMaskData,
                emissiveStrength
        );
    }

    public static <T extends GeoAnimatable> ChaosGpuRenderCapture renderCapture(
            PoseStack poseStack,
            T animatable,
            GeoModel<T> geoModel,
            AnimationState<T> animationState,
            MultiBufferSource bufferSource,
            RenderType renderType,
            ResourceLocation texture,
            ResourceLocation emissiveTexture,
            BakedGeoModel model,
            int packedLight,
            int[] boneLightData,
            Set<String> includedBones,
            Set<String> emissiveBones,
            float emissiveStrength,
            Object poseCacheKey) {
        if (!ChaosGpuRenderRuntime.isGpuPathSupported(model)) {
            return null;
        }

        ChaosGpuGeoMesh mesh = ChaosGpuGeoMesh.getOrCreate(model, includedBones, shouldNormalizeAnimatedTextureUv(texture, includedBones));
        if (mesh.getInstancedVertexCount() <= 0) {
            return ChaosGpuRenderCapture.empty(includedBones);
        }
        Object bonePoseData = geoModel.prepareGpuBonePoseData(animatable, poseMeshForAnimation(model, mesh, includedBones), animationState, poseCacheKey);
        return renderCapture(
                poseStack,
                renderType,
                texture,
                emissiveTexture,
                model,
                mesh,
                packedLight,
                boneLightData,
                bonePoseData,
                includedBones,
                emissiveBones,
                emissiveStrength
        );
    }

    public static boolean render(
            PoseStack poseStack,
            RenderType renderType,
            ResourceLocation texture,
            ResourceLocation emissiveTexture,
            BakedGeoModel model,
            ChaosGpuGeoMesh mesh,
            int packedLight,
            int[] boneLightData,
            Object bonePoseData,
            Set<String> emissiveBones,
            float emissiveStrength
    ) {
        return renderCapture(
                poseStack,
                renderType,
                texture,
                emissiveTexture,
                model,
                mesh,
                packedLight,
                boneLightData,
                bonePoseData,
                null,
                emissiveBones,
                emissiveStrength
        ) != null;
    }

    public static ChaosGpuRenderCapture renderCapture(
            PoseStack poseStack,
            RenderType renderType,
            ResourceLocation texture,
            ResourceLocation emissiveTexture,
            BakedGeoModel model,
            ChaosGpuGeoMesh mesh,
            int packedLight,
            int[] boneLightData,
            Object bonePoseData,
            Set<String> includedBones,
            Set<String> emissiveBones,
            float emissiveStrength
    ) {
        if (!ChaosGpuRenderRuntime.isGpuPathSupported(model)) {
            return null;
        }

        if (mesh.getInstancedVertexCount() <= 0) {
            return ChaosGpuRenderCapture.empty(includedBones);
        }
        float[] emissiveMaskData = ChaosGpuPoseDataCache.prepareEmissiveMaskData(mesh, emissiveBones);
        if (!ChaosGpuWorldRenderDispatcher.enqueue(renderType, mesh, texture, emissiveTexture, poseStack.last().pose(), packedLight, boneLightData, bonePoseData, emissiveMaskData, emissiveStrength)) {
            return null;
        }

        return new ChaosGpuRenderCapture(mesh, bonePoseData, includedBones);
    }

    private static ChaosGpuGeoMesh poseMeshForAnimation(BakedGeoModel model, ChaosGpuGeoMesh renderMesh, Set<String> includedBones) {
        return includedBones == null ? renderMesh : ChaosGpuGeoMesh.getOrCreate(model);
    }

    static boolean draw(
            ChaosGpuGeoMesh mesh,
            ResourceLocation texture,
            ResourceLocation emissiveTexture,
            Matrix4f modelViewMatrix,
            int packedLight,
            int[] boneLightData,
            Object bonePoseData,
            float[] emissiveMaskData,
            float emissiveStrength,
            Matrix4f projectionMatrix,
            ShaderInstance shader) {
        if (!prepareRenderState(shader)) {
            finishRenderState();
            return false;
        }
        int previousVertexArray = ChaosGlDebug.captureVertexArrayBinding("ChaosGpuGeoRenderer.draw.captureVertexArray");

        try {
            bindTextures(texture, emissiveTexture);
            setupFrameShaderState(shader, projectionMatrix);
            return drawPrepared(mesh, texture, emissiveTexture, modelViewMatrix, packedLight, boneLightData, bonePoseData, emissiveMaskData, emissiveStrength, projectionMatrix, shader);
        } finally {
            ChaosGlDebug.restoreVertexArrayBinding(previousVertexArray, "ChaosGpuGeoRenderer.draw.restore");
            finishRenderState();
        }
    }

    static boolean drawPrepared(
            ChaosGpuGeoMesh mesh,
            ResourceLocation texture,
            ResourceLocation emissiveTexture,
            Matrix4f modelViewMatrix,
            int packedLight,
            int[] boneLightData,
            Object bonePoseData,
            float[] emissiveMaskData,
            float emissiveStrength,
            Matrix4f projectionMatrix,
            ShaderInstance shader) {
        StandardShaderBindings bindings = standardShaderBindings(shader);
        if (!bindings.isComplete()) {
            return false;
        }

        bindings.lightUv().set(
                packedLight & 0xFFFF,
                packedLight >>> 16 & 0xFFFF
        );
        bindings.useBoneLightSampler().set(ChaosGpuLightDataStorage.bindBoneLights(boneLightData) ? 1 : 0);
        bindings.useWorldLightVolume().set(ChaosGpuWorldLightVolumeStorage.bindCurrentVolume(shader) ? 1 : 0);
        bindings.boneCount().set(mesh.getIndexedBones().size());
        boolean resolvedBoneBackend = ChaosGpuRenderRuntime.isResolvedBoneBackendActive();
        bindings.boneDataResolved().set(resolvedBoneBackend ? 1 : 0);
        if (bindings.bonePoseBase() != null) {
            bindings.bonePoseBase().set(resolvedBoneBackend ? 0 : ChaosGpuAnimationPoseStorage.poseBaseFor(bonePoseData));
        }
        bindings.emissiveEnabled().set(emissiveTexture != null ? 1 : 0);
        bindings.emissiveStrength().set(emissiveStrength);
        setupModelViewUniform(shader, modelViewMatrix);
        shader.apply();
        mesh.bindGeometry();
        if (!ChaosGpuBoneDataStorage.bindForStandardShaders(mesh, bonePoseData, emissiveMaskData)) {
            return false;
        }
        mesh.drawGeometry();
        return !ChaosGlDebug.failIfErrored("ChaosGpuGeoRenderer.drawPrepared");
    }

    static void setupFrameShaderState(ShaderInstance shader, Matrix4f projectionMatrix) {
        for (int i = 0; i < 12; i++) {
            shader.setSampler("Sampler" + i, RenderSystem.getShaderTexture(i));
        }

        if (shader.PROJECTION_MATRIX != null) {
            shader.PROJECTION_MATRIX.set(projectionMatrix);
        }
        ChaosViewRotation.apply(shader);
        if (shader.TEXTURE_MATRIX != null) {
            shader.TEXTURE_MATRIX.set(RenderSystem.getTextureMatrix());
        }
        if (shader.COLOR_MODULATOR != null) {
            shader.COLOR_MODULATOR.set(RenderSystem.getShaderColor());
        }
        if (shader.FOG_START != null) {
            shader.FOG_START.set(RenderSystem.getShaderFogStart());
        }
        if (shader.FOG_END != null) {
            shader.FOG_END.set(RenderSystem.getShaderFogEnd());
        }
        if (shader.FOG_COLOR != null) {
            shader.FOG_COLOR.set(RenderSystem.getShaderFogColor());
        }
        if (shader.FOG_SHAPE != null) {
            shader.FOG_SHAPE.set(RenderSystem.getShaderFogShape().getIndex());
        }
        if (shader.SCREEN_SIZE != null) {
            Minecraft client = Minecraft.getInstance();
            shader.SCREEN_SIZE.set(client.getWindow().getWidth(), client.getWindow().getHeight());
        }
        if (shader.GAME_TIME != null) {
            shader.GAME_TIME.set(RenderSystem.getShaderGameTime());
        }
        RenderSystem.setupShaderLights(shader);
    }

    private static void setupModelViewUniform(ShaderInstance shader, Matrix4f modelViewMatrix) {
        if (shader.MODEL_VIEW_MATRIX != null) {
            shader.MODEL_VIEW_MATRIX.set(modelViewMatrix);
        }
    }

    static boolean prepareRenderState(ShaderInstance shader) {
        RenderSystem.setShader(() -> shader);
        shader.apply();
        Minecraft.getInstance().gameRenderer.lightTexture().turnOnLightLayer();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);
        RenderSystem.disableCull();
        RenderSystem.disableBlend();
        return !ChaosGlDebug.failIfErrored("ChaosGpuGeoRenderer.prepareRenderState");
    }

    static void bindTextures(ResourceLocation texture, ResourceLocation emissiveTexture) {
        RenderSystem.setShaderTexture(0, texture);
        RenderSystem.setShaderTexture(1, emissiveTexture != null ? emissiveTexture : texture);
    }

    static void finishRenderState() {
        ChaosGpuBoneDataStorage.unbindSamplers();
        ChaosGpuLightDataStorage.unbindSampler();
        ChaosGpuInstanceDataStorage.unbindSamplers();
        ChaosGpuWorldLightVolumeStorage.unbindSamplers();
        ShaderInstance activeShader = RenderSystem.getShader();
        if (activeShader != null) {
            activeShader.clear();
            ChaosGlDebug.check("ChaosGpuGeoRenderer.finishRenderState.shader.unbind");
        }
        Minecraft.getInstance().gameRenderer.lightTexture().turnOffLightLayer();
    }

    private static StandardShaderBindings standardShaderBindings(ShaderInstance shader) {
        StandardShaderBindings bindings = STANDARD_SHADER_BINDINGS.get(shader);
        if (bindings != null) {
            return bindings;
        }

        bindings = new StandardShaderBindings(
                shader.getUniform("LightUV"),
                shader.getUniform("UseBoneLightSampler"),
                shader.getUniform("UseWorldLightVolume"),
                shader.getUniform("BoneCount"),
                shader.getUniform("BoneDataResolved"),
                shader.getUniform("BonePoseBase"),
                shader.getUniform("UseEmissiveLayer"),
                shader.getUniform("EmissiveStrength")
        );
        STANDARD_SHADER_BINDINGS.put(shader, bindings);
        return bindings;
    }

    private record StandardShaderBindings(
            Uniform lightUv,
            Uniform useBoneLightSampler,
            Uniform useWorldLightVolume,
            Uniform boneCount,
            Uniform boneDataResolved,
            Uniform bonePoseBase,
            Uniform emissiveEnabled,
            Uniform emissiveStrength) {
        private boolean isComplete() {
            return this.lightUv != null
                    && this.useBoneLightSampler != null
                    && this.useWorldLightVolume != null
                    && this.boneCount != null
                    && this.boneDataResolved != null
                    && this.emissiveEnabled != null
                    && this.emissiveStrength != null;
        }
    }

}
