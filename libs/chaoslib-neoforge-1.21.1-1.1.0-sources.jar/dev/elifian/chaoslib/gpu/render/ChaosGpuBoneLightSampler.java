package dev.elifian.chaoslib.gpu.render;

import dev.elifian.chaoslib.cache.object.GeoBone;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuBoneResolveDispatcher;
import dev.elifian.chaoslib.gpu.mesh.ChaosGpuGeoMesh;
import net.minecraft.world.phys.Vec3;

import dev.elifian.chaoslib.platform.ClientOnly;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@ClientOnly
public final class ChaosGpuBoneLightSampler {
    private static final int[] EMPTY_LIGHTS = new int[0];
    private static final Map<Integer, int[]> FULL_BRIGHT_CACHE = new ConcurrentHashMap<>();

    private ChaosGpuBoneLightSampler() {
    }

    @FunctionalInterface
    public interface PackedLightResolver {
        int resolve(float worldX, float worldY, float worldZ);
    }

    public static int[] fullBright(int boneCount) {
        if (boneCount <= 0) {
            return EMPTY_LIGHTS;
        }

        return FULL_BRIGHT_CACHE.computeIfAbsent(boneCount, ignored -> {
            int[] fullBright = new int[boneCount];
            java.util.Arrays.fill(fullBright, net.minecraft.client.renderer.LightTexture.FULL_BRIGHT);
            return fullBright;
        });
    }

    public static int[] sampleBlockEntityBoneLights(
            ChaosGpuGeoMesh mesh,
            Object bonePoseData,
            Matrix4f rootTransform,
            Vec3 worldOffset,
            int minimumPackedLight,
            PackedLightResolver resolver
    ) {
        float[] resolvedMatrices = resolveBoneMatrices(mesh, bonePoseData);
        if (resolvedMatrices == null) {
            return null;
        }

        int boneCount = mesh.getIndexedBones().size();
        if (boneCount <= 0) {
            return EMPTY_LIGHTS;
        }

        int[] packedLights = new int[boneCount];
        Matrix4f resolvedMatrix = new Matrix4f();
        Matrix4f worldMatrix = new Matrix4f();
        Vector3f position = new Vector3f();
        for (int boneIndex = 0; boneIndex < boneCount; boneIndex++) {
            int base = boneIndex * 16;
            GeoBone bone = mesh.getIndexedBones().get(boneIndex);
            resolvedMatrix.set(resolvedMatrices, base);
            worldMatrix.set(rootTransform)
                    .mul(resolvedMatrix)
                    .translate((float) worldOffset.x, (float) worldOffset.y, (float) worldOffset.z);
            worldMatrix.transformPosition(bone.getPivotX() / 16.0f, bone.getPivotY() / 16.0f, bone.getPivotZ() / 16.0f, position);
            packedLights[boneIndex] = maxPackedLight(minimumPackedLight, resolver.resolve(position.x, position.y, position.z));
        }

        return packedLights;
    }

    public static int[] sampleEntityBoneLights(
            ChaosGpuGeoMesh mesh,
            Object bonePoseData,
            Matrix4f rootTransform,
            Matrix4f entityRenderTranslations,
            double entityX,
            double entityY,
            double entityZ,
            int minimumPackedLight,
            PackedLightResolver resolver
    ) {
        float[] resolvedMatrices = resolveBoneMatrices(mesh, bonePoseData);
        if (resolvedMatrices == null) {
            return null;
        }

        int boneCount = mesh.getIndexedBones().size();
        if (boneCount <= 0) {
            return EMPTY_LIGHTS;
        }

        int[] packedLights = new int[boneCount];
        Matrix4f entityInverse = new Matrix4f(entityRenderTranslations).invert();
        Matrix4f entityTranslation = new Matrix4f().translation((float) entityX, (float) entityY, (float) entityZ);
        Matrix4f resolvedMatrix = new Matrix4f();
        Matrix4f poseState = new Matrix4f();
        Matrix4f localMatrix = new Matrix4f();
        Matrix4f worldMatrix = new Matrix4f();
        Vector3f position = new Vector3f();
        for (int boneIndex = 0; boneIndex < boneCount; boneIndex++) {
            int base = boneIndex * 16;
            GeoBone bone = mesh.getIndexedBones().get(boneIndex);
            resolvedMatrix.set(resolvedMatrices, base);
            poseState.set(rootTransform).mul(resolvedMatrix);
            localMatrix.set(entityInverse).mul(poseState);
            worldMatrix.set(entityTranslation).mul(localMatrix);
            worldMatrix.transformPosition(bone.getPivotX() / 16.0f, bone.getPivotY() / 16.0f, bone.getPivotZ() / 16.0f, position);
            packedLights[boneIndex] = maxPackedLight(minimumPackedLight, resolver.resolve(position.x, position.y, position.z));
        }

        return packedLights;
    }

    private static float[] resolveBoneMatrices(ChaosGpuGeoMesh mesh, Object bonePoseData) {
        if (bonePoseData == null) {
            return null;
        }

        if (bonePoseData instanceof float[] localPoseData) {
            return resolveLocalPoseData(mesh, localPoseData);
        }

        return ChaosGpuBoneResolveDispatcher.resolveAndRead(mesh, bonePoseData);
    }

    private static float[] resolveLocalPoseData(ChaosGpuGeoMesh mesh, float[] localPoseData) {
        int boneCount = mesh.getIndexedBones().size();
        if (boneCount <= 0 || localPoseData.length < boneCount * 16) {
            return null;
        }

        float[] resolvedMatrices = new float[boneCount * 16];
        Matrix4f localMatrix = new Matrix4f();
        Matrix4f parentMatrix = new Matrix4f();
        Matrix4f resolvedMatrix = new Matrix4f();
        for (int boneIndex = 0; boneIndex < boneCount; boneIndex++) {
            int base = boneIndex * 16;
            buildLocalMatrix(localMatrix, localPoseData, base);
            int parentIndex = mesh.getParentIndex(boneIndex);
            if (parentIndex >= 0) {
                parentMatrix.set(resolvedMatrices, parentIndex * 16);
                resolvedMatrix.set(parentMatrix).mul(localMatrix);
            } else {
                resolvedMatrix.set(localMatrix);
            }
            resolvedMatrix.get(resolvedMatrices, base);
        }

        return resolvedMatrices;
    }

    private static void buildLocalMatrix(Matrix4f target, float[] localPoseData, int base) {
        float positionX = localPoseData[base] / 16.0f;
        float positionY = localPoseData[base + 1] / 16.0f;
        float positionZ = localPoseData[base + 2] / 16.0f;
        float pivotX = localPoseData[base + 4] / 16.0f;
        float pivotY = localPoseData[base + 5] / 16.0f;
        float pivotZ = localPoseData[base + 6] / 16.0f;
        float rotationX = localPoseData[base + 8];
        float rotationY = localPoseData[base + 9];
        float rotationZ = localPoseData[base + 10];
        float scaleX = localPoseData[base + 12];
        float scaleY = localPoseData[base + 13];
        float scaleZ = localPoseData[base + 14];

        target.identity()
                .translate(-positionX, positionY, positionZ)
                .translate(pivotX, pivotY, pivotZ)
                .rotateZ(rotationZ)
                .rotateY(rotationY)
                .rotateX(rotationX)
                .scale(scaleX, scaleY, scaleZ)
                .translate(-pivotX, -pivotY, -pivotZ);
    }

    private static int maxPackedLight(int left, int right) {
        int block = Math.max(left & 0xFFFF, right & 0xFFFF);
        int sky = Math.max((left >>> 16) & 0xFFFF, (right >>> 16) & 0xFFFF);
        return block | (sky << 16);
    }
}
