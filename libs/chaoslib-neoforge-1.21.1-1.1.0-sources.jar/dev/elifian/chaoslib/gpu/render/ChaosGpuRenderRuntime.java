package dev.elifian.chaoslib.gpu.render;

import dev.elifian.chaoslib.cache.object.BakedGeoModel;
import dev.elifian.chaoslib.compat.iris.IrisCompatInternal;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuBoneDataStorage;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuBoneResolveDispatcher;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuRuntimePolicy;
import dev.elifian.chaoslib.api.model.GeoModel;

import dev.elifian.chaoslib.platform.ClientOnly;
import dev.elifian.chaoslib.platform.render.ChaosWorldRenderStage;

@ClientOnly
public final class ChaosGpuRenderRuntime {
    private ChaosGpuRenderRuntime() {
    }

    public static boolean isGpuPathSupported(BakedGeoModel model) {
        return model.properties().gpuPipeline() && isGpuPathSupported();
    }

    public static boolean isGpuPathSupported() {
        return ChaosGpuBoneDataStorage.isSupported()
                && ChaosGpuRuntimePolicy.isCoreGpuShaderSupported()
                && (!IrisCompatInternal.isIrisShaderPackActive() || ChaosGpuRuntimePolicy.isShaderPackTransformFeedbackSupported());
    }

    public static boolean isResolvedBoneBackendActive() {
        return ChaosGpuBoneResolveDispatcher.usesResolvedBackend();
    }

    public static boolean isInstancedWorldDrawSupported() {
        return ChaosGpuBoneDataStorage.isInstancingSupported();
    }

    public static boolean isShaderPackPipelineActive() {
        return IrisCompatInternal.isIrisShaderPackActive() && ChaosGpuRuntimePolicy.isShaderPackTransformFeedbackSupported();
    }

    public static boolean shouldFlushWorldStage(ChaosWorldRenderStage stage) {
        return stage == ChaosWorldRenderStage.AFTER_BLOCK_ENTITIES;
    }

    public static void clearFrameCaches() {
        ChaosGpuPoseDataCache.clear();
        GeoModel.clearPoseCache();
    }
}
