package dev.elifian.chaoslib.gpu.render;

import dev.elifian.chaoslib.gpu.mesh.ChaosGpuGeoMesh;

import dev.elifian.chaoslib.platform.ClientOnly;
import org.jetbrains.annotations.Nullable;

import java.util.Set;

@ClientOnly
public record ChaosGpuRenderCapture(
        @Nullable ChaosGpuGeoMesh mesh,
        @Nullable Object bonePoseData,
        @Nullable Set<String> includedBones
) {
    public ChaosGpuRenderCapture {
        includedBones = includedBones == null ? null : Set.copyOf(includedBones);
    }

    public static ChaosGpuRenderCapture empty(@Nullable Set<String> includedBones) {
        return new ChaosGpuRenderCapture(null, null, includedBones);
    }

    public boolean canResolve(Set<String> boneNames) {
        return this.mesh != null
                && this.bonePoseData != null
                && (this.includedBones == null || this.includedBones.containsAll(boneNames));
    }
}
