package dev.elifian.chaoslib.platform;

import dev.elifian.chaoslib.platform.services.ClientLifecycleHelper;
import dev.elifian.chaoslib.platform.services.ModelDiscoveryHelper;
import dev.elifian.chaoslib.platform.services.RegistrationHelper;
import dev.elifian.chaoslib.platform.services.NetworkHelper;
import dev.elifian.chaoslib.platform.services.PlatformHelper;
import dev.elifian.chaoslib.platform.services.RenderEventHelper;
import dev.elifian.chaoslib.platform.services.StaticModelHelper;

import java.util.ServiceLoader;

/**
 * Entry point for platform services. Each loader ships an implementation registered
 * via {@code META-INF/services}; common code reaches them through the constants here.
 */
public final class Services {
    public static final PlatformHelper PLATFORM = load(PlatformHelper.class);
    public static final NetworkHelper NETWORK = load(NetworkHelper.class);
    public static final RenderEventHelper RENDER_EVENTS = load(RenderEventHelper.class);
    public static final ModelDiscoveryHelper MODEL_DISCOVERY = load(ModelDiscoveryHelper.class);
    public static final StaticModelHelper STATIC_MODELS = load(StaticModelHelper.class);
    public static final RegistrationHelper REGISTRATION = load(RegistrationHelper.class);
    public static final ClientLifecycleHelper CLIENT_LIFECYCLE = load(ClientLifecycleHelper.class);

    private Services() {
    }

    public static <T> T load(Class<T> serviceClass) {
        return ServiceLoader.load(serviceClass)
                .findFirst()
                .orElseThrow(() -> new IllegalStateException(
                        "No ChaosLib platform implementation found for " + serviceClass.getName()));
    }
}
