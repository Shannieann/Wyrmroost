package dev.elifian.chaoslib.platform.registry;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Creates a block entity. Vanilla's own equivalent is not accessible outside its package, and each
 * loader builds the block entity type its own way.
 */
@FunctionalInterface
public interface ChaosBlockEntityFactory<T extends BlockEntity> {
    T create(BlockPos pos, BlockState state);
}
