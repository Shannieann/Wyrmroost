package dev.elifian.chaoslib.platform;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Marks a type or member as client-only, replacing the platform-specific
 * {@code net.neoforged.api.distmarker.OnlyIn} / {@code net.fabricmc.api.Environment}
 * markers so common code stays free of loader imports.
 *
 * <p>This is an informational marker: ChaosLib guards side separation through its
 * dist-gated initialization and the {@code client}/{@code mixins} split in the mixin
 * configs, not through loader-level class stripping.</p>
 */
@Retention(RetentionPolicy.CLASS)
@Target({ElementType.TYPE, ElementType.METHOD, ElementType.FIELD, ElementType.CONSTRUCTOR})
public @interface ClientOnly {
}
