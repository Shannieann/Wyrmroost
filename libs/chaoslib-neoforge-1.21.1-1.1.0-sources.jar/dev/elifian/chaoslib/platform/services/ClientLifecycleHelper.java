package dev.elifian.chaoslib.platform.services;

import dev.elifian.chaoslib.platform.render.ChaosShaderRegistry;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.server.packs.resources.ResourceManager;

import java.util.function.BiConsumer;
import java.util.function.Consumer;

/**
 * Client-side hooks whose timing the loader owns: core shader registration, resource reloads and
 * the debug overlay layer.
 */
public interface ClientLifecycleHelper {
    void onRegisterShaders(Consumer<ChaosShaderRegistry> callback);

    void onClientResourceReload(Consumer<ResourceManager> callback);

    void registerDebugOverlay(BiConsumer<GuiGraphics, DeltaTracker> renderer);
}
