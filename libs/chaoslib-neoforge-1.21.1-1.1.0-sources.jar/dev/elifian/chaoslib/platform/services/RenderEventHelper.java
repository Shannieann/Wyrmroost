package dev.elifian.chaoslib.platform.services;

import dev.elifian.chaoslib.platform.render.ChaosWorldRenderStageListener;

/**
 * Hooks common render code into the loader's world render pipeline.
 */
public interface RenderEventHelper {
    void registerWorldRenderStageListener(ChaosWorldRenderStageListener listener);
}
