package dev.elifian.chaoslib.platform.services;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.elifian.chaoslib.api.animatable.GeoBlockEntity;
import dev.elifian.chaoslib.model.baked.StaticGeoBakedModel;
import dev.elifian.chaoslib.platform.render.GeoFrozenRenderSupport;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Static baked-model support. NeoForge bakes geo models into chunk meshes through its
 * geometry loader; Fabric has no equivalent yet, so it supplies no-op implementations
 * and block entities always render through the live geo path.
 */
public interface StaticModelHelper {
    <T extends BlockEntity & GeoBlockEntity> GeoFrozenRenderSupport<T> createFrozenRenderSupport();

    /**
     * Drops every cache that holds baked static geometry (config change, resource reload).
     */
    void clearStaticRenderCaches();

    /**
     * Asks the chunk mesher to re-read the block entity's static model data. No-op where
     * static baking is unavailable.
     */
    void requestModelDataUpdate(BlockEntity blockEntity);


    /**
     * Wraps a baked static geo model in whatever the loader's chunk mesher expects, so the
     * per-block-entity render state reaches it.
     */
    BakedModel wrapStaticModel(StaticGeoBakedModel model);

    /**
     * Draws a baked static model directly, once per render layer it uses.
     */
    void renderStaticModel(PoseStack poseStack, MultiBufferSource bufferSource, BlockState state,
                           BakedModel model, RandomSource random, int packedLight, int packedOverlay);
}
