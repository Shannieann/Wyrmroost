package dev.elifian.chaoslib.platform.services;

import dev.elifian.chaoslib.platform.registry.ChaosBlockEntityFactory;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;

import java.util.function.Supplier;

/**
 * Registers content and its renderers. Shared code decides what is registered; each loader only
 * knows how. Registration may be deferred -- NeoForge does not accept entries until its own event
 * fires -- so everything is handed back as a {@link Supplier}.
 */
public interface RegistrationHelper {
    <T extends Entity> Supplier<EntityType<T>> registerEntityType(ResourceLocation id, Supplier<EntityType<T>> type);

    <T extends Block> Supplier<T> registerBlock(ResourceLocation id, Supplier<T> block);

    <T extends Item> Supplier<T> registerItem(ResourceLocation id, Supplier<T> item);

    <T extends BlockEntity> Supplier<BlockEntityType<T>> registerBlockEntityType(
            ResourceLocation id, ChaosBlockEntityFactory<T> factory, Supplier<Block> block);

    <T extends LivingEntity> void registerAttributes(Supplier<EntityType<T>> type, Supplier<AttributeSupplier> attributes);

    <T extends Entity> void registerEntityRenderer(Supplier<EntityType<T>> type, EntityRendererProvider<T> renderer);

    <T extends BlockEntity> void registerBlockEntityRenderer(Supplier<BlockEntityType<T>> type, BlockEntityRendererProvider<T> renderer);
}
