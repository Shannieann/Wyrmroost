package dev.elifian.chaoslib.platform.services;

import java.nio.file.Path;

/**
 * Cross-cutting platform queries that differ between NeoForge and Fabric.
 * Registration, networking and render-stage hooks have their own services.
 */
public interface PlatformHelper {
    String platformName();

    boolean isModLoaded(String modId);

    boolean isClient();

    boolean isDevelopmentEnvironment();

    Path configDirectory();
}
