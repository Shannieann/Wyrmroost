package dev.elifian.chaoslib.platform.services;

import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerPlayer;

import java.util.function.BiConsumer;

/**
 * Packet transport. The payloads are vanilla {@link CustomPacketPayload}s; only registering and
 * sending them differs between loaders. Handlers are always called on the server thread.
 */
public interface NetworkHelper {
    <T extends CustomPacketPayload> void registerServerbound(
            CustomPacketPayload.Type<T> type,
            StreamCodec<FriendlyByteBuf, T> codec,
            BiConsumer<T, ServerPlayer> handler);

    void sendToServer(CustomPacketPayload payload);
}
