package dev.elifian.chaoslib.platform.services;

import java.nio.file.Path;
import java.util.List;

/**
 * Where GeoModel classes may live. NeoForge already knows the answer from its scan data; Fabric has
 * none, and hands back the paths to walk instead. Scanning itself is shared.
 */
public interface ModelDiscoveryHelper {
    /**
     * The binary names of every direct GeoModel subclass, or an empty list when the loader cannot
     * answer and {@link #classScanRoots()} should be walked instead.
     */
    List<String> knownGeoModelClassNames();

    /**
     * Roots to scan for GeoModel classes when the loader has no scan data of its own.
     */
    List<Path> classScanRoots();
}
