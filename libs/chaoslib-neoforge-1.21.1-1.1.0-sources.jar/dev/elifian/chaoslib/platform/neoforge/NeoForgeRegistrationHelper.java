package dev.elifian.chaoslib.platform.neoforge;

import dev.elifian.chaoslib.ChaosLib;
import dev.elifian.chaoslib.platform.registry.ChaosBlockEntityFactory;
import dev.elifian.chaoslib.platform.services.RegistrationHelper;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.loading.FMLEnvironment;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public final class NeoForgeRegistrationHelper implements RegistrationHelper {
    private static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(Registries.ENTITY_TYPE, ChaosLib.MOD_ID);
    private static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(Registries.BLOCK, ChaosLib.MOD_ID);
    private static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(Registries.ITEM, ChaosLib.MOD_ID);
    private static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, ChaosLib.MOD_ID);

    private static final List<Runnable> ATTRIBUTE_REGISTRATIONS = new ArrayList<>();
    private static final List<Runnable> RENDERER_REGISTRATIONS = new ArrayList<>();
    private static EntityAttributeCreationEvent attributeEvent;
    private static EntityRenderersEvent.RegisterRenderers rendererEvent;

    public static void bind(IEventBus modEventBus) {
        ENTITY_TYPES.register(modEventBus);
        BLOCKS.register(modEventBus);
        ITEMS.register(modEventBus);
        BLOCK_ENTITIES.register(modEventBus);

        modEventBus.addListener(EntityAttributeCreationEvent.class, event -> {
            attributeEvent = event;
            ATTRIBUTE_REGISTRATIONS.forEach(Runnable::run);
        });

        if (FMLEnvironment.dist == Dist.CLIENT) {
            modEventBus.addListener(EntityRenderersEvent.RegisterRenderers.class, event -> {
                rendererEvent = event;
                RENDERER_REGISTRATIONS.forEach(Runnable::run);
            });
        }
    }

    @Override
    public <T extends Entity> Supplier<EntityType<T>> registerEntityType(ResourceLocation id, Supplier<EntityType<T>> type) {
        return ENTITY_TYPES.register(id.getPath(), type::get)::get;
    }

    @Override
    public <T extends Block> Supplier<T> registerBlock(ResourceLocation id, Supplier<T> block) {
        return BLOCKS.register(id.getPath(), block::get)::get;
    }

    @Override
    public <T extends Item> Supplier<T> registerItem(ResourceLocation id, Supplier<T> item) {
        return ITEMS.register(id.getPath(), item::get)::get;
    }

    @Override
    public <T extends BlockEntity> Supplier<BlockEntityType<T>> registerBlockEntityType(
            ResourceLocation id, ChaosBlockEntityFactory<T> factory, Supplier<Block> block) {
        return BLOCK_ENTITIES.register(id.getPath(),
                () -> BlockEntityType.Builder.of(factory::create, block.get()).build(null))::get;
    }

    @Override
    public <T extends LivingEntity> void registerAttributes(Supplier<EntityType<T>> type, Supplier<AttributeSupplier> attributes) {
        ATTRIBUTE_REGISTRATIONS.add(() -> attributeEvent.put(type.get(), attributes.get()));
    }

    @Override
    public <T extends Entity> void registerEntityRenderer(Supplier<EntityType<T>> type, EntityRendererProvider<T> renderer) {
        RENDERER_REGISTRATIONS.add(() -> rendererEvent.registerEntityRenderer(type.get(), renderer));
    }

    @Override
    public <T extends BlockEntity> void registerBlockEntityRenderer(Supplier<BlockEntityType<T>> type, BlockEntityRendererProvider<T> renderer) {
        RENDERER_REGISTRATIONS.add(() -> rendererEvent.registerBlockEntityRenderer(type.get(), renderer));
    }
}
