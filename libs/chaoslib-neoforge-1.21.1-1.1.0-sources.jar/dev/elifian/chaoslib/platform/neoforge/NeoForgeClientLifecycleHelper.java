package dev.elifian.chaoslib.platform.neoforge;

import dev.elifian.chaoslib.ChaosLib;
import dev.elifian.chaoslib.platform.neoforge.model.NeoForgeStaticGeoGeometryLoader;
import dev.elifian.chaoslib.platform.render.ChaosShaderRegistry;
import dev.elifian.chaoslib.platform.services.ClientLifecycleHelper;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.ResourceManagerReloadListener;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.client.event.ModelEvent;
import net.neoforged.neoforge.client.event.RegisterClientReloadListenersEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RegisterShadersEvent;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

public final class NeoForgeClientLifecycleHelper implements ClientLifecycleHelper {
    private static final List<Consumer<ChaosShaderRegistry>> SHADER_CALLBACKS = new ArrayList<>();
    private static final List<Consumer<ResourceManager>> RELOAD_CALLBACKS = new ArrayList<>();
    private static final List<BiConsumer<GuiGraphics, DeltaTracker>> OVERLAYS = new ArrayList<>();

    public static void bind(IEventBus modEventBus) {
        modEventBus.addListener(RegisterShadersEvent.class, event -> {
            ChaosShaderRegistry registry = (id, vertexFormat, onLoaded) -> {
                try {
                    event.registerShader(new ShaderInstance(event.getResourceProvider(), id, vertexFormat), onLoaded::accept);
                } catch (IOException exception) {
                    throw new IllegalStateException("Failed to register ChaosLib shader " + id, exception);
                }
            };

            SHADER_CALLBACKS.forEach(callback -> callback.accept(registry));
        });

        modEventBus.addListener(ModelEvent.RegisterGeometryLoaders.class, event ->
                event.register(ChaosLib.id("geo_model"), NeoForgeStaticGeoGeometryLoader.INSTANCE));

        modEventBus.addListener(RegisterClientReloadListenersEvent.class, event ->
                event.registerReloadListener((ResourceManagerReloadListener) resourceManager ->
                        RELOAD_CALLBACKS.forEach(callback -> callback.accept(resourceManager))));

        modEventBus.addListener(RegisterGuiLayersEvent.class, event -> {
            for (BiConsumer<GuiGraphics, DeltaTracker> overlay : OVERLAYS) {
                event.registerAbove(VanillaGuiLayers.DEBUG_OVERLAY, ChaosLib.id("debug_overlay"), overlay::accept);
            }
        });
    }

    @Override
    public void onRegisterShaders(Consumer<ChaosShaderRegistry> callback) {
        SHADER_CALLBACKS.add(callback);
    }

    @Override
    public void onClientResourceReload(Consumer<ResourceManager> callback) {
        RELOAD_CALLBACKS.add(callback);
    }

    @Override
    public void registerDebugOverlay(BiConsumer<GuiGraphics, DeltaTracker> renderer) {
        OVERLAYS.add(renderer);
    }
}
