package dev.elifian.chaoslib.platform.neoforge;

import dev.elifian.chaoslib.platform.render.ChaosWorldRenderStage;
import dev.elifian.chaoslib.platform.render.ChaosWorldRenderStageDispatcher;
import dev.elifian.chaoslib.platform.render.ChaosWorldRenderStageListener;
import dev.elifian.chaoslib.platform.services.RenderEventHelper;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import net.neoforged.neoforge.common.NeoForge;
import org.jetbrains.annotations.Nullable;

public final class NeoForgeRenderEventHelper implements RenderEventHelper {
    private static boolean hooked;

    @Override
    public void registerWorldRenderStageListener(ChaosWorldRenderStageListener listener) {
        ChaosWorldRenderStageDispatcher.addListener(listener);
        hook();
    }

    private static void hook() {
        if (hooked) {
            return;
        }

        hooked = true;
        NeoForge.EVENT_BUS.addListener(RenderLevelStageEvent.class, event -> {
            ChaosWorldRenderStage stage = translate(event.getStage());
            if (stage == null) {
                return;
            }

            ChaosWorldRenderStageDispatcher.dispatch(
                    stage,
                    event.getProjectionMatrix(),
                    event.getPoseStack(),
                    event.getCamera(),
                    event.getFrustum(),
                    event.getPartialTick().getGameTimeDeltaPartialTick(false)
            );
        });
    }

    @Nullable
    private static ChaosWorldRenderStage translate(RenderLevelStageEvent.Stage stage) {
        if (stage == RenderLevelStageEvent.Stage.AFTER_ENTITIES) {
            return ChaosWorldRenderStage.AFTER_ENTITIES;
        }
        if (stage == RenderLevelStageEvent.Stage.AFTER_BLOCK_ENTITIES) {
            return ChaosWorldRenderStage.AFTER_BLOCK_ENTITIES;
        }

        return null;
    }
}
