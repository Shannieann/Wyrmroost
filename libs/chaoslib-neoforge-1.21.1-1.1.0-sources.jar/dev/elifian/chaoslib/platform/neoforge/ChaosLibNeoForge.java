package dev.elifian.chaoslib.platform.neoforge;

import dev.elifian.chaoslib.ChaosLib;
import dev.elifian.chaoslib.init.ChaosExampleRegistrations;
import dev.elifian.chaoslib.init.ChaosLibBootstrap;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.loading.FMLEnvironment;

/**
 * Hands the mod event bus to the services, then lets shared code decide what to set up.
 */
@Mod(ChaosLib.MOD_ID)
public final class ChaosLibNeoForge {
    public ChaosLibNeoForge(IEventBus modEventBus) {
        NeoForgeRegistrationHelper.bind(modEventBus);
        NeoForgeNetworkHelper.bind(modEventBus);
        if (FMLEnvironment.dist == Dist.CLIENT) {
            NeoForgeClientLifecycleHelper.bind(modEventBus);
        }

        ChaosLibBootstrap.init();
        if (FMLEnvironment.dist == Dist.CLIENT) {
            ChaosLibBootstrap.initClient();
        }

        modEventBus.addListener(FMLCommonSetupEvent.class, event ->
                event.enqueueWork(ChaosExampleRegistrations::publish));
    }
}
