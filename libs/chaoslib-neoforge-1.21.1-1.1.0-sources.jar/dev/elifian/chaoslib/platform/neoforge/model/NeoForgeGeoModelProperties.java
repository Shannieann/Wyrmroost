package dev.elifian.chaoslib.platform.neoforge.model;

import dev.elifian.chaoslib.model.baked.GeoStaticModelData;
import net.neoforged.neoforge.client.model.data.ModelProperty;

public final class NeoForgeGeoModelProperties {
    public static final ModelProperty<GeoStaticModelData.State> STATE = new ModelProperty<>();

    private NeoForgeGeoModelProperties() {
    }
}
