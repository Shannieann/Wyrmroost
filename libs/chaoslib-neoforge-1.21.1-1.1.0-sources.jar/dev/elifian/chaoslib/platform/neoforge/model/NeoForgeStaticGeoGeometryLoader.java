package dev.elifian.chaoslib.platform.neoforge.model;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;

import dev.elifian.chaoslib.platform.ClientOnly;
import net.neoforged.neoforge.client.model.geometry.IGeometryLoader;

@ClientOnly
public final class NeoForgeStaticGeoGeometryLoader implements IGeometryLoader<NeoForgeStaticGeoGeometry> {
    public static final NeoForgeStaticGeoGeometryLoader INSTANCE = new NeoForgeStaticGeoGeometryLoader();

    private NeoForgeStaticGeoGeometryLoader() {
    }

    @Override
    public NeoForgeStaticGeoGeometry read(JsonObject jsonObject, JsonDeserializationContext deserializationContext) {
        return new NeoForgeStaticGeoGeometry();
    }
}
