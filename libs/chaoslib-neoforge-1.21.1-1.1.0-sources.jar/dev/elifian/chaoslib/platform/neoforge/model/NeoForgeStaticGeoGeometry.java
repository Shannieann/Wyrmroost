package dev.elifian.chaoslib.platform.neoforge.model;

import dev.elifian.chaoslib.client.model.baked.StaticGeoBakeContext;
import dev.elifian.chaoslib.client.model.baked.StaticGeoModelBaker;
import dev.elifian.chaoslib.platform.ClientOnly;
import net.minecraft.client.renderer.block.model.ItemOverrides;
import net.minecraft.client.renderer.block.model.ItemTransforms;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.resources.model.Material;
import net.minecraft.client.resources.model.ModelBaker;
import net.minecraft.client.resources.model.ModelState;
import net.neoforged.neoforge.client.model.geometry.IGeometryBakingContext;
import net.neoforged.neoforge.client.model.geometry.IUnbakedGeometry;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

import java.util.function.Function;

/**
 * Plugs the shared static geo baker into NeoForge's custom geometry loader.
 */
@ClientOnly
public final class NeoForgeStaticGeoGeometry implements IUnbakedGeometry<NeoForgeStaticGeoGeometry> {
    public static void clearBakeCache() {
        StaticGeoModelBaker.clearBakeCache();
    }

    @Override
    public BakedModel bake(
            IGeometryBakingContext context,
            ModelBaker baker,
            Function<Material, TextureAtlasSprite> spriteGetter,
            ModelState modelState,
            ItemOverrides overrides
    ) {
        return StaticGeoModelBaker.bake(new NeoForgeBakeContext(context), baker, spriteGetter, modelState, overrides);
    }

    private record NeoForgeBakeContext(IGeometryBakingContext context) implements StaticGeoBakeContext {
        @Override
        public String modelName() {
            return this.context.getModelName();
        }

        @Override
        public boolean hasMaterial(String name) {
            return this.context.hasMaterial(name);
        }

        @Override
        public Material material(String name) {
            return this.context.getMaterial(name);
        }

        @Override
        public boolean useAmbientOcclusion() {
            return this.context.useAmbientOcclusion();
        }

        @Override
        public boolean isGui3d() {
            return this.context.isGui3d();
        }

        @Override
        public boolean useBlockLight() {
            return this.context.useBlockLight();
        }

        @Override
        @Nullable
        public ItemTransforms transforms() {
            return this.context.getTransforms();
        }

        @Override
        public Matrix4f rootTransform() {
            return this.context.getRootTransform().getMatrix();
        }
    }
}
