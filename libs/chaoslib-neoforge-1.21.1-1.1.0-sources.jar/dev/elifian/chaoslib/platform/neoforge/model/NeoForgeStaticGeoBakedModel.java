package dev.elifian.chaoslib.platform.neoforge.model;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.elifian.chaoslib.model.baked.StaticGeoBakedModel;
import dev.elifian.chaoslib.platform.ClientOnly;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.block.model.ItemOverrides;
import net.minecraft.client.renderer.block.model.ItemTransforms;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.client.ChunkRenderTypeSet;
import net.neoforged.neoforge.client.extensions.IBakedModelExtension;
import net.neoforged.neoforge.client.model.data.ModelData;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * Hands the shared static model to NeoForge's chunk mesher, which asks for quads and render types
 * through ModelData.
 */
@ClientOnly
public final class NeoForgeStaticGeoBakedModel implements BakedModel, IBakedModelExtension {
    private final StaticGeoBakedModel model;

    public NeoForgeStaticGeoBakedModel(StaticGeoBakedModel model) {
        this.model = model;
    }

    @Override
    public List<BakedQuad> getQuads(BlockState state, Direction face, RandomSource random) {
        return this.model.getQuads(state, face, null, null);
    }

    @Override
    public @NotNull List<BakedQuad> getQuads(@Nullable BlockState state, @Nullable Direction face,
                                             @NotNull RandomSource random, @NotNull ModelData data,
                                             @Nullable RenderType renderType) {
        return this.model.getQuads(state, face, data.get(NeoForgeGeoModelProperties.STATE), renderType);
    }

    @Override
    public @NotNull ChunkRenderTypeSet getRenderTypes(@NotNull BlockState state, @NotNull RandomSource random,
                                                      @NotNull ModelData data) {
        return ChunkRenderTypeSet.of(this.model.getRenderLayers(state, data.get(NeoForgeGeoModelProperties.STATE)));
    }

    @Override
    public boolean useAmbientOcclusion() {
        return this.model.useAmbientOcclusion();
    }

    @Override
    public boolean isGui3d() {
        return this.model.isGui3d();
    }

    @Override
    public boolean usesBlockLight() {
        return this.model.usesBlockLight();
    }

    @Override
    public boolean isCustomRenderer() {
        return this.model.isCustomRenderer();
    }

    @Override
    public TextureAtlasSprite getParticleIcon() {
        return this.model.getParticleIcon();
    }

    @Override
    public ItemTransforms getTransforms() {
        return this.model.getTransforms();
    }

    @Override
    public ItemOverrides getOverrides() {
        return this.model.getOverrides();
    }

    @Override
    public BakedModel applyTransform(ItemDisplayContext transformType, PoseStack poseStack, boolean applyLeftHandTransform) {
        this.model.applyTransform(transformType, poseStack, applyLeftHandTransform);
        return this;
    }
}
