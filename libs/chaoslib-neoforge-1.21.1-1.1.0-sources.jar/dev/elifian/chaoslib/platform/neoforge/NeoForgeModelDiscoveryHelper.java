package dev.elifian.chaoslib.platform.neoforge;

import dev.elifian.chaoslib.api.model.GeoModel;
import dev.elifian.chaoslib.platform.services.ModelDiscoveryHelper;
import net.neoforged.fml.ModList;

import java.nio.file.Path;
import java.util.Comparator;
import java.util.List;

public final class NeoForgeModelDiscoveryHelper implements ModelDiscoveryHelper {
    @Override
    public List<String> knownGeoModelClassNames() {
        return ModList.get().getAllScanData().stream()
                .flatMap(scanData -> scanData.getClasses().stream())
                .filter(classData -> classData.parent() != null)
                .filter(classData -> GeoModel.class.getName().equals(classData.parent().getClassName()))
                .map(classData -> classData.clazz().getClassName())
                .distinct()
                .sorted(Comparator.naturalOrder())
                .toList();
    }

    @Override
    public List<Path> classScanRoots() {
        return List.of();
    }
}
