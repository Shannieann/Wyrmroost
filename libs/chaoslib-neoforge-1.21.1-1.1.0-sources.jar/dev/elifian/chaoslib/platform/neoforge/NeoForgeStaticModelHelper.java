package dev.elifian.chaoslib.platform.neoforge;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.elifian.chaoslib.api.animatable.GeoBlockEntity;
import dev.elifian.chaoslib.model.baked.StaticGeoBakedModel;
import dev.elifian.chaoslib.platform.neoforge.model.NeoForgeStaticGeoBakedModel;
import dev.elifian.chaoslib.platform.neoforge.model.NeoForgeStaticGeoGeometry;
import dev.elifian.chaoslib.platform.render.GeoFrozenRenderSupport;
import dev.elifian.chaoslib.platform.services.StaticModelHelper;
import dev.elifian.chaoslib.renderer.block.GeoBlockFrozenRenderHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.client.model.data.ModelData;

public final class NeoForgeStaticModelHelper implements StaticModelHelper {
    @Override
    public <T extends BlockEntity & GeoBlockEntity> GeoFrozenRenderSupport<T> createFrozenRenderSupport() {
        return new GeoBlockFrozenRenderHelper<>();
    }

    @Override
    public void clearStaticRenderCaches() {
        GeoBlockFrozenRenderHelper.clearAllCaches();
        NeoForgeStaticGeoGeometry.clearBakeCache();
    }

    @Override
    public void requestModelDataUpdate(BlockEntity blockEntity) {
        blockEntity.requestModelDataUpdate();
    }


    @Override
    public BakedModel wrapStaticModel(StaticGeoBakedModel model) {
        return new NeoForgeStaticGeoBakedModel(model);
    }

    @Override
    public void renderStaticModel(PoseStack poseStack, MultiBufferSource bufferSource, BlockState state,
                                  BakedModel model, RandomSource random, int packedLight, int packedOverlay) {
        var modelRenderer = Minecraft.getInstance().getBlockRenderer().getModelRenderer();
        for (RenderType layer : model.getRenderTypes(state, random, ModelData.EMPTY)) {
            VertexConsumer consumer = bufferSource.getBuffer(layer);
            modelRenderer.renderModel(poseStack.last(), consumer, state, model, 1.0f, 1.0f, 1.0f,
                    packedLight, packedOverlay, ModelData.EMPTY, layer);
        }
    }
}
