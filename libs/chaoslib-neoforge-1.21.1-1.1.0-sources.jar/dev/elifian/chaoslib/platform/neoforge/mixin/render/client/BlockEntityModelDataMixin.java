package dev.elifian.chaoslib.platform.neoforge.mixin.render.client;

import dev.elifian.chaoslib.api.animatable.GeoBlockEntity;
import dev.elifian.chaoslib.model.baked.GeoStaticModelData;
import dev.elifian.chaoslib.platform.neoforge.model.NeoForgeGeoModelProperties;
import dev.elifian.chaoslib.renderer.block.StaticGeoRenderStateResolver;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.neoforged.neoforge.client.model.data.ModelData;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

/**
 * Feeds the block entity's static render state to NeoForge's chunk mesher. The state itself is
 * resolved by shared code; only this hand-off is loader-specific.
 */
@SuppressWarnings({"AddedMixinMembersNamePattern", "unused", "MissingUnique"})
@Mixin(BlockEntity.class)
abstract class BlockEntityModelDataMixin {
    @Unique
    private static final StaticGeoRenderStateResolver CHAOS_STATIC_RENDER_STATE_RESOLVER = new StaticGeoRenderStateResolver();

    public ModelData getModelData() {
        if (!((Object) this instanceof GeoBlockEntity geoBlockEntity)) {
            return ModelData.EMPTY;
        }

        GeoStaticModelData.State state = CHAOS_STATIC_RENDER_STATE_RESOLVER.resolveState(geoBlockEntity);
        return state == null
                ? ModelData.EMPTY
                : ModelData.builder().with(NeoForgeGeoModelProperties.STATE, state).build();
    }
}
