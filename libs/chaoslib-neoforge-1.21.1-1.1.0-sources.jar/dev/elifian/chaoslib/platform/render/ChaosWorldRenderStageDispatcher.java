package dev.elifian.chaoslib.platform.render;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.elifian.chaoslib.mixin.render.client.WorldRendererAccessor;
import dev.elifian.chaoslib.platform.ClientOnly;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.culling.Frustum;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

/**
 * Where the world render stages arrive, whichever way the loader delivers them: NeoForge fires an
 * event, Fabric has none and is driven straight out of renderLevel by a mixin.
 */
@ClientOnly
public final class ChaosWorldRenderStageDispatcher {
    private static final List<ChaosWorldRenderStageListener> LISTENERS = new ArrayList<>();

    private ChaosWorldRenderStageDispatcher() {
    }

    public static void addListener(ChaosWorldRenderStageListener listener) {
        LISTENERS.add(listener);
    }

    public static void dispatch(
            ChaosWorldRenderStage stage,
            Matrix4f projectionMatrix,
            @Nullable PoseStack poseStack,
            @Nullable Camera camera,
            @Nullable Frustum frustum,
            float partialTick) {
        if (LISTENERS.isEmpty()) {
            return;
        }

        ChaosWorldRenderContext context = new ChaosWorldRenderContext(
                stage, projectionMatrix, poseStack, camera, frustum, partialTick);
        for (ChaosWorldRenderStageListener listener : LISTENERS) {
            listener.onWorldRenderStage(context);
        }
    }

    /**
     * Dispatches with the frustum the level renderer is currently culling against, for callers that
     * do not have one to hand.
     */
    public static void dispatch(
            ChaosWorldRenderStage stage,
            Matrix4f projectionMatrix,
            @Nullable PoseStack poseStack,
            @Nullable Camera camera,
            float partialTick) {
        dispatch(stage, projectionMatrix, poseStack, camera, currentFrustum(), partialTick);
    }

    @Nullable
    private static Frustum currentFrustum() {
        Minecraft client = Minecraft.getInstance();
        return client.levelRenderer == null ? null : ((WorldRendererAccessor) client.levelRenderer).getFrustum();
    }
}
