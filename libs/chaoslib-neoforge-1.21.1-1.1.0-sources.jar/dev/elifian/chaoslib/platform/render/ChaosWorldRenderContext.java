package dev.elifian.chaoslib.platform.render;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Camera;
import net.minecraft.client.renderer.culling.Frustum;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

/**
 * Loader-agnostic view of a world render stage callback.
 */
public record ChaosWorldRenderContext(
        ChaosWorldRenderStage stage,
        Matrix4f projectionMatrix,
        @Nullable PoseStack poseStack,
        @Nullable Camera camera,
        @Nullable Frustum frustum,
        float partialTick
) {
}
