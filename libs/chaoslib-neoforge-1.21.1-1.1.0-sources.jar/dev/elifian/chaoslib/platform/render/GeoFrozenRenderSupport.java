package dev.elifian.chaoslib.platform.render;

import com.mojang.blaze3d.vertex.PoseStack;
import dev.elifian.chaoslib.api.animatable.GeoBlockEntity;
import dev.elifian.chaoslib.api.renderer.GeoBlockRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.level.block.entity.BlockEntity;

/**
 * Renders a block entity from its frozen static bake instead of the live geo path.
 *
 * <p>Backed by the loader's baked-model extensions, so only NeoForge implements it;
 * Fabric answers "not frozen" and the live path always runs.</p>
 */
public interface GeoFrozenRenderSupport<T extends BlockEntity & GeoBlockEntity> {
    boolean shouldRenderFrozen(GeoBlockRenderer<T> renderer, T animatable);

    boolean renderFrozen(GeoBlockRenderer<T> renderer, PoseStack poseStack, T animatable,
                         MultiBufferSource bufferSource, float partialTick, int packedLight, int packedOverlay);

    void onReturnToLive(T animatable);

    void clear(T animatable);

    void applyThawTransitionIfActive(GeoBlockRenderer<T> renderer, T animatable, float partialTick);

    boolean hasActiveThawTransition(T animatable);
}
