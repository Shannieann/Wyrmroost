package dev.elifian.chaoslib.platform.render;

@FunctionalInterface
public interface ChaosWorldRenderStageListener {
    void onWorldRenderStage(ChaosWorldRenderContext context);
}
