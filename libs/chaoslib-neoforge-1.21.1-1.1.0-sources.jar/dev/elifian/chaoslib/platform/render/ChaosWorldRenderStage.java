package dev.elifian.chaoslib.platform.render;

/**
 * Loader-agnostic world render stages ChaosLib flushes its GPU batches on.
 */
public enum ChaosWorldRenderStage {
    AFTER_ENTITIES,
    AFTER_BLOCK_ENTITIES
}
