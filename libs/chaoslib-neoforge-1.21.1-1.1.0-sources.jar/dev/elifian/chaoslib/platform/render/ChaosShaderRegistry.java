package dev.elifian.chaoslib.platform.render;

import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.resources.ResourceLocation;

import java.util.function.Consumer;

/**
 * Sink handed to common code during core shader registration. The loader decides how the
 * shader is built and when the callback fires.
 */
public interface ChaosShaderRegistry {
    void register(ResourceLocation id, VertexFormat vertexFormat, Consumer<ShaderInstance> onLoaded);
}
