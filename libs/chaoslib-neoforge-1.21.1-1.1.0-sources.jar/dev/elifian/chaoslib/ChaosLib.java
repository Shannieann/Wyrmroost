package dev.elifian.chaoslib;

import dev.elifian.chaoslib.util.IdentifierUtil;
import net.minecraft.resources.ResourceLocation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class ChaosLib {
    public static final String MOD_ID = "chaoslib";
    public static final Logger LOGGER = LoggerFactory.getLogger("ChaosLib");

    private ChaosLib() {
    }

    public static ResourceLocation id(String path) {
        return IdentifierUtil.id(MOD_ID, path);
    }
}
