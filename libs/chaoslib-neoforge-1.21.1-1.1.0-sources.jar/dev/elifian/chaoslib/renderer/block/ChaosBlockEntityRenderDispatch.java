package dev.elifian.chaoslib.renderer.block;

import net.minecraft.world.level.block.entity.BlockEntity;

import dev.elifian.chaoslib.platform.ClientOnly;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@ClientOnly
public final class ChaosBlockEntityRenderDispatch {
    private static final Map<Class<?>, Snapshot> SNAPSHOTS = new ConcurrentHashMap<>();
    private static volatile boolean diagnosticsEnabled;

    private ChaosBlockEntityRenderDispatch() {
    }

    public static void setDiagnosticsEnabled(boolean enabled) {
        diagnosticsEnabled = enabled;
    }

    public static void record(BlockEntity blockEntity, ChaosBlockEntityRenderBackend backend, String reasonKey) {
        if (!diagnosticsEnabled) {
            return;
        }

        Class<?> blockEntityClass = blockEntity.getClass();
        Snapshot previous = SNAPSHOTS.get(blockEntityClass);
        if (previous != null && previous.backend() == backend && previous.reasonKey().equals(reasonKey)) {
            return;
        }

        SNAPSHOTS.put(blockEntityClass, new Snapshot(backend, reasonKey));
    }

    public static Snapshot get(BlockEntity blockEntity) {
        Snapshot snapshot = SNAPSHOTS.get(blockEntity.getClass());
        return snapshot != null ? snapshot : new Snapshot(ChaosBlockEntityRenderBackend.UNKNOWN, "not_rendered_yet");
    }

    public record Snapshot(ChaosBlockEntityRenderBackend backend, String reasonKey) {
    }
}
