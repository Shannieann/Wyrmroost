package dev.elifian.chaoslib.renderer.block;

import dev.elifian.chaoslib.api.model.GeoModel;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuAnimationPoseStorage;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuPoseSlotStore;

import dev.elifian.chaoslib.platform.ClientOnly;

@ClientOnly
public final class ChaosBlockEntityRenderFrameClock {
    private static int frameId = 1;

    private ChaosBlockEntityRenderFrameClock() {
    }

    public static void beginFrame() {
        frameId++;
        if (frameId == 0) {
            frameId = 1;
        }
        GeoModel.clearProceduralFramePoseDedup();
        ChaosGpuPoseSlotStore.beginFrame();
        ChaosGpuAnimationPoseStorage.beginFrame();
    }

    public static int frameId() {
        return frameId;
    }
}
