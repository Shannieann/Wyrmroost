package dev.elifian.chaoslib.renderer.block;

import net.minecraft.network.chat.Component;

import dev.elifian.chaoslib.platform.ClientOnly;

@ClientOnly
public enum ChaosBlockEntityRenderBackend {
    CHAOS_EARLY("chaos_early"),
    CHAOS("chaos"),
    MINECRAFT("minecraft"),
    STATIC_ONLY("static_only"),
    CULLED("culled"),
    UNKNOWN("unknown");

    private final String translationSuffix;

    ChaosBlockEntityRenderBackend(String translationSuffix) {
        this.translationSuffix = translationSuffix;
    }

    public Component displayText() {
        return Component.translatable("chaoslib.sodium.debug.render_backend." + this.translationSuffix);
    }
}
