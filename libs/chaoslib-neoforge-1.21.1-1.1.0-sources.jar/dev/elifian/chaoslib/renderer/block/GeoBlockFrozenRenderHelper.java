package dev.elifian.chaoslib.renderer.block;

import dev.elifian.chaoslib.api.animatable.GeoBlockEntity;
import dev.elifian.chaoslib.api.renderer.GeoBlockRenderer;
import dev.elifian.chaoslib.cache.object.BakedGeoModel;
import dev.elifian.chaoslib.cache.object.GeoBone;
import dev.elifian.chaoslib.compat.sodium.ChaosSodiumBlockEntitySettings;
import dev.elifian.chaoslib.compat.iris.IrisCompatInternal;
import dev.elifian.chaoslib.gpu.render.ChaosShaderRenderPhase;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuAnimationPoseStorage;
import dev.elifian.chaoslib.gpu.mesh.ChaosGpuGeoMesh;
import dev.elifian.chaoslib.gpu.render.ChaosGpuPoseDataCache;
import dev.elifian.chaoslib.gpu.render.ChaosGpuRenderRuntime;
import dev.elifian.chaoslib.gpu.render.ChaosGpuShaderPackRenderer;
import dev.elifian.chaoslib.gpu.render.ChaosGpuWorldRenderDispatcher;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuWorldLightVolumeStorage;
import dev.elifian.chaoslib.model.baked.StaticGeoBakedModel;
import dev.elifian.chaoslib.model.baked.StaticGeoBonePose;
import dev.elifian.chaoslib.model.baked.StaticGeoRenderMode;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.block.model.ItemOverrides;
import net.minecraft.client.renderer.block.model.ItemTransforms;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.renderer.texture.TextureAtlas;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import net.minecraft.util.RandomSource;

import dev.elifian.chaoslib.platform.ClientOnly;
import dev.elifian.chaoslib.platform.Services;
import dev.elifian.chaoslib.platform.render.GeoFrozenRenderSupport;
import org.joml.Matrix4f;

import java.util.*;

@ClientOnly
public final class GeoBlockFrozenRenderHelper<T extends BlockEntity & GeoBlockEntity> implements GeoFrozenRenderSupport<T> {
    private static final Set<GeoBlockFrozenRenderHelper<?>> HELPERS = Collections.newSetFromMap(new WeakHashMap<>());
    private static final long CLEANUP_INTERVAL_TICKS = 200L;
    private final Map<T, FrozenRenderState> frozenRenderStates = new IdentityHashMap<>();
    private final Map<T, ThawTransitionState> thawTransitionStates = new IdentityHashMap<>();
    private boolean hasFrozenState;
    private long lastCleanupWorldTime = Long.MIN_VALUE;

    public GeoBlockFrozenRenderHelper() {
        HELPERS.add(this);
    }

    @Override
    public boolean shouldRenderFrozen(GeoBlockRenderer<T> renderer, T animatable) {
        double radius = ChaosSodiumBlockEntitySettings.resolveFrozenRenderRadius(animatable, renderer.getGeoModel().getFrozenBlockEntityRenderRadius());
        if (radius <= 0.0d) {
            return false;
        }

        Minecraft client = Minecraft.getInstance();
        if (client.player == null || animatable.getLevel() == null) {
            return false;
        }

        return Vec3.atCenterOf(animatable.getBlockPos()).distanceToSqr(client.player.position()) > radius * radius;
    }

    @Override
    public boolean renderFrozen(GeoBlockRenderer<T> renderer, PoseStack poseStack, T animatable, MultiBufferSource bufferSource, float partialTick, int packedLight, int packedOverlay) {
        cleanupIfNeeded(animatable);
        FrozenRenderState frozen = this.frozenRenderStates.get(animatable);
        if (frozen == null) {
            frozen = createFrozenRenderState(renderer, animatable, partialTick);
            if (frozen != null) {
                this.frozenRenderStates.put(animatable, frozen);
                this.hasFrozenState = true;
            }
        }

        if (frozen == null) {
            return false;
        }

        FrozenGpuState gpuState = frozen.gpuState();
        if (gpuState != null && renderFrozenGpu(renderer, poseStack, animatable, packedLight, gpuState)) {
            if (!frozen.liveBones().isEmpty()) {
                renderer.renderFrozenLiveBones(poseStack, animatable, bufferSource, partialTick, packedLight, packedOverlay, frozen.liveBones());
            }
            return true;
        }

        if (frozen.model() == null) {
            return false;
        }

        poseStack.pushPose();
        poseStack.translate(0.5d, 0.0d, 0.5d);
        renderer.rotateBlock(renderer.getFacing(animatable), poseStack);
        poseStack.translate(-0.5d, 0.0d, -0.5d);

        BlockState state = animatable.getBlockState();
        RandomSource random = RandomSource.create(state.getSeed(animatable.getBlockPos()));
        Services.STATIC_MODELS.renderStaticModel(poseStack, bufferSource, state, frozen.model(), random, packedLight, packedOverlay);
        poseStack.popPose();
        if (!frozen.liveBones().isEmpty()) {
            renderer.renderFrozenLiveBones(poseStack, animatable, bufferSource, partialTick, packedLight, packedOverlay, frozen.liveBones());
        }
        return true;
    }

    @Override
    public void onReturnToLive(T animatable) {
        if (!this.hasFrozenState) {
            return;
        }

        cleanupIfNeeded(animatable);
        FrozenRenderState frozenState = this.frozenRenderStates.remove(animatable);
        refreshFrozenStateFlag();
        if (frozenState != null && !frozenState.bonePoses().isEmpty()) {
            this.thawTransitionStates.put(animatable, new ThawTransitionState(frozenState.bonePoses(), System.nanoTime()));
            this.hasFrozenState = true;
        }
    }

    @Override
    public void clear(T animatable) {
        if (!this.hasFrozenState) {
            return;
        }

        this.frozenRenderStates.remove(animatable);
        this.thawTransitionStates.remove(animatable);
        refreshFrozenStateFlag();
    }

    @Override
    public void applyThawTransitionIfActive(GeoBlockRenderer<T> renderer, T animatable, float partialTick) {
        cleanupIfNeeded(animatable);
        ThawTransitionState thawState = this.thawTransitionStates.get(animatable);
        if (thawState == null) {
            return;
        }

        float durationTicks = renderer.getGeoModel().getFrozenBlockEntityThawDurationTicks();
        if (durationTicks <= 0.0f) {
            this.thawTransitionStates.remove(animatable);
            return;
        }

        long elapsedNanos = System.nanoTime() - thawState.startedAtNanos();
        float elapsedTicks = elapsedNanos / 50_000_000.0f + partialTick;
        float blend = Math.max(0.0f, Math.min(1.0f, elapsedTicks / durationTicks));
        renderer.getGeoModel().blendCurrentPoseWithCaptured(thawState.bonePoses(), blend);
        if (blend >= 0.9999f) {
            this.thawTransitionStates.remove(animatable);
        }
    }

    @Override
    public boolean hasActiveThawTransition(T animatable) {
        cleanupIfNeeded(animatable);
        return this.thawTransitionStates.containsKey(animatable);
    }

    int cacheSize() {
        return this.frozenRenderStates.size();
    }

    public static void clearAllCaches() {
        for (GeoBlockFrozenRenderHelper<?> helper : HELPERS) {
            helper.clearAll();
        }
    }

    public static int totalFrozenStateCount() {
        int total = 0;
        for (GeoBlockFrozenRenderHelper<?> helper : HELPERS) {
            total += helper.cacheSize();
        }
        return total;
    }

    private void clearAll() {
        this.frozenRenderStates.clear();
        this.thawTransitionStates.clear();
        this.hasFrozenState = false;
    }

    private void cleanupIfNeeded(T animatable) {
        if (animatable.getLevel() == null) {
            return;
        }

        long worldTime = animatable.getLevel().getGameTime();
        if (this.lastCleanupWorldTime != Long.MIN_VALUE && worldTime - this.lastCleanupWorldTime < CLEANUP_INTERVAL_TICKS) {
            return;
        }

        this.lastCleanupWorldTime = worldTime;
        cleanupMap(this.frozenRenderStates);
        cleanupMap(this.thawTransitionStates);
    }

    private <V> void cleanupMap(Map<T, V> map) {
        Iterator<Map.Entry<T, V>> iterator = map.entrySet().iterator();
        while (iterator.hasNext()) {
            T entity = iterator.next().getKey();
            if (entity == null || entity.isRemoved() || entity.getLevel() == null) {
                iterator.remove();
            }
        }
        refreshFrozenStateFlag();
    }

    private void refreshFrozenStateFlag() {
        this.hasFrozenState = !this.frozenRenderStates.isEmpty() || !this.thawTransitionStates.isEmpty();
    }

    private FrozenRenderState createFrozenRenderState(GeoBlockRenderer<T> renderer, T animatable, float partialTick) {
        BakedGeoModel bakedGeoModel = renderer.getGeoModel().getBakedModel(renderer.getGeoModel().getModelResource(animatable));
        long instanceId = renderer.getInstanceId(animatable);
        Map<String, StaticGeoBonePose> frozenBonePoses = renderer.getGeoModel().captureCurrentStaticBonePoses(animatable, instanceId, partialTick);
        Set<String> liveBones = resolveFrozenLiveBones(renderer, animatable, bakedGeoModel);
        FrozenGpuState gpuState = createFrozenGpuState(renderer, animatable, bakedGeoModel, frozenBonePoses, liveBones);

        ResourceLocation geoModelId = renderer.getGeoModel().getStaticGeoModelResource();
        ResourceLocation textureId = renderer.getGeoModel().getStaticTextureResource();
        if (geoModelId == null || textureId == null) {
            return gpuState == null ? null : new FrozenRenderState(null, frozenBonePoses, gpuState, liveBones);
        }

        TextureAtlasSprite staticSprite = getBlockAtlasSprite(textureId);
        if (staticSprite == null) {
            return gpuState == null ? null : new FrozenRenderState(null, frozenBonePoses, gpuState, liveBones);
        }

        Set<String> allBones = bakedGeoModel.boneNames();
        Set<String> frozenBones = subtractBones(allBones, liveBones);
        Map<StaticGeoRenderMode, Set<String>> includedBones = Map.of(StaticGeoRenderMode.ALL_BONES, frozenBones);
        BlockState state = animatable.getBlockState();
        Matrix4f rootTransform = renderer.getGeoModel().getStaticRootTransform(state);
        StaticGeoBakedModel.LayeredQuadBuckets combined = StaticGeoBakedModel.bakeQuadsByMode(
                bakedGeoModel,
                rootTransform,
                staticSprite,
                includedBones,
                frozenBonePoses,
                renderer.getGeoModel().getStaticQuadCullingMode(state),
                textureId,
                false
        ).get(StaticGeoRenderMode.ALL_BONES);
        if (combined == null) {
            return null;
        }

        ResourceLocation emissiveTextureId = null;
        Set<String> emissiveBones = subtractBones(renderer.getGeoModel().getResolvedEmissiveBones(animatable, bakedGeoModel, null), liveBones);
        if (!emissiveBones.isEmpty() && renderer.getGeoModel().shouldRenderEmissive(animatable)) {
            ResourceLocation candidate = renderer.getGeoModel().getEmissiveTextureResource(animatable);
            if (candidate != null && renderer.getGeoModel().hasClientResource(candidate)) {
                emissiveTextureId = candidate;
            }
        }

        if (emissiveTextureId != null) {
            TextureAtlasSprite emissiveSprite = getBlockAtlasSprite(emissiveTextureId);
            if (emissiveSprite != null) {
                Map<StaticGeoRenderMode, Set<String>> emissiveBonesByMode = Map.of(StaticGeoRenderMode.ALL_BONES, emissiveBones);
                int emissivePassCount = Math.max(0, renderer.getGeoModel().getStaticEmissivePassCount());
                for (int pass = 0; pass < emissivePassCount; pass++) {
                    StaticGeoBakedModel.LayeredQuadBuckets emissive = StaticGeoBakedModel.bakeQuadsByMode(
                            bakedGeoModel,
                            rootTransform,
                            emissiveSprite,
                            emissiveBonesByMode,
                            frozenBonePoses,
                            renderer.getGeoModel().getStaticQuadCullingMode(state),
                            emissiveTextureId,
                            true,
                            pass
                    ).get(StaticGeoRenderMode.ALL_BONES);
                    if (emissive != null) {
                        combined.mergeFrom(emissive);
                    }
                }
            }
        }

        boolean hasFrozenEmissive = emissiveTextureId != null && !emissiveBones.isEmpty();
        StaticGeoBakedModel runtimeModel = StaticGeoBakedModel.create(
                bakedGeoModel,
                Map.of("default", Map.of(StaticGeoRenderMode.ALL_BONES, combined.freeze())),
                staticSprite,
                blockState -> StaticGeoRenderMode.ALL_BONES,
                blockState -> "default",
                renderer.getGeoModel()::getStaticRenderLayer,
                blockState -> hasFrozenEmissive,
                renderer.getGeoModel().useStaticAmbientOcclusion(),
                true,
                true,
                ItemTransforms.NO_TRANSFORMS,
                null,
                ItemOverrides.EMPTY
        );
        return new FrozenRenderState(runtimeModel, frozenBonePoses, gpuState, liveBones);
    }

    private Set<String> resolveFrozenLiveBones(GeoBlockRenderer<T> renderer, T animatable, BakedGeoModel bakedGeoModel) {
        if (ChaosSodiumBlockEntitySettings.shouldKeepFrozenLiveBonesOnBer(renderer.getGeoModel(), animatable)) {
            return renderer.resolveFrozenLiveRenderBones(animatable, bakedGeoModel);
        }

        Set<String> animatedBones = renderer.getGeoModel().getBakeExcludedBones().resolve(bakedGeoModel);
        if (animatedBones.isEmpty() || animatedBones.containsAll(bakedGeoModel.boneNames())) {
            return Set.of();
        }

        return animatedBones;
    }

    private FrozenGpuState createFrozenGpuState(
            GeoBlockRenderer<T> renderer,
            T animatable,
            BakedGeoModel bakedGeoModel,
            Map<String, StaticGeoBonePose> frozenBonePoses,
            Set<String> liveBones) {
        if (!bakedGeoModel.properties().gpuPipeline()) {
            return null;
        }

        ResourceLocation textureId = renderer.getTextureLocation(animatable);
        if (textureId == null) {
            return null;
        }

        Set<String> frozenBones = subtractBones(bakedGeoModel.boneNames(), liveBones);
        ChaosGpuGeoMesh mesh = ChaosGpuGeoMesh.getOrCreate(bakedGeoModel, frozenBones);
        Object poseKey = renderer.getGeoModel().createFrozenPoseCacheKey(animatable, bakedGeoModel, frozenBonePoses);
        if (poseKey == null) {
            poseKey = FrozenPoseKey.create(mesh, frozenBonePoses);
        }
        Object bonePoseData = ChaosGpuAnimationPoseStorage.prepareStaticPoseToken(mesh, frozenBonePoses, poseKey);
        if (bonePoseData == null) {
            bonePoseData = ChaosGpuPoseDataCache.prepareStaticBonePoseData(mesh, frozenBonePoses, poseKey);
        }

        Set<String> emissiveBones = subtractBones(renderer.resolveFrozenEmissiveBones(animatable, bakedGeoModel, liveBones), liveBones);
        ResourceLocation emissiveTextureId = emissiveBones.isEmpty() ? null : renderer.resolveEmissiveTexture(animatable);
        float[] emissiveMaskData = ChaosGpuPoseDataCache.prepareEmissiveMaskData(mesh, emissiveBones);

        return new FrozenGpuState(
                mesh,
                textureId,
                emissiveTextureId,
                renderer.getGeoModel().getBlockEntityEmissiveStrength(animatable),
                bonePoseData,
                emissiveMaskData,
                frozenBonePoses,
                poseKey,
                emissiveBones
        );
    }

    private boolean renderFrozenGpu(
            GeoBlockRenderer<T> renderer,
            PoseStack poseStack,
            T animatable,
            int packedLight,
            FrozenGpuState frozenGpuState) {
        poseStack.pushPose();
        poseStack.translate(0.5d, 0.0d, 0.5d);
        renderer.rotateBlock(renderer.getFacing(animatable), poseStack);
        poseStack.mulPose(renderer.getGeoModel().getBlockEntityRootTransform(animatable));
        try {
            RenderType renderLayer = IrisCompatInternal.wrapBlockEntityRenderLayer(
                    renderer.getGeoModel().getRenderPolicy().getRenderType(animatable, frozenGpuState.texture())
            );
            int[] boneLightData = ChaosGpuWorldLightVolumeStorage.shouldUseVolume(packedLight)
                    ? null
                    : renderer.resolveBoneLightData(
                            animatable,
                            frozenGpuState.mesh(),
                            frozenGpuState.bonePoseData(),
                            poseStack.last().pose(),
                            packedLight
                    );
            if (ChaosGpuRenderRuntime.isShaderPackPipelineActive()) {
                if (!ChaosGpuShaderPackRenderer.renderPreparedMeshPass(
                        poseStack,
                        frozenGpuState.mesh(),
                        frozenGpuState.bonePoseData(),
                        packedLight,
                        boneLightData,
                        renderLayer,
                        ChaosShaderRenderPhase.BLOCK_ENTITIES
                )) {
                    return false;
                }

                ResourceLocation emissiveTexture = frozenGpuState.emissiveTexture();
                if (emissiveTexture == null || frozenGpuState.emissiveBones().isEmpty()) {
                    return true;
                }

                ChaosGpuGeoMesh emissiveMesh = ChaosGpuGeoMesh.getOrCreate(renderer.getGeoModel().getBakedModel(renderer.getGeoModel().getModelResource(animatable)), frozenGpuState.emissiveBones());
                Object emissivePoseData = prepareStaticBonePoseData(emissiveMesh, frozenGpuState.bonePoses(), frozenGpuState.poseKey());
                RenderType emissiveRenderLayer = IrisCompatInternal.wrapBlockEntityRenderLayer(
                        renderer.getGeoModel().getRenderPolicy().getEmissiveRenderType(animatable, emissiveTexture)
                );
                return ChaosGpuShaderPackRenderer.renderPreparedMeshPass(
                        poseStack,
                        emissiveMesh,
                        emissivePoseData,
                        LightTexture.FULL_BRIGHT,
                        null,
                        emissiveRenderLayer,
                        ChaosShaderRenderPhase.BLOCK_ENTITIES,
                        frozenGpuState.emissiveStrength()
                );
            }

            return ChaosGpuWorldRenderDispatcher.enqueue(
                    renderLayer,
                    frozenGpuState.mesh(),
                    frozenGpuState.texture(),
                    frozenGpuState.emissiveTexture(),
                    poseStack.last().pose(),
                    packedLight,
                    boneLightData,
                    frozenGpuState.bonePoseData(),
                    frozenGpuState.emissiveMaskData(),
                    frozenGpuState.emissiveStrength()
            );
        } finally {
            poseStack.popPose();
        }
    }

    private static Object prepareStaticBonePoseData(ChaosGpuGeoMesh mesh, Map<String, StaticGeoBonePose> bonePoses, Object poseKey) {
        Object bonePoseData = ChaosGpuAnimationPoseStorage.prepareStaticPoseToken(mesh, bonePoses, poseKey);
        return bonePoseData != null ? bonePoseData : ChaosGpuPoseDataCache.prepareStaticBonePoseData(mesh, bonePoses, poseKey);
    }

    private static TextureAtlasSprite getBlockAtlasSprite(ResourceLocation textureId) {
        ResourceLocation atlasId = toBlockAtlasId(textureId);
        TextureAtlas atlas = Minecraft.getInstance()
                .getModelManager()
                .getAtlas(InventoryMenu.BLOCK_ATLAS);
        return atlas == null ? null : atlas.getSprite(atlasId);
    }

    private static ResourceLocation toBlockAtlasId(ResourceLocation textureId) {
        String path = textureId.getPath();
        if (path.startsWith("textures/")) {
            path = path.substring("textures/".length());
        }
        if (path.endsWith(".png")) {
            path = path.substring(0, path.length() - ".png".length());
        }
        return ResourceLocation.fromNamespaceAndPath(textureId.getNamespace(), path);
    }

    private static Set<String> subtractBones(Set<String> source, Set<String> excluded) {
        if (source == null || source.isEmpty()) {
            return Set.of();
        }
        if (excluded == null || excluded.isEmpty()) {
            return source;
        }

        LinkedHashSet<String> result = new LinkedHashSet<>(source);
        result.removeAll(excluded);
        return result.isEmpty() ? Set.of() : Set.copyOf(result);
    }

    private record FrozenRenderState(StaticGeoBakedModel model, Map<String, StaticGeoBonePose> bonePoses,
                                     FrozenGpuState gpuState, Set<String> liveBones) {
    }

    private record FrozenGpuState(
            ChaosGpuGeoMesh mesh,
            ResourceLocation texture,
            ResourceLocation emissiveTexture,
            float emissiveStrength,
            Object bonePoseData,
            float[] emissiveMaskData,
            Map<String, StaticGeoBonePose> bonePoses,
            Object poseKey,
            Set<String> emissiveBones) {
    }

    private static final class FrozenPoseKey {
        private final int hash;
        private final int[] signature;

        private FrozenPoseKey(int[] signature) {
            this.signature = signature;
            this.hash = Arrays.hashCode(signature);
        }

        static FrozenPoseKey create(ChaosGpuGeoMesh mesh, Map<String, StaticGeoBonePose> bonePoses) {
            int[] signature = new int[mesh.getIndexedBones().size() * 11];
            int cursor = 0;

            for (GeoBone bone : mesh.getIndexedBones()) {
                StaticGeoBonePose pose = bonePoses.getOrDefault(bone.getName(), StaticGeoBonePose.IDENTITY);
                signature[cursor++] = Float.floatToRawIntBits(pose.posX());
                signature[cursor++] = Float.floatToRawIntBits(pose.posY());
                signature[cursor++] = Float.floatToRawIntBits(pose.posZ());
                signature[cursor++] = Float.floatToRawIntBits(pose.rotX());
                signature[cursor++] = Float.floatToRawIntBits(pose.rotY());
                signature[cursor++] = Float.floatToRawIntBits(pose.rotZ());
                signature[cursor++] = Float.floatToRawIntBits(pose.scaleX());
                signature[cursor++] = Float.floatToRawIntBits(pose.scaleY());
                signature[cursor++] = Float.floatToRawIntBits(pose.scaleZ());
                signature[cursor++] = pose.hidden() ? 1 : 0;
                signature[cursor++] = bone.getName().hashCode();
            }

            return new FrozenPoseKey(signature);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof FrozenPoseKey frozenPoseKey) || this.hash != frozenPoseKey.hash) {
                return false;
            }
            return Arrays.equals(this.signature, frozenPoseKey.signature);
        }

        @Override
        public int hashCode() {
            return this.hash;
        }
    }

    private record ThawTransitionState(Map<String, StaticGeoBonePose> bonePoses, long startedAtNanos) {
    }
}
