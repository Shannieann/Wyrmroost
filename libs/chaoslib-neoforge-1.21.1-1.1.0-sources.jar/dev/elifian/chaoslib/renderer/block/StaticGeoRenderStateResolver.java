package dev.elifian.chaoslib.renderer.block;

import dev.elifian.chaoslib.animatable.state.GeoRenderStateAccess;
import dev.elifian.chaoslib.animatable.state.GeoRenderStateTracker;
import dev.elifian.chaoslib.api.animatable.GeoBlockEntity;
import dev.elifian.chaoslib.model.baked.GeoStaticModelData;
import dev.elifian.chaoslib.model.baked.StaticGeoRenderMode;
import dev.elifian.chaoslib.platform.ClientOnly;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

/**
 * Resolves the static baked render state of a block entity, cached per world tick. Each loader
 * carries the result to its chunk mesher its own way: ModelData on NeoForge, a render attachment
 * on Fabric.
 */
@ClientOnly
public final class StaticGeoRenderStateResolver {
    @Nullable
    public GeoStaticModelData.State resolveState(GeoBlockEntity blockEntity) {
        if (!(blockEntity instanceof BlockEntity vanillaBlockEntity)) {
            return null;
        }

        GeoRenderStateAccess renderState = (GeoRenderStateAccess) vanillaBlockEntity;
        long worldTime = vanillaBlockEntity.getLevel() != null
                ? vanillaBlockEntity.getLevel().getGameTime()
                : Long.MIN_VALUE;
        if (renderState.getGeoModelDataLastWorldTime() == worldTime) {
            return emptyToNull(renderState.getGeoCachedStaticModelDataState());
        }

        if (vanillaBlockEntity.getLevel() != null && vanillaBlockEntity.getLevel().isClientSide()) {
            GeoRenderStateTracker.isActive(blockEntity);
        }

        BlockState state = vanillaBlockEntity.getBlockState();
        GeoStaticModelData.State staticState = new GeoStaticModelData.State(
                renderState.isGeoModelDataOnly() ? StaticGeoRenderMode.ALL_BONES : blockEntity.getGeoStaticRenderMode(state),
                blockEntity.getStaticPoseKey(state)
        );

        renderState.setGeoModelDataLastWorldTime(worldTime);
        renderState.setGeoCachedStaticModelDataState(staticState);
        return emptyToNull(staticState);
    }

    @Nullable
    private static GeoStaticModelData.State emptyToNull(@Nullable GeoStaticModelData.State state) {
        return state == null || state.isEmpty() ? null : state;
    }
}
