package dev.elifian.chaoslib.renderer.entity;

import dev.elifian.chaoslib.api.animatable.GeoAnimatable;
import dev.elifian.chaoslib.api.renderer.GeoEntityRenderer;
import dev.elifian.chaoslib.cache.object.BakedGeoModel;
import dev.elifian.chaoslib.model.GeoRenderPolicy;
import dev.elifian.chaoslib.model.GeoResourceSet;
import net.minecraft.client.renderer.MultiBufferSource;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;

import java.util.Set;

public final class GeoEntityRenderPipeline<T extends Entity & GeoAnimatable> {
    public void render(GeoEntityRenderer<T> renderer, T entity, float entityYaw, float partialTick, PoseStack poseStack, MultiBufferSource bufferSource, int packedLight) {
        GeoResourceSet<T> resources = renderer.getGeoModel().getResourceSet();
        GeoRenderPolicy<T> renderPolicy = renderer.getGeoModel().getRenderPolicy();
        BakedGeoModel model = renderer.getGeoModel().getBakedModel(resources.getModelResource(entity));
        ResourceLocation texture = resources.getTextureResource(entity);
        var dynamicSelection = renderPolicy.getLiveRenderBones(entity);
        Set<String> dynamicRenderBones;
        if (dynamicSelection.isAll() || dynamicSelection.isNone()) {
            dynamicRenderBones = null;
        } else {
            Set<String> resolved = dynamicSelection.resolve(model);
            dynamicRenderBones = resolved.isEmpty() ? null : resolved;
        }
        Set<String> emissiveRenderBones = renderPolicy.getResolvedEmissiveBones(entity, model, dynamicRenderBones);
        int packedOverlay = renderer.getPackedOverlay(entity, 0.0f);
        float renderAlpha = renderer.getRenderAlpha(entity, partialTick);
        renderer.primeResolvedRenderBones(dynamicRenderBones, emissiveRenderBones, dynamicSelection.isAll());

        poseStack.pushPose();
        renderer.preRender(poseStack, entity, model, bufferSource, null, false, partialTick, packedLight, packedOverlay, 1.0f, 1.0f, 1.0f, renderAlpha);
        renderer.actuallyRender(poseStack, entity, model, null, bufferSource, null, false, partialTick, packedLight, packedOverlay, 1.0f, 1.0f, 1.0f, renderAlpha, texture, entityYaw);
        renderer.postRender(poseStack, entity, model, bufferSource, null, false, partialTick, packedLight, packedOverlay, 1.0f, 1.0f, 1.0f, renderAlpha);
        poseStack.popPose();
    }
}
