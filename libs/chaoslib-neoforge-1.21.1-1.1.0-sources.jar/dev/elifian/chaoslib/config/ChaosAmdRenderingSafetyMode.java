package dev.elifian.chaoslib.config;

import com.google.gson.annotations.SerializedName;
import net.minecraft.network.chat.Component;

import dev.elifian.chaoslib.platform.ClientOnly;

@ClientOnly
public enum ChaosAmdRenderingSafetyMode {
    @SerializedName("auto")
    AUTO("auto"),
    @SerializedName("force_default")
    FORCE_DEFAULT("force_default"),
    @SerializedName("force_amd_safe")
    FORCE_AMD_SAFE("force_amd_safe");

    private final String translationSuffix;

    ChaosAmdRenderingSafetyMode(String translationSuffix) {
        this.translationSuffix = translationSuffix;
    }

    public Component displayText() {
        return Component.translatable("chaoslib.config.option.amd_rendering_safety_mode.value." + this.translationSuffix);
    }
}
