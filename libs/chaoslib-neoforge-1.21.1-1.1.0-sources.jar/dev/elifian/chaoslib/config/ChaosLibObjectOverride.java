package dev.elifian.chaoslib.config;

import dev.elifian.chaoslib.compat.sodium.ChaosSodiumGpuSkinningMode;

import dev.elifian.chaoslib.platform.ClientOnly;

@ClientOnly
public final class ChaosLibObjectOverride {
    public boolean enabled;
    public int freezeRadius;
    public int modelDataRadius;
    public boolean keepAnimatedBones;
    public ChaosSodiumGpuSkinningMode gpuSkinningMode = ChaosSodiumGpuSkinningMode.AUTO;

    public ChaosLibObjectOverride(int freezeRadius, int modelDataRadius) {
        this.freezeRadius = freezeRadius;
        this.modelDataRadius = modelDataRadius;
    }

    public ChaosLibObjectOverride copy() {
        ChaosLibObjectOverride copy = new ChaosLibObjectOverride(this.freezeRadius, this.modelDataRadius);
        copy.enabled = this.enabled;
        copy.keepAnimatedBones = this.keepAnimatedBones;
        copy.gpuSkinningMode = this.gpuSkinningMode;
        return copy;
    }
}
