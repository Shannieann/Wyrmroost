package dev.elifian.chaoslib.config;


import dev.elifian.chaoslib.platform.ClientOnly;

import java.util.LinkedHashMap;
import java.util.Map;

@ClientOnly
public final class ChaosLibSodiumOptions {
    public boolean enableForcedBlockEntityDistances;
    public int forcedFreezeRadius = 64;
    public int forcedModelDataRadius = 64;
    public boolean keepFrozenLiveBonesOnBer;
    public boolean showDebugOverlay;
    public Map<String, ChaosLibObjectOverride> objectOverrides = new LinkedHashMap<>();

    public ChaosLibObjectOverride getOrCreateObjectOverride(String key, int defaultFreezeRadius, int defaultModelDataRadius) {
        return this.objectOverrides.computeIfAbsent(key, ignored -> new ChaosLibObjectOverride(defaultFreezeRadius, defaultModelDataRadius));
    }

    public ChaosLibSodiumOptions copy() {
        ChaosLibSodiumOptions copy = new ChaosLibSodiumOptions();
        copy.enableForcedBlockEntityDistances = this.enableForcedBlockEntityDistances;
        copy.forcedFreezeRadius = this.forcedFreezeRadius;
        copy.forcedModelDataRadius = this.forcedModelDataRadius;
        copy.keepFrozenLiveBonesOnBer = this.keepFrozenLiveBonesOnBer;
        copy.showDebugOverlay = this.showDebugOverlay;
        copy.objectOverrides = new LinkedHashMap<>();
        this.objectOverrides.forEach((key, value) -> copy.objectOverrides.put(key, value.copy()));
        return copy;
    }
}
