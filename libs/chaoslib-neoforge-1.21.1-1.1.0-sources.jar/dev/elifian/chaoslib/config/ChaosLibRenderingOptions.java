package dev.elifian.chaoslib.config;


import dev.elifian.chaoslib.platform.ClientOnly;

@ClientOnly
public final class ChaosLibRenderingOptions {
    public ChaosAmdRenderingSafetyMode amdRenderingSafetyMode = ChaosAmdRenderingSafetyMode.AUTO;

    public ChaosLibRenderingOptions copy() {
        ChaosLibRenderingOptions copy = new ChaosLibRenderingOptions();
        copy.amdRenderingSafetyMode = this.amdRenderingSafetyMode;
        return copy;
    }
}
