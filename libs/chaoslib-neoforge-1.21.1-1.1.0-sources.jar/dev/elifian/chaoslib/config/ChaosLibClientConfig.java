package dev.elifian.chaoslib.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dev.elifian.chaoslib.ChaosLib;
import dev.elifian.chaoslib.client.render.StaticOnlyBlockEntityRenderCache;
import dev.elifian.chaoslib.compat.sodium.ChaosSodiumBlockEntitySettings;
import dev.elifian.chaoslib.compat.sodium.ChaosSodiumGpuSkinningMode;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuBoneResolveDispatcher;
import dev.elifian.chaoslib.gpu.render.ChaosGpuShaderPackRenderer;
import dev.elifian.chaoslib.renderer.block.ChaosBlockEntityRenderDispatch;
import net.minecraft.client.Minecraft;

import dev.elifian.chaoslib.platform.ClientOnly;
import dev.elifian.chaoslib.platform.Services;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Objects;

@ClientOnly
public final class ChaosLibClientConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = Services.PLATFORM.configDirectory().resolve("chaoslib").resolve("chaoslib-client.json");
    private static ChaosLibClientOptions options = new ChaosLibClientOptions();
    private static boolean loaded;
    private static long version;

    private ChaosLibClientConfig() {
    }

    public static void load() {
        if (loaded) {
            return;
        }

        loaded = true;
        if (Files.exists(CONFIG_PATH)) {
            try (Reader reader = Files.newBufferedReader(CONFIG_PATH)) {
                ChaosLibClientOptions loadedOptions = GSON.fromJson(reader, ChaosLibClientOptions.class);
                options = sanitize(loadedOptions == null ? new ChaosLibClientOptions() : loadedOptions);
                save();
                return;
            } catch (IOException exception) {
                ChaosLib.LOGGER.warn("Failed to load ChaosLib client config, using defaults", exception);
                options = new ChaosLibClientOptions();
            }
        }

        sanitize(options);
        save();
    }

    public static ChaosLibClientOptions get() {
        load();
        return options;
    }

    public static ChaosLibSodiumOptions sodium() {
        return get().sodium;
    }

    public static ChaosLibRenderingOptions rendering() {
        return get().rendering;
    }

    public static ChaosLibAdditionalOptions additional() {
        return get().additional;
    }

    public static long version() {
        load();
        return version;
    }

    public static void apply(ChaosLibClientOptions updatedOptions) {
        options = sanitize(updatedOptions.copy());
        version++;
        save();
        invalidateRuntimeState();
    }

    private static void save() {
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            try (Writer writer = Files.newBufferedWriter(CONFIG_PATH)) {
                GSON.toJson(options, writer);
            }
        } catch (IOException exception) {
            ChaosLib.LOGGER.warn("Failed to save ChaosLib client config", exception);
        }
    }

    private static ChaosLibClientOptions sanitize(ChaosLibClientOptions value) {
        if (value.rendering == null) {
            value.rendering = new ChaosLibRenderingOptions();
        }
        if (value.rendering.amdRenderingSafetyMode == null) {
            value.rendering.amdRenderingSafetyMode = ChaosAmdRenderingSafetyMode.AUTO;
        }

        if (value.sodium == null) {
            value.sodium = new ChaosLibSodiumOptions();
        }
        sanitizeSodium(value.sodium);
        return value;
    }

    private static void sanitizeSodium(ChaosLibSodiumOptions value) {
        value.forcedFreezeRadius = Math.max(0, Math.min(256, value.forcedFreezeRadius));
        value.forcedModelDataRadius = Math.max(0, Math.min(256, value.forcedModelDataRadius));
        if (value.objectOverrides == null) {
            value.objectOverrides = new LinkedHashMap<>();
        } else {
            value.objectOverrides.values().removeIf(Objects::isNull);
            value.objectOverrides.values().forEach(override -> {
                override.freezeRadius = Math.max(0, Math.min(256, override.freezeRadius));
                override.modelDataRadius = Math.max(0, Math.min(256, override.modelDataRadius));
                if (override.gpuSkinningMode == null) {
                    override.gpuSkinningMode = ChaosSodiumGpuSkinningMode.AUTO;
                }
            });
        }
    }

    private static void invalidateRuntimeState() {
        ChaosBlockEntityRenderDispatch.setDiagnosticsEnabled(options.sodium.showDebugOverlay);
        ChaosSodiumBlockEntitySettings.clearRuntimeCache();
        StaticOnlyBlockEntityRenderCache.clear();
        Services.STATIC_MODELS.clearStaticRenderCaches();
        ChaosGpuShaderPackRenderer.invalidateAll();
        // Drop GPU buffers of both resolve backends so a live amdRenderingSafetyMode switch
        // (COMPUTE <-> TRANSFORM_FEEDBACK) does not leak the previous backend's allocations.
        ChaosGpuBoneResolveDispatcher.invalidateAll();
        Minecraft client = Minecraft.getInstance();
        if (client.levelRenderer != null) {
            client.levelRenderer.allChanged();
        }
    }
}
