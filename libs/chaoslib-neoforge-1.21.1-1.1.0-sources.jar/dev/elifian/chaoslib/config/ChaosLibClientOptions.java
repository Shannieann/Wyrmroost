package dev.elifian.chaoslib.config;


import dev.elifian.chaoslib.platform.ClientOnly;

@ClientOnly
public final class ChaosLibClientOptions {
    public ChaosLibRenderingOptions rendering = new ChaosLibRenderingOptions();
    public ChaosLibSodiumOptions sodium = new ChaosLibSodiumOptions();
    public ChaosLibAdditionalOptions additional = new ChaosLibAdditionalOptions();

    public ChaosLibClientOptions copy() {
        ChaosLibClientOptions copy = new ChaosLibClientOptions();
        copy.rendering = this.rendering.copy();
        copy.sodium = this.sodium.copy();
        copy.additional = this.additional.copy();
        return copy;
    }
}
