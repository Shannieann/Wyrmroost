package dev.elifian.chaoslib.config;


import dev.elifian.chaoslib.platform.ClientOnly;

@ClientOnly
public final class ChaosLibAdditionalOptions {
    public boolean wideSodiumVideoSettings = true;

    public ChaosLibAdditionalOptions copy() {
        ChaosLibAdditionalOptions copy = new ChaosLibAdditionalOptions();
        copy.wideSodiumVideoSettings = this.wideSodiumVideoSettings;
        return copy;
    }
}
