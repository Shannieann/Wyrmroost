package dev.elifian.chaoslib.util;

import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerChunkCache;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.function.Consumer;

public final class TrackingPlayerUtil {
    private static final Map<ServerLevel, ChunkWatcherSnapshot> WATCHER_CACHE = new WeakHashMap<>();

    private TrackingPlayerUtil() {
    }

    public static List<ServerPlayer> getChunkTrackingPlayers(BlockEntity blockEntity, ServerLevel serverWorld) {
        return getChunkTrackingPlayers(new ChunkPos(blockEntity.getBlockPos()), serverWorld);
    }

    public static List<ServerPlayer> getChunkTrackingPlayers(Entity entity, ServerLevel serverWorld) {
        return getChunkTrackingPlayers(entity.chunkPosition(), serverWorld);
    }

    public static void forEachPlayerInRange(BlockEntity blockEntity, ServerLevel serverWorld, double radiusSquared, Consumer<ServerPlayer> consumer) {
        BlockPos pos = blockEntity.getBlockPos();
        double x = pos.getX() + 0.5d;
        double y = pos.getY() + 0.5d;
        double z = pos.getZ() + 0.5d;

        for (ServerPlayer player : getChunkTrackingPlayers(blockEntity, serverWorld)) {
            if (player.distanceToSqr(x, y, z) <= radiusSquared) {
                consumer.accept(player);
            }
        }
    }

    private static List<ServerPlayer> getChunkTrackingPlayers(ChunkPos chunkPos, ServerLevel serverWorld) {
        return WATCHER_CACHE
                .computeIfAbsent(serverWorld, ignored -> new ChunkWatcherSnapshot())
                .getOrCreate(serverWorld, chunkPos);
    }

    private static long toChunkKey(int chunkX, int chunkZ) {
        return ((long) chunkX << 32) ^ (chunkZ & 0xFFFFFFFFL);
    }

    private static final class ChunkWatcherSnapshot {
        private final Map<Long, List<ServerPlayer>> playersByChunk = new HashMap<>();
        private long gameTime = Long.MIN_VALUE;

        private List<ServerPlayer> getOrCreate(ServerLevel serverWorld, ChunkPos chunkPos) {
            long currentTime = serverWorld.getGameTime();
            if (this.gameTime != currentTime) {
                this.gameTime = currentTime;
                this.playersByChunk.clear();
            }

            long chunkKey = toChunkKey(chunkPos.x, chunkPos.z);
            return this.playersByChunk.computeIfAbsent(chunkKey, ignored -> List.copyOf(
                    ((ServerChunkCache) serverWorld.getChunkSource())
                            .chunkMap
                            .getPlayersCloseForSpawning(chunkPos)
            ));
        }
    }
}
