package dev.elifian.chaoslib.util;

import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.Nullable;

public final class IdentifierUtil {
    private IdentifierUtil() {
    }

    public static ResourceLocation id(String namespace, String path) {
        return ResourceLocation.fromNamespaceAndPath(namespace, path);
    }

    public static @Nullable ResourceLocation deriveEmissiveTexture(@Nullable ResourceLocation baseTextureId) {
        if (baseTextureId == null) {
            return null;
        }

        String path = baseTextureId.getPath();
        int extensionIndex = path.lastIndexOf('.');
        String emissivePath = extensionIndex >= 0
                ? path.substring(0, extensionIndex) + "_e" + path.substring(extensionIndex)
                : path + "_e";
        return ResourceLocation.fromNamespaceAndPath(baseTextureId.getNamespace(), emissivePath);
    }
}
