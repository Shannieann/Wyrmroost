package dev.elifian.chaoslib.util;

import dev.elifian.chaoslib.api.animatable.GeoAnimatable;
import dev.elifian.chaoslib.animatable.cache.AnimatableInstanceCache;

public final class ChaosLibUtil {
    private ChaosLibUtil() {
    }

    public static AnimatableInstanceCache createInstanceCache(GeoAnimatable animatable) {
        return new AnimatableInstanceCache(animatable);
    }
}
