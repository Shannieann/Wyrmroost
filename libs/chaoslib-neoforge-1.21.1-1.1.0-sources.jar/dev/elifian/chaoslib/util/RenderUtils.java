package dev.elifian.chaoslib.util;

import dev.elifian.chaoslib.cache.object.GeoBone;
import dev.elifian.chaoslib.cache.object.GeoCube;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;

import dev.elifian.chaoslib.platform.ClientOnly;
import org.joml.Matrix4f;

@ClientOnly
public final class RenderUtils {
    private RenderUtils() {
    }

    public static void translateMatrixToBone(PoseStack poseStack, GeoBone bone) {
        poseStack.translate(-bone.getPosX() / 16.0f, bone.getPosY() / 16.0f, bone.getPosZ() / 16.0f);
    }

    public static void rotateMatrixAroundBone(PoseStack poseStack, GeoBone bone) {
        if (bone.getRotZ() != 0.0f) {
            poseStack.mulPose(Axis.ZP.rotation(bone.getRotZ()));
        }
        if (bone.getRotY() != 0.0f) {
            poseStack.mulPose(Axis.YP.rotation(bone.getRotY()));
        }
        if (bone.getRotX() != 0.0f) {
            poseStack.mulPose(Axis.XP.rotation(bone.getRotX()));
        }
    }

    public static void rotateMatrixAroundCube(PoseStack poseStack, GeoCube cube) {
        float rotZ = (float) cube.rotation().z();
        float rotY = (float) cube.rotation().y();
        float rotX = (float) cube.rotation().x();

        if (rotZ != 0.0f) {
            poseStack.mulPose(Axis.ZP.rotation(rotZ));
        }
        if (rotY != 0.0f) {
            poseStack.mulPose(Axis.YP.rotation(rotY));
        }
        if (rotX != 0.0f) {
            poseStack.mulPose(Axis.XP.rotation(rotX));
        }
    }

    public static void scaleMatrixForBone(PoseStack poseStack, GeoBone bone) {
        poseStack.scale(bone.getScaleX(), bone.getScaleY(), bone.getScaleZ());
    }

    public static void translateToPivotPoint(PoseStack poseStack, GeoBone bone) {
        poseStack.translate(bone.getPivotX() / 16.0f, bone.getPivotY() / 16.0f, bone.getPivotZ() / 16.0f);
    }

    public static void translateToPivotPoint(PoseStack poseStack, GeoCube cube) {
        poseStack.translate(cube.pivot().x() / 16.0f, cube.pivot().y() / 16.0f, cube.pivot().z() / 16.0f);
    }

    public static void translateAwayFromPivotPoint(PoseStack poseStack, GeoBone bone) {
        poseStack.translate(-bone.getPivotX() / 16.0f, -bone.getPivotY() / 16.0f, -bone.getPivotZ() / 16.0f);
    }

    public static void translateAwayFromPivotPoint(PoseStack poseStack, GeoCube cube) {
        poseStack.translate(-cube.pivot().x() / 16.0f, -cube.pivot().y() / 16.0f, -cube.pivot().z() / 16.0f);
    }

    public static void prepMatrixForBone(PoseStack poseStack, GeoBone bone) {
        translateMatrixToBone(poseStack, bone);
        translateToPivotPoint(poseStack, bone);
        rotateMatrixAroundBone(poseStack, bone);
        scaleMatrixForBone(poseStack, bone);
        translateAwayFromPivotPoint(poseStack, bone);
    }

    public static Matrix4f invertAndMultiplyMatrices(Matrix4f baseMatrix, Matrix4f inputMatrix) {
        Matrix4f matrix = new Matrix4f(inputMatrix);
        matrix.invert();
        matrix.mul(baseMatrix);
        return matrix;
    }
}
