package dev.elifian.chaoslib.client.render;


import dev.elifian.chaoslib.platform.ClientOnly;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

@ClientOnly
public final class StaticOnlyBlockEntityRenderCache {
    private static final ConcurrentMap<Class<?>, Boolean> STATIC_ONLY_BLOCK_ENTITY_CLASSES = new ConcurrentHashMap<>();
    private static Class<?> lastBlockEntityClass;
    private static Boolean lastStaticOnly;

    private StaticOnlyBlockEntityRenderCache() {
    }

    public static Boolean get(Class<?> blockEntityClass) {
        if (blockEntityClass == lastBlockEntityClass) {
            return lastStaticOnly;
        }

        return STATIC_ONLY_BLOCK_ENTITY_CLASSES.get(blockEntityClass);
    }

    public static void put(Class<?> blockEntityClass, boolean staticOnly) {
        STATIC_ONLY_BLOCK_ENTITY_CLASSES.put(blockEntityClass, staticOnly);
        lastBlockEntityClass = blockEntityClass;
        lastStaticOnly = staticOnly;
    }

    public static void clear() {
        STATIC_ONLY_BLOCK_ENTITY_CLASSES.clear();
        lastBlockEntityClass = null;
        lastStaticOnly = null;
    }
}
