package dev.elifian.chaoslib.client.render;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.elifian.chaoslib.gpu.shader.ChaosGuiShaderManager;
import net.minecraft.client.Minecraft;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.shaders.Uniform;
import net.minecraft.client.renderer.ShaderInstance;
import com.mojang.blaze3d.pipeline.TextureTarget;
import net.minecraft.client.gui.GuiGraphics;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;

import dev.elifian.chaoslib.platform.ClientOnly;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL30C;

/**
 * Blurs the scene already drawn into the main framebuffer behind a small GUI region (a debug panel),
 * cheaply and without a full-screen post pass.
 *
 * <p>The framebuffer cannot be sampled while it is also the draw target (feedback), so the region is first
 * snapshotted into a reusable off-screen framebuffer via {@code glBlitFramebuffer}, then a single Gaussian
 * pass ({@code chaoslib:gui_blur}) samples the snapshot into just the panel rectangle. Because the blurred
 * area is tiny the cost is negligible. Everything is wrapped so any failure (shader missing, GL issue) falls
 * back to no blur rather than breaking the HUD - callers should still draw their own darkening on top.</p>
 */
@ClientOnly
public final class ChaosGuiBlurRenderer {
    private static TextureTarget snapshot;

    private ChaosGuiBlurRenderer() {
    }

    public static void invalidate() {
        if (snapshot != null) {
            snapshot.destroyBuffers();
            snapshot = null;
        }
    }

    /**
     * Blurs the scene behind the GUI rectangle {@code (x, y, width, height)}. Returns {@code false} (drawing
     * nothing) when blur is unavailable, so the caller can fall back to a plain darkened panel.
     */
    public static boolean blur(GuiGraphics context, int x, int y, int width, int height) {
        ShaderInstance shader = ChaosGuiShaderManager.getGuiBlurShader();
        if (shader == null || width <= 0 || height <= 0) {
            return false;
        }

        Minecraft client = Minecraft.getInstance();
        RenderTarget main = client.getMainRenderTarget();
        int fbWidth = main.width;
        int fbHeight = main.height;
        if (fbWidth <= 0 || fbHeight <= 0) {
            return false;
        }

        try {
            ensureSnapshot(fbWidth, fbHeight);

            GlStateManager._glBindFramebuffer(GL30C.GL_READ_FRAMEBUFFER, main.frameBufferId);
            GlStateManager._glBindFramebuffer(GL30C.GL_DRAW_FRAMEBUFFER, snapshot.frameBufferId);
            GlStateManager._glBlitFrameBuffer(
                    0, 0, fbWidth, fbHeight,
                    0, 0, fbWidth, fbHeight,
                    GL11.GL_COLOR_BUFFER_BIT, GL11.GL_NEAREST
            );
            main.bindWrite(false);

            float scale = (float) client.getWindow().getGuiScale();
            float leftU = (x * scale) / fbWidth;
            float rightU = ((x + width) * scale) / fbWidth;
            float topV = 1.0f - (y * scale) / fbHeight;
            float bottomV = 1.0f - ((y + height) * scale) / fbHeight;

            RenderSystem.setShader(ChaosGuiShaderManager::getGuiBlurShader);
            RenderSystem.setShaderTexture(0, snapshot.getColorTextureId());
            Uniform texelSize = shader.getUniform("BlurTexelSize");
            if (texelSize != null) {
                texelSize.set(1.0f / fbWidth, 1.0f / fbHeight);
            }
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.disableCull();

            Matrix4f matrix = context.pose().last().pose();
            Tesselator tessellator = Tesselator.getInstance();
            BufferBuilder buffer = tessellator.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX);
            buffer.addVertex(matrix, x, y, 0.0f).setUv(leftU, topV);
            buffer.addVertex(matrix, x, y + height, 0.0f).setUv(leftU, bottomV);
            buffer.addVertex(matrix, x + width, y + height, 0.0f).setUv(rightU, bottomV);
            buffer.addVertex(matrix, x + width, y, 0.0f).setUv(rightU, topV);
            BufferUploader.drawWithShader(buffer.buildOrThrow());

            RenderSystem.enableCull();
            return true;
        } catch (Throwable throwable) {
            // Never let a HUD blur break rendering; fall back to the plain darkened panel.
            return false;
        }
    }

    private static void ensureSnapshot(int width, int height) {
        if (snapshot == null) {
            snapshot = new TextureTarget(width, height, false, Minecraft.ON_OSX);
        } else if (snapshot.width != width || snapshot.height != height) {
            snapshot.resize(width, height, Minecraft.ON_OSX);
        }
    }
}
