package dev.elifian.chaoslib.client.render;

import dev.elifian.chaoslib.api.animatable.GeoAnimatable;
import dev.elifian.chaoslib.client.color.ChaosColorUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.Util;

import dev.elifian.chaoslib.platform.ClientOnly;

import java.util.HashMap;
import java.util.Map;
import java.util.WeakHashMap;

@ClientOnly
public final class LiveRenderColorInterpolator {
    private static final Map<GeoAnimatable, Map<String, ColorState>> STATES = new WeakHashMap<>();

    private LiveRenderColorInterpolator() {
    }

    public static int resolve(GeoAnimatable animatable, String channel, int targetColor, float partialTick, float transitionRate) {
        if (!Float.isFinite(transitionRate) || transitionRate <= 0.0f) {
            return targetColor;
        }

        double currentTime = currentRenderTime(partialTick);
        Map<String, ColorState> channels = STATES.computeIfAbsent(animatable, ignored -> new HashMap<>());
        ColorState state = channels.get(channel);
        if (state == null) {
            channels.put(channel, new ColorState(targetColor, currentTime));
            return targetColor;
        }

        double deltaTicks = Math.max(0.0d, Math.min(20.0d, currentTime - state.lastSampleTime));
        state.lastSampleTime = currentTime;
        if (state.currentColor == targetColor) {
            return targetColor;
        }

        double baseRate = Math.max(0.0d, Math.min(0.999f, transitionRate));
        double blend = deltaTicks <= 0.0d ? baseRate : 1.0d - Math.pow(1.0d - baseRate, deltaTicks);
        state.currentColor = ChaosColorUtils.interpolateArgb(state.currentColor, targetColor, (float) blend);
        if (isCloseEnough(state.currentColor, targetColor)) {
            state.currentColor = targetColor;
        }
        return state.currentColor;
    }

    private static double currentRenderTime(float partialTick) {
        Minecraft client = Minecraft.getInstance();
        if (client != null && client.level != null) {
            return client.level.getGameTime() + partialTick;
        }
        return Util.getMillis() / 50.0d;
    }

    private static boolean isCloseEnough(int current, int target) {
        return Math.abs(((current >>> 24) & 0xFF) - ((target >>> 24) & 0xFF)) <= 1
                && Math.abs(((current >>> 16) & 0xFF) - ((target >>> 16) & 0xFF)) <= 1
                && Math.abs(((current >>> 8) & 0xFF) - ((target >>> 8) & 0xFF)) <= 1
                && Math.abs((current & 0xFF) - (target & 0xFF)) <= 1;
    }

    private static final class ColorState {
        private int currentColor;
        private double lastSampleTime;

        private ColorState(int currentColor, double lastSampleTime) {
            this.currentColor = currentColor;
            this.lastSampleTime = lastSampleTime;
        }
    }
}
