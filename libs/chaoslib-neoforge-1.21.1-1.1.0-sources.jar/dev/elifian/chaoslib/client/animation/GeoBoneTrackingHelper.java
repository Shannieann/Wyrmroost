package dev.elifian.chaoslib.client.animation;

import dev.elifian.chaoslib.api.animatable.GeoBoneTrackingAnimatable;
import dev.elifian.chaoslib.cache.object.GeoBone;
import dev.elifian.chaoslib.api.multipart.GeoTrackedBonePose;
import dev.elifian.chaoslib.util.RenderUtils;
import net.minecraft.world.entity.Entity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.world.phys.Vec3;

import dev.elifian.chaoslib.platform.ClientOnly;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;

@ClientOnly
public final class GeoBoneTrackingHelper {
    private GeoBoneTrackingHelper() {
    }

    public static Map<String, GeoTrackedBonePose> collectWorldPoses(Set<String> boneNames, Function<String, Optional<GeoBone>> boneResolver) {
        if (boneNames.isEmpty()) {
            return Map.of();
        }

        LinkedHashMap<String, GeoTrackedBonePose> poses = new LinkedHashMap<>(boneNames.size());
        for (String boneName : boneNames) {
            boneResolver.apply(boneName).ifPresent(bone -> poses.put(
                    boneName,
                    GeoTrackedBonePose.fromMatrix(bone.getWorldSpaceMatrix(), bone.getPivotX(), bone.getPivotY(), bone.getPivotZ())
            ));
        }
        return poses.isEmpty() ? Map.of() : poses;
    }

    public static Map<String, GeoTrackedBonePose> collectResolvedWorldPoses(
            Iterable<GeoBone> bones,
            float[] resolvedMatrices,
            Set<String> trackedBoneNames,
            Matrix4f rootTransform,
            @Nullable Vec3 worldOffset
    ) {
        if (trackedBoneNames.isEmpty() || resolvedMatrices == null) {
            return Map.of();
        }

        LinkedHashMap<String, GeoTrackedBonePose> poses = new LinkedHashMap<>(trackedBoneNames.size());
        int boneIndex = 0;
        for (GeoBone bone : bones) {
            int base = boneIndex * 16;
            if (base + 15 >= resolvedMatrices.length) {
                break;
            }
            if (trackedBoneNames.contains(bone.getName())) {
                Matrix4f worldMatrix = new Matrix4f(rootTransform).mul(readResolvedMatrix(resolvedMatrices, base));
                if (worldOffset != null) {
                    worldMatrix.translate((float) worldOffset.x, (float) worldOffset.y, (float) worldOffset.z);
                }
                poses.put(bone.getName(), GeoTrackedBonePose.fromMatrix(worldMatrix, bone.getPivotX(), bone.getPivotY(), bone.getPivotZ()));
            }
            boneIndex++;
        }
        return poses.isEmpty() ? Map.of() : poses;
    }

    public static Map<String, GeoTrackedBonePose> collectResolvedEntityBonePoses(
            Iterable<GeoBone> bones,
            float[] resolvedMatrices,
            Set<String> trackedBoneNames,
            Matrix4f rootTransform,
            Matrix4f entityRenderTranslations,
            Entity entity
    ) {
        if (trackedBoneNames.isEmpty() || resolvedMatrices == null) {
            return Map.of();
        }

        LinkedHashMap<String, GeoTrackedBonePose> poses = new LinkedHashMap<>(trackedBoneNames.size());
        int boneIndex = 0;
        float entityX = (float) entity.getX();
        float entityY = (float) entity.getY();
        float entityZ = (float) entity.getZ();
        for (GeoBone bone : bones) {
            int base = boneIndex * 16;
            if (base + 15 >= resolvedMatrices.length) {
                break;
            }
            if (trackedBoneNames.contains(bone.getName())) {
                Matrix4f poseState = new Matrix4f(rootTransform).mul(readResolvedMatrix(resolvedMatrices, base));
                Matrix4f localMatrix = RenderUtils.invertAndMultiplyMatrices(poseState, entityRenderTranslations);
                Matrix4f worldMatrix = new Matrix4f()
                        .translation(entityX, entityY, entityZ)
                        .mul(localMatrix);
                poses.put(bone.getName(), GeoTrackedBonePose.fromMatrix(worldMatrix, bone.getPivotX(), bone.getPivotY(), bone.getPivotZ()));
            }
            boneIndex++;
        }
        return poses.isEmpty() ? Map.of() : poses;
    }

    public static Map<String, Vec3> collectWorldPositions(Set<String> boneNames, Function<String, Optional<GeoBone>> boneResolver) {
        Map<String, GeoTrackedBonePose> poses = collectWorldPoses(boneNames, boneResolver);
        if (poses.isEmpty()) {
            return Map.of();
        }

        LinkedHashMap<String, Vec3> positions = new LinkedHashMap<>();
        for (Map.Entry<String, GeoTrackedBonePose> entry : poses.entrySet()) {
            positions.put(entry.getKey(), entry.getValue().position());
        }
        return Map.copyOf(positions);
    }

    public static void updateTrackedBonePoses(GeoBoneTrackingAnimatable animatable, Function<String, Optional<GeoBone>> boneResolver) {
        Map<String, GeoTrackedBonePose> poses = collectWorldPoses(animatable.getTrackedBones(), boneResolver);
        animatable.receiveTrackedBonePoses(poses);
    }

    public static Map<String, GeoTrackedBonePose> captureTrackedEntityBonePoses(
            Iterable<GeoBone> topLevelBones,
            Set<String> trackedBoneNames,
            Matrix4f rootTransform,
            Matrix4f entityRenderTranslations,
            Matrix4f modelRenderTranslations,
            Entity entity
    ) {
        if (trackedBoneNames.isEmpty()) {
            return Map.of();
        }
        Set<String> trackedBones = trackedBoneNames instanceof HashSet<?> ? trackedBoneNames : new HashSet<>(trackedBoneNames);
        float entityX = (float) entity.getX();
        float entityY = (float) entity.getY();
        float entityZ = (float) entity.getZ();

        PoseStack trackingStack = new PoseStack();
        trackingStack.last().pose().set(rootTransform);
        LinkedHashMap<String, GeoTrackedBonePose> poses = new LinkedHashMap<>(trackedBones.size());
        for (GeoBone bone : topLevelBones) {
            captureTrackedEntityBonePosesRecursively(
                    trackingStack,
                    bone,
                    trackedBones,
                    entityRenderTranslations,
                    modelRenderTranslations,
                    entityX,
                    entityY,
                    entityZ,
                    poses
            );
        }
        return poses.isEmpty() ? Map.of() : poses;
    }

    public static void updateTrackedBonePoses(
            GeoBoneTrackingAnimatable animatable,
            Iterable<GeoBone> bones,
            float[] resolvedMatrices,
            Matrix4f rootTransform,
            @Nullable Vec3 worldOffset
    ) {
        Map<String, GeoTrackedBonePose> poses = collectResolvedWorldPoses(
                bones,
                resolvedMatrices,
                animatable.getTrackedBones(),
                rootTransform,
                worldOffset
        );
        animatable.receiveTrackedBonePoses(poses);
    }

    public static void updateTrackedEntityBonePoses(
            GeoBoneTrackingAnimatable animatable,
            Iterable<GeoBone> bones,
            float[] resolvedMatrices,
            Matrix4f rootTransform,
            Matrix4f entityRenderTranslations,
            Entity entity
    ) {
        Map<String, GeoTrackedBonePose> poses = collectResolvedEntityBonePoses(
                bones,
                resolvedMatrices,
                animatable.getTrackedBones(),
                rootTransform,
                entityRenderTranslations,
                entity
        );
        animatable.receiveTrackedBonePoses(poses);
    }

    public static void captureTrackedBoneMatrices(Iterable<GeoBone> topLevelBones, Set<String> trackedBoneNames, Matrix4f rootTransform, @Nullable Vec3 worldOffset) {
        if (trackedBoneNames.isEmpty()) {
            return;
        }

        PoseStack trackingStack = new PoseStack();
        trackingStack.last().pose().set(rootTransform);
        for (GeoBone bone : topLevelBones) {
            captureTrackedBoneMatricesRecursively(trackingStack, bone, trackedBoneNames, worldOffset);
        }
    }

    public static void captureTrackedEntityBoneMatrices(
            Iterable<GeoBone> topLevelBones,
            Set<String> trackedBoneNames,
            Matrix4f rootTransform,
            Matrix4f entityRenderTranslations,
            Matrix4f modelRenderTranslations,
            Entity entity
    ) {
        if (trackedBoneNames.isEmpty()) {
            return;
        }

        PoseStack trackingStack = new PoseStack();
        trackingStack.last().pose().set(rootTransform);
        for (GeoBone bone : topLevelBones) {
            captureTrackedEntityBoneMatricesRecursively(
                    trackingStack,
                    bone,
                    trackedBoneNames,
                    entityRenderTranslations,
                    modelRenderTranslations,
                    entity
            );
        }
    }

    public static void captureTrackedResolvedBoneMatrices(Iterable<GeoBone> bones, float[] resolvedMatrices, Set<String> trackedBoneNames, Matrix4f rootTransform, @Nullable Vec3 worldOffset) {
        if (trackedBoneNames.isEmpty() || resolvedMatrices == null) {
            return;
        }

        int boneIndex = 0;
        for (GeoBone bone : bones) {
            int base = boneIndex * 16;
            if (base + 15 >= resolvedMatrices.length) {
                break;
            }

            Matrix4f worldMatrix = new Matrix4f(rootTransform).mul(readResolvedMatrix(resolvedMatrices, base));
            if (bone.isTrackingMatrices() || trackedBoneNames.contains(bone.getName())) {
                if (worldOffset != null) {
                    worldMatrix = new Matrix4f(worldMatrix).translate((float) worldOffset.x, (float) worldOffset.y, (float) worldOffset.z);
                }
                bone.setWorldSpaceMatrix(worldMatrix);
            }
            boneIndex++;
        }
    }

    private static void captureTrackedBoneMatricesRecursively(PoseStack poseStack, GeoBone bone, Set<String> trackedBoneNames, @Nullable Vec3 worldOffset) {
        poseStack.pushPose();
        RenderUtils.prepMatrixForBone(poseStack, bone);

        if (bone.isTrackingMatrices() || trackedBoneNames.contains(bone.getName())) {
            Matrix4f worldState = new Matrix4f(poseStack.last().pose());
            if (worldOffset != null) {
                worldState.translate((float) worldOffset.x, (float) worldOffset.y, (float) worldOffset.z);
            }
            bone.setWorldSpaceMatrix(worldState);
        }

        if (!bone.isHidingChildren()) {
            for (GeoBone childBone : bone.getChildBones()) {
                captureTrackedBoneMatricesRecursively(poseStack, childBone, trackedBoneNames, worldOffset);
            }
        }

        poseStack.popPose();
    }

    private static void captureTrackedEntityBoneMatricesRecursively(
            PoseStack poseStack,
            GeoBone bone,
            Set<String> trackedBoneNames,
            Matrix4f entityRenderTranslations,
            Matrix4f modelRenderTranslations,
            Entity entity
    ) {
        poseStack.pushPose();
        RenderUtils.prepMatrixForBone(poseStack, bone);

        if (bone.isTrackingMatrices() || trackedBoneNames.contains(bone.getName())) {
            Matrix4f poseState = new Matrix4f(poseStack.last().pose());
            Matrix4f localMatrix = RenderUtils.invertAndMultiplyMatrices(poseState, entityRenderTranslations);
            Matrix4f worldState = new Matrix4f()
                    .translation((float) entity.getX(), (float) entity.getY(), (float) entity.getZ())
                    .mul(localMatrix);

            bone.setModelSpaceMatrix(RenderUtils.invertAndMultiplyMatrices(poseState, modelRenderTranslations));
            bone.setLocalSpaceMatrix(localMatrix);
            bone.setWorldSpaceMatrix(worldState);
        }

        if (!bone.isHidingChildren()) {
            for (GeoBone childBone : bone.getChildBones()) {
                captureTrackedEntityBoneMatricesRecursively(
                        poseStack,
                        childBone,
                        trackedBoneNames,
                        entityRenderTranslations,
                        modelRenderTranslations,
                        entity
                );
            }
        }

        poseStack.popPose();
    }

    private static void captureTrackedEntityBonePosesRecursively(
            PoseStack poseStack,
            GeoBone bone,
            Set<String> trackedBoneNames,
            Matrix4f entityRenderTranslations,
            Matrix4f modelRenderTranslations,
            float entityX,
            float entityY,
            float entityZ,
            Map<String, GeoTrackedBonePose> poses
    ) {
        poseStack.pushPose();
        RenderUtils.prepMatrixForBone(poseStack, bone);

        boolean tracked = trackedBoneNames.contains(bone.getName());
        if (bone.isTrackingMatrices() || tracked) {
            Matrix4f poseState = new Matrix4f(poseStack.last().pose());
            Matrix4f localMatrix = RenderUtils.invertAndMultiplyMatrices(poseState, entityRenderTranslations);
            Matrix4f worldState = new Matrix4f()
                    .translation(entityX, entityY, entityZ)
                    .mul(localMatrix);

            bone.setModelSpaceMatrix(RenderUtils.invertAndMultiplyMatrices(poseState, modelRenderTranslations));
            bone.setLocalSpaceMatrix(localMatrix);
            bone.setWorldSpaceMatrix(worldState);
            if (tracked) {
                poses.put(bone.getName(), GeoTrackedBonePose.fromMatrix(worldState, bone.getPivotX(), bone.getPivotY(), bone.getPivotZ()));
            }
        }

        if (!bone.isHidingChildren()) {
            for (GeoBone childBone : bone.getChildBones()) {
                captureTrackedEntityBonePosesRecursively(
                        poseStack,
                        childBone,
                        trackedBoneNames,
                        entityRenderTranslations,
                        modelRenderTranslations,
                        entityX,
                        entityY,
                        entityZ,
                        poses
                );
            }
        }

        poseStack.popPose();
    }

    private static Matrix4f readResolvedMatrix(float[] resolvedMatrices, int base) {
        return new Matrix4f(
                resolvedMatrices[base], resolvedMatrices[base + 1], resolvedMatrices[base + 2], resolvedMatrices[base + 3],
                resolvedMatrices[base + 4], resolvedMatrices[base + 5], resolvedMatrices[base + 6], resolvedMatrices[base + 7],
                resolvedMatrices[base + 8], resolvedMatrices[base + 9], resolvedMatrices[base + 10], resolvedMatrices[base + 11],
                resolvedMatrices[base + 12], resolvedMatrices[base + 13], resolvedMatrices[base + 14], resolvedMatrices[base + 15]
        );
    }
}
