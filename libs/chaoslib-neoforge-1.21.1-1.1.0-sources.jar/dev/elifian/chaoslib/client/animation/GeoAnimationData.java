package dev.elifian.chaoslib.client.animation;

import dev.elifian.chaoslib.molang.MolangRuntime;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

public record GeoAnimationData(Map<String, AnimationClip> animations, Format format) {
    public GeoAnimationData(Map<String, AnimationClip> animations) {
        this(animations, Format.BEDROCK);
    }

    public @Nullable AnimationClip get(String name) {
        return this.animations.get(name);
    }

    public record AnimationClip(boolean loop, float lengthSeconds, Map<String, BoneAnimation> bones) {
    }

    public record BoneAnimation(@Nullable Channel position, @Nullable Channel rotation, @Nullable Channel scale,
                                RelativeTo relativeTo) {
        public BoneAnimation(@Nullable Channel position, @Nullable Channel rotation, @Nullable Channel scale) {
            this(position, rotation, scale, RelativeTo.LOCAL);
        }

        public boolean hasNonLocalRelativeTo() {
            return this.relativeTo.position() != Space.LOCAL
                    || this.relativeTo.rotation() != Space.LOCAL
                    || this.relativeTo.scale() != Space.LOCAL;
        }
    }

    public record Channel(@Nullable VectorExpression constantValue, List<Keyframe> keyframes) {
        public static Channel constant(VectorExpression constantValue) {
            return new Channel(constantValue, List.of());
        }

        public static Channel keyframes(List<Keyframe> keyframes) {
            ArrayList<Keyframe> sorted = new ArrayList<>(keyframes);
            sorted.sort(Comparator.comparingDouble(Keyframe::timeSeconds));
            return new Channel(null, List.copyOf(sorted));
        }

        public boolean isConstant() {
            return this.constantValue != null;
        }

        public boolean isEmpty() {
            return this.constantValue == null && this.keyframes.isEmpty();
        }
    }

    public record Keyframe(
            float timeSeconds,
            VectorExpression pre,
            VectorExpression post,
            VectorExpression leftBezier,
            VectorExpression rightBezier,
            LerpMode lerpMode,
            @Nullable Easing easing
    ) {
    }

    public record Easing(String type, List<MolangRuntime.MolangExpression> args) {
        public Easing {
            args = List.copyOf(args);
        }
    }

    public record RelativeTo(Space position, Space rotation, Space scale) {
        public static final RelativeTo LOCAL = new RelativeTo(Space.LOCAL, Space.LOCAL, Space.LOCAL);
    }

    public record VectorExpression(MolangRuntime.MolangExpression x, MolangRuntime.MolangExpression y,
                                   MolangRuntime.MolangExpression z) {
        public static VectorExpression constant(double x, double y, double z) {
            return new VectorExpression(MolangRuntime.constant(x), MolangRuntime.constant(y), MolangRuntime.constant(z));
        }
    }

    public enum LerpMode {
        LINEAR,
        SMOOTH,
        BEZIER,
        STEP
    }

    public enum Format {
        BEDROCK,
        GECKOLIB
    }

    public enum Space {
        LOCAL,
        ENTITY
    }
}
