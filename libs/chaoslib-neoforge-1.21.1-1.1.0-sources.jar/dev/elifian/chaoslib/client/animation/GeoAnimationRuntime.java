package dev.elifian.chaoslib.client.animation;

import dev.elifian.chaoslib.api.animation.AnimationController;
import dev.elifian.chaoslib.cache.object.GeoBone;
import dev.elifian.chaoslib.api.animatable.GeoAnimatable;
import dev.elifian.chaoslib.api.animation.AnimationPlaybackController;
import dev.elifian.chaoslib.api.animation.AnimationState;
import dev.elifian.chaoslib.api.animation.RawAnimation;
import dev.elifian.chaoslib.molang.MolangQueryNames;
import dev.elifian.chaoslib.molang.MolangQueryProvider;
import dev.elifian.chaoslib.molang.MolangQueryProviders;
import dev.elifian.chaoslib.molang.MolangQueryResolvers;
import dev.elifian.chaoslib.molang.MolangRuntime;
import dev.elifian.chaoslib.molang.query.animation.MolangAnimationQueryProvider;
import dev.elifian.chaoslib.molang.query.animation.MolangAnimationQuerySource;
import dev.elifian.chaoslib.molang.query.bone.MolangBoneQueryProvider;
import dev.elifian.chaoslib.molang.query.block.MolangBlockQueryProvider;
import dev.elifian.chaoslib.molang.query.block.MolangPropertyAccess;
import dev.elifian.chaoslib.molang.query.entity.MolangEntityQueryProvider;
import dev.elifian.chaoslib.molang.query.item.MolangItemQueryProvider;
import dev.elifian.chaoslib.molang.query.player.MolangPlayerQueryProvider;
import dev.elifian.chaoslib.molang.query.render.MolangRenderQueryProvider;
import dev.elifian.chaoslib.molang.query.scoreboard.MolangScoreboardQueryProvider;
import dev.elifian.chaoslib.molang.query.world.MolangWorldQueryProvider;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.LinkedHashMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

public final class GeoAnimationRuntime {
    private static final double POSE_TIME_QUANTIZATION = 16.0d;
    private static final ThreadLocal<RuntimeContext> RUNTIME_CONTEXT = ThreadLocal.withInitial(RuntimeContext::new);

    private GeoAnimationRuntime() {
    }

    public static <T extends GeoAnimatable> void applyAnimations(
            GeoAnimationData animationData,
            Iterable<? extends AnimationPlaybackController<T>> controllers,
            AnimationState<T> animationState,
            Function<String, Optional<GeoBone>> boneResolver
    ) {
        applyAnimations(animationData, controllers, animationState.getAnimationTick(), animationState, boneResolver);
    }

    public static <T extends GeoAnimatable> void applyAnimations(
            GeoAnimationData animationData,
            Iterable<? extends AnimationPlaybackController<T>> controllers,
            double animationTick,
            @Nullable AnimationState<T> animationState,
            Function<String, Optional<GeoBone>> boneResolver
    ) {
        ArrayList<ControllerBlend<T>> orderedBlends = new ArrayList<>();
        for (AnimationPlaybackController<T> controller : controllers) {
            ControllerBlend<T> blend = sampleController(animationData, controller, animationTick, animationState, boneResolver);
            if (blend != null) {
                orderedBlends.add(blend);
            }
        }
        orderedBlends.sort((left, right) -> Integer.compare(left.controller().getPriority(), right.controller().getPriority()));

        LinkedHashMap<String, MixedBoneSample> mixedSamples = new LinkedHashMap<>();
        for (ControllerBlend<T> blend : orderedBlends) {
            if (blend.controller().getBlendMode() == AnimationPlaybackController.BlendMode.OVERRIDE) {
                clearOverriddenChannels(mixedSamples, blend.previousPose, blend.previousWeight);
                clearOverriddenChannels(mixedSamples, blend.currentPose, blend.currentWeight);
            }
            for (Map.Entry<String, BoneSample> entry : blend.currentPose.entrySet()) {
                mixedSamples.computeIfAbsent(entry.getKey(), ignored -> new MixedBoneSample())
                        .accumulate(entry.getValue(), blend.currentWeight);
            }
            for (Map.Entry<String, BoneSample> entry : blend.previousPose.entrySet()) {
                mixedSamples.computeIfAbsent(entry.getKey(), ignored -> new MixedBoneSample())
                        .accumulate(entry.getValue(), blend.previousWeight);
            }
        }

        for (Map.Entry<String, MixedBoneSample> entry : mixedSamples.entrySet()) {
            boneResolver.apply(entry.getKey()).ifPresent(bone -> entry.getValue().apply(bone));
        }
    }

    private static void clearOverriddenChannels(LinkedHashMap<String, MixedBoneSample> mixedSamples, Map<String, BoneSample> pose, float weight) {
        if (weight <= 1.0e-4f || pose.isEmpty()) {
            return;
        }

        for (Map.Entry<String, BoneSample> entry : pose.entrySet()) {
            MixedBoneSample mixedBoneSample = mixedSamples.get(entry.getKey());
            if (mixedBoneSample != null) {
                mixedBoneSample.clearChannels(entry.getValue());
            }
        }
    }

    public static Object createAnimationStateKey(Iterable<? extends AnimationPlaybackController<?>> controllers, double animationTick) {
        ArrayList<AnimationPlaybackController<?>> controllerList = new ArrayList<>();
        for (AnimationPlaybackController<?> controller : controllers) {
            controllerList.add(controller);
        }
        long[] numericKey = new long[controllerList.size() * 11];
        RawAnimation[] animationKey = new RawAnimation[controllerList.size() * 2];
        int numericIndex = 0;
        int animationIndex = 0;
        for (AnimationPlaybackController<?> controller : controllerList) {
            numericKey[numericIndex++] = quantizeTick(controller.getAccumulatedAnimationTick());
            animationKey[animationIndex++] = controller.getCurrentAnimation();
            numericKey[numericIndex++] = quantizeTick(animationTick - controller.getAnimationStartedTick());
            numericKey[numericIndex++] = quantizeTick(animationTick - controller.getCurrentAnimationFrozenTick());
            animationKey[animationIndex++] = controller.getPreviousAnimation();
            numericKey[numericIndex++] = quantizeTick(animationTick - controller.getPreviousAnimationStartedTick());
            numericKey[numericIndex++] = quantizeTick(animationTick - controller.getPreviousAnimationFrozenTick());
            numericKey[numericIndex++] = quantizeTick(animationTick - controller.getTransitionStartedTick());
            numericKey[numericIndex++] = controller.getTransitionLengthTicks();
            numericKey[numericIndex++] = transitionPoseStateKey(controller.getTransitionBonePoses());
            numericKey[numericIndex++] = Math.round(controller.getAnimationSpeed() * 1000.0d);
            numericKey[numericIndex++] = controller.getPriority();
            numericKey[numericIndex++] = controller.getBlendMode().ordinal();
        }
        return new AnimationStateCacheKey(numericKey, animationKey);
    }

    private static long quantizeTick(double tick) {
        return Math.round(tick * POSE_TIME_QUANTIZATION);
    }

    private static int transitionPoseStateKey(Map<String, AnimationPlaybackController.TransitionBonePose> poses) {
        if (poses.isEmpty()) {
            return 0;
        }

        ArrayList<String> boneNames = new ArrayList<>(poses.keySet());
        boneNames.sort(String::compareTo);
        int hash = 1;
        for (String boneName : boneNames) {
            AnimationPlaybackController.TransitionBonePose pose = poses.get(boneName);
            hash = 31 * hash + boneName.hashCode();
            hash = 31 * hash + Float.floatToIntBits(pose.hasPosition() ? pose.posX() : 0.0f);
            hash = 31 * hash + Float.floatToIntBits(pose.hasPosition() ? pose.posY() : 0.0f);
            hash = 31 * hash + Float.floatToIntBits(pose.hasPosition() ? pose.posZ() : 0.0f);
            hash = 31 * hash + Float.floatToIntBits(pose.hasRotation() ? pose.rotX() : 0.0f);
            hash = 31 * hash + Float.floatToIntBits(pose.hasRotation() ? pose.rotY() : 0.0f);
            hash = 31 * hash + Float.floatToIntBits(pose.hasRotation() ? pose.rotZ() : 0.0f);
            hash = 31 * hash + Float.floatToIntBits(pose.hasScale() ? pose.scaleX() : 1.0f);
            hash = 31 * hash + Float.floatToIntBits(pose.hasScale() ? pose.scaleY() : 1.0f);
            hash = 31 * hash + Float.floatToIntBits(pose.hasScale() ? pose.scaleZ() : 1.0f);
            hash = 31 * hash + Boolean.hashCode(pose.hasPosition());
            hash = 31 * hash + Boolean.hashCode(pose.hasRotation());
            hash = 31 * hash + Boolean.hashCode(pose.hasScale());
        }
        return hash;
    }

    private static final class AnimationStateCacheKey {
        private final long[] numericKey;
        private final RawAnimation[] animationKey;
        private final int hashCode;

        private AnimationStateCacheKey(long[] numericKey, RawAnimation[] animationKey) {
            this.numericKey = numericKey;
            this.animationKey = animationKey;
            int result = Arrays.hashCode(numericKey);
            for (RawAnimation animation : animationKey) {
                result = 31 * result + (animation == null ? 0 : animation.hashCode());
            }
            this.hashCode = result;
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof AnimationStateCacheKey key) || this.hashCode != key.hashCode) {
                return false;
            }
            return Arrays.equals(this.numericKey, key.numericKey) && animationKeysEqual(this.animationKey, key.animationKey);
        }

        @Override
        public int hashCode() {
            return this.hashCode;
        }
    }

    private static boolean animationKeysEqual(RawAnimation[] first, RawAnimation[] second) {
        if (first.length != second.length) {
            return false;
        }
        for (int i = 0; i < first.length; i++) {
            RawAnimation left = first[i];
            RawAnimation right = second[i];
            if (left != right && (left == null || !left.equals(right))) {
                return false;
            }
        }
        return true;
    }

    public static Map<String, AnimationPlaybackController.TransitionBonePose> createTransitionBonePoses(
            GeoAnimationData animationData,
            AnimationPlaybackController<?> controller
    ) {
        ControllerSample sample = sampleRawAnimation(
                animationData,
                controller.getPreviousAnimation(),
                controller.getPreviousAnimationStartedTick(),
                controller.getPreviousAnimationFrozenTick()
        );
        if (sample == null) {
            return Map.of();
        }

        Map<String, BoneSample> pose = sampleClipPose(
                animationData,
                sample.clipName(),
                sample.localTimeSeconds(),
                controller.getPreviousAnimationFrozenTick(),
                null,
                ignored -> Optional.empty()
        );
        if (pose.isEmpty()) {
            return Map.of();
        }

        LinkedHashMap<String, AnimationPlaybackController.TransitionBonePose> result = new LinkedHashMap<>(pose.size());
        for (Map.Entry<String, BoneSample> entry : pose.entrySet()) {
            BoneSample boneSample = entry.getValue();
            Vector3 position = boneSample.position == null ? new Vector3(0.0f, 0.0f, 0.0f) : boneSample.position;
            Vector3 rotation = boneSample.rotation == null ? new Vector3(0.0f, 0.0f, 0.0f) : boneSample.rotation;
            Vector3 scale = boneSample.scale == null ? new Vector3(1.0f, 1.0f, 1.0f) : boneSample.scale;
            result.put(entry.getKey(), new AnimationPlaybackController.TransitionBonePose(
                    position.x,
                    position.y,
                    position.z,
                    rotation.x,
                    rotation.y,
                    rotation.z,
                    scale.x,
                    scale.y,
                    scale.z,
                    boneSample.position != null,
                    boneSample.rotation != null,
                    boneSample.scale != null
            ));
        }
        return Map.copyOf(result);
    }

    private static <T extends GeoAnimatable> @Nullable ControllerBlend<T> sampleController(
            GeoAnimationData animationData,
            AnimationPlaybackController<T> controller,
            double animationTick,
            @Nullable AnimationState<T> animationState,
            Function<String, Optional<GeoBone>> boneResolver
    ) {
        double accumulatedAnimationTick = controller.getAccumulatedAnimationTick();
        Map<String, BoneSample> transitionPose = controller.getTransitionLengthTicks() <= 0
                ? Map.of()
                : transitionPose(controller);
        boolean transitioning = controller.getPreviousAnimation() != null;
        double currentTick = transitioning
                ? controller.getCurrentAnimationFrozenTick()
                : accumulatedAnimationTick;
        ControllerSample currentSample = sampleRawAnimation(animationData, controller.getCurrentAnimation(), controller.getAnimationStartedTick(), currentTick);
        ControllerSample previousSample = transitionPose.isEmpty()
                ? sampleRawAnimation(animationData, controller.getPreviousAnimation(), controller.getPreviousAnimationStartedTick(), controller.getPreviousAnimationFrozenTick())
                : null;
        float transition = (float) controller.getTransitionProgress(animationTick);

        float currentWeight = transitioning
                ? transition
                : (currentSample == null ? 0.0f : 1.0f);
        float previousWeight = transitioning
                ? 1.0f - transition
                : 0.0f;
        if (currentWeight <= 1.0e-4f && previousWeight <= 1.0e-4f) {
            return null;
        }

        Map<String, BoneSample> currentPose = currentSample == null
                ? Map.of()
                : sampleClipPose(animationData, currentSample.clipName, currentSample.localTimeSeconds, animationTick, animationState, boneResolver);
        Map<String, BoneSample> previousPose = transitionPose.isEmpty()
                ? (previousSample == null ? Map.of() : sampleClipPose(animationData, previousSample.clipName, previousSample.localTimeSeconds, animationTick, animationState, boneResolver))
                : transitionPose;
        if (transitioning) {
            TransitionChannelCoverage stabilized = stabilizeTransitionChannelCoverage(currentPose, currentWeight, previousPose, previousWeight, boneResolver);
            currentPose = stabilized.currentPose();
            previousPose = stabilized.previousPose();
        }
        if (currentPose.isEmpty() && previousPose.isEmpty()) {
            return null;
        }
        return new ControllerBlend<>(controller, currentPose, currentWeight, previousPose, previousWeight);
    }

    private static Map<String, BoneSample> transitionPose(AnimationPlaybackController<?> controller) {
        Map<String, AnimationPlaybackController.TransitionBonePose> poses = controller.getTransitionBonePoses();
        if (poses.isEmpty()) {
            return Map.of();
        }

        LinkedHashMap<String, BoneSample> samples = new LinkedHashMap<>(poses.size());
        for (Map.Entry<String, AnimationPlaybackController.TransitionBonePose> entry : poses.entrySet()) {
            AnimationPlaybackController.TransitionBonePose pose = entry.getValue();
            samples.put(entry.getKey(), new BoneSample(
                    pose.hasPosition() ? new Vector3(pose.posX(), pose.posY(), pose.posZ()) : null,
                    pose.hasRotation() ? new Vector3(pose.rotX(), pose.rotY(), pose.rotZ()) : null,
                    pose.hasScale() ? new Vector3(pose.scaleX(), pose.scaleY(), pose.scaleZ()) : null
            ));
        }
        return samples;
    }

    private static @Nullable ControllerSample sampleRawAnimation(GeoAnimationData animationData, @Nullable RawAnimation rawAnimation, double startedTick, double animationTick) {
        if (rawAnimation == null || rawAnimation.isEmpty()) {
            return null;
        }

        double elapsedSeconds = Math.max(0.0d, (animationTick - startedTick) / 20.0d);
        for (RawAnimation.Stage stage : rawAnimation.getStages()) {
            GeoAnimationData.AnimationClip clip = animationData.get(stage.animationName());
            if (clip == null) {
                continue;
            }

            double length = Math.max(clip.lengthSeconds(), 0.0f);
            if (stage.playbackMode() == RawAnimation.PlaybackMode.LOOP || clip.loop()) {
                double localTime = length <= 0.0d ? elapsedSeconds : elapsedSeconds % length;
                return new ControllerSample(stage.animationName(), (float) localTime);
            }
            if (elapsedSeconds <= length) {
                return new ControllerSample(stage.animationName(), (float) elapsedSeconds);
            }

            elapsedSeconds -= length;
            if (stage.playbackMode() == RawAnimation.PlaybackMode.PLAY_AND_HOLD) {
                return new ControllerSample(stage.animationName(), (float) length);
            }
        }

        RawAnimation.Stage lastStage = rawAnimation.getStages().get(rawAnimation.getStages().size() - 1);
        GeoAnimationData.AnimationClip lastClip = animationData.get(lastStage.animationName());
        return lastClip == null ? null : new ControllerSample(lastStage.animationName(), lastClip.lengthSeconds());
    }

    private static Map<String, BoneSample> sampleClipPose(GeoAnimationData animationData, String clipName, float animTimeSeconds, double animationTick, @Nullable AnimationState<?> animationState, Function<String, Optional<GeoBone>> boneResolver) {
        GeoAnimationData.AnimationClip clip = animationData.get(clipName);
        if (clip == null) {
            return Map.of();
        }

        RuntimeContext context = RUNTIME_CONTEXT.get().reset(animTimeSeconds, animationTick / 20.0d, animationState, animationData, boneResolver);
        LinkedHashMap<String, RawBoneSample> rawSamples = new LinkedHashMap<>();
        boolean hasNonLocalRelativeTo = false;
        for (Map.Entry<String, GeoAnimationData.BoneAnimation> entry : clip.bones().entrySet()) {
            RawBoneSample sample = sampleBone(entry.getKey(), entry.getValue(), animTimeSeconds, context, boneResolver);
            rawSamples.put(entry.getKey(), sample);
            hasNonLocalRelativeTo |= entry.getValue().hasNonLocalRelativeTo();
        }

        LinkedHashMap<String, BoneSample> samples = new LinkedHashMap<>();
        if (!hasNonLocalRelativeTo) {
            for (Map.Entry<String, RawBoneSample> entry : rawSamples.entrySet()) {
                BoneSample sample = toLocalBoneSample(entry.getKey(), entry.getValue(), boneResolver);
                if (!sample.isIdentity()) {
                    samples.put(entry.getKey(), sample);
                }
            }
            return samples.isEmpty() ? Map.of() : samples;
        }

        IdentityHashMap<GeoBone, ResolvedBoneState> resolvedBones = new IdentityHashMap<>();
        LinkedHashMap<String, ResolvedBoneState> resolvedByName = new LinkedHashMap<>();
        for (Map.Entry<String, RawBoneSample> entry : rawSamples.entrySet()) {
            ResolvedBoneState state = resolveBoneState(entry.getKey(), entry.getValue(), rawSamples, resolvedByName, resolvedBones, boneResolver);
            if (!state.sample().isIdentity()) {
                samples.put(entry.getKey(), state.sample());
            }
        }
        return samples.isEmpty() ? Map.of() : samples;
    }

    private static RawBoneSample sampleBone(String boneName, GeoAnimationData.BoneAnimation boneAnimation, float animTimeSeconds, RuntimeContext context, Function<String, Optional<GeoBone>> boneResolver) {
        context.withCurrentBone(boneResolver.apply(boneName).orElse(null));
        Vector3 position = sampleChannel(boneAnimation.position(), animTimeSeconds, context);
        Vector3 rotation = sampleChannel(boneAnimation.rotation(), animTimeSeconds, context);
        Vector3 scale = sampleChannel(boneAnimation.scale(), animTimeSeconds, context);
        context.withCurrentBone(null);
        return new RawBoneSample(position, rotation, scale, boneAnimation.relativeTo());
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    public static @Nullable Vector3f sampleChannelValue(
            GeoAnimationData animationData,
            @Nullable GeoAnimationData.Channel channel,
            String boneName,
            float animTimeSeconds,
            double animationTick,
            @Nullable AnimationState<?> animationState,
            @Nullable AnimationPlaybackController<?> controller,
            Function<String, Optional<GeoBone>> boneResolver
    ) {
        if (channel == null || channel.isEmpty()) {
            return null;
        }

        AnimationState<?> runtimeState = animationState;
        if (animationState != null && controller instanceof AnimationController<?> animationController) {
            runtimeState = ((AnimationState) animationState).forController((AnimationController) animationController);
        }

        RuntimeContext context = RUNTIME_CONTEXT.get().reset(animTimeSeconds, animationTick / 20.0d, runtimeState, animationData, boneResolver);
        context.withCurrentBone(boneResolver.apply(boneName).orElse(null));
        Vector3 sampled = sampleChannel(channel, animTimeSeconds, context);
        context.withCurrentBone(null);
        return sampled == null ? null : new Vector3f(sampled.x, sampled.y, sampled.z);
    }

    private static @Nullable Vector3 sampleChannel(@Nullable GeoAnimationData.Channel channel, float animTimeSeconds, RuntimeContext context) {
        if (channel == null || channel.isEmpty()) {
            return null;
        }
        if (channel.isConstant()) {
            return evaluateVector(channel.constantValue(), context);
        }

        if (channel.keyframes().size() == 1) {
            return evaluateVector(channel.keyframes().get(0).post(), context);
        }

        GeoAnimationData.Keyframe previous = channel.keyframes().get(0);
        if (animTimeSeconds <= previous.timeSeconds()) {
            return evaluateVector(previous.pre(), context);
        }

        for (int i = 1; i < channel.keyframes().size(); i++) {
            GeoAnimationData.Keyframe next = channel.keyframes().get(i);
            if (animTimeSeconds <= next.timeSeconds()) {
                float span = next.timeSeconds() - previous.timeSeconds();
                float alpha = span <= 1.0e-6f ? 1.0f : (animTimeSeconds - previous.timeSeconds()) / span;
                Vector3 start = evaluateVector(previous.post(), context);
                Vector3 end = evaluateVector(next.pre(), context);
                if (next.easing() != null) {
                    float easedAlpha = GeoAnimationEasing.apply(
                            next.easing().type(),
                            alpha,
                            evaluateEasingArg(next.easing(), context)
                    );
                    return start.lerp(end, easedAlpha);
                }
                return switch (next.lerpMode()) {
                    case STEP -> start;
                    case SMOOTH -> start.lerp(end, smooth(alpha));
                    case BEZIER -> {
                        Vector3 control1 = evaluateVector(previous.rightBezier(), context);
                        Vector3 control2 = evaluateVector(next.leftBezier(), context);
                        yield cubicBezier(start, control1, control2, end, alpha);
                    }
                    case LINEAR -> start.lerp(end, alpha);
                };
            }
            previous = next;
        }

        return evaluateVector(previous.post(), context);
    }

    private static float smooth(float alpha) {
        return alpha * alpha * (3.0f - 2.0f * alpha);
    }

    private static Vector3 cubicBezier(Vector3 p0, Vector3 p1, Vector3 p2, Vector3 p3, float t) {
        float u = 1.0f - t;
        float tt = t * t;
        float uu = u * u;
        float uuu = uu * u;
        float ttt = tt * t;
        return new Vector3(
                uuu * p0.x + 3.0f * uu * t * p1.x + 3.0f * u * tt * p2.x + ttt * p3.x,
                uuu * p0.y + 3.0f * uu * t * p1.y + 3.0f * u * tt * p2.y + ttt * p3.y,
                uuu * p0.z + 3.0f * uu * t * p1.z + 3.0f * u * tt * p2.z + ttt * p3.z
        );
    }

    private static Vector3 evaluateVector(GeoAnimationData.VectorExpression expression, RuntimeContext context) {
        return new Vector3(
                (float) expression.x().evaluateNumber(context),
                (float) expression.y().evaluateNumber(context),
                (float) expression.z().evaluateNumber(context)
        );
    }

    private static @Nullable Double evaluateEasingArg(GeoAnimationData.Easing easing, RuntimeContext context) {
        if (easing.args().isEmpty()) {
            return null;
        }

        return easing.args().get(0).evaluateNumber(context);
    }

    private static BoneSample toLocalBoneSample(String boneName, RawBoneSample rawSample, Function<String, Optional<GeoBone>> boneResolver) {
        GeoBone bone = boneResolver.apply(boneName).orElse(null);
        Vector3 position = rawSample.position();
        Vector3 scale = rawSample.scale();
        Vector3 rotation = defaultLocalRotation(rawSample.rotation(), bone);
        return new BoneSample(position, rotation, scale);
    }

    private static ResolvedBoneState resolveBoneState(
            String boneName,
            RawBoneSample rawSample,
            Map<String, RawBoneSample> rawSamples,
            Map<String, ResolvedBoneState> resolvedByName,
            IdentityHashMap<GeoBone, ResolvedBoneState> resolvedBones,
            Function<String, Optional<GeoBone>> boneResolver
    ) {
        ResolvedBoneState cached = resolvedByName.get(boneName);
        if (cached != null) {
            return cached;
        }

        GeoBone bone = boneResolver.apply(boneName).orElse(null);
        ResolvedBoneState parentState = resolveParentState(bone, rawSamples, resolvedByName, resolvedBones, boneResolver);
        Quaternionf parentModelRotation = parentState.modelRotation();

        Vector3 position = rawSample.position();
        if (rawSample.relativeTo().position() == GeoAnimationData.Space.ENTITY && position != null) {
            position = rotateVector(new Quaternionf(parentModelRotation).invert(), position);
        }

        Vector3 scale = rawSample.scale();
        Vector3 rotation = rawSample.relativeTo().rotation() == GeoAnimationData.Space.ENTITY
                ? entityRelativeRotation(rawSample.rotation(), bone, parentModelRotation)
                : defaultLocalRotation(rawSample.rotation(), bone);
        Quaternionf localRotation = rotationQuaternion(rotation.x, rotation.y, rotation.z);
        Quaternionf modelRotation = new Quaternionf(parentModelRotation).mul(localRotation);
        ResolvedBoneState resolved = new ResolvedBoneState(new BoneSample(position, rotation, scale), modelRotation);
        resolvedByName.put(boneName, resolved);
        return resolved;
    }

    private static ResolvedBoneState resolveParentState(
            @Nullable GeoBone bone,
            Map<String, RawBoneSample> rawSamples,
            Map<String, ResolvedBoneState> resolvedByName,
            IdentityHashMap<GeoBone, ResolvedBoneState> resolvedBones,
            Function<String, Optional<GeoBone>> boneResolver
    ) {
        if (bone == null || bone.getParent() == null) {
            return ResolvedBoneState.IDENTITY;
        }

        GeoBone parent = bone.getParent();
        ResolvedBoneState cached = resolvedBones.get(parent);
        if (cached != null) {
            return cached;
        }

        RawBoneSample parentRaw = rawSamples.get(parent.getName());
        ResolvedBoneState resolved = parentRaw != null
                ? resolveBoneState(parent.getName(), parentRaw, rawSamples, resolvedByName, resolvedBones, boneResolver)
                : resolveStaticBoneState(parent, resolvedBones);
        resolvedBones.put(parent, resolved);
        return resolved;
    }

    private static ResolvedBoneState resolveStaticBoneState(GeoBone bone, IdentityHashMap<GeoBone, ResolvedBoneState> resolvedBones) {
        ResolvedBoneState cached = resolvedBones.get(bone);
        if (cached != null) {
            return cached;
        }

        ResolvedBoneState parentState = bone.getParent() == null
                ? ResolvedBoneState.IDENTITY
                : resolveStaticBoneState(bone.getParent(), resolvedBones);
        Quaternionf localRotation = rotationQuaternion(bone.getInitialRotX(), bone.getInitialRotY(), bone.getInitialRotZ());
        ResolvedBoneState resolved = new ResolvedBoneState(
                new BoneSample(null, new Vector3(bone.getInitialRotX(), bone.getInitialRotY(), bone.getInitialRotZ()), null),
                new Quaternionf(parentState.modelRotation()).mul(localRotation)
        );
        resolvedBones.put(bone, resolved);
        return resolved;
    }

    private static Vector3 entityRelativeRotation(@Nullable Vector3 rawRotationDegrees, @Nullable GeoBone bone, Quaternionf parentModelRotation) {
        Quaternionf baseLocalRotation = bone == null
                ? new Quaternionf().identity()
                : rotationQuaternion(bone.getInitialRotX(), bone.getInitialRotY(), bone.getInitialRotZ());
        if (rawRotationDegrees == null) {
            return rotationAngles(baseLocalRotation);
        }

        Quaternionf entityDelta = rotationQuaternion(
                (float) Math.toRadians(-rawRotationDegrees.x),
                (float) Math.toRadians(-rawRotationDegrees.y),
                (float) Math.toRadians(rawRotationDegrees.z)
        );
        Quaternionf localRotation = new Quaternionf(parentModelRotation)
                .invert()
                .mul(entityDelta)
                .mul(parentModelRotation)
                .mul(baseLocalRotation);
        return rotationAngles(localRotation);
    }

    private static Vector3 defaultLocalRotation(@Nullable Vector3 rawRotationDegrees, @Nullable GeoBone bone) {
        float baseX = bone == null ? 0.0f : bone.getInitialRotX();
        float baseY = bone == null ? 0.0f : bone.getInitialRotY();
        float baseZ = bone == null ? 0.0f : bone.getInitialRotZ();
        if (rawRotationDegrees == null) {
            return new Vector3(baseX, baseY, baseZ);
        }

        return new Vector3(
                baseX + (float) Math.toRadians(-rawRotationDegrees.x),
                baseY + (float) Math.toRadians(-rawRotationDegrees.y),
                baseZ + (float) Math.toRadians(rawRotationDegrees.z)
        );
    }

    private static Quaternionf rotationQuaternion(float rotX, float rotY, float rotZ) {
        return new Quaternionf().rotationZYX(rotZ, rotY, rotX);
    }

    private static Vector3 rotationAngles(Quaternionf rotation) {
        Vector3f angles = new Matrix4f().rotation(rotation.normalize(new Quaternionf())).getEulerAnglesZYX(new Vector3f());
        return new Vector3(angles.x, angles.y, angles.z);
    }

    private static Vector3 rotateVector(Quaternionf rotation, Vector3 vector) {
        Vector3f result = rotation.transform(new Vector3f(vector.x, vector.y, vector.z));
        return new Vector3(result.x, result.y, result.z);
    }

    private record ControllerSample(String clipName, float localTimeSeconds) {
    }

    private record TransitionChannelCoverage(Map<String, BoneSample> currentPose, Map<String, BoneSample> previousPose) {
    }

    private record ControllerBlend<T extends GeoAnimatable>(
            AnimationPlaybackController<T> controller,
            Map<String, BoneSample> currentPose,
            float currentWeight,
            Map<String, BoneSample> previousPose,
            float previousWeight
    ) {
    }

    private static final class RuntimeContext extends MolangRuntime.MutableContext implements MolangQueryProvider, MolangAnimationQuerySource {
        private static final double DELTA_TIME_SECONDS = 1.0d / 20.0d;
        private static final List<String> BONE_QUERY_VALUES = List.of(
                MolangQueryNames.BONE_ORIGIN,
                MolangQueryNames.BONE_ROTATION,
                MolangQueryNames.BONE_ORIENTATION_MATRIX,
                MolangQueryNames.BONE_ORIENTATION_TRS,
                MolangQueryNames.BONE_AABB
        );
        private static final List<String> BONE_QUERY_CALLS = List.of(
                MolangQueryNames.GET_DEFAULT_BONE_PIVOT,
                MolangQueryNames.GET_LOCATOR_OFFSET,
                MolangQueryNames.GET_ROOT_LOCATOR_OFFSET
        );
        private MolangRuntime.MolangValue animTime = MolangRuntime.MolangValue.NULL;
        private MolangRuntime.MolangValue lifeTime = MolangRuntime.MolangValue.NULL;
        private @Nullable AnimationState<?> animationState;
        private @Nullable GeoAnimationData animationData;
        private @Nullable GeoBone currentBone;
        private Function<String, Optional<GeoBone>> boneResolver = ignored -> Optional.empty();
        private MolangQueryProvider sharedQueryProvider = MolangQueryProviders.composite();
        private MolangQueryProvider boneQueryProvider = MolangQueryProviders.composite();

        private RuntimeContext() {
            withQueryResolver(MolangQueryResolvers.standard());
        }

        private RuntimeContext reset(float animTimeSeconds, double lifeTimeSeconds, @Nullable AnimationState<?> animationState, @Nullable GeoAnimationData animationData, Function<String, Optional<GeoBone>> boneResolver) {
            clearLocalState();
            this.animTime = MolangRuntime.MolangValue.number(animTimeSeconds);
            this.lifeTime = MolangRuntime.MolangValue.number(lifeTimeSeconds);
            this.animationState = animationState;
            this.animationData = animationData;
            this.currentBone = null;
            this.boneResolver = boneResolver;
            this.sharedQueryProvider = MolangQueryProviders.composite(
                    new MolangAnimationQueryProvider(this),
                    createEntityProvider(animationState),
                    createWorldProvider(animationState),
                    createPlayerProvider(animationState),
                    createItemProvider(animationState),
                    createRenderProvider(animationState),
                    createScoreboardProvider(animationState),
                    createBlockProvider(animationState)
            );
            this.boneQueryProvider = MolangQueryProviders.composite();
            seedScalarFrameQueries();
            return this;
        }

        private RuntimeContext withCurrentBone(@Nullable GeoBone currentBone) {
            this.currentBone = currentBone;
            this.boneQueryProvider = new MolangBoneQueryProvider(this.currentBone, this.boneResolver);
            return this;
        }

        @Override
        public MolangRuntime.MolangValue getQueryValue(String normalizedPath) {
            MolangRuntime.MolangValue boneValue = this.boneQueryProvider.getQueryValue(normalizedPath);
            return boneValue != null ? boneValue : this.sharedQueryProvider.getQueryValue(normalizedPath);
        }

        @Override
        public @Nullable MolangRuntime.MolangValue callQuery(String normalizedName, List<MolangRuntime.MolangValue> args) {
            MolangRuntime.MolangValue boneValue = this.boneQueryProvider.callQuery(normalizedName, args);
            return boneValue != null ? boneValue : this.sharedQueryProvider.callQuery(normalizedName, args);
        }

        @Override
        protected boolean shouldCacheQueryValue(String normalizedPath) {
            return !BONE_QUERY_VALUES.contains(normalizedPath);
        }

        @Override
        protected boolean shouldCacheQueryCall(String normalizedName, List<MolangRuntime.MolangValue> args) {
            return !BONE_QUERY_CALLS.contains(normalizedName);
        }

        @Override
        public double animTimeSeconds() {
            return this.animTime.asNumber();
        }

        @Override
        public double lifeTimeSeconds() {
            return this.lifeTime.asNumber();
        }

        @Override
        public double deltaTimeSeconds() {
            return DELTA_TIME_SECONDS;
        }

        @Override
        public boolean allAnimationsFinished() {
            return animationCompletion().allFinished();
        }

        @Override
        public boolean anyAnimationFinished() {
            return animationCompletion().anyFinished();
        }

        @Override
        public double stateTimeSeconds() {
            if (this.animationState == null || this.animationState.getController() == null) {
                return 0.0d;
            }
            double elapsedTicks = this.animationState.getController().getAccumulatedAnimationTick()
                    - this.animationState.getController().getAnimationStartedTick();
            return Math.max(0.0d, elapsedTicks / 20.0d);
        }

        private CompletionState animationCompletion() {
            if (this.animationState == null || this.animationState.getController() == null || this.animationData == null) {
                return CompletionState.NOT_FINISHED;
            }

            RawAnimation animation = this.animationState.getController().getCurrentAnimation();
            if (animation == null || animation.isEmpty()) {
                return CompletionState.NOT_FINISHED;
            }

            double remainingSeconds = stateTimeSeconds();
            boolean anyFinished = false;
            for (RawAnimation.Stage stage : animation.getStages()) {
                GeoAnimationData.AnimationClip clip = this.animationData.get(stage.animationName());
                if (clip == null) {
                    continue;
                }

                double length = Math.max(clip.lengthSeconds(), 0.0f);
                if (stage.playbackMode() == RawAnimation.PlaybackMode.LOOP || clip.loop()) {
                    return new CompletionState(anyFinished, false);
                }
                if (remainingSeconds >= length) {
                    anyFinished = true;
                    remainingSeconds -= length;
                    continue;
                }
                return new CompletionState(anyFinished, false);
            }

            return new CompletionState(anyFinished, true);
        }

        private void seedScalarFrameQueries() {
            cacheQueryValueNormalized(MolangQueryNames.ANIM_TIME, this.animTime);
            cacheQueryValueNormalized(MolangQueryNames.LIFE_TIME, this.lifeTime);
            cacheQueryValueNormalized(MolangQueryNames.DELTA_TIME, MolangRuntime.MolangValue.number(DELTA_TIME_SECONDS));
        }

        private static @Nullable MolangQueryProvider createEntityProvider(@Nullable AnimationState<?> animationState) {
            if (animationState == null) {
                return null;
            }
            Object animatable = animationState.getAnimatable();
            return animatable instanceof Entity entity ? new MolangEntityQueryProvider<>(entity, animationState) : null;
        }

        private static @Nullable MolangQueryProvider createWorldProvider(@Nullable AnimationState<?> animationState) {
            if (animationState == null) {
                return null;
            }
            Object animatable = animationState.getAnimatable();
            if (animatable instanceof Entity entity) {
                return new MolangWorldQueryProvider(entity.level());
            }
            if (animatable instanceof BlockEntity blockEntity) {
                return new MolangWorldQueryProvider(blockEntity.getLevel());
            }
            return null;
        }

        private static @Nullable MolangQueryProvider createPlayerProvider(@Nullable AnimationState<?> animationState) {
            if (animationState == null) {
                return null;
            }
            Object animatable = animationState.getAnimatable();
            return animatable instanceof Player player ? new MolangPlayerQueryProvider(player) : null;
        }

        private static @Nullable MolangQueryProvider createItemProvider(@Nullable AnimationState<?> animationState) {
            if (animationState == null) {
                return null;
            }
            Object animatable = animationState.getAnimatable();
            return animatable instanceof LivingEntity living ? new MolangItemQueryProvider(living) : null;
        }

        private static @Nullable MolangQueryProvider createRenderProvider(@Nullable AnimationState<?> animationState) {
            if (animationState == null) {
                return null;
            }
            Object animatable = animationState.getAnimatable();
            return animatable instanceof Entity entity ? new MolangRenderQueryProvider(entity) : null;
        }

        private static @Nullable MolangQueryProvider createScoreboardProvider(@Nullable AnimationState<?> animationState) {
            if (animationState == null) {
                return null;
            }
            Object animatable = animationState.getAnimatable();
            return animatable instanceof Entity entity ? new MolangScoreboardQueryProvider(entity) : null;
        }

        private static @Nullable MolangQueryProvider createBlockProvider(@Nullable AnimationState<?> animationState) {
            if (animationState == null) {
                return null;
            }
            Object animatable = animationState.getAnimatable();
            if (!(animatable instanceof BlockEntity blockEntity)) {
                return null;
            }
            return new MolangBlockQueryProvider(blockEntity, animatable instanceof MolangPropertyAccess access ? access : null);
        }
    }

    private record CompletionState(boolean anyFinished, boolean allFinished) {
        private static final CompletionState NOT_FINISHED = new CompletionState(false, false);
    }

    private record Vector3(float x, float y, float z) {
        private Vector3 lerp(Vector3 target, float alpha) {
            return new Vector3(
                    this.x + (target.x - this.x) * alpha,
                    this.y + (target.y - this.y) * alpha,
                    this.z + (target.z - this.z) * alpha
            );
        }
    }

    private record BoneSample(@Nullable Vector3 position, @Nullable Vector3 rotation, @Nullable Vector3 scale) {
        private boolean isIdentity() {
            return this.position == null && this.rotation == null && this.scale == null;
        }
    }

    private record RawBoneSample(@Nullable Vector3 position, @Nullable Vector3 rotation, @Nullable Vector3 scale,
                                 GeoAnimationData.RelativeTo relativeTo) {
    }

    private record ResolvedBoneState(BoneSample sample, Quaternionf modelRotation) {
        private static final ResolvedBoneState IDENTITY = new ResolvedBoneState(
                new BoneSample(null, null, null),
                new Quaternionf().identity()
        );
    }

    private static TransitionChannelCoverage stabilizeTransitionChannelCoverage(
            Map<String, BoneSample> currentPose,
            float currentWeight,
            Map<String, BoneSample> previousPose,
            float previousWeight,
            Function<String, Optional<GeoBone>> boneResolver
    ) {
        if (currentWeight <= 1.0e-4f && previousWeight <= 1.0e-4f) {
            return new TransitionChannelCoverage(currentPose, previousPose);
        }

        LinkedHashMap<String, BoneSample> adjustedCurrent = null;
        LinkedHashMap<String, BoneSample> adjustedPrevious = null;
        LinkedHashMap<String, BoneSample> union = new LinkedHashMap<>(previousPose.size() + currentPose.size());
        union.putAll(previousPose);
        currentPose.forEach(union::putIfAbsent);

        for (Map.Entry<String, BoneSample> entry : union.entrySet()) {
            String boneName = entry.getKey();
            BoneSample currentSample = currentPose.get(boneName);
            BoneSample previousSample = previousPose.get(boneName);

            boolean addCurrentPosition = currentWeight > 1.0e-4f
                    && hasPosition(previousSample)
                    && !hasPosition(currentSample);
            boolean addCurrentRotation = currentWeight > 1.0e-4f
                    && hasRotation(previousSample)
                    && !hasRotation(currentSample);
            boolean addCurrentScale = currentWeight > 1.0e-4f
                    && hasScale(previousSample)
                    && !hasScale(currentSample);
            if (addCurrentPosition || addCurrentRotation || addCurrentScale) {
                adjustedCurrent = ensureMutableCopy(adjustedCurrent, currentPose);
                adjustedCurrent.put(
                        boneName,
                        addFallbackChannels(
                                currentSample,
                                defaultBoneSample(boneResolver.apply(boneName).orElse(null)),
                                addCurrentPosition,
                                addCurrentRotation,
                                addCurrentScale
                        )
                );
            }

            boolean addPreviousPosition = previousWeight > 1.0e-4f
                    && hasPosition(currentSample)
                    && !hasPosition(previousSample);
            boolean addPreviousRotation = previousWeight > 1.0e-4f
                    && hasRotation(currentSample)
                    && !hasRotation(previousSample);
            boolean addPreviousScale = previousWeight > 1.0e-4f
                    && hasScale(currentSample)
                    && !hasScale(previousSample);
            if (addPreviousPosition || addPreviousRotation || addPreviousScale) {
                adjustedPrevious = ensureMutableCopy(adjustedPrevious, previousPose);
                adjustedPrevious.put(
                        boneName,
                        addFallbackChannels(
                                previousSample,
                                defaultBoneSample(boneResolver.apply(boneName).orElse(null)),
                                addPreviousPosition,
                                addPreviousRotation,
                                addPreviousScale
                        )
                );
            }
        }

        return new TransitionChannelCoverage(
                adjustedCurrent == null ? currentPose : adjustedCurrent,
                adjustedPrevious == null ? previousPose : adjustedPrevious
        );
    }

    private static LinkedHashMap<String, BoneSample> ensureMutableCopy(@Nullable LinkedHashMap<String, BoneSample> current, Map<String, BoneSample> source) {
        return current == null ? new LinkedHashMap<>(source) : current;
    }

    private static BoneSample addFallbackChannels(
            @Nullable BoneSample sample,
            BoneSample defaults,
            boolean addPosition,
            boolean addRotation,
            boolean addScale
    ) {
        Vector3 position = sample == null ? null : sample.position();
        Vector3 rotation = sample == null ? null : sample.rotation();
        Vector3 scale = sample == null ? null : sample.scale();
        return new BoneSample(
                addPosition ? defaults.position() : position,
                addRotation ? defaults.rotation() : rotation,
                addScale ? defaults.scale() : scale
        );
    }

    private static BoneSample defaultBoneSample(@Nullable GeoBone bone) {
        return new BoneSample(
                new Vector3(0.0f, 0.0f, 0.0f),
                new Vector3(
                        bone == null ? 0.0f : bone.getInitialRotX(),
                        bone == null ? 0.0f : bone.getInitialRotY(),
                        bone == null ? 0.0f : bone.getInitialRotZ()
                ),
                new Vector3(1.0f, 1.0f, 1.0f)
        );
    }

    private static boolean hasPosition(@Nullable BoneSample sample) {
        return sample != null && sample.position() != null;
    }

    private static boolean hasRotation(@Nullable BoneSample sample) {
        return sample != null && sample.rotation() != null;
    }

    private static boolean hasScale(@Nullable BoneSample sample) {
        return sample != null && sample.scale() != null;
    }

    private static final class MixedBoneSample {
        private float positionX;
        private float positionY;
        private float positionZ;
        private float positionWeight;
        private float rotationX;
        private float rotationY;
        private float rotationZ;
        private float rotationWeight;
        private float scaleX;
        private float scaleY;
        private float scaleZ;
        private float scaleWeight;

        private void accumulate(BoneSample sample, float weight) {
            if (weight <= 1.0e-4f) {
                return;
            }
            if (sample.position != null) {
                this.positionX += sample.position.x * weight;
                this.positionY += sample.position.y * weight;
                this.positionZ += sample.position.z * weight;
                this.positionWeight += weight;
            }
            if (sample.rotation != null) {
                this.rotationX += sample.rotation.x * weight;
                this.rotationY += sample.rotation.y * weight;
                this.rotationZ += sample.rotation.z * weight;
                this.rotationWeight += weight;
            }
            if (sample.scale != null) {
                this.scaleX += (sample.scale.x - 1.0f) * weight;
                this.scaleY += (sample.scale.y - 1.0f) * weight;
                this.scaleZ += (sample.scale.z - 1.0f) * weight;
                this.scaleWeight += weight;
            }
        }

        private void clearChannels(BoneSample sample) {
            if (sample.position != null) {
                this.positionX = 0.0f;
                this.positionY = 0.0f;
                this.positionZ = 0.0f;
                this.positionWeight = 0.0f;
            }
            if (sample.rotation != null) {
                this.rotationX = 0.0f;
                this.rotationY = 0.0f;
                this.rotationZ = 0.0f;
                this.rotationWeight = 0.0f;
            }
            if (sample.scale != null) {
                this.scaleX = 0.0f;
                this.scaleY = 0.0f;
                this.scaleZ = 0.0f;
                this.scaleWeight = 0.0f;
            }
        }

        private void apply(GeoBone bone) {
            if (this.positionWeight > 1.0e-4f) {
                bone.setPosX(this.positionX / this.positionWeight);
                bone.setPosY(this.positionY / this.positionWeight);
                bone.setPosZ(this.positionZ / this.positionWeight);
            }
            if (this.rotationWeight > 1.0e-4f) {
                bone.setRotX(this.rotationX / this.rotationWeight);
                bone.setRotY(this.rotationY / this.rotationWeight);
                bone.setRotZ(this.rotationZ / this.rotationWeight);
            }
            if (this.scaleWeight > 1.0e-4f) {
                bone.setScaleX(1.0f + this.scaleX / this.scaleWeight);
                bone.setScaleY(1.0f + this.scaleY / this.scaleWeight);
                bone.setScaleZ(1.0f + this.scaleZ / this.scaleWeight);
            }
        }
    }
}
