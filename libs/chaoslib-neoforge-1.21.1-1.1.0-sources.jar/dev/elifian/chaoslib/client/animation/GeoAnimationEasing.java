package dev.elifian.chaoslib.client.animation;

import org.jetbrains.annotations.Nullable;

import java.util.Locale;

public final class GeoAnimationEasing {
    private GeoAnimationEasing() {
    }

    public static float apply(String rawType, float alpha, @Nullable Double arg) {
        double clamped = Math.max(0.0d, Math.min(1.0d, alpha));
        double value = switch (normalize(rawType)) {
            case "none", "linear" -> clamped;
            case "step" -> clamped <= 0.0d ? 0.0d : 1.0d;
            case "catmullrom" -> easeInOut(GeoAnimationEasing::catmullRom, clamped);
            case "easeinsine" -> sine(clamped);
            case "easeoutsine" -> easeOut(GeoAnimationEasing::sine, clamped);
            case "easeinoutsine" -> easeInOut(GeoAnimationEasing::sine, clamped);
            case "easeinquad" -> quadratic(clamped);
            case "easeoutquad" -> easeOut(GeoAnimationEasing::quadratic, clamped);
            case "easeinoutquad" -> easeInOut(GeoAnimationEasing::quadratic, clamped);
            case "easeincubic" -> cubic(clamped);
            case "easeoutcubic" -> easeOut(GeoAnimationEasing::cubic, clamped);
            case "easeinoutcubic" -> easeInOut(GeoAnimationEasing::cubic, clamped);
            case "easeinquart" -> pow(clamped, 4);
            case "easeoutquart" -> easeOut(t -> pow(t, 4), clamped);
            case "easeinoutquart" -> easeInOut(t -> pow(t, 4), clamped);
            case "easeinquint" -> pow(clamped, 5);
            case "easeoutquint" -> easeOut(t -> pow(t, 5), clamped);
            case "easeinoutquint" -> easeInOut(t -> pow(t, 5), clamped);
            case "easeinexpo" -> exp(clamped);
            case "easeoutexpo" -> easeOut(GeoAnimationEasing::exp, clamped);
            case "easeinoutexpo" -> easeInOut(GeoAnimationEasing::exp, clamped);
            case "easeincirc" -> circle(clamped);
            case "easeoutcirc" -> easeOut(GeoAnimationEasing::circle, clamped);
            case "easeinoutcirc" -> easeInOut(GeoAnimationEasing::circle, clamped);
            case "easeinback" -> back(clamped, arg);
            case "easeoutback" -> easeOut(t -> back(t, arg), clamped);
            case "easeinoutback" -> easeInOut(t -> back(t, arg), clamped);
            case "easeinelastic" -> elastic(clamped, arg);
            case "easeoutelastic" -> easeOut(t -> elastic(t, arg), clamped);
            case "easeinoutelastic" -> easeInOut(t -> elastic(t, arg), clamped);
            case "easeinbounce" -> bounceIn(clamped, arg);
            case "easeoutbounce" -> bounceOut(clamped, arg);
            case "easeinoutbounce" -> bounceInOut(clamped, arg);
            default -> clamped;
        };
        return (float) Math.max(0.0d, Math.min(1.0d, value));
    }

    private static String normalize(String rawType) {
        return rawType == null ? "linear" : rawType.toLowerCase(Locale.ROOT);
    }

    private static double easeOut(DoubleUnary function, double time) {
        return 1.0d - function.apply(1.0d - time);
    }

    private static double easeInOut(DoubleUnary function, double time) {
        if (time < 0.5d) {
            return function.apply(time * 2.0d) / 2.0d;
        }
        return 1.0d - function.apply((1.0d - time) * 2.0d) / 2.0d;
    }

    private static double quadratic(double time) {
        return time * time;
    }

    private static double cubic(double time) {
        return time * time * time;
    }

    private static double sine(double time) {
        return 1.0d - Math.cos(time * Math.PI / 2.0d);
    }

    private static double circle(double time) {
        return 1.0d - Math.sqrt(Math.max(0.0d, 1.0d - time * time));
    }

    private static double exp(double time) {
        return time <= 0.0d ? 0.0d : Math.pow(2.0d, 10.0d * (time - 1.0d));
    }

    private static double pow(double time, int power) {
        return Math.pow(time, power);
    }

    private static double back(double time, @Nullable Double arg) {
        double overshoot = arg == null ? 1.70158d : arg;
        return time * time * ((overshoot + 1.0d) * time - overshoot);
    }

    private static double elastic(double time, @Nullable Double arg) {
        double oscillations = arg == null ? 1.0d : arg;
        return 1.0d - Math.pow(Math.cos(time * Math.PI / 2.0d), 3.0d) * Math.cos(time * oscillations * Math.PI);
    }

    private static double bounceOut(double time, @Nullable Double arg) {
        double bounciness = arg == null ? 0.5d : arg;
        double scale = 1.0d + Math.max(0.0d, bounciness) * 0.5d;
        return Math.abs(Math.sin((time + 1.0d) * Math.PI * scale) * (1.0d - time));
    }

    private static double bounceIn(double time, @Nullable Double arg) {
        return 1.0d - bounceOut(1.0d - time, arg);
    }

    private static double bounceInOut(double time, @Nullable Double arg) {
        if (time < 0.5d) {
            return bounceIn(time * 2.0d, arg) / 2.0d;
        }
        return 0.5d + bounceOut(time * 2.0d - 1.0d, arg) / 2.0d;
    }

    private static double catmullRom(double value) {
        return 0.5d * (2.0d * (value + 1.0d) + ((value + 2.0d) - value)
                + (2.0d * value - 5.0d * (value + 1.0d) + 4.0d * (value + 2.0d) - (value + 3.0d))
                + (3.0d * (value + 1.0d) - value - 3.0d * (value + 2.0d) + (value + 3.0d)));
    }

    @FunctionalInterface
    private interface DoubleUnary {
        double apply(double value);
    }
}
