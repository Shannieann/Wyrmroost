package dev.elifian.chaoslib.client.animation;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.elifian.chaoslib.molang.MolangRuntime;
import net.minecraft.client.Minecraft;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.GsonHelper;

import dev.elifian.chaoslib.platform.ClientOnly;
import org.jetbrains.annotations.Nullable;

import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

@ClientOnly
public final class GeoAnimationLoader {
    private static final Map<ResourceLocation, GeoAnimationData> CACHE = new ConcurrentHashMap<>();
    private static final Set<ResourceLocation> USED = ConcurrentHashMap.newKeySet();

    private GeoAnimationLoader() {
    }

    public static GeoAnimationData load(ResourceLocation id) {
        return load(id, Minecraft.getInstance().getResourceManager());
    }

    public static GeoAnimationData load(ResourceLocation id, ResourceManager resourceManager) {
        USED.add(id);
        return CACHE.computeIfAbsent(id, key -> read(key, resourceManager));
    }

    public static void clearCache() {
        CACHE.clear();
    }

    public static void preload(ResourceManager resourceManager) {
        for (ResourceLocation id : resourceManager.listResources("animations", path -> path.getPath().endsWith(".animation.json")).keySet()) {
            load(id, resourceManager);
        }
    }

    /**
     * Preloads only the provided animation IDs (no resource manager scanning).
     */
    public static void preload(ResourceManager resourceManager, Iterable<ResourceLocation> ids) {
        for (ResourceLocation id : ids) {
            if (id != null) {
                load(id, resourceManager);
            }
        }
    }

    /**
     * Preloads only animations that have been requested via {@link #load(ResourceLocation)} so far.
     */
    public static void preloadUsed(ResourceManager resourceManager) {
        preload(resourceManager, List.copyOf(USED));
    }

    private static GeoAnimationData read(ResourceLocation id, ResourceManager resourceManager) {
        try (InputStreamReader reader = new InputStreamReader(
                resourceManager.getResource(id).orElseThrow().open(),
                StandardCharsets.UTF_8)) {
            return parse(JsonParser.parseReader(reader).getAsJsonObject());
        } catch (Exception exception) {
            throw new IllegalStateException("Failed to load Chaos animation resource " + id, exception);
        }
    }

    static GeoAnimationData parse(JsonObject root) {
        GeoAnimationData.Format format = root.has("geckolib_format_version")
                ? GeoAnimationData.Format.GECKOLIB
                : GeoAnimationData.Format.BEDROCK;
        JsonObject animationsJson = GsonHelper.getAsJsonObject(root, "animations");
        LinkedHashMap<String, GeoAnimationData.AnimationClip> animations = new LinkedHashMap<>();
        for (Map.Entry<String, JsonElement> animationEntry : animationsJson.entrySet()) {
            JsonObject animationObject = animationEntry.getValue().getAsJsonObject();
            boolean loop = parseLoop(animationObject.get("loop"));
            float animationLength = animationObject.has("animation_length")
                    ? GsonHelper.getAsFloat(animationObject, "animation_length")
                    : 0.0f;
            LinkedHashMap<String, GeoAnimationData.BoneAnimation> bones = new LinkedHashMap<>();
            if (animationObject.has("bones")) {
                JsonObject bonesObject = GsonHelper.getAsJsonObject(animationObject, "bones");
                for (Map.Entry<String, JsonElement> boneEntry : bonesObject.entrySet()) {
                    JsonObject boneObject = boneEntry.getValue().getAsJsonObject();
                    GeoAnimationData.RelativeTo relativeTo = parseRelativeTo(boneObject.get("relative_to"));
                    bones.put(boneEntry.getKey(), new GeoAnimationData.BoneAnimation(
                            parseChannel(boneObject.get("position"), format),
                            parseChannel(boneObject.get("rotation"), format),
                            parseChannel(boneObject.get("scale"), format),
                            relativeTo
                    ));
                }
            }
            animations.put(animationEntry.getKey(), new GeoAnimationData.AnimationClip(loop, animationLength, Map.copyOf(bones)));
        }
        return new GeoAnimationData(Map.copyOf(animations), format);
    }

    private static boolean parseLoop(@Nullable JsonElement loopElement) {
        if (loopElement == null || loopElement.isJsonNull()) {
            return false;
        }
        if (loopElement.isJsonPrimitive() && loopElement.getAsJsonPrimitive().isBoolean()) {
            return loopElement.getAsBoolean();
        }
        if (loopElement.isJsonPrimitive() && loopElement.getAsJsonPrimitive().isString()) {
            return !"false".equalsIgnoreCase(loopElement.getAsString());
        }
        return false;
    }

    private static @Nullable GeoAnimationData.Channel parseChannel(@Nullable JsonElement channelElement, GeoAnimationData.Format format) {
        if (channelElement == null || channelElement.isJsonNull()) {
            return null;
        }
        if (channelElement.isJsonArray() || channelElement.isJsonPrimitive()) {
            return GeoAnimationData.Channel.constant(parseVectorExpression(channelElement));
        }

        JsonObject object = channelElement.getAsJsonObject();
        if (object.has("vector") || object.has("post") || object.has("pre")) {
            GeoAnimationData.Keyframe keyframe = parseKeyframe(0.0f, object, format);
            return GeoAnimationData.Channel.constant(keyframe.post());
        }

        ArrayList<GeoAnimationData.Keyframe> keyframes = new ArrayList<>();
        for (Map.Entry<String, JsonElement> entry : object.entrySet()) {
            if (!isKeyframeTimestamp(entry.getKey())) {
                continue;
            }
            keyframes.add(parseKeyframe(Float.parseFloat(entry.getKey()), entry.getValue(), format));
        }
        return keyframes.isEmpty() ? null : GeoAnimationData.Channel.keyframes(keyframes);
    }

    private static GeoAnimationData.Keyframe parseKeyframe(float timeSeconds, JsonElement element, GeoAnimationData.Format format) {
        if (element.isJsonArray()) {
            GeoAnimationData.VectorExpression vector = parseVectorExpression(element);
            return new GeoAnimationData.Keyframe(timeSeconds, vector, vector, vector, vector, GeoAnimationData.LerpMode.LINEAR, null);
        }
        if (element.isJsonPrimitive()) {
            GeoAnimationData.VectorExpression vector = parseVectorExpression(element);
            return new GeoAnimationData.Keyframe(timeSeconds, vector, vector, vector, vector, GeoAnimationData.LerpMode.LINEAR, null);
        }

        JsonObject object = element.getAsJsonObject();
        GeoAnimationData.VectorExpression vector = parseKeyframeVector(object, format);
        if (format == GeoAnimationData.Format.GECKOLIB) {
            GeoAnimationData.Easing easing = object.has("vector") ? parseEasing(object) : null;
            return new GeoAnimationData.Keyframe(
                    timeSeconds,
                    vector,
                    vector,
                    vector,
                    vector,
                    GeoAnimationData.LerpMode.LINEAR,
                    easing
            );
        }

        GeoAnimationData.VectorExpression pre = object.has("pre") ? parseVectorExpression(object.get("pre")) : vector;
        GeoAnimationData.VectorExpression post = object.has("post") ? parseVectorExpression(object.get("post")) : vector;
        GeoAnimationData.VectorExpression leftBezier = object.has("left_bezier") ? parseVectorExpression(object.get("left_bezier")) : pre;
        GeoAnimationData.VectorExpression rightBezier = object.has("right_bezier") ? parseVectorExpression(object.get("right_bezier")) : post;
        GeoAnimationData.LerpMode lerpMode = object.has("lerp_mode")
                ? parseLerpMode(GsonHelper.getAsString(object, "lerp_mode"))
                : GeoAnimationData.LerpMode.LINEAR;
        GeoAnimationData.Easing easing = parseEasing(object);
        return new GeoAnimationData.Keyframe(timeSeconds, pre, post, leftBezier, rightBezier, lerpMode, easing);
    }

    private static GeoAnimationData.VectorExpression parseKeyframeVector(JsonObject object, GeoAnimationData.Format format) {
        if (object.has("vector")) {
            return parseVectorExpression(object.get("vector"));
        }

        if (format == GeoAnimationData.Format.GECKOLIB) {
            if (object.has("pre")) {
                return parseVectorExpression(object.get("pre"));
            }
            if (object.has("post")) {
                return parseVectorExpression(object.get("post"));
            }
        }

        if (object.has("post")) {
            return parseVectorExpression(object.get("post"));
        }

        if (object.has("pre")) {
            return parseVectorExpression(object.get("pre"));
        }

        throw new IllegalArgumentException("Animation keyframe is missing vector/pre/post: " + object);
    }

    private static GeoAnimationData.LerpMode parseLerpMode(String rawMode) {
        return switch (rawMode.toLowerCase(Locale.ROOT)) {
            case "step" -> GeoAnimationData.LerpMode.STEP;
            case "smooth", "catmullrom" -> GeoAnimationData.LerpMode.SMOOTH;
            case "bezier" -> GeoAnimationData.LerpMode.BEZIER;
            default -> GeoAnimationData.LerpMode.LINEAR;
        };
    }

    private static GeoAnimationData.VectorExpression parseVectorExpression(JsonElement element) {
        if (element.isJsonObject()) {
            JsonObject object = element.getAsJsonObject();
            if (object.has("vector")) {
                return parseVectorExpression(object.get("vector"));
            }
        }

        if (element.isJsonPrimitive()) {
            MolangRuntime.MolangExpression scalar = parseScalarExpression(element);
            return new GeoAnimationData.VectorExpression(scalar, scalar, scalar);
        }

        List<JsonElement> elements = new ArrayList<>(3);
        element.getAsJsonArray().forEach(elements::add);
        if (elements.size() != 3) {
            throw new IllegalArgumentException("Animation vector must have exactly 3 components");
        }
        return new GeoAnimationData.VectorExpression(
                parseScalarExpression(elements.get(0)),
                parseScalarExpression(elements.get(1)),
                parseScalarExpression(elements.get(2))
        );
    }

    private static MolangRuntime.MolangExpression parseScalarExpression(JsonElement element) {
        if (element.isJsonPrimitive() && element.getAsJsonPrimitive().isNumber()) {
            return MolangRuntime.constant(element.getAsDouble());
        }
        if (element.isJsonPrimitive() && element.getAsJsonPrimitive().isString()) {
            String raw = element.getAsString().trim();
            if (raw.isEmpty() || "-".equals(raw)) {
                return MolangRuntime.constant(0.0);
            }
            return MolangRuntime.parse(raw);
        }
        throw new IllegalArgumentException("Unsupported animation expression: " + element);
    }

    private static boolean isKeyframeTimestamp(String key) {
        if (key == null) {
            return false;
        }
        try {
            Float.parseFloat(key);
            return true;
        } catch (NumberFormatException ignored) {
            return false;
        }
    }

    private static @Nullable GeoAnimationData.Easing parseEasing(JsonObject object) {
        if (!object.has("easing")) {
            return null;
        }

        String type = GsonHelper.getAsString(object, "easing").trim();
        if (type.isEmpty()) {
            return null;
        }

        List<MolangRuntime.MolangExpression> args = Collections.emptyList();
        if (object.has("easingArgs")) {
            ArrayList<MolangRuntime.MolangExpression> parsed = new ArrayList<>();
            object.getAsJsonArray("easingArgs").forEach(arg -> parsed.add(parseScalarExpression(arg)));
            args = List.copyOf(parsed);
        }

        return new GeoAnimationData.Easing(type, args);
    }

    private static GeoAnimationData.RelativeTo parseRelativeTo(@Nullable JsonElement element) {
        if (element == null || element.isJsonNull()) {
            return GeoAnimationData.RelativeTo.LOCAL;
        }

        JsonObject object = element.getAsJsonObject();
        return new GeoAnimationData.RelativeTo(
                parseSpace(object, "position"),
                parseSpace(object, "rotation"),
                parseSpace(object, "scale")
        );
    }

    private static GeoAnimationData.Space parseSpace(JsonObject object, String key) {
        if (!object.has(key)) {
            return GeoAnimationData.Space.LOCAL;
        }

        String value = GsonHelper.getAsString(object, key, "local").trim().toLowerCase(Locale.ROOT);
        return switch (value) {
            case "entity" -> GeoAnimationData.Space.ENTITY;
            default -> GeoAnimationData.Space.LOCAL;
        };
    }
}
