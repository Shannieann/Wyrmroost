package dev.elifian.chaoslib.client.model.baked;

import dev.elifian.chaoslib.api.model.render.GeoRenderPass;
import dev.elifian.chaoslib.cache.object.BakedGeoModel;
import dev.elifian.chaoslib.cache.object.GeoBone;
import dev.elifian.chaoslib.cache.object.GeoCube;
import dev.elifian.chaoslib.cache.object.GeoQuad;
import dev.elifian.chaoslib.cache.object.GeoVertex;
import dev.elifian.chaoslib.loading.GeoModelLoader;
import dev.elifian.chaoslib.mixin.render.client.JsonUnbakedModelAccessor;
import dev.elifian.chaoslib.model.baked.StaticGeoBakedModel;
import dev.elifian.chaoslib.model.baked.StaticGeoBonePose;
import dev.elifian.chaoslib.model.baked.StaticGeoModelRegistry;
import dev.elifian.chaoslib.model.baked.StaticGeoQuadCullingMode;
import dev.elifian.chaoslib.model.baked.StaticGeoRenderMode;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.resources.model.ModelBaker;
import net.minecraft.client.resources.model.ModelState;
import net.minecraft.client.resources.model.UnbakedModel;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.Material;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.resources.ResourceLocation;

import dev.elifian.chaoslib.platform.ClientOnly;
import dev.elifian.chaoslib.platform.Services;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Vector4f;

import java.util.HashSet;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import net.minecraft.client.renderer.block.model.BlockModel;
import net.minecraft.client.renderer.block.model.ItemOverrides;
import net.minecraft.client.renderer.block.model.ItemTransforms;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.client.renderer.block.model.ItemTransform;

@ClientOnly
public final class StaticGeoModelBaker {
    private static final String STATIC_TEXTURE_MATERIAL = "static";
    private static final String PARTICLE_TEXTURE_MATERIAL = "particle";
    private static final Map<BakeCacheKey, Map<StaticGeoRenderMode, StaticGeoBakedModel.LayeredQuadBuckets>> BAKE_CACHE = new ConcurrentHashMap<>();

    public static void clearBakeCache() {
        BAKE_CACHE.clear();
    }

    public static BakedModel bake(
            StaticGeoBakeContext context,
            ModelBaker baker,
            Function<Material, TextureAtlasSprite> spriteGetter,
            ModelState modelState,
            ItemOverrides overrides
    ) {
        ResourceLocation modelLocation = ResourceLocation.parse(context.modelName());
        ResourceLocation requestedModelId = resolveRequestedModelId(context, modelLocation);
        boolean blockModel = isBlockModel(modelLocation);
        boolean itemModel = !blockModel && requestedModelId.getPath().startsWith("item/");
        if (itemModel && !hasRequiredItemParentModel(baker, requestedModelId)) {
            return Minecraft.getInstance().getModelManager().getMissingModel();
        }

        ResourceLocation registryModelId = resolveRegistryModelId(baker, requestedModelId, modelLocation);
        StaticGeoModelRegistry.Entry entry = StaticGeoModelRegistry.lookup(registryModelId);
        if (entry == null) {
            throw new IllegalStateException("No ChaosLib static geo entry registered for model " + requestedModelId);
        }

        BakedGeoModel geoModel = GeoModelLoader.load(entry.geoModelId());
        ResourceLocation fallbackStaticTextureId = resolveLegacyStaticTexture(entry);
        TextureAtlasSprite sprite = spriteGetter.apply(context.material(STATIC_TEXTURE_MATERIAL));
        if (sprite == null && fallbackStaticTextureId != null) {
            sprite = spriteGetter.apply(new Material(
                    InventoryMenu.BLOCK_ATLAS,
                    toBlockAtlasId(fallbackStaticTextureId)
            ));
        }
        TextureAtlasSprite particleSprite = context.hasMaterial(PARTICLE_TEXTURE_MATERIAL)
                ? spriteGetter.apply(context.material(PARTICLE_TEXTURE_MATERIAL))
                : sprite;
        if (particleSprite == null && fallbackStaticTextureId != null) {
            particleSprite = spriteGetter.apply(new Material(
                    InventoryMenu.BLOCK_ATLAS,
                    toBlockAtlasId(fallbackStaticTextureId)
            ));
        }
        if (particleSprite == null) {
            particleSprite = sprite;
        }
        Matrix4f rootTransform = resolveRootTransform(entry, context, modelState, blockModel);
        Matrix4f centeredItemTransform = itemModel
                ? buildCenteredItemTransform(geoModel, entry.geoModelDefinition().getBoneRestPoses("default"), rootTransform)
                : null;
        Matrix4f bakedRootTransform = itemModel ? new Matrix4f() : rootTransform;
        Matrix4f postTransform = itemModel ? centeredItemTransform : null;

        final TextureAtlasSprite bakedSprite = sprite;
        final ResourceLocation staticTextureId = fallbackStaticTextureId;
        final ResourceLocation emissiveTextureId = entry.geoModelDefinition().useEmissiveLayer()
                ? entry.geoModelDefinition().getStaticEmissiveTextureResource()
                : null;
        final boolean hasEmissive = emissiveTextureId != null && entry.geoModelDefinition().hasClientResource(emissiveTextureId);
        final int staticEmissivePassCount = Math.max(0, entry.geoModelDefinition().getStaticEmissivePassCount());
        final boolean customPassModel = entry.geoModelDefinition().usesCustomRenderPasses();
        final ItemTransforms transforms = resolveTransforms(context, baker, requestedModelId);

        Map<String, Map<StaticGeoRenderMode, StaticGeoBakedModel.LayeredQuadBuckets>> quadsByVariant = new LinkedHashMap<>();
        quadsByVariant.put("default", bakeVariant(
                "default",
                entry,
                geoModel,
                bakedRootTransform,
                bakedSprite,
                staticTextureId,
                hasEmissive,
                emissiveTextureId,
                staticEmissivePassCount,
                itemModel,
                customPassModel,
                spriteGetter
        ));

        return Services.STATIC_MODELS.wrapStaticModel(StaticGeoBakedModel.createLazy(
                geoModel,
                quadsByVariant,
                variantKey -> bakeVariant(
                        variantKey,
                        entry,
                        geoModel,
                        bakedRootTransform,
                        bakedSprite,
                        staticTextureId,
                        hasEmissive,
                        emissiveTextureId,
                        staticEmissivePassCount,
                        itemModel,
                        customPassModel,
                        spriteGetter
                ),
                particleSprite,
                entry.renderModeSelector(),
                entry.geoModelDefinition()::getStaticPoseVariantKey,
                entry.geoModelDefinition()::getStaticRenderLayer,
                blockState -> customPassModel || entry.geoModelDefinition().shouldRenderStaticEmissive(blockState),
                entry.geoModelDefinition().useStaticAmbientOcclusion(),
                true,
                context.useBlockLight(),
                transforms,
                postTransform,
                overrides
        ));
    }

    private static Map<StaticGeoRenderMode, StaticGeoBakedModel.LayeredQuadBuckets> bakeVariant(
            String variantKey,
            StaticGeoModelRegistry.Entry entry,
            BakedGeoModel geoModel,
            Matrix4f bakedRootTransform,
            TextureAtlasSprite bakedSprite,
            ResourceLocation staticTextureId,
            boolean hasEmissive,
            @Nullable ResourceLocation emissiveTextureId,
            int staticEmissivePassCount,
            boolean itemModel,
            boolean customPassModel,
            Function<Material, TextureAtlasSprite> spriteGetter
    ) {
        if (customPassModel) {
            return bakeRenderPassVariant(variantKey, entry, geoModel, bakedRootTransform, itemModel, spriteGetter);
        }

        Map<String, StaticGeoBonePose> boneRestPoses = entry.geoModelDefinition().getBoneRestPoses(variantKey);
        Map<StaticGeoRenderMode, Set<String>> includedBonesByMode = Map.of(
                StaticGeoRenderMode.NONE, entry.geoModelDefinition().getStaticBoneNames(geoModel, StaticGeoRenderMode.NONE),
                StaticGeoRenderMode.ALL_BONES, entry.geoModelDefinition().getStaticBoneNames(geoModel, StaticGeoRenderMode.ALL_BONES),
                StaticGeoRenderMode.STATIC_ONLY, entry.geoModelDefinition().getStaticBoneNames(geoModel, StaticGeoRenderMode.STATIC_ONLY)
        );
        Map<StaticGeoRenderMode, Set<String>> emissiveBonesByMode = Map.of(
                StaticGeoRenderMode.NONE, entry.geoModelDefinition().getStaticEmissiveBoneNames(geoModel, variantKey, StaticGeoRenderMode.NONE),
                StaticGeoRenderMode.ALL_BONES, entry.geoModelDefinition().getStaticEmissiveBoneNames(geoModel, variantKey, StaticGeoRenderMode.ALL_BONES),
                StaticGeoRenderMode.STATIC_ONLY, entry.geoModelDefinition().getStaticEmissiveBoneNames(geoModel, variantKey, StaticGeoRenderMode.STATIC_ONLY)
        );
        BakeCacheKey cacheKey = new BakeCacheKey(
                entry.geoModelId(),
                bakedRootTransform,
                staticTextureId,
                hasEmissive ? emissiveTextureId : null,
                entry.geoModelDefinition().getStaticQuadCullingMode(null),
                boneRestPoses,
                includedBonesByMode,
                emissiveBonesByMode
        );
        return BAKE_CACHE.computeIfAbsent(
                cacheKey,
                ignored -> {
                    Map<StaticGeoRenderMode, StaticGeoBakedModel.LayeredQuadBuckets> combined = StaticGeoBakedModel.bakeQuadsByMode(
                            geoModel,
                            cacheKey.rootTransform(),
                            bakedSprite,
                            cacheKey.includedBonesByMode(),
                            boneRestPoses,
                            entry.geoModelDefinition().getStaticQuadCullingMode(null),
                            staticTextureId,
                            entry.geoModelDefinition().getStaticRenderLayer(null),
                            false
                    );
                    if (!hasEmissive) {
                        return combined;
                    }

                    TextureAtlasSprite emissiveSprite = spriteGetter.apply(new Material(InventoryMenu.BLOCK_ATLAS, toBlockAtlasId(emissiveTextureId)));
                    if (emissiveSprite == null) {
                        return combined;
                    }

                    for (int pass = 0; pass < staticEmissivePassCount; pass++) {
                        Map<StaticGeoRenderMode, StaticGeoBakedModel.LayeredQuadBuckets> emissive = StaticGeoBakedModel.bakeQuadsByMode(
                                geoModel,
                                cacheKey.rootTransform(),
                                emissiveSprite,
                                cacheKey.emissiveBonesByMode(),
                                boneRestPoses,
                                entry.geoModelDefinition().getStaticQuadCullingMode(null),
                                emissiveTextureId,
                                null,
                                true,
                                pass
                        );
                        combined.forEach((mode, buckets) -> {
                            StaticGeoBakedModel.LayeredQuadBuckets emissiveBuckets = emissive.get(mode);
                            if (emissiveBuckets != null) {
                                buckets.mergeFrom(emissiveBuckets);
                            }
                        });
                    }
                    return combined;
                }
        );
    }

    private static Map<StaticGeoRenderMode, StaticGeoBakedModel.LayeredQuadBuckets> bakeRenderPassVariant(
            String variantKey,
            StaticGeoModelRegistry.Entry entry,
            BakedGeoModel geoModel,
            Matrix4f bakedRootTransform,
            boolean itemModel,
            Function<Material, TextureAtlasSprite> spriteGetter
    ) {
        Map<String, StaticGeoBonePose> boneRestPoses = entry.geoModelDefinition().getBoneRestPoses(variantKey);
        EnumMap<StaticGeoRenderMode, StaticGeoBakedModel.LayeredQuadBuckets> combined = new EnumMap<>(StaticGeoRenderMode.class);
        for (StaticGeoRenderMode mode : StaticGeoRenderMode.values()) {
            combined.put(mode, new StaticGeoBakedModel.LayeredQuadBuckets());
        }

        for (GeoRenderPass<?> pass : entry.geoModelDefinition().getRenderPasses()) {
            if (itemModel ? !pass.shouldBakeIntoItemModel() : !pass.shouldBakeIntoBlockModel()) {
                continue;
            }

            ResourceLocation textureId = pass.getStaticTexture();
            if (textureId == null || !entry.geoModelDefinition().hasClientResource(textureId)) {
                continue;
            }

            TextureAtlasSprite sprite = spriteGetter.apply(new Material(InventoryMenu.BLOCK_ATLAS, toBlockAtlasId(textureId)));
            if (sprite == null) {
                continue;
            }

            Map<StaticGeoRenderMode, Set<String>> includedBonesByMode = Map.of(
                    StaticGeoRenderMode.NONE, entry.geoModelDefinition().resolveStaticRenderPassBones(pass, geoModel, variantKey, StaticGeoRenderMode.NONE, itemModel),
                    StaticGeoRenderMode.ALL_BONES, entry.geoModelDefinition().resolveStaticRenderPassBones(pass, geoModel, variantKey, StaticGeoRenderMode.ALL_BONES, itemModel),
                    StaticGeoRenderMode.STATIC_ONLY, entry.geoModelDefinition().resolveStaticRenderPassBones(pass, geoModel, variantKey, StaticGeoRenderMode.STATIC_ONLY, itemModel)
            );
            if (includedBonesByMode.values().stream().allMatch(Set::isEmpty)) {
                continue;
            }

            RenderType forcedLayer = pass.getStaticRenderLayer(textureId);
            int bakePassCount = pass.isStaticEmissive() ? pass.getStaticBakePassCount() : 1;
            for (int passIndex = 0; passIndex < bakePassCount; passIndex++) {
                Map<StaticGeoRenderMode, StaticGeoBakedModel.LayeredQuadBuckets> baked = StaticGeoBakedModel.bakeQuadsByMode(
                        geoModel,
                        bakedRootTransform,
                        sprite,
                        includedBonesByMode,
                        boneRestPoses,
                        entry.geoModelDefinition().getStaticQuadCullingMode(null),
                        textureId,
                        forcedLayer,
                        pass.isStaticEmissive(),
                        passIndex
                );
                combined.forEach((mode, buckets) -> {
                    StaticGeoBakedModel.LayeredQuadBuckets passBuckets = baked.get(mode);
                    if (passBuckets != null) {
                        buckets.mergeFrom(passBuckets);
                    }
                });
            }
        }

        return Map.copyOf(combined);
    }

    private static ItemTransforms resolveTransforms(StaticGeoBakeContext context, ModelBaker baker, ResourceLocation modelLocation) {
        ItemTransforms contextTransforms = context.transforms();
        if (contextTransforms != ItemTransforms.NO_TRANSFORMS) {
            return contextTransforms;
        }

        return resolveTransformsRecursive(baker, modelLocation, new HashSet<>());
    }

    private static ItemTransforms resolveTransformsRecursive(ModelBaker baker, ResourceLocation modelLocation, Set<ResourceLocation> visited) {
        if (!visited.add(modelLocation)) {
            return ItemTransforms.NO_TRANSFORMS;
        }

        UnbakedModel unbakedModel = baker.getModel(modelLocation);
        if (!(unbakedModel instanceof BlockModel jsonModel)) {
            return ItemTransforms.NO_TRANSFORMS;
        }

        ItemTransforms ownTransforms = jsonModel.getTransforms();
        ResourceLocation parentId = getParentModelId(jsonModel);
        if (parentId == null) {
            return ownTransforms;
        }

        ItemTransforms parentTransforms = resolveTransformsRecursive(baker, parentId, visited);
        return mergeTransforms(ownTransforms, parentTransforms);
    }

    private static ItemTransforms mergeTransforms(ItemTransforms primary, ItemTransforms fallback) {
        return new ItemTransforms(
                selectTransform(primary, fallback, ItemDisplayContext.THIRD_PERSON_LEFT_HAND),
                selectTransform(primary, fallback, ItemDisplayContext.THIRD_PERSON_RIGHT_HAND),
                selectTransform(primary, fallback, ItemDisplayContext.FIRST_PERSON_LEFT_HAND),
                selectTransform(primary, fallback, ItemDisplayContext.FIRST_PERSON_RIGHT_HAND),
                selectTransform(primary, fallback, ItemDisplayContext.HEAD),
                selectTransform(primary, fallback, ItemDisplayContext.GUI),
                selectTransform(primary, fallback, ItemDisplayContext.GROUND),
                selectTransform(primary, fallback, ItemDisplayContext.FIXED)
        );
    }

    private static ItemTransform selectTransform(ItemTransforms primary, ItemTransforms fallback, ItemDisplayContext mode) {
        if (primary != null && primary.hasTransform(mode)) {
            return primary.getTransform(mode);
        }

        if (fallback != null && fallback.hasTransform(mode)) {
            return fallback.getTransform(mode);
        }

        return ItemTransform.NO_TRANSFORM;
    }

    private static boolean hasRequiredItemParentModel(ModelBaker baker, ResourceLocation modelLocation) {
        UnbakedModel unbakedModel = baker.getModel(modelLocation);
        if (!(unbakedModel instanceof BlockModel jsonModel)) {
            return false;
        }

        return getParentModelId(jsonModel) != null;
    }

    private static ResourceLocation resolveRequestedModelId(StaticGeoBakeContext context, ResourceLocation fallback) {
        String modelName = context.modelName();
        if (modelName == null || modelName.isBlank()) {
            return fallback;
        }

        int variantSeparator = modelName.indexOf('#');
        String plainModelName = variantSeparator >= 0 ? modelName.substring(0, variantSeparator) : modelName;
        ResourceLocation parsed = ResourceLocation.tryParse(plainModelName);
        return parsed != null ? parsed : fallback;
    }

    private static ResourceLocation resolveRegistryModelId(ModelBaker baker, ResourceLocation requestedModelId, ResourceLocation fallback) {
        ResourceLocation directItemId = resolveDirectItemRegistryId(requestedModelId);
        if (directItemId != null && StaticGeoModelRegistry.lookup(directItemId) != null) {
            return directItemId;
        }

        ResourceLocation currentModelId = requestedModelId;
        Set<ResourceLocation> visited = new HashSet<>();

        while (currentModelId != null && visited.add(currentModelId)) {
            if (StaticGeoModelRegistry.lookup(currentModelId) != null) {
                return currentModelId;
            }

            UnbakedModel unbakedModel = baker.getModel(currentModelId);
            if (!(unbakedModel instanceof BlockModel jsonModel)) {
                break;
            }

            ResourceLocation parentId = getParentModelId(jsonModel);
            if (parentId == null) {
                break;
            }

            currentModelId = parentId;
        }

        return fallback;
    }

    private static ResourceLocation resolveDirectItemRegistryId(ResourceLocation modelId) {
        String path = modelId.getPath();
        if (!path.startsWith("item/")) {
            return null;
        }

        return ResourceLocation.fromNamespaceAndPath(modelId.getNamespace(), path.substring("item/".length()));
    }

    private static ResourceLocation getParentModelId(BlockModel jsonModel) {
        return ((JsonUnbakedModelAccessor) jsonModel).getParentId();
    }

    private static Matrix4f resolveRootTransform(
            StaticGeoModelRegistry.Entry entry,
            StaticGeoBakeContext context,
            ModelState modelState,
            boolean blockModel
    ) {
        if (blockModel) {
            return new Matrix4f()
                    .translate(0.5f, 0.5f, 0.5f)
                    .mul(modelState.getRotation().getMatrix())
                    .translate(0.0f, -0.5f, 0.0f)
                    .mul(entry.rootTransform())
                    .mul(context.rootTransform());
        }

        return new Matrix4f()
                .mul(entry.rootTransform())
                .mul(context.rootTransform())
                .mul(modelState.getRotation().getMatrix());
    }

    private static Matrix4f buildCenteredItemTransform(
            BakedGeoModel model,
            Map<String, StaticGeoBonePose> staticBonePoses,
            Matrix4f rootTransform
    ) {
        ModelBounds bounds = computeModelBounds(model, staticBonePoses);
        if (!bounds.isValid()) {
            return new Matrix4f(rootTransform).translate(0.5f, 0.5f, 0.5f);
        }

        float centerX = (bounds.minX + bounds.maxX) * 0.5f;
        float centerY = (bounds.minY + bounds.maxY) * 0.5f;
        float centerZ = (bounds.minZ + bounds.maxZ) * 0.5f;

        return new Matrix4f(rootTransform)
                .translate(0.5f - centerX, 0.5f - centerY, 0.5f - centerZ);
    }

    private static ModelBounds computeModelBounds(BakedGeoModel model, Map<String, StaticGeoBonePose> staticBonePoses) {
        Matrix4f[] matrixStack = new Matrix4f[Math.max(model.orderedBones().size() + 1, 2)];
        for (int i = 0; i < matrixStack.length; i++) {
            matrixStack[i] = new Matrix4f();
        }

        matrixStack[0].identity();
        ModelBounds bounds = new ModelBounds();
        collectModelBounds(model.topLevelBones(), matrixStack, 1, staticBonePoses, bounds);
        return bounds;
    }

    private static void collectModelBounds(
            Iterable<GeoBone> bones,
            Matrix4f[] matrixStack,
            int depth,
            Map<String, StaticGeoBonePose> staticBonePoses,
            ModelBounds bounds
    ) {
        Matrix4f parentMatrix = matrixStack[depth - 1];

        for (GeoBone bone : bones) {
            StaticGeoBonePose pose = staticBonePoses.getOrDefault(bone.getName(), StaticGeoBonePose.IDENTITY);
            float posX = bone.getPosX() + pose.posX();
            float posY = bone.getPosY() + pose.posY();
            float posZ = bone.getPosZ() + pose.posZ();
            float rotX = bone.getRotX() + pose.rotX();
            float rotY = bone.getRotY() + pose.rotY();
            float rotZ = bone.getRotZ() + pose.rotZ();
            float scaleX = bone.getScaleX() * pose.scaleX();
            float scaleY = bone.getScaleY() * pose.scaleY();
            float scaleZ = bone.getScaleZ() * pose.scaleZ();

            Matrix4f boneMatrix = matrixStack[depth]
                    .set(parentMatrix)
                    .translate(-posX / 16.0f, posY / 16.0f, posZ / 16.0f)
                    .translate(bone.getPivotX() / 16.0f, bone.getPivotY() / 16.0f, bone.getPivotZ() / 16.0f)
                    .rotateZ(rotZ)
                    .rotateY(rotY)
                    .rotateX(rotX)
                    .scale(scaleX, scaleY, scaleZ)
                    .translate(-bone.getPivotX() / 16.0f, -bone.getPivotY() / 16.0f, -bone.getPivotZ() / 16.0f);

            for (GeoCube cube : bone.getCubes()) {
                collectCubeBounds(boneMatrix, cube, bounds);
            }

            collectModelBounds(bone.getChildBones(), matrixStack, depth + 1, staticBonePoses, bounds);
        }
    }

    private static void collectCubeBounds(Matrix4f boneMatrix, GeoCube cube, ModelBounds bounds) {
        Matrix4f cubeMatrix = new Matrix4f(boneMatrix)
                .translate((float) cube.pivot().x() / 16.0f, (float) cube.pivot().y() / 16.0f, (float) cube.pivot().z() / 16.0f)
                .rotateZ((float) cube.rotation().z())
                .rotateY((float) cube.rotation().y())
                .rotateX((float) cube.rotation().x())
                .translate((float) -cube.pivot().x() / 16.0f, (float) -cube.pivot().y() / 16.0f, (float) -cube.pivot().z() / 16.0f);

        for (GeoQuad quad : cube.quads()) {
            if (quad == null) {
                continue;
            }

            for (GeoVertex vertex : quad.vertices()) {
                Vector4f transformed = cubeMatrix.transform(new Vector4f(vertex.x(), vertex.y(), vertex.z(), 1.0f));
                bounds.include(transformed.x(), transformed.y(), transformed.z());
            }
        }
    }

    private static ResourceLocation toBlockAtlasId(ResourceLocation textureId) {
        String path = textureId.getPath();
        if (path.startsWith("textures/")) {
            path = path.substring("textures/".length());
        }
        if (path.endsWith(".png")) {
            path = path.substring(0, path.length() - 4);
        }
        return ResourceLocation.fromNamespaceAndPath(textureId.getNamespace(), path);
    }

    private static boolean isBlockModel(ResourceLocation modelLocation) {
        return modelLocation.getPath().startsWith("block/");
    }

    private static @Nullable ResourceLocation resolveLegacyStaticTexture(StaticGeoModelRegistry.Entry entry) {
        try {
            return entry.geoModelDefinition().getStaticTextureResource();
        } catch (RuntimeException ignored) {
            return null;
        }
    }

    private record BakeCacheKey(
            ResourceLocation geoModelId,
            Matrix4f rootTransform,
            ResourceLocation textureId,
            ResourceLocation emissiveTextureId,
            StaticGeoQuadCullingMode quadCullingMode,
            Map<String, StaticGeoBonePose> boneRestPoses,
            Map<StaticGeoRenderMode, Set<String>> includedBonesByMode,
            Map<StaticGeoRenderMode, Set<String>> emissiveBonesByMode
    ) {
        @Override
        public int hashCode() {
            return Objects.hash(
                    this.geoModelId,
                    matrixHash(this.rootTransform),
                    this.textureId,
                    this.emissiveTextureId,
                    this.quadCullingMode,
                    this.boneRestPoses,
                    this.includedBonesByMode,
                    this.emissiveBonesByMode
            );
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) return true;
            if (!(obj instanceof BakeCacheKey other)) return false;
            return Objects.equals(this.geoModelId, other.geoModelId)
                    && matrixEquals(this.rootTransform, other.rootTransform)
                    && Objects.equals(this.textureId, other.textureId)
                    && Objects.equals(this.emissiveTextureId, other.emissiveTextureId)
                    && this.quadCullingMode == other.quadCullingMode
                    && Objects.equals(this.boneRestPoses, other.boneRestPoses)
                    && Objects.equals(this.includedBonesByMode, other.includedBonesByMode)
                    && Objects.equals(this.emissiveBonesByMode, other.emissiveBonesByMode);
        }

        private static int matrixHash(Matrix4f matrix) {
            int hash = 1;
            for (int row = 0; row < 4; row++) {
                for (int col = 0; col < 4; col++) {
                    hash = 31 * hash + Float.hashCode(matrix.get(row, col));
                }
            }
            return hash;
        }

        private static boolean matrixEquals(Matrix4f left, Matrix4f right) {
            for (int row = 0; row < 4; row++) {
                for (int col = 0; col < 4; col++) {
                    if (Float.floatToIntBits(left.get(row, col)) != Float.floatToIntBits(right.get(row, col))) {
                        return false;
                    }
                }
            }
            return true;
        }
    }

    private static final class ModelBounds {
        private float minX = Float.POSITIVE_INFINITY;
        private float minY = Float.POSITIVE_INFINITY;
        private float minZ = Float.POSITIVE_INFINITY;
        private float maxX = Float.NEGATIVE_INFINITY;
        private float maxY = Float.NEGATIVE_INFINITY;
        private float maxZ = Float.NEGATIVE_INFINITY;

        private void include(float x, float y, float z) {
            this.minX = Math.min(this.minX, x);
            this.minY = Math.min(this.minY, y);
            this.minZ = Math.min(this.minZ, z);
            this.maxX = Math.max(this.maxX, x);
            this.maxY = Math.max(this.maxY, y);
            this.maxZ = Math.max(this.maxZ, z);
        }

        private boolean isValid() {
            return this.minX <= this.maxX && this.minY <= this.maxY && this.minZ <= this.maxZ;
        }
    }
}
