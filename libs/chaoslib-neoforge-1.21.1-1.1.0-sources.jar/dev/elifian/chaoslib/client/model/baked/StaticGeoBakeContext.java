package dev.elifian.chaoslib.client.model.baked;

import dev.elifian.chaoslib.platform.ClientOnly;
import net.minecraft.client.renderer.block.model.ItemTransforms;
import net.minecraft.client.resources.model.Material;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

/**
 * What the static geo baker needs from the model being baked. NeoForge supplies this from its
 * geometry baking context; Fabric from the loaded block model.
 */
@ClientOnly
public interface StaticGeoBakeContext {
    String modelName();

    boolean hasMaterial(String name);

    Material material(String name);

    boolean useAmbientOcclusion();

    boolean isGui3d();

    boolean useBlockLight();

    @Nullable
    ItemTransforms transforms();

    /**
     * Extra transform declared by the model itself. NeoForge reads it from the model json;
     * Fabric has no equivalent and leaves it as the identity.
     */
    Matrix4f rootTransform();
}
