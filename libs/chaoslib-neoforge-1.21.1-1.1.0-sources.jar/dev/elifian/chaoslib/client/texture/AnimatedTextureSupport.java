package dev.elifian.chaoslib.client.texture;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.Util;

import dev.elifian.chaoslib.platform.ClientOnly;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@ClientOnly
public final class AnimatedTextureSupport {
    private static final Map<ResourceLocation, AnimationData> CACHE = new HashMap<>();
    private static ResourceManager lastResourceManager;

    private AnimatedTextureSupport() {
    }

    public static ResourceLocation resolveRenderTexture(@Nullable ResourceLocation texture) {
        if (texture == null) {
            return null;
        }

        AnimationData data = resolveAnimationData(texture);
        if (!data.animated()) {
            return texture;
        }

        ResourceLocation frameTexture = data.resolveFrameTexture(texture);
        return frameTexture != null ? frameTexture : texture;
    }

    public static Matrix4f pushTextureMatrix(@Nullable ResourceLocation texture) {
        Matrix4f previous = new Matrix4f(RenderSystem.getTextureMatrix());
        Matrix4f animationMatrix = texture != null ? resolveTextureMatrix(texture) : null;
        if (animationMatrix != null) {
            RenderSystem.setTextureMatrix(animationMatrix);
        }
        return previous;
    }

    public static Matrix4f pushTextureMatrix(@Nullable ResourceLocation texture, @Nullable UvRegion uvRegion) {
        Matrix4f previous = new Matrix4f(RenderSystem.getTextureMatrix());
        Matrix4f textureMatrix = resolveTextureMatrix(texture, uvRegion);
        if (textureMatrix != null) {
            RenderSystem.setTextureMatrix(textureMatrix);
        }
        return previous;
    }

    public static void popTextureMatrix(Matrix4f previous) {
        RenderSystem.setTextureMatrix(previous);
    }

    private static Matrix4f resolveTextureMatrix(ResourceLocation texture) {
        return resolveTextureMatrix(texture, null);
    }

    public static boolean isAnimated(@Nullable ResourceLocation texture) {
        return texture != null && resolveAnimationData(texture).animated();
    }

    public static boolean requiresUvNormalization(@Nullable ResourceLocation texture) {
        if (texture == null) {
            return false;
        }
        if (isGeneratedFrameTexture(texture)) {
            return true;
        }
        return resolveAnimationData(texture).animated();
    }

    private static boolean isGeneratedFrameTexture(ResourceLocation texture) {
        return "chaoslib".equals(texture.getNamespace()) && texture.getPath().startsWith("generated/animated_frame/");
    }

    private static @Nullable Matrix4f resolveTextureMatrix(@Nullable ResourceLocation texture, @Nullable UvRegion uvRegion) {
        if (texture == null) {
            return uvRegion == null || uvRegion.isFullCoverage() ? null : normalizationMatrix(uvRegion);
        }

        AnimationData data = resolveAnimationData(texture);
        Matrix4f normalization = uvRegion == null || uvRegion.isFullCoverage() ? null : normalizationMatrix(uvRegion);
        if (!data.animated()) {
            return normalization;
        }

        int frame = data.currentFrame();
        float frameScaleU = (float) data.frameWidth() / (float) data.imageWidth();
        float frameScaleV = (float) data.frameHeight() / (float) data.imageHeight();
        float frameOffsetU = (frame % data.columns()) * frameScaleU;
        float frameOffsetV = (frame / data.columns()) * frameScaleV;
        Matrix4f animation = new Matrix4f()
                .identity()
                .translate(frameOffsetU, frameOffsetV, 0.0f)
                .scale(frameScaleU, frameScaleV, 1.0f);
        return normalization == null ? animation : animation.mul(normalization, new Matrix4f());
    }

    private static Matrix4f normalizationMatrix(UvRegion uvRegion) {
        return new Matrix4f()
                .identity()
                .scale(1.0f / uvRegion.width(), 1.0f / uvRegion.height(), 1.0f)
                .translate(-uvRegion.minU(), -uvRegion.minV(), 0.0f);
    }

    private static AnimationData resolveAnimationData(ResourceLocation texture) {
        Minecraft client = Minecraft.getInstance();
        if (client == null) {
            return AnimationData.NONE;
        }

        ResourceManager resourceManager = client.getResourceManager();
        if (resourceManager != lastResourceManager) {
            clearCache(client);
            lastResourceManager = resourceManager;
        }

        return CACHE.computeIfAbsent(texture, id -> loadAnimationData(resourceManager, id).orElse(AnimationData.NONE));
    }

    private static Optional<AnimationData> loadAnimationData(ResourceManager resourceManager, ResourceLocation texture) {
        ResourceLocation textureId = resolveTextureResourceId(texture);
        ResourceLocation metadataId = resolveTextureMetadataId(texture);

        Optional<JsonObject> metadata = resourceManager.getResource(metadataId).map(resource -> {
            try (var inputStream = resource.open();
                 InputStreamReader reader = new InputStreamReader(inputStream)) {
                JsonElement parsed = JsonParser.parseReader(reader);
                return parsed.isJsonObject() ? parsed.getAsJsonObject() : null;
            } catch (Exception ignored) {
                return null;
            }
        });
        if (metadata.isEmpty()) {
            return Optional.empty();
        }

        JsonObject animation = metadata.get().has("animation") && metadata.get().get("animation").isJsonObject()
                ? metadata.get().getAsJsonObject("animation")
                : null;
        if (animation == null) {
            return Optional.empty();
        }

        NativeImage image;
        int width;
        int height;
        try (var inputStream = resourceManager.getResource(textureId).orElseThrow().open()) {
            image = NativeImage.read(inputStream);
            if (image == null) {
                return Optional.empty();
            }
            width = image.getWidth();
            height = image.getHeight();
        } catch (Exception ignored) {
            return Optional.empty();
        }

        FrameSize frameSize = resolveFrameSize(animation, width, height);
        if (frameSize == null) {
            image.close();
            return Optional.empty();
        }

        int columns = width / frameSize.width();
        int rows = height / frameSize.height();
        int frameCount = columns * rows;
        int defaultFrameTime = Math.max(1, animation.has("frametime") ? animation.get("frametime").getAsInt() : 1);
        Frame[] frames = parseFrames(animation.getAsJsonArray("frames"), frameCount, defaultFrameTime);
        return Optional.of(new AnimationData(image, width, height, frameSize.width(), frameSize.height(), columns, frameCount, frames));
    }

    private static void clearCache(@Nullable Minecraft client) {
        TextureManager textureManager = client != null ? client.getTextureManager() : null;
        for (AnimationData data : CACHE.values()) {
            data.close(textureManager);
        }
        CACHE.clear();
    }

    private static @Nullable FrameSize resolveFrameSize(JsonObject animation, int imageWidth, int imageHeight) {
        int frameWidth = animation.has("width") ? animation.get("width").getAsInt() : -1;
        int frameHeight = animation.has("height") ? animation.get("height").getAsInt() : -1;
        if (frameWidth != -1) {
            frameHeight = frameHeight != -1 ? frameHeight : imageHeight;
        } else if (frameHeight != -1) {
            frameWidth = imageWidth;
        } else {
            frameWidth = Math.min(imageWidth, imageHeight);
            frameHeight = frameWidth;
        }

        if (frameWidth <= 0 || frameHeight <= 0 || imageWidth % frameWidth != 0 || imageHeight % frameHeight != 0) {
            return null;
        }
        return new FrameSize(frameWidth, frameHeight);
    }

    static ResourceLocation resolveTextureResourceId(ResourceLocation texture) {
        String path = texture.getPath();
        if (!path.startsWith("textures/")) {
            path = "textures/" + path;
        }
        if (!path.endsWith(".png")) {
            path = path + ".png";
        }
        return ResourceLocation.fromNamespaceAndPath(texture.getNamespace(), path);
    }

    static ResourceLocation resolveTextureMetadataId(ResourceLocation texture) {
        ResourceLocation textureResourceId = resolveTextureResourceId(texture);
        return ResourceLocation.fromNamespaceAndPath(textureResourceId.getNamespace(), textureResourceId.getPath() + ".mcmeta");
    }

    private static Frame[] parseFrames(JsonArray framesJson, int frameCount, int defaultFrameTime) {
        if (framesJson == null || framesJson.isEmpty()) {
            Frame[] frames = new Frame[frameCount];
            for (int i = 0; i < frameCount; i++) {
                frames[i] = new Frame(i, defaultFrameTime);
            }
            return frames;
        }

        Frame[] frames = new Frame[framesJson.size()];
        int validCount = 0;
        for (JsonElement element : framesJson) {
            Frame frame = parseFrame(element, frameCount, defaultFrameTime);
            if (frame != null) {
                frames[validCount++] = frame;
            }
        }

        if (validCount == 0) {
            return parseFrames(null, frameCount, defaultFrameTime);
        }

        Frame[] compact = new Frame[validCount];
        System.arraycopy(frames, 0, compact, 0, validCount);
        return compact;
    }

    private static Frame parseFrame(JsonElement element, int frameCount, int defaultFrameTime) {
        if (element == null || element.isJsonNull()) {
            return null;
        }

        if (element.isJsonPrimitive() && element.getAsJsonPrimitive().isNumber()) {
            int index = element.getAsInt();
            return index >= 0 && index < frameCount ? new Frame(index, defaultFrameTime) : null;
        }

        if (!element.isJsonObject()) {
            return null;
        }

        JsonObject object = element.getAsJsonObject();
        if (!object.has("index")) {
            return null;
        }

        int index = object.get("index").getAsInt();
        if (index < 0 || index >= frameCount) {
            return null;
        }

        int time = object.has("time") ? Math.max(1, object.get("time").getAsInt()) : defaultFrameTime;
        return new Frame(index, time);
    }

    private record Frame(int index, int time) {
    }

    private record FrameSize(int width, int height) {
    }

    private static final class AnimationData {
        private static final AnimationData NONE = new AnimationData(null, 1, 1, 1, 1, 1, 1, new Frame[0]);

        private final @Nullable NativeImage image;
        private final int imageWidth;
        private final int imageHeight;
        private final int frameWidth;
        private final int frameHeight;
        private final int columns;
        private final int frameCount;
        private final Frame[] frames;
        private @Nullable ResourceLocation frameTextureId;
        private @Nullable NativeImage frameImage;
        private @Nullable DynamicTexture frameTexture;
        private int uploadedFrame = -1;

        private AnimationData(@Nullable NativeImage image, int imageWidth, int imageHeight, int frameWidth, int frameHeight, int columns, int frameCount, Frame[] frames) {
            this.image = image;
            this.imageWidth = imageWidth;
            this.imageHeight = imageHeight;
            this.frameWidth = frameWidth;
            this.frameHeight = frameHeight;
            this.columns = columns;
            this.frameCount = frameCount;
            this.frames = frames;
        }

        private boolean animated() {
            return this.frames.length > 1 || this.frameCount > 1;
        }

        private int imageWidth() {
            return this.imageWidth;
        }

        private int imageHeight() {
            return this.imageHeight;
        }

        private int frameWidth() {
            return this.frameWidth;
        }

        private int frameHeight() {
            return this.frameHeight;
        }

        private int columns() {
            return this.columns;
        }

        private int currentFrame() {
            if (this.frames.length == 0) {
                return 0;
            }

            long gameTicks = Util.getMillis() / 50L;
            long totalDuration = 0L;
            for (Frame frame : this.frames) {
                totalDuration += frame.time();
            }
            if (totalDuration <= 0L) {
                return this.frames[0].index();
            }

            long tickInCycle = gameTicks % totalDuration;
            long elapsed = 0L;
            for (Frame frame : this.frames) {
                elapsed += frame.time();
                if (tickInCycle < elapsed) {
                    return frame.index();
                }
            }
            return this.frames[this.frames.length - 1].index();
        }

        private @Nullable ResourceLocation resolveFrameTexture(ResourceLocation sourceTexture) {
            if (this.image == null || !this.animated()) {
                return null;
            }

            Minecraft client = Minecraft.getInstance();
            if (client == null) {
                return null;
            }

            ensureFrameTexture(client.getTextureManager(), sourceTexture);
            if (this.frameTexture == null || this.frameTextureId == null) {
                return null;
            }

            int frame = this.currentFrame();
            if (frame != this.uploadedFrame) {
                copyFrame(frame);
                this.frameTexture.upload();
                this.uploadedFrame = frame;
            }
            return this.frameTextureId;
        }

        private void ensureFrameTexture(TextureManager textureManager, ResourceLocation sourceTexture) {
            if (this.frameTexture != null && this.frameTextureId != null) {
                return;
            }

            this.frameImage = new NativeImage(this.frameWidth, this.frameHeight, false);
            this.frameTexture = new DynamicTexture(this.frameImage);
            this.frameTextureId = ResourceLocation.fromNamespaceAndPath(
                    "chaoslib",
                    "generated/animated_frame/" + sanitize(sourceTexture.getNamespace()) + "/" + sanitize(sourceTexture.getPath())
            );
            textureManager.register(this.frameTextureId, this.frameTexture);
        }

        private void copyFrame(int frame) {
            if (this.image == null || this.frameImage == null) {
                return;
            }

            int sourceX = (frame % this.columns) * this.frameWidth;
            int sourceY = (frame / this.columns) * this.frameHeight;
            for (int y = 0; y < this.frameHeight; y++) {
                for (int x = 0; x < this.frameWidth; x++) {
                    this.frameImage.setPixelRGBA(x, y, this.image.getPixelRGBA(sourceX + x, sourceY + y));
                }
            }
        }

        private void close(@Nullable TextureManager textureManager) {
            if (textureManager != null && this.frameTextureId != null) {
                textureManager.release(this.frameTextureId);
            } else if (this.frameTexture != null) {
                this.frameTexture.close();
            }
            if (this.image != null) {
                this.image.close();
            }
            this.frameTextureId = null;
            this.frameTexture = null;
            this.frameImage = null;
            this.uploadedFrame = -1;
        }

        private static String sanitize(String value) {
            StringBuilder builder = new StringBuilder(value.length());
            for (int i = 0; i < value.length(); i++) {
                char c = value.charAt(i);
                builder.append((c >= 'a' && c <= 'z')
                        || (c >= '0' && c <= '9')
                        || c == '/'
                        || c == '_'
                        || c == '-'
                        || c == '.'
                        ? c
                        : '_');
            }
            return builder.toString();
        }
    }

    public record UvRegion(float minU, float minV, float width, float height) {
        public boolean isFullCoverage() {
            return Math.abs(this.minU) <= 1.0e-6f
                    && Math.abs(this.minV) <= 1.0e-6f
                    && Math.abs(this.width - 1.0f) <= 1.0e-6f
                    && Math.abs(this.height - 1.0f) <= 1.0e-6f;
        }
    }
}
