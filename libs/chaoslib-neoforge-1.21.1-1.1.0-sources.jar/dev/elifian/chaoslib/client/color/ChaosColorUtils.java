package dev.elifian.chaoslib.client.color;


import dev.elifian.chaoslib.platform.ClientOnly;

@ClientOnly
public final class ChaosColorUtils {
    private ChaosColorUtils() {
    }

    public static int packArgb(int alpha, int red, int green, int blue) {
        return (clampChannel(alpha) << 24)
                | (clampChannel(red) << 16)
                | (clampChannel(green) << 8)
                | clampChannel(blue);
    }

    public static int clampChannel(double value) {
        return Math.max(0, Math.min(255, (int) Math.round(value)));
    }

    public static int interpolateArgb(int from, int to, float factor) {
        float clampedFactor = Math.max(0.0f, Math.min(1.0f, factor));
        if (clampedFactor <= 0.0f) {
            return from;
        }
        if (clampedFactor >= 1.0f) {
            return to;
        }

        int fromAlpha = (from >>> 24) & 0xFF;
        int toAlpha = (to >>> 24) & 0xFF;
        double fromRed = srgbToLinear((from >>> 16) & 0xFF);
        double fromGreen = srgbToLinear((from >>> 8) & 0xFF);
        double fromBlue = srgbToLinear(from & 0xFF);
        double toRed = srgbToLinear((to >>> 16) & 0xFF);
        double toGreen = srgbToLinear((to >>> 8) & 0xFF);
        double toBlue = srgbToLinear(to & 0xFF);

        int alpha = clampChannel(fromAlpha + (toAlpha - fromAlpha) * clampedFactor);
        int red = linearToSrgbChannel(fromRed + (toRed - fromRed) * clampedFactor);
        int green = linearToSrgbChannel(fromGreen + (toGreen - fromGreen) * clampedFactor);
        int blue = linearToSrgbChannel(fromBlue + (toBlue - fromBlue) * clampedFactor);
        return packArgb(alpha, red, green, blue);
    }

    public static double srgbToLinear(int channel) {
        return srgbToLinear(channel / 255.0d);
    }

    public static double srgbToLinear(double channel) {
        if (channel <= 0.04045d) {
            return channel / 12.92d;
        }
        return Math.pow((channel + 0.055d) / 1.055d, 2.4d);
    }

    public static int linearToSrgbChannel(double channel) {
        double clamped = Math.max(0.0d, Math.min(1.0d, channel));
        double srgb = clamped <= 0.0031308d
                ? clamped * 12.92d
                : 1.055d * Math.pow(clamped, 1.0d / 2.4d) - 0.055d;
        return clampChannel(srgb * 255.0d);
    }

    public static double smoothstep(double edge0, double edge1, double value) {
        if (edge0 == edge1) {
            return value < edge0 ? 0.0d : 1.0d;
        }
        double t = Math.max(0.0d, Math.min(1.0d, (value - edge0) / (edge1 - edge0)));
        return t * t * (3.0d - 2.0d * t);
    }
}
