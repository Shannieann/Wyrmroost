package dev.elifian.chaoslib.client.resource;

import dev.elifian.chaoslib.api.model.GeoModel;
import dev.elifian.chaoslib.platform.Services;
import dev.elifian.chaoslib.compat.iris.IrisCompatInternal;
import dev.elifian.chaoslib.gpu.shader.ChaosGpuShaderManager;
import dev.elifian.chaoslib.client.render.StaticOnlyBlockEntityRenderCache;
import net.minecraft.server.packs.resources.ResourceManager;

import dev.elifian.chaoslib.platform.ClientOnly;

@ClientOnly
public final class ChaosLibClientReloadManager {
    private ChaosLibClientReloadManager() {
    }

    public static void reload(ResourceManager resourceManager) {
        invalidateClientRuntime();
        GeoModel.reloadResourceCaches(resourceManager);
    }

    public static void invalidateClientRuntime() {
        GeoModel.clearTextureTransparencyProfiles();
        GeoModel.clearPoseCache();
        GeoModel.clearResourceCaches();
        StaticOnlyBlockEntityRenderCache.clear();
        Services.STATIC_MODELS.clearStaticRenderCaches();
        ChaosGpuShaderManager.invalidateRuntimeCaches();
        IrisCompatInternal.invalidateCaches();
    }
}
