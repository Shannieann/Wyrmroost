package dev.elifian.chaoslib.client.multipart;

import dev.elifian.chaoslib.api.multipart.GeoTrackedBonePose;
import dev.elifian.chaoslib.api.multipart.GeoEntityPart;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.Optional;

public final class GeoMultipartHitboxHelper {
    private GeoMultipartHitboxHelper() {
    }

    public static GeoTrackedBonePose resolvePartPose(GeoTrackedBonePose pose, GeoEntityPart<?> part) {
        return part.resolveTrackedPose(pose);
    }

    public static AABB enclosingBox(GeoTrackedBonePose pose, GeoEntityPart<?> part) {
        return part.computeEnclosingBox(pose);
    }

    public static Optional<Vec3> raycast(GeoTrackedBonePose pose, GeoEntityPart<?> part, Vec3 from, Vec3 to) {
        return part.raycast(pose, from, to);
    }

    public static boolean containsPoint(GeoTrackedBonePose pose, GeoEntityPart<?> part, Vec3 point) {
        return part.containsPoint(pose, point);
    }
}
