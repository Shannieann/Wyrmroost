package dev.elifian.chaoslib.client.multipart;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;

import dev.elifian.chaoslib.platform.ClientOnly;

import java.util.Map;
import java.util.WeakHashMap;

@ClientOnly
public final class GeoMultipartClientBroadPhaseCache {
    private static final Map<Entity, CacheEntry> CACHE = new WeakHashMap<>();

    private GeoMultipartClientBroadPhaseCache() {
    }

    public static AABB get(Entity entity, Object snapshotToken) {
        CacheEntry entry = CACHE.get(entity);
        if (entry == null || !entry.matches(snapshotToken)) {
            return null;
        }

        return entry.box();
    }

    public static void put(Entity entity, Object snapshotToken, AABB box) {
        CACHE.put(entity, new CacheEntry(snapshotToken, box));
    }

    public static void clear() {
        CACHE.clear();
    }

    private record CacheEntry(Object snapshotToken, AABB box) {
        private boolean matches(Object token) {
            return this.snapshotToken == token;
        }
    }
}
