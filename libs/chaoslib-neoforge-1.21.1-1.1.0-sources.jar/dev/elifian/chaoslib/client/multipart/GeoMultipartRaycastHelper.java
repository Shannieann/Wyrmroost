package dev.elifian.chaoslib.client.multipart;

import dev.elifian.chaoslib.api.multipart.GeoMultipartEntity;
import dev.elifian.chaoslib.api.multipart.GeoTrackedBonePose;
import dev.elifian.chaoslib.multipart.interaction.GeoMultipartHitResult;
import dev.elifian.chaoslib.api.multipart.GeoEntityPart;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.ClipContext;

import dev.elifian.chaoslib.platform.ClientOnly;

import java.util.Optional;

@ClientOnly
public final class GeoMultipartRaycastHelper {
    private GeoMultipartRaycastHelper() {
    }

    public static Optional<EntityHitResult> findMultipartHit(Minecraft client, Entity cameraEntity, float tickDelta) {
        return findMultipartPartHit(client, cameraEntity, tickDelta)
                .map(hit -> new EntityHitResult(hit.part().getOwner(), hit.hitPos()));
    }

    public static Optional<GeoMultipartHitResult> findMultipartPartHit(Minecraft client, Entity cameraEntity, float tickDelta) {
        if (client.level == null || client.gameMode == null) {
            return Optional.empty();
        }

        double reach = client.player != null ? client.player.entityInteractionRange() : 3.0d;
        Vec3 start = cameraEntity.getEyePosition(tickDelta);
        Vec3 end = start.add(cameraEntity.getViewVector(tickDelta).scale(reach));
        double vanillaDistanceSquared = currentHitDistanceSquared(start, client.hitResult, reach);
        AABB searchBox = new AABB(start, end).inflate(2.0);

        GeoEntityPart<?> bestPart = null;
        Vec3 bestHitPos = null;
        double bestDistanceSquared = vanillaDistanceSquared;

        for (Entity entity : client.level.getEntities(cameraEntity, searchBox)) {
            if (!(entity instanceof GeoMultipartEntity multipart)
                    || entity.isSpectator()) {
                continue;
            }

            GeoMultipartClientPoseStore.PoseSnapshot snapshot = GeoMultipartClientPoseStore.snapshot(entity);
            if (snapshot == null || !snapshot.hasPoses()) {
                continue;
            }

            for (var part : multipart.getMultipartPartManager().getTrackedParts()) {
                if (!part.hasCollision()) {
                    continue;
                }

                GeoTrackedBonePose trackedPose = snapshot.getPoseOrNull(part.getTrackedBoneName(), tickDelta);
                Optional<Vec3> hitPos = trackedPose != null
                        ? GeoMultipartHitboxHelper.raycast(GeoMultipartHitboxHelper.resolvePartPose(trackedPose, part), part, start, end)
                        : part.raycast(start, end);
                if (hitPos.isEmpty()) {
                    continue;
                }

                double hitDistanceSquared = start.distanceToSqr(hitPos.get());
                if (hitDistanceSquared < bestDistanceSquared) {
                    bestDistanceSquared = hitDistanceSquared;
                    bestPart = part;
                    bestHitPos = hitPos.get();
                }
            }
        }

        return bestPart == null || bestHitPos == null
                ? Optional.empty()
                : Optional.of(new GeoMultipartHitResult(bestPart, bestHitPos, bestDistanceSquared));
    }

    public static HitResult fallbackTarget(Entity cameraEntity, float tickDelta, double reach) {
        Vec3 start = cameraEntity.getEyePosition(tickDelta);
        Vec3 end = start.add(cameraEntity.getViewVector(tickDelta).scale(reach));
        return cameraEntity.level().clip(new ClipContext(
                start,
                end,
                ClipContext.Block.OUTLINE,
                ClipContext.Fluid.NONE,
                cameraEntity
        ));
    }

    private static double currentHitDistanceSquared(Vec3 start, HitResult hitResult, double reach) {
        if (hitResult == null || hitResult.getType() == HitResult.Type.MISS) {
            return reach * reach;
        }
        return start.distanceToSqr(hitResult.getLocation());
    }
}
