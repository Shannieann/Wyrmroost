package dev.elifian.chaoslib.client.multipart;

import dev.elifian.chaoslib.cache.object.GeoBone;
import dev.elifian.chaoslib.client.animation.GeoBoneTrackingHelper;
import dev.elifian.chaoslib.platform.Services;
import dev.elifian.chaoslib.api.multipart.GeoMultipartEntity;
import dev.elifian.chaoslib.api.multipart.GeoTrackedBonePose;
import dev.elifian.chaoslib.network.c2s.GeoMultipartBoneSyncC2SPacket;
import net.minecraft.world.entity.Entity;

import dev.elifian.chaoslib.platform.ClientOnly;

import java.util.*;
import java.util.function.Function;

@ClientOnly
public final class GeoMultipartSyncHelper {
    private static final Map<Entity, SyncState> SYNC_STATE = new IdentityHashMap<>();

    private GeoMultipartSyncHelper() {
    }

    public static <T extends Entity & GeoMultipartEntity> void sync(T entity, Function<String, Optional<GeoBone>> boneResolver) {
        Set<String> trackedBones = entity.getTrackedBones();
        if (trackedBones.isEmpty()) {
            return;
        }

        Map<String, GeoTrackedBonePose> poses = GeoBoneTrackingHelper.collectWorldPoses(trackedBones, boneResolver);
        if (poses.isEmpty()) {
            return;
        }

        entity.receiveTrackedBonePoses(poses);

        SyncState state = SYNC_STATE.computeIfAbsent(entity, ignored -> new SyncState());
        int age = entity.tickCount;
        if (!state.shouldSend(
                poses,
                age,
                entity.getMultipartSyncIntervalTicks(),
                entity.getMultipartForcedSyncIntervalTicks(),
                entity.getMultipartSyncPositionThreshold(),
                entity.getMultipartSyncRotationThresholdDot()
        )) {
            return;
        }

        Services.NETWORK.sendToServer(new GeoMultipartBoneSyncC2SPacket(entity.getId(), poses));
        state.record(poses, age);
    }

    public static <T extends Entity & GeoMultipartEntity> void sync(T entity, Map<String, GeoTrackedBonePose> poses) {
        if (poses == null || poses.isEmpty()) {
            return;
        }

        entity.receiveTrackedBonePoses(poses);

        SyncState state = SYNC_STATE.computeIfAbsent(entity, ignored -> new SyncState());
        int age = entity.tickCount;
        if (!state.shouldSend(
                poses,
                age,
                entity.getMultipartSyncIntervalTicks(),
                entity.getMultipartForcedSyncIntervalTicks(),
                entity.getMultipartSyncPositionThreshold(),
                entity.getMultipartSyncRotationThresholdDot()
        )) {
            return;
        }

        Services.NETWORK.sendToServer(new GeoMultipartBoneSyncC2SPacket(entity.getId(), poses));
        state.record(poses, age);
    }

    private static final class SyncState {
        private final Map<String, GeoTrackedBonePose> lastSentPositions = new LinkedHashMap<>();
        private int lastSentAge = Integer.MIN_VALUE;

        private boolean shouldSend(Map<String, GeoTrackedBonePose> positions, int age, int intervalTicks, int forcedSyncIntervalTicks, double threshold, float rotationDotThreshold) {
            if (this.lastSentPositions.isEmpty()) {
                return true;
            }
            if (forcedSyncIntervalTicks > 0 && age - this.lastSentAge >= forcedSyncIntervalTicks) {
                return true;
            }
            if (intervalTicks > 0 && age - this.lastSentAge < intervalTicks) {
                return false;
            }

            double thresholdSquared = threshold * threshold;
            for (Map.Entry<String, GeoTrackedBonePose> entry : positions.entrySet()) {
                GeoTrackedBonePose previous = this.lastSentPositions.get(entry.getKey());
                if (previous == null
                        || previous.squaredDistanceTo(entry.getValue()) > thresholdSquared
                        || previous.rotationDot(entry.getValue()) < rotationDotThreshold) {
                    return true;
                }
            }
            return false;
        }

        private void record(Map<String, GeoTrackedBonePose> positions, int age) {
            if (this.lastSentPositions.isEmpty()) {
                this.lastSentPositions.putAll(positions);
            } else {
                this.lastSentPositions.keySet().retainAll(positions.keySet());
                for (Map.Entry<String, GeoTrackedBonePose> entry : positions.entrySet()) {
                    this.lastSentPositions.put(entry.getKey(), entry.getValue());
                }
            }
            this.lastSentAge = age;
        }
    }
}
