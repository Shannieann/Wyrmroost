package dev.elifian.chaoslib.client.multipart;

import dev.elifian.chaoslib.api.multipart.GeoTrackedBonePose;
import net.minecraft.world.entity.Entity;

import dev.elifian.chaoslib.platform.ClientOnly;

import java.util.Map;
import java.util.Optional;
import java.util.WeakHashMap;

@ClientOnly
public final class GeoMultipartClientPoseStore {
    private static final Map<Entity, EntityPoseFrame> POSES = new WeakHashMap<>();

    private GeoMultipartClientPoseStore() {
    }

    public static void update(Entity entity, Map<String, GeoTrackedBonePose> poses) {
        if (poses.isEmpty()) {
            POSES.remove(entity);
            return;
        }

        EntityPoseFrame frame = POSES.computeIfAbsent(entity, ignored -> new EntityPoseFrame());
        frame.update(entity.tickCount, poses);
    }

    public static PoseSnapshot snapshot(Entity entity) {
        EntityPoseFrame frame = POSES.get(entity);
        return frame == null ? null : frame.snapshot();
    }

    public static Optional<GeoTrackedBonePose> getPose(Entity entity, String boneName, float partialTick) {
        PoseSnapshot snapshot = snapshot(entity);
        if (snapshot == null) {
            return Optional.empty();
        }
        return snapshot.getPose(boneName, partialTick);
    }

    public static GeoTrackedBonePose getPoseOrNull(Entity entity, String boneName, float partialTick) {
        PoseSnapshot snapshot = snapshot(entity);
        return snapshot == null ? null : snapshot.getPoseOrNull(boneName, partialTick);
    }

    public static boolean hasPoses(Entity entity) {
        PoseSnapshot snapshot = snapshot(entity);
        return snapshot != null && snapshot.hasPoses();
    }

    public static boolean hasPose(Entity entity, String boneName) {
        PoseSnapshot snapshot = snapshot(entity);
        return snapshot != null && snapshot.hasPose(boneName);
    }

    private static final class EntityPoseFrame {
        private Map<String, GeoTrackedBonePose> previous = Map.of();
        private Map<String, GeoTrackedBonePose> current = Map.of();
        private int lastAge = Integer.MIN_VALUE;
        private PoseSnapshot snapshot = PoseSnapshot.EMPTY;

        private void update(int age, Map<String, GeoTrackedBonePose> poses) {
            Map<String, GeoTrackedBonePose> immutablePoses = Map.copyOf(poses);
            if (this.lastAge != age) {
                this.previous = this.current;
                this.lastAge = age;
            }

            this.current = immutablePoses;

            if (this.previous.isEmpty()) {
                this.previous = immutablePoses;
            }

            this.snapshot = new PoseSnapshot(this.previous, this.current, this.lastAge);
        }

        private PoseSnapshot snapshot() {
            return this.snapshot;
        }
    }

    public static final class PoseSnapshot {
        private static final PoseSnapshot EMPTY = new PoseSnapshot(Map.of(), Map.of(), Integer.MIN_VALUE);

        private final Map<String, GeoTrackedBonePose> previous;
        private final Map<String, GeoTrackedBonePose> current;
        private final int age;

        private PoseSnapshot(Map<String, GeoTrackedBonePose> previous, Map<String, GeoTrackedBonePose> current, int age) {
            this.previous = previous;
            this.current = current;
            this.age = age;
        }

        public Optional<GeoTrackedBonePose> getPose(String boneName, float partialTick) {
            GeoTrackedBonePose pose = getPoseOrNull(boneName, partialTick);
            return pose == null ? Optional.empty() : Optional.of(pose);
        }

        public GeoTrackedBonePose getPoseOrNull(String boneName, float partialTick) {
            GeoTrackedBonePose currentPose = this.current.get(boneName);
            if (currentPose == null) {
                return null;
            }
            if (partialTick <= 0.0f) {
                return this.previous.getOrDefault(boneName, currentPose);
            }
            if (partialTick >= 1.0f) {
                return currentPose;
            }

            GeoTrackedBonePose previousPose = this.previous.getOrDefault(boneName, currentPose);
            return previousPose == currentPose ? currentPose : previousPose.lerp(currentPose, partialTick);
        }

        public GeoTrackedBonePose getCurrentPoseOrNull(String boneName) {
            return this.current.get(boneName);
        }

        public Object cacheToken() {
            return this.current;
        }

        public int age() {
            return this.age;
        }

        public boolean hasPoses() {
            return !this.current.isEmpty();
        }

        public boolean hasPose(String boneName) {
            return this.current.containsKey(boneName);
        }
    }
}
