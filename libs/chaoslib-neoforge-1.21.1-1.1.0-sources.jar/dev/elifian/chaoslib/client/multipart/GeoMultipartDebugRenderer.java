package dev.elifian.chaoslib.client.multipart;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.elifian.chaoslib.api.multipart.GeoMultipartEntity;
import dev.elifian.chaoslib.api.multipart.GeoTrackedBonePose;
import dev.elifian.chaoslib.api.multipart.GeoEntityPart;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.RenderType;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import dev.elifian.chaoslib.platform.ClientOnly;
import dev.elifian.chaoslib.platform.render.ChaosWorldRenderContext;
import dev.elifian.chaoslib.platform.render.ChaosWorldRenderStage;

import java.util.ArrayList;

@ClientOnly
public final class GeoMultipartDebugRenderer {
    private static final int[][] EDGES = {
            {0, 1}, {0, 2}, {0, 4},
            {1, 3}, {1, 5},
            {2, 3}, {2, 6},
            {3, 7},
            {4, 5}, {4, 6},
            {5, 7},
            {6, 7}
    };

    private GeoMultipartDebugRenderer() {
    }

    public static void onWorldRenderStage(ChaosWorldRenderContext context) {
        if (context.stage() != ChaosWorldRenderStage.AFTER_ENTITIES
                || context.camera() == null
                || context.frustum() == null
                || context.poseStack() == null) {
            return;
        }

        Minecraft client = Minecraft.getInstance();
        if (client.level == null || !client.getEntityRenderDispatcher().shouldRenderHitBoxes()) {
            return;
        }

        Vec3 cameraPos = context.camera().getPosition();
        Entity cameraEntity = context.camera().getEntity();
        Frustum frustum = context.frustum();
        double searchRadius = client.options.renderDistance().get() * 16.0;
        AABB searchBox = AABB.ofSize(cameraPos, searchRadius * 2.0, searchRadius * 2.0, searchRadius * 2.0);
        MultiBufferSource.BufferSource buffers = client.renderBuffers().bufferSource();
        VertexConsumer lines = buffers.getBuffer(RenderType.lines());
        PoseStack poseStack = context.poseStack();

        poseStack.pushPose();
        poseStack.translate(-cameraPos.x, -cameraPos.y, -cameraPos.z);
        RenderSystem.disableCull();

        for (Entity entity : client.level.getEntities(cameraEntity, searchBox, candidate ->
                candidate instanceof GeoMultipartEntity
                        && !candidate.isSpectator()
                        && GeoMultipartClientPoseStore.hasPoses(candidate))) {
            if (!(entity instanceof GeoMultipartEntity multipart)) {
                continue;
            }

            GeoMultipartClientPoseStore.PoseSnapshot snapshot = GeoMultipartClientPoseStore.snapshot(entity);
            if (snapshot == null || !snapshot.hasPoses()) {
                continue;
            }

            if (!frustum.isVisible(multipart.getMultipartBroadPhaseBoundingBox())) {
                continue;
            }

            for (GeoEntityPart<?> part : multipart.getMultipartPartManager().getTrackedParts()) {
                if (!multipart.shouldRenderMultipartDebugHitbox(part)) {
                    continue;
                }

                GeoTrackedBonePose trackedPose = snapshot.getPoseOrNull(part.getTrackedBoneName(), context.partialTick());
                if (trackedPose == null) {
                    continue;
                }

                GeoTrackedBonePose pose = GeoMultipartHitboxHelper.resolvePartPose(trackedPose, part);
                AABB enclosingBox = GeoMultipartHitboxHelper.enclosingBox(pose, part);
                if (!frustum.isVisible(enclosingBox)) {
                    continue;
                }
                ArrayList<Vec3[]> debugBoxes = new ArrayList<>();
                part.appendDebugBoxes(pose, debugBoxes);
                int color = normalizeDebugColor(multipart.getMultipartDebugHitboxColor(part));
                if (((color >>> 24) & 0xFF) == 0) {
                    continue;
                }
                for (Vec3[] corners : debugBoxes) {
                    drawOrientedBox(poseStack, lines, corners, color);
                }
            }
        }

        poseStack.popPose();
        RenderSystem.enableCull();
        buffers.endBatch(RenderType.lines());
    }

    private static int normalizeDebugColor(int color) {
        if ((color & 0xFF000000) == 0 && (color & 0x00FFFFFF) != 0) {
            return color | 0xFF000000;
        }
        return color;
    }

    private static void drawOrientedBox(PoseStack poseStack, VertexConsumer buffer, Vec3[] corners, int color) {
        if (!hasValidCorners(corners)) {
            return;
        }

        PoseStack.Pose entry = poseStack.last();
        float alpha = ((color >>> 24) & 0xFF) / 255.0f;
        float red = ((color >>> 16) & 0xFF) / 255.0f;
        float green = ((color >>> 8) & 0xFF) / 255.0f;
        float blue = (color & 0xFF) / 255.0f;
        for (int[] edge : EDGES) {
            Vec3 from = corners[edge[0]];
            Vec3 to = corners[edge[1]];
            float dx = (float) (to.x - from.x);
            float dy = (float) (to.y - from.y);
            float dz = (float) (to.z - from.z);
            float length = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
            float nx = length == 0.0f ? 0.0f : dx / length;
            float ny = length == 0.0f ? 1.0f : dy / length;
            float nz = length == 0.0f ? 0.0f : dz / length;
            buffer.addVertex(entry.pose(), (float) from.x, (float) from.y, (float) from.z)
                    .setColor(red, green, blue, alpha)
                    .setNormal(entry, nx, ny, nz);
            buffer.addVertex(entry.pose(), (float) to.x, (float) to.y, (float) to.z)
                    .setColor(red, green, blue, alpha)
                    .setNormal(entry, nx, ny, nz);
        }
    }

    private static boolean hasValidCorners(Vec3[] corners) {
        if (corners == null || corners.length != 8) {
            return false;
        }

        for (Vec3 corner : corners) {
            if (corner == null
                    || !Double.isFinite(corner.x)
                    || !Double.isFinite(corner.y)
                    || !Double.isFinite(corner.z)) {
                return false;
            }
        }

        return true;
    }
}
