package dev.elifian.chaoslib.loading;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.elifian.chaoslib.loading.json.raw.Model;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.resources.ResourceLocation;

import dev.elifian.chaoslib.platform.ClientOnly;

import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;

@ClientOnly
public final class FileLoader {
    private FileLoader() {
    }

    public static Model loadModelFile(ResourceLocation id, ResourceManager resourceManager) {
        try (InputStreamReader reader = new InputStreamReader(
                resourceManager.getResource(id).orElseThrow().open(),
                StandardCharsets.UTF_8)) {
            return loadModelFile(reader);
        } catch (Exception exception) {
            throw new IllegalStateException("Failed to read Chaos geo model " + id, exception);
        }
    }

    public static Model loadModelFile(Reader reader) {
        return Model.fromJson(loadFile(reader));
    }

    public static JsonObject loadFile(Reader reader) {
        return JsonParser.parseReader(reader).getAsJsonObject();
    }
}
