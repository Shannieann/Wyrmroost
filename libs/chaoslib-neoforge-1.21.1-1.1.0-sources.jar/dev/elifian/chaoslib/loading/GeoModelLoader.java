package dev.elifian.chaoslib.loading;

import dev.elifian.chaoslib.cache.object.BakedGeoModel;
import dev.elifian.chaoslib.loading.json.FormatVersion;
import dev.elifian.chaoslib.loading.json.raw.Model;
import dev.elifian.chaoslib.loading.object.BakedModelFactory;
import dev.elifian.chaoslib.loading.object.GeometryTree;
import net.minecraft.client.Minecraft;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.resources.ResourceLocation;

import dev.elifian.chaoslib.platform.ClientOnly;

@ClientOnly
public final class GeoModelLoader {
    private GeoModelLoader() {
    }

    public static BakedGeoModel load(ResourceLocation id) {
        return load(id, Minecraft.getInstance().getResourceManager());
    }

    public static BakedGeoModel load(ResourceLocation id, ResourceManager resourceManager) {
        try {
            Model model = FileLoader.loadModelFile(id, resourceManager);
            if (model.formatVersion() != FormatVersion.V_1_12_0
                && model.formatVersion() != FormatVersion.V_1_21_0) {
                throw new IllegalArgumentException(
                    "Unsupported Chaos geo model version. Supported versions: 1.12.0 and 1.21.x"
                );
            }

            return BakedModelFactory.getForNamespace(id.getNamespace()).constructGeoModel(GeometryTree.fromModel(model));
        } catch (Exception exception) {
            throw new IllegalStateException("Failed to load Chaos geo model " + id, exception);
        }
    }
}
