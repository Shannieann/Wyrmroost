package dev.elifian.chaoslib.loading.json;

public enum FormatVersion {
    V_1_12_0("1.12.0"),
    V_1_21_0("1.21.0");

    private final String serializedName;

    FormatVersion(String serializedName) {
        this.serializedName = serializedName;
    }

    public static FormatVersion fromString(String value) {
        for (FormatVersion version : values()) {
            if (version.serializedName.equals(value)) {
                return version;
            }
        }

        if (value.startsWith("1.21.")) {
            return V_1_21_0;
        }

        throw new IllegalArgumentException("Unsupported ChaosLib geo model format version: " + value);
    }
}
