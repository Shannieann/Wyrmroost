package dev.elifian.chaoslib.loading.json.raw;

import com.google.gson.JsonObject;
import net.minecraft.util.GsonHelper;

public record FaceUV(double[] uv, double[] uvSize, int uvRotation) {
    public static FaceUV fromJson(JsonObject json) {
        return new FaceUV(
                JsonParsing.readVector(json, "uv", new double[]{0.0d, 0.0d}),
                JsonParsing.readVector(json, "uv_size", new double[]{0.0d, 0.0d}),
                json.has("uv_rotation") ? GsonHelper.getAsInt(json, "uv_rotation") : 0
        );
    }
}
