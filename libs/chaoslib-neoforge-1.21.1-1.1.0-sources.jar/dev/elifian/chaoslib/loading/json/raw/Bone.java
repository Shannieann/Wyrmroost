package dev.elifian.chaoslib.loading.json.raw;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.minecraft.util.GsonHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public record Bone(String name, String parent, double[] pivot, double[] rotation, Cube[] cubes, LocatorValue[] locators) {
    public static Bone fromJson(JsonObject json) {
        List<Cube> cubes = new ArrayList<>();
        if (json.has("cubes")) {
            for (JsonElement cube : json.getAsJsonArray("cubes")) {
                cubes.add(Cube.fromJson(cube.getAsJsonObject()));
            }
        }

        List<LocatorValue> locators = new ArrayList<>();
        if (json.has("locators")) {
            for (Map.Entry<String, JsonElement> entry : json.getAsJsonObject("locators").entrySet()) {
                locators.add(LocatorValue.fromJson(entry.getKey(), entry.getValue()));
            }
        }

        return new Bone(
                GsonHelper.getAsString(json, "name"),
                json.has("parent") ? GsonHelper.getAsString(json, "parent") : null,
                JsonParsing.readVector(json, "pivot", new double[]{0.0d, 0.0d, 0.0d}),
                JsonParsing.readVector(json, "rotation", new double[]{0.0d, 0.0d, 0.0d}),
                cubes.toArray(Cube[]::new),
                locators.toArray(LocatorValue[]::new)
        );
    }
}
