package dev.elifian.chaoslib.loading.json.raw;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

final class JsonParsing {
    private JsonParsing() {
    }

    static double[] readVector(JsonObject json, String key, double[] defaultValue) {
        if (!json.has(key)) {
            return defaultValue;
        }

        return readVector(json.get(key), defaultValue);
    }

    static double[] readVector(JsonElement element, double[] defaultValue) {
        if (element == null || !element.isJsonArray()) {
            return defaultValue;
        }

        JsonArray array = element.getAsJsonArray();
        double[] values = new double[array.size()];
        for (int i = 0; i < array.size(); i++) {
            values[i] = array.get(i).getAsDouble();
        }
        return values;
    }
}
