package dev.elifian.chaoslib.loading.json.raw;

import com.google.gson.JsonObject;
import net.minecraft.util.GsonHelper;

public record Cube(Double inflate, Boolean mirror, double[] origin, double[] pivot, double[] rotation, double[] size, UVUnion uv) {
    public static Cube fromJson(JsonObject json) {
        return new Cube(
                json.has("inflate") ? GsonHelper.getAsDouble(json, "inflate") : null,
                json.has("mirror") ? GsonHelper.getAsBoolean(json, "mirror") : null,
                JsonParsing.readVector(json, "origin", new double[]{0.0d, 0.0d, 0.0d}),
                JsonParsing.readVector(json, "pivot", new double[]{0.0d, 0.0d, 0.0d}),
                JsonParsing.readVector(json, "rotation", new double[]{0.0d, 0.0d, 0.0d}),
                JsonParsing.readVector(json, "size", new double[]{0.0d, 0.0d, 0.0d}),
                UVUnion.fromJson(json.get("uv"))
        );
    }
}
