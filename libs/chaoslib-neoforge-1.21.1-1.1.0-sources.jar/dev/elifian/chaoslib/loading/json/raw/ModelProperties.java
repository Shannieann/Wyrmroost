package dev.elifian.chaoslib.loading.json.raw;

import com.google.gson.JsonObject;
import net.minecraft.util.GsonHelper;

public record ModelProperties(int textureWidth, int textureHeight, boolean gpuPipeline) {
    public static ModelProperties fromJson(JsonObject json) {
        return new ModelProperties(
                GsonHelper.getAsInt(json, "texture_width"),
                GsonHelper.getAsInt(json, "texture_height"),
                GsonHelper.getAsBoolean(json, "gpu_pipeline", true)
        );
    }
}
