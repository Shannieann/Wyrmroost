package dev.elifian.chaoslib.loading.json.raw;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

public record LocatorValue(String name, double[] offset, double[] rotation) {
    public static LocatorValue fromJson(String name, JsonElement element) {
        if (element.isJsonArray()) {
            return new LocatorValue(name, JsonParsing.readVector(element, new double[]{0.0d, 0.0d, 0.0d}), new double[]{0.0d, 0.0d, 0.0d});
        }

        JsonObject json = element.getAsJsonObject();
        return new LocatorValue(
                name,
                JsonParsing.readVector(json, "offset", new double[]{0.0d, 0.0d, 0.0d}),
                JsonParsing.readVector(json, "rotation", new double[]{0.0d, 0.0d, 0.0d})
        );
    }
}
