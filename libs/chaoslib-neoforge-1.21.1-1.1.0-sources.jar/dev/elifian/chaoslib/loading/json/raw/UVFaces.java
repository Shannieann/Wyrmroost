package dev.elifian.chaoslib.loading.json.raw;

import com.google.gson.JsonObject;
import net.minecraft.core.Direction;

import java.util.EnumMap;
import java.util.Map;

public record UVFaces(Map<Direction, FaceUV> faces) {
    public static UVFaces fromJson(JsonObject json) {
        EnumMap<Direction, FaceUV> faces = new EnumMap<>(Direction.class);

        addFace(faces, json, Direction.DOWN, "down");
        addFace(faces, json, Direction.UP, "up");
        addFace(faces, json, Direction.NORTH, "north");
        addFace(faces, json, Direction.SOUTH, "south");
        addFace(faces, json, Direction.WEST, "west");
        addFace(faces, json, Direction.EAST, "east");

        return new UVFaces(Map.copyOf(faces));
    }

    public FaceUV fromDirection(Direction direction) {
        return this.faces.get(direction);
    }

    private static void addFace(Map<Direction, FaceUV> faces, JsonObject json, Direction direction, String key) {
        if (json.has(key)) {
            faces.put(direction, FaceUV.fromJson(json.getAsJsonObject(key)));
        }
    }
}
