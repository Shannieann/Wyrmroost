package dev.elifian.chaoslib.loading.json.raw;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

public record MinecraftGeometry(ModelProperties modelProperties, Bone[] bones) {
    public static MinecraftGeometry fromJson(JsonObject json) {
        JsonArray bones = json.getAsJsonArray("bones");
        Bone[] parsedBones = new Bone[bones.size()];
        for (int i = 0; i < bones.size(); i++) {
            parsedBones[i] = Bone.fromJson(bones.get(i).getAsJsonObject());
        }

        return new MinecraftGeometry(
                ModelProperties.fromJson(json.getAsJsonObject("description")),
                parsedBones
        );
    }
}
