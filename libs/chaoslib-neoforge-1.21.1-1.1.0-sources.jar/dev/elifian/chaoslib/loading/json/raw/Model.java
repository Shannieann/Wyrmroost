package dev.elifian.chaoslib.loading.json.raw;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import dev.elifian.chaoslib.loading.json.FormatVersion;
import net.minecraft.util.GsonHelper;

public record Model(FormatVersion formatVersion, MinecraftGeometry[] minecraftGeometry) {
    public static Model fromJson(JsonObject root) {
        JsonArray geometries = root.getAsJsonArray("minecraft:geometry");
        MinecraftGeometry[] parsed = new MinecraftGeometry[geometries.size()];
        for (int i = 0; i < geometries.size(); i++) {
            parsed[i] = MinecraftGeometry.fromJson(geometries.get(i).getAsJsonObject());
        }

        return new Model(
                FormatVersion.fromString(GsonHelper.getAsString(root, "format_version")),
                parsed
        );
    }
}
