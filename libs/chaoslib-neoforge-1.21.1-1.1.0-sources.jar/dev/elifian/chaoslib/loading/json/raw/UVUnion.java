package dev.elifian.chaoslib.loading.json.raw;

import com.google.gson.JsonElement;

public record UVUnion(double[] boxUVCoords, UVFaces faceUV) {
    public static UVUnion fromJson(JsonElement element) {
        if (element == null || element.isJsonNull()) {
            return new UVUnion(null, null);
        }

        if (element.isJsonArray()) {
            return new UVUnion(JsonParsing.readVector(element, new double[]{0.0d, 0.0d}), null);
        }

        return new UVUnion(null, UVFaces.fromJson(element.getAsJsonObject()));
    }

    public boolean isBoxUV() {
        return this.boxUVCoords != null;
    }
}
