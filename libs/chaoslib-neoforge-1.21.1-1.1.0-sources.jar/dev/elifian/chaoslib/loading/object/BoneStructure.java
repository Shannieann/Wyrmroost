package dev.elifian.chaoslib.loading.object;

import dev.elifian.chaoslib.loading.json.raw.Bone;

import java.util.LinkedHashMap;
import java.util.Map;

public record BoneStructure(Bone self, Map<String, BoneStructure> children) {
    public BoneStructure(Bone self) {
        this(self, new LinkedHashMap<>());
    }
}
