package dev.elifian.chaoslib.loading.object;

import dev.elifian.chaoslib.loading.json.raw.Bone;
import dev.elifian.chaoslib.loading.json.raw.MinecraftGeometry;
import dev.elifian.chaoslib.loading.json.raw.Model;
import dev.elifian.chaoslib.loading.json.raw.ModelProperties;

import java.util.LinkedHashMap;
import java.util.Map;

public record GeometryTree(Map<String, BoneStructure> topLevelBones, ModelProperties properties) {
    public static GeometryTree fromModel(Model model) {
        MinecraftGeometry geometry = model.minecraftGeometry()[0];
        Bone[] bones = geometry.bones();
        Map<String, BoneStructure> topLevelBones = new LinkedHashMap<>();
        Map<String, BoneStructure> lookup = new LinkedHashMap<>();

        for (Bone bone : bones) {
            BoneStructure structure = new BoneStructure(bone);
            lookup.put(bone.name(), structure);

            if (bone.parent() == null) {
                topLevelBones.put(bone.name(), structure);
            }
        }

        for (Bone bone : bones) {
            String parentName = bone.parent();
            if (parentName == null) {
                continue;
            }

            if (parentName.equals(bone.name())) {
                throw new IllegalArgumentException("Invalid model definition. Bone has defined itself as its own parent: " + bone.name());
            }

            BoneStructure parentStructure = lookup.get(parentName);
            if (parentStructure == null) {
                throw new IllegalArgumentException("Invalid model definition. Found bone with undefined parent (child -> parent): " + bone.name() + " -> " + parentName);
            }

            parentStructure.children().put(bone.name(), lookup.get(bone.name()));
        }

        return new GeometryTree(
                topLevelBones,
                geometry.modelProperties()
        );
    }
}
