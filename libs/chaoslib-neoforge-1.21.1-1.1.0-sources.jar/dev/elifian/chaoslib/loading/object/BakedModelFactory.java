package dev.elifian.chaoslib.loading.object;

import dev.elifian.chaoslib.cache.object.BakedGeoModel;
import dev.elifian.chaoslib.cache.object.GeoBone;
import dev.elifian.chaoslib.cache.object.GeoCube;
import dev.elifian.chaoslib.cache.object.GeoLocator;
import dev.elifian.chaoslib.cache.object.GeoQuad;
import dev.elifian.chaoslib.cache.object.GeoVertex;
import dev.elifian.chaoslib.loading.json.raw.Bone;
import dev.elifian.chaoslib.loading.json.raw.Cube;
import dev.elifian.chaoslib.loading.json.raw.FaceUV;
import dev.elifian.chaoslib.loading.json.raw.LocatorValue;
import dev.elifian.chaoslib.loading.json.raw.ModelProperties;
import dev.elifian.chaoslib.loading.json.raw.UVUnion;
import net.minecraft.core.Direction;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3d;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public interface BakedModelFactory {
    Map<String, BakedModelFactory> FACTORIES = new ConcurrentHashMap<>();
    BakedModelFactory DEFAULT_FACTORY = new Builtin();

    static BakedModelFactory getForNamespace(String namespace) {
        return FACTORIES.getOrDefault(namespace, DEFAULT_FACTORY);
    }

    static void register(String namespace, BakedModelFactory factory) {
        FACTORIES.put(namespace, factory);
    }

    BakedGeoModel constructGeoModel(GeometryTree geometryTree);

    GeoBone constructBone(BoneStructure boneStructure, ModelProperties properties, @Nullable GeoBone parent);

    GeoCube constructCube(Cube cube, ModelProperties properties, GeoBone bone);

    default GeoQuad[] buildQuads(UVUnion uvUnion, VertexSet vertices, Cube cube, float textureWidth, float textureHeight, boolean mirror) {
        GeoQuad[] quads = new GeoQuad[6];
        quads[0] = shouldRenderFace(cube, Direction.WEST) ? buildQuad(vertices, cube, uvUnion, textureWidth, textureHeight, mirror, Direction.WEST) : null;
        quads[1] = shouldRenderFace(cube, Direction.EAST) ? buildQuad(vertices, cube, uvUnion, textureWidth, textureHeight, mirror, Direction.EAST) : null;
        quads[2] = shouldRenderFace(cube, Direction.NORTH) ? buildQuad(vertices, cube, uvUnion, textureWidth, textureHeight, mirror, Direction.NORTH) : null;
        quads[3] = shouldRenderFace(cube, Direction.SOUTH) ? buildQuad(vertices, cube, uvUnion, textureWidth, textureHeight, mirror, Direction.SOUTH) : null;
        quads[4] = shouldRenderFace(cube, Direction.UP) ? buildQuad(vertices, cube, uvUnion, textureWidth, textureHeight, mirror, Direction.UP) : null;
        quads[5] = shouldRenderFace(cube, Direction.DOWN) ? buildQuad(vertices, cube, uvUnion, textureWidth, textureHeight, mirror, Direction.DOWN) : null;
        return quads;
    }

    private static boolean shouldRenderFace(Cube cube, Direction direction) {
        double[] size = cube.size();
        boolean flatX = size[0] == 0.0d;
        boolean flatY = size[1] == 0.0d;
        boolean flatZ = size[2] == 0.0d;

        if (flatX) {
            return direction == Direction.WEST || direction == Direction.EAST;
        }
        if (flatY) {
            return direction == Direction.UP || direction == Direction.DOWN;
        }
        if (flatZ) {
            return direction == Direction.NORTH || direction == Direction.SOUTH;
        }

        return true;
    }

    default GeoQuad buildQuad(VertexSet vertices, Cube cube, UVUnion uvUnion, float textureWidth, float textureHeight, boolean mirror, Direction direction) {
        if (!uvUnion.isBoxUV()) {
            FaceUV faceUV = uvUnion.faceUV() == null ? null : uvUnion.faceUV().fromDirection(direction);
            if (faceUV == null) {
                return null;
            }

            return GeoQuad.build(
                    vertices.verticesForQuad(direction, false, mirror),
                    faceUV.uv(),
                    faceUV.uvSize(),
                    textureWidth,
                    textureHeight,
                    mirror,
                    direction,
                    faceUV.uvRotation()
            );
        }

        double[] uv = uvUnion.boxUVCoords();
        double[] cubeSize = cube.size();
        double uvSizeX = Math.floor(cubeSize[0]);
        double uvSizeY = Math.floor(cubeSize[1]);
        double uvSizeZ = Math.floor(cubeSize[2]);

        double[] uvCoords;
        double[] uvSize;
        switch (direction) {
            case WEST -> {
                uvCoords = new double[]{uv[0] + uvSizeZ + uvSizeX, uv[1] + uvSizeZ};
                uvSize = new double[]{uvSizeZ, uvSizeY};
            }
            case EAST -> {
                uvCoords = new double[]{uv[0], uv[1] + uvSizeZ};
                uvSize = new double[]{uvSizeZ, uvSizeY};
            }
            case NORTH -> {
                uvCoords = new double[]{uv[0] + uvSizeZ, uv[1] + uvSizeZ};
                uvSize = new double[]{uvSizeX, uvSizeY};
            }
            case SOUTH -> {
                uvCoords = new double[]{uv[0] + uvSizeZ + uvSizeX + uvSizeZ, uv[1] + uvSizeZ};
                uvSize = new double[]{uvSizeX, uvSizeY};
            }
            case UP -> {
                uvCoords = new double[]{uv[0] + uvSizeZ, uv[1]};
                uvSize = new double[]{uvSizeX, uvSizeZ};
            }
            case DOWN -> {
                uvCoords = new double[]{uv[0] + uvSizeZ + uvSizeX, uv[1] + uvSizeZ};
                uvSize = new double[]{uvSizeX, -uvSizeZ};
            }
            default -> {
                return null;
            }
        }

        return GeoQuad.build(
                vertices.verticesForQuad(direction, true, mirror),
                uvCoords,
                uvSize,
                textureWidth,
                textureHeight,
                mirror,
                direction
        );
    }

    final class Builtin implements BakedModelFactory {
        @Override
        public BakedGeoModel constructGeoModel(GeometryTree geometryTree) {
            List<GeoBone> bones = new ArrayList<>();
            for (BoneStructure boneStructure : geometryTree.topLevelBones().values()) {
                bones.add(constructBone(boneStructure, geometryTree.properties(), null));
            }

            return new BakedGeoModel(bones, geometryTree.properties());
        }

        @Override
        public GeoBone constructBone(BoneStructure boneStructure, ModelProperties properties, @Nullable GeoBone parent) {
            Bone bone = boneStructure.self();
            double[] rotation = bone.rotation();
            double[] pivot = bone.pivot();
            GeoBone newBone = new GeoBone(
                    parent,
                    bone.name(),
                    (float) -pivot[0],
                    (float) pivot[1],
                    (float) pivot[2],
                    (float) Math.toRadians(-rotation[0]),
                    (float) Math.toRadians(-rotation[1]),
                    (float) Math.toRadians(rotation[2])
            );

            for (Cube cube : bone.cubes()) {
                newBone.getCubes().add(constructCube(cube, properties, newBone));
            }

            for (LocatorValue locator : bone.locators()) {
                newBone.getLocators().add(new GeoLocator(
                        locator.name(),
                        (float) -locator.offset()[0],
                        (float) locator.offset()[1],
                        (float) locator.offset()[2],
                        (float) Math.toRadians(-locator.rotation()[0]),
                        (float) Math.toRadians(-locator.rotation()[1]),
                        (float) Math.toRadians(locator.rotation()[2])
                ));
            }

            for (BoneStructure child : boneStructure.children().values()) {
                newBone.getChildBones().add(constructBone(child, properties, newBone));
            }

            return newBone;
        }

        @Override
        public GeoCube constructCube(Cube cube, ModelProperties properties, GeoBone bone) {
            boolean mirror = cube.mirror() == Boolean.TRUE;
            double inflate = cube.inflate() != null ? cube.inflate() / 16.0d : 0.0d;
            Vector3d size = fixZeroSizeCube(new Vector3d(cube.size()[0], cube.size()[1], cube.size()[2]));
            Vector3d origin = new Vector3d(
                    -(cube.origin()[0] + cube.size()[0]) / 16.0d,
                    cube.origin()[1] / 16.0d,
                    cube.origin()[2] / 16.0d
            );
            Vector3d rotation = new Vector3d(
                    Math.toRadians(-cube.rotation()[0]),
                    Math.toRadians(-cube.rotation()[1]),
                    Math.toRadians(cube.rotation()[2])
            );
            Vector3d pivot = new Vector3d(-cube.pivot()[0], cube.pivot()[1], cube.pivot()[2]);
            Vector3d vertexSize = fixZeroSizeCube(new Vector3d(cube.size()[0] / 16.0d, cube.size()[1] / 16.0d, cube.size()[2] / 16.0d));
            GeoQuad[] quads = buildQuads(cube.uv(), new VertexSet(origin, vertexSize, inflate), cube, properties.textureWidth(), properties.textureHeight(), mirror);

            return new GeoCube(quads, pivot, rotation, size, inflate, mirror);
        }
    }

    record VertexSet(GeoVertex bottomLeftBack, GeoVertex bottomRightBack, GeoVertex topLeftBack, GeoVertex topRightBack,
                     GeoVertex topLeftFront, GeoVertex topRightFront, GeoVertex bottomLeftFront, GeoVertex bottomRightFront) {
        public VertexSet(Vector3d origin, Vector3d vertexSize, double inflation) {
            this(
                    new GeoVertex(origin.x - inflation, origin.y - inflation, origin.z - inflation),
                    new GeoVertex(origin.x - inflation, origin.y - inflation, origin.z + vertexSize.z + inflation),
                    new GeoVertex(origin.x - inflation, origin.y + vertexSize.y + inflation, origin.z - inflation),
                    new GeoVertex(origin.x - inflation, origin.y + vertexSize.y + inflation, origin.z + vertexSize.z + inflation),
                    new GeoVertex(origin.x + vertexSize.x + inflation, origin.y + vertexSize.y + inflation, origin.z - inflation),
                    new GeoVertex(origin.x + vertexSize.x + inflation, origin.y + vertexSize.y + inflation, origin.z + vertexSize.z + inflation),
                    new GeoVertex(origin.x + vertexSize.x + inflation, origin.y - inflation, origin.z - inflation),
                    new GeoVertex(origin.x + vertexSize.x + inflation, origin.y - inflation, origin.z + vertexSize.z + inflation)
            );
        }

        public GeoVertex[] quadWest() {
            return new GeoVertex[]{this.topRightBack, this.topLeftBack, this.bottomLeftBack, this.bottomRightBack};
        }

        public GeoVertex[] quadEast() {
            return new GeoVertex[]{this.topLeftFront, this.topRightFront, this.bottomRightFront, this.bottomLeftFront};
        }

        public GeoVertex[] quadNorth() {
            return new GeoVertex[]{this.topLeftBack, this.topLeftFront, this.bottomLeftFront, this.bottomLeftBack};
        }

        public GeoVertex[] quadSouth() {
            return new GeoVertex[]{this.topRightFront, this.topRightBack, this.bottomRightBack, this.bottomRightFront};
        }

        public GeoVertex[] quadUp() {
            return new GeoVertex[]{this.topRightBack, this.topRightFront, this.topLeftFront, this.topLeftBack};
        }

        public GeoVertex[] quadDown() {
            return new GeoVertex[]{this.bottomLeftBack, this.bottomLeftFront, this.bottomRightFront, this.bottomRightBack};
        }

        public GeoVertex[] verticesForQuad(Direction direction, boolean boxUv, boolean mirror) {
            return switch (direction) {
                case WEST -> mirror ? quadEast() : quadWest();
                case EAST -> mirror ? quadWest() : quadEast();
                case NORTH -> quadNorth();
                case SOUTH -> quadSouth();
                case UP -> mirror && !boxUv ? quadDown() : quadUp();
                case DOWN -> mirror && !boxUv ? quadUp() : quadDown();
            };
        }
    }

    private static Vector3d fixZeroSizeCube(Vector3d size) {
        if (size.x == 0.0d) {
            size = new Vector3d(0.001d, size.y, size.z);
        }
        if (size.y == 0.0d) {
            size = new Vector3d(size.x, 0.001d, size.z);
        }
        if (size.z == 0.0d) {
            size = new Vector3d(size.x, size.y, 0.001d);
        }

        return size;
    }
}
