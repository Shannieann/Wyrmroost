package dev.elifian.chaoslib.api.animation;

import dev.elifian.chaoslib.api.animatable.GeoAnimatable;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Declarative animation state graph that can be interpreted by ChaosLib animation runtimes.
 */
public class AnimationGraph<T extends GeoAnimatable, S extends AnimationGraphState<T>> {
    private final List<S> states;
    private final Map<S, Integer> stateIndices;
    private final Map<S, List<Transition<T, S>>> transitions;
    private final int initialStateIndex;

    protected AnimationGraph(List<S> states, Map<S, Integer> stateIndices, Map<S, List<Transition<T, S>>> transitions, int initialStateIndex) {
        this.states = List.copyOf(states);
        this.stateIndices = Map.copyOf(stateIndices);
        this.transitions = Map.copyOf(transitions);
        this.initialStateIndex = initialStateIndex;
    }

    public static <T extends GeoAnimatable, S extends AnimationGraphState<T>> Builder<T, S> builder(S initialState) {
        return new Builder<>(initialState);
    }

    public S state(int index) {
        return this.states.get(index);
    }

    public int initialStateIndex() {
        return this.initialStateIndex;
    }

    public int stateIndex(S state) {
        Integer index = this.stateIndices.get(state);
        if (index == null) {
            throw new IllegalArgumentException("Unknown animation graph state: " + state);
        }
        return index;
    }

    public List<Transition<T, S>> transitions(S state) {
        return this.transitions.getOrDefault(state, List.of());
    }

    public record Transition<T extends GeoAnimatable, S extends AnimationGraphState<T>>(
            S targetState,
            AnimationCondition condition,
            int transitionLengthTicks
    ) {
    }

    public interface SpeedResolver<T extends GeoAnimatable, S extends AnimationGraphState<T>> {
        double resolve(AnimationState<T> state, S currentState);
    }

    public static class Builder<T extends GeoAnimatable, S extends AnimationGraphState<T>> {
        private final S initialState;
        private final LinkedHashMap<S, List<Transition<T, S>>> transitions = new LinkedHashMap<>();

        protected Builder(S initialState) {
            this.initialState = initialState;
        }

        public Builder<T, S> state(S state) {
            this.transitions.computeIfAbsent(state, ignored -> new ArrayList<>());
            return this;
        }

        public Builder<T, S> transition(S fromState, S toState, AnimationCondition condition, int transitionLengthTicks) {
            this.transitions.computeIfAbsent(fromState, ignored -> new ArrayList<>())
                    .add(new Transition<>(toState, condition, transitionLengthTicks));
            this.transitions.computeIfAbsent(toState, ignored -> new ArrayList<>());
            return this;
        }

        public AnimationGraph<T, S> build() {
            LinkedHashMap<S, Integer> indices = new LinkedHashMap<>();
            ArrayList<S> builtStates = new ArrayList<>(this.transitions.size());
            int index = 0;
            for (S state : this.transitions.keySet()) {
                indices.put(state, index++);
                builtStates.add(state);
            }
            if (!indices.containsKey(this.initialState)) {
                throw new IllegalStateException("Initial state is not declared: " + this.initialState);
            }

            LinkedHashMap<S, List<Transition<T, S>>> builtTransitions = new LinkedHashMap<>();
            for (Map.Entry<S, List<Transition<T, S>>> entry : this.transitions.entrySet()) {
                for (Transition<T, S> transition : entry.getValue()) {
                    if (!indices.containsKey(transition.targetState())) {
                        throw new IllegalStateException("Transition target state is not declared: " + transition.targetState());
                    }
                }
                builtTransitions.put(entry.getKey(), List.copyOf(entry.getValue()));
            }

            return new AnimationGraph<>(builtStates, indices, builtTransitions, indices.get(this.initialState));
        }
    }
}
