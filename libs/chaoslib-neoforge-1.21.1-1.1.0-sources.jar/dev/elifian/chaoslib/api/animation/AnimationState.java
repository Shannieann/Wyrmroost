package dev.elifian.chaoslib.api.animation;

import dev.elifian.chaoslib.api.animatable.GeoAnimatable;
import net.minecraft.world.entity.LivingEntity;
import org.jetbrains.annotations.Nullable;

/**
 * Mutable animation evaluation state passed to controller predicates.
 */
public final class AnimationState<T extends GeoAnimatable> {
    private T animatable;
    private float limbSwing;
    private float limbSwingAmount;
    private float partialTick;
    private double animationTick;
    private boolean moving;
    private boolean hasExplicitMovementState;
    private @Nullable AnimationController<T> controller;
    private @Nullable RawAnimation currentAnimation;

    /**
     * Creates animation state for the current animatable and partial tick.
     */
    public AnimationState(T animatable, float partialTick) {
        this(animatable, 0.0f, 0.0f, partialTick, false, false, animatable.getTick() + partialTick, null);
    }

    /**
     * Re-initialises this instance for a new evaluation (the simple {@link #AnimationState(GeoAnimatable, float)}
     * form), so the renderer can reuse one short-lived instance per block entity instead of allocating a fresh
     * one every frame. The state is transient and must not be retained across render calls.
     */
    public void reset(T animatable, float partialTick) {
        this.animatable = animatable;
        this.limbSwing = 0.0f;
        this.limbSwingAmount = 0.0f;
        this.partialTick = partialTick;
        this.moving = false;
        this.hasExplicitMovementState = false;
        this.animationTick = animatable.getTick() + partialTick;
        this.controller = null;
        this.currentAnimation = null;
    }

    public AnimationState(T animatable, float limbSwing, float limbSwingAmount, float partialTick, boolean moving) {
        this(animatable, limbSwing, limbSwingAmount, partialTick, moving, true, animatable.getTick() + partialTick, null);
    }

    private AnimationState(
            T animatable,
            float limbSwing,
            float limbSwingAmount,
            float partialTick,
            boolean moving,
            boolean hasExplicitMovementState,
            double animationTick,
            @Nullable AnimationController<T> controller
    ) {
        this.animatable = animatable;
        this.limbSwing = limbSwing;
        this.limbSwingAmount = limbSwingAmount;
        this.partialTick = partialTick;
        this.moving = moving;
        this.hasExplicitMovementState = hasExplicitMovementState;
        this.animationTick = animationTick;
        this.controller = controller;
    }

    /**
     * Returns the animatable being evaluated.
     */
    public T getAnimatable() {
        return this.animatable;
    }

    /**
     * Returns the render partial tick used for this evaluation.
     */
    public float getPartialTick() {
        return this.partialTick;
    }

    public float getLimbSwing() {
        return this.limbSwing;
    }

    public float getLimbSwingAmount() {
        return this.limbSwingAmount;
    }

    /**
     * Returns the animation tick used for this evaluation.
     */
    public double getAnimationTick() {
        return this.animationTick;
    }

    /**
     * Returns the controller currently evaluating this state.
     */
    public @Nullable AnimationController<T> getController() {
        return this.controller;
    }

    /**
     * Returns the animation selected during this controller evaluation.
     */
    public @Nullable RawAnimation getCurrentAnimation() {
        return this.currentAnimation;
    }

    /**
     * Sets the active animation and returns {@link PlayState#CONTINUE}.
     */
    public PlayState setAndContinue(RawAnimation animation) {
        this.currentAnimation = animation;
        return PlayState.CONTINUE;
    }

    /**
     * Clears the active animation and returns {@link PlayState#STOP}.
     */
    public PlayState stop() {
        this.currentAnimation = null;
        return PlayState.STOP;
    }

    public boolean isMoving() {
        if (this.hasExplicitMovementState) {
            return this.moving;
        }

        if (this.moving) {
            return true;
        }

        if (this.animatable instanceof LivingEntity livingEntity) {
            return livingEntity.swinging || livingEntity.walkAnimation.speed() > 1.0e-3f;
        }

        return Math.abs(this.limbSwingAmount) > 1.0e-3f;
    }

    public AnimationState<T> forController(AnimationController<T> controller) {
        AnimationState<T> state = new AnimationState<>(
                this.animatable,
                this.limbSwing,
                this.limbSwingAmount,
                this.partialTick,
                this.moving,
                this.hasExplicitMovementState,
                this.animationTick,
                controller
        );
        state.currentAnimation = controller.getCurrentAnimation();
        return state;
    }
}
