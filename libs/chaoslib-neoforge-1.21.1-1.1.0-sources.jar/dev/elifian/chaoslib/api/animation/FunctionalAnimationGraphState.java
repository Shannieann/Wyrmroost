package dev.elifian.chaoslib.api.animation;

import dev.elifian.chaoslib.api.animatable.GeoAnimatable;

import java.util.function.Function;

/**
 * Internal {@link AnimationGraphState} implementation backed by a function that resolves a clip
 * from the current animatable instance.
 */
final class FunctionalAnimationGraphState<T extends GeoAnimatable> implements AnimationGraphState<T> {
    private final Function<T, RawAnimation> resolver;

    FunctionalAnimationGraphState(Function<T, RawAnimation> resolver) {
        this.resolver = resolver;
    }

    @Override
    public RawAnimation animation(T animatable) {
        return this.resolver.apply(animatable);
    }
}
