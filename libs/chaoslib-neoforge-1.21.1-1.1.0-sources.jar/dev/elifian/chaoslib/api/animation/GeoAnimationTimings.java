package dev.elifian.chaoslib.api.animation;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.GsonHelper;
import org.jetbrains.annotations.Nullable;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Common-side animation timing resolver backed by classpath resource loading.
 */
public final class GeoAnimationTimings {
    private static final Map<ResourceLocation, Map<String, Float>> CACHE = new ConcurrentHashMap<>();

    private GeoAnimationTimings() {
    }

    public static float clipLengthSeconds(ResourceLocation animationResource, String clipName) {
        return requireClipLength(
                CACHE.computeIfAbsent(animationResource, GeoAnimationTimings::loadClipLengths),
                clipName,
                animationResource
        );
    }

    static float clipLengthSeconds(Map<String, Float> clipLengths, String clipName) {
        return requireClipLength(clipLengths, clipName, null);
    }

    public static int clipLengthTicks(ResourceLocation animationResource, String clipName) {
        return clipLengthTicks(CACHE.computeIfAbsent(animationResource, GeoAnimationTimings::loadClipLengths), clipName);
    }

    static int clipLengthTicks(Map<String, Float> clipLengths, String clipName) {
        return Math.max(1, Math.round(clipLengthSeconds(clipLengths, clipName) * 20.0f));
    }

    public static float rawAnimationLengthSeconds(ResourceLocation animationResource, @Nullable RawAnimation animation) {
        return rawAnimationLengthSeconds(CACHE.computeIfAbsent(animationResource, GeoAnimationTimings::loadClipLengths), animation);
    }

    static float rawAnimationLengthSeconds(Map<String, Float> clipLengths, @Nullable RawAnimation animation) {
        if (animation == null || animation.isEmpty()) {
            return 0.0f;
        }

        float total = 0.0f;
        for (RawAnimation.Stage stage : animation.getStages()) {
            float length = clipLengthSeconds(clipLengths, stage.animationName());
            if (stage.playbackMode() == RawAnimation.PlaybackMode.LOOP) {
                return Float.POSITIVE_INFINITY;
            }
            total += length;
        }
        return total;
    }

    public static int rawAnimationLengthTicks(ResourceLocation animationResource, @Nullable RawAnimation animation) {
        return rawAnimationLengthTicks(CACHE.computeIfAbsent(animationResource, GeoAnimationTimings::loadClipLengths), animation);
    }

    static int rawAnimationLengthTicks(Map<String, Float> clipLengths, @Nullable RawAnimation animation) {
        float lengthSeconds = rawAnimationLengthSeconds(clipLengths, animation);
        if (!Float.isFinite(lengthSeconds)) {
            return Integer.MAX_VALUE;
        }
        return Math.max(1, Math.round(lengthSeconds * 20.0f));
    }

    public static void clearCache() {
        CACHE.clear();
    }

    static Map<String, Float> parseClipLengths(JsonObject root) {
        JsonObject animationsObject = GsonHelper.getAsJsonObject(root, "animations");
        LinkedHashMap<String, Float> lengths = new LinkedHashMap<>();
        for (Map.Entry<String, JsonElement> entry : animationsObject.entrySet()) {
            JsonObject animationObject = entry.getValue().getAsJsonObject();
            float explicitLength = animationObject.has("animation_length")
                    ? GsonHelper.getAsFloat(animationObject, "animation_length")
                    : -1.0f;
            float inferredLength = inferAnimationLength(animationObject);
            lengths.put(entry.getKey(), explicitLength >= 0.0f ? explicitLength : inferredLength);
        }
        return Map.copyOf(lengths);
    }

    private static Map<String, Float> loadClipLengths(ResourceLocation animationResource) {
        try (InputStream stream = openAnimationResource(animationResource);
             InputStreamReader reader = new InputStreamReader(stream, StandardCharsets.UTF_8)) {
            return parseClipLengths(JsonParser.parseReader(reader).getAsJsonObject());
        } catch (Exception exception) {
            throw new IllegalStateException("Failed to resolve animation timings for " + animationResource, exception);
        }
    }

    private static InputStream openAnimationResource(ResourceLocation animationResource) {
        String resourcePath = "assets/" + animationResource.getNamespace() + "/" + animationResource.getPath();
        ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();
        InputStream stream = contextClassLoader == null ? null : contextClassLoader.getResourceAsStream(resourcePath);
        if (stream == null) {
            stream = GeoAnimationTimings.class.getClassLoader().getResourceAsStream(resourcePath);
        }
        if (stream == null) {
            throw new IllegalStateException("Resource not found on classpath: " + resourcePath);
        }
        return stream;
    }

    private static float requireClipLength(Map<String, Float> clipLengths, String clipName, @Nullable ResourceLocation animationResource) {
        Float length = clipLengths.get(clipName);
        if (length == null) {
            if (animationResource == null) {
                throw new IllegalArgumentException("Animation clip not found: clip=" + clipName);
            }
            throw new IllegalArgumentException(
                    "Animation clip not found: resource=" + animationResource + ", clip=" + clipName
            );
        }
        return length;
    }

    private static float inferAnimationLength(JsonObject animationObject) {
        if (!animationObject.has("bones")) {
            return 0.0f;
        }

        float maxTimestamp = 0.0f;
        JsonObject bones = GsonHelper.getAsJsonObject(animationObject, "bones");
        for (Map.Entry<String, JsonElement> boneEntry : bones.entrySet()) {
            JsonObject boneObject = boneEntry.getValue().getAsJsonObject();
            maxTimestamp = Math.max(maxTimestamp, maxTimestamp(boneObject.get("position")));
            maxTimestamp = Math.max(maxTimestamp, maxTimestamp(boneObject.get("rotation")));
            maxTimestamp = Math.max(maxTimestamp, maxTimestamp(boneObject.get("scale")));
        }
        return maxTimestamp;
    }

    private static float maxTimestamp(@Nullable JsonElement channelElement) {
        if (channelElement == null || !channelElement.isJsonObject()) {
            return 0.0f;
        }

        float max = 0.0f;
        JsonObject object = channelElement.getAsJsonObject();
        for (Map.Entry<String, JsonElement> entry : object.entrySet()) {
            try {
                max = Math.max(max, Float.parseFloat(entry.getKey()));
            } catch (NumberFormatException ignored) {
            }
        }
        return max;
    }
}
