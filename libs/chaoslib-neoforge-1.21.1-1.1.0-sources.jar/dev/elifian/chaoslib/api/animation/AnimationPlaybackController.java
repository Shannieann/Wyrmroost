package dev.elifian.chaoslib.api.animation;

import dev.elifian.chaoslib.api.animatable.GeoAnimatable;
import org.jetbrains.annotations.Nullable;

import java.util.Map;

/**
 * Shared runtime contract for animation backends that can drive clip playback and transitions.
 */
public interface AnimationPlaybackController<T extends GeoAnimatable> {
    enum BlendMode {
        MIX,
        OVERRIDE
    }

    @Nullable RawAnimation getCurrentAnimation();

    @Nullable RawAnimation getPreviousAnimation();

    double getAnimationStartedTick();

    double getPreviousAnimationStartedTick();

    double getPreviousAnimationFrozenTick();

    double getCurrentAnimationFrozenTick();

    double getTransitionStartedTick();

    double getTransitionProgress(double currentTick);

    int getTransitionLengthTicks();

    double getAnimationSpeed();

    double getAccumulatedAnimationTick();

    boolean didStartTransitionThisTick();

    Map<String, TransitionBonePose> getTransitionBonePoses();

    default int getPriority() {
        return 0;
    }

    default BlendMode getBlendMode() {
        return BlendMode.MIX;
    }

    PlayState process(AnimationState<T> state);

    record TransitionBonePose(
            float posX,
            float posY,
            float posZ,
            float rotX,
            float rotY,
            float rotZ,
            float scaleX,
            float scaleY,
            float scaleZ,
            boolean hasPosition,
            boolean hasRotation,
            boolean hasScale
    ) {
        public TransitionBonePose(
                float posX,
                float posY,
                float posZ,
                float rotX,
                float rotY,
                float rotZ,
                float scaleX,
                float scaleY,
                float scaleZ
        ) {
            this(posX, posY, posZ, rotX, rotY, rotZ, scaleX, scaleY, scaleZ, true, true, true);
        }
    }
}
