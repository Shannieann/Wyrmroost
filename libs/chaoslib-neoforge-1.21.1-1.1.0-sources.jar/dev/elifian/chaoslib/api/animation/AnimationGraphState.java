package dev.elifian.chaoslib.api.animation;

import dev.elifian.chaoslib.api.animatable.GeoAnimatable;

import java.util.function.Function;

/**
 * Typed state node used by declarative animation graphs.
 */
public interface AnimationGraphState<T extends GeoAnimatable> {
    RawAnimation animation(T animatable);

    static <T extends GeoAnimatable> AnimationGraphState<T> of(Function<T, RawAnimation> resolver) {
        return new FunctionalAnimationGraphState<>(resolver);
    }
}
