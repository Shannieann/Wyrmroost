package dev.elifian.chaoslib.api.animation;

import java.util.*;

/**
 * Immutable animation clip sequence definition used by controllers and graphs.
 *
 * <p>A raw animation is composed of one or more named stages, each with its own playback mode.
 * Builders and chaining helpers are used to construct the declarative sequence that runtime
 * controllers later interpret.</p>
 */
public final class RawAnimation {
    private static final Map<Stage, RawAnimation> SINGLE_STAGE_CACHE = new HashMap<>();
    private final List<Stage> stages;
    private final int hashCode;

    private RawAnimation(List<Stage> stages) {
        this.stages = List.copyOf(stages);
        this.hashCode = Objects.hash(this.stages);
    }

    public static Builder begin() {
        return new Builder();
    }

    public RawAnimation thenLoop(String animationName) {
        if (this.stages.isEmpty()) {
            return singleStage(animationName, PlaybackMode.LOOP);
        }
        ArrayList<Stage> combinedStages = new ArrayList<>(this.stages);
        combinedStages.add(new Stage(animationName, PlaybackMode.LOOP));
        return new RawAnimation(combinedStages);
    }

    public RawAnimation thenPlayAndHold(String animationName) {
        if (this.stages.isEmpty()) {
            return singleStage(animationName, PlaybackMode.PLAY_AND_HOLD);
        }
        ArrayList<Stage> combinedStages = new ArrayList<>(this.stages);
        combinedStages.add(new Stage(animationName, PlaybackMode.PLAY_AND_HOLD));
        return new RawAnimation(combinedStages);
    }

    public List<Stage> getStages() {
        return this.stages;
    }

    public boolean isEmpty() {
        return this.stages.isEmpty();
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof RawAnimation rawAnimation)) {
            return false;
        }
        if (this.hashCode != rawAnimation.hashCode) {
            return false;
        }
        return this.stages.equals(rawAnimation.stages);
    }

    @Override
    public int hashCode() {
        return this.hashCode;
    }

    public record Stage(String animationName, PlaybackMode playbackMode) {
    }

    public enum PlaybackMode {
        LOOP,
        PLAY_AND_HOLD
    }

    private static RawAnimation singleStage(String animationName, PlaybackMode playbackMode) {
        Stage stage = new Stage(animationName, playbackMode);
        synchronized (SINGLE_STAGE_CACHE) {
            return SINGLE_STAGE_CACHE.computeIfAbsent(stage, key -> new RawAnimation(List.of(key)));
        }
    }

    public static final class Builder {
        private final List<Stage> stages = new ArrayList<>();

        public RawAnimation thenLoop(String animationName) {
            if (this.stages.isEmpty()) {
                return singleStage(animationName, PlaybackMode.LOOP);
            }
            this.stages.add(new Stage(animationName, PlaybackMode.LOOP));
            return new RawAnimation(this.stages);
        }

        public RawAnimation thenPlayAndHold(String animationName) {
            if (this.stages.isEmpty()) {
                return singleStage(animationName, PlaybackMode.PLAY_AND_HOLD);
            }
            this.stages.add(new Stage(animationName, PlaybackMode.PLAY_AND_HOLD));
            return new RawAnimation(this.stages);
        }
    }
}
