package dev.elifian.chaoslib.api.animation;

import dev.elifian.chaoslib.api.animatable.GeoAnimatable;
import org.jetbrains.annotations.Nullable;

import java.util.Map;

/**
 * Evaluates animation predicates and tracks animation transitions for one controller.
 */
public class AnimationController<T extends GeoAnimatable> implements AnimationPlaybackController<T> {
    private final T animatable;
    private int transitionLengthTicks;
    private int priority;
    private BlendMode blendMode = BlendMode.MIX;
    private final @Nullable AnimationPredicate<T> predicate;
    private final @Nullable GraphMode<T, ? extends AnimationGraphState<T>> graphMode;
    private @Nullable RawAnimation currentAnimation;
    private @Nullable RawAnimation previousAnimation;
    private PlayState lastPlayState = PlayState.STOP;
    private double animationStartedTick;
    private double previousAnimationStartedTick;
    private double previousAnimationFrozenTick;
    private double transitionStartedTick;
    private double currentAnimationFrozenTick;
    private double animationSpeed = 1.0d;
    private double scaledAnimationTick;
    private double lastAnimationTick = Double.NaN;
    private boolean startedTransitionThisTick;
    private Map<String, TransitionBonePose> transitionBonePoses = Map.of();

    /**
     * Creates a controller with a name, transition length, and predicate.
     */
    public AnimationController(T animatable, int transitionLengthTicks, AnimationPredicate<T> predicate) {
        this.animatable = animatable;
        this.transitionLengthTicks = transitionLengthTicks;
        this.predicate = predicate;
        this.graphMode = null;
    }

    /**
     * Creates a controller that always loops the given animation id.
     */
    public AnimationController(T animatable, String loopAnimationName) {
        this(animatable, 0, loopAnimationName);
    }

    /**
     * Creates a controller that always loops the given animation id with a transition duration.
     */
    public AnimationController(T animatable, int transitionLengthTicks, String loopAnimationName) {
        this(animatable, transitionLengthTicks, RawAnimation.begin().thenLoop(loopAnimationName));
    }

    /**
     * Creates a controller that always plays the given raw animation.
     */
    public AnimationController(T animatable, RawAnimation animation) {
        this(animatable, 0, animation);
    }

    /**
     * Creates a controller that always plays the given raw animation with a transition duration.
     */
    public AnimationController(T animatable, int transitionLengthTicks, RawAnimation animation) {
        this(animatable, fixedAnimationGraph(animation));
        this.transitionLengthTicks = Math.max(0, transitionLengthTicks);
    }

    /**
     * Creates a controller backed by a shared animation state graph.
     */
    public <S extends AnimationGraphState<T>> AnimationController(T animatable, AnimationGraph<T, S> graph) {
        this(animatable, graph, (state, currentState) -> 1.0d);
    }

    /**
     * Creates a controller backed by a shared animation state graph with dynamic speed resolution.
     */
    public <S extends AnimationGraphState<T>> AnimationController(
            T animatable,
            AnimationGraph<T, S> graph,
            AnimationGraph.SpeedResolver<T, S> speedResolver
    ) {
        this.animatable = animatable;
        this.transitionLengthTicks = 0;
        this.predicate = null;
        this.graphMode = new GraphMode<>(graph, speedResolver);
    }

    /**
     * Returns the animatable owned by this controller.
     */
    public T getAnimatable() {
        return this.animatable;
    }

    /**
     * Returns the transition duration in ticks.
     */
    public int getTransitionLengthTicks() {
        if (this.graphMode != null) {
            return currentGraphTransitionLength();
        }
        return this.transitionLengthTicks;
    }

    /**
     * Overrides the transition duration in ticks for this controller.
     */
    public AnimationController<T> transitionLength(int ticks) {
        this.transitionLengthTicks = Math.max(0, ticks);
        return this;
    }

    public AnimationController<T> priority(int priority) {
        this.priority = priority;
        return this;
    }

    @Override
    public int getPriority() {
        return this.priority;
    }

    public AnimationController<T> blendMode(BlendMode blendMode) {
        this.blendMode = blendMode == null ? BlendMode.MIX : blendMode;
        return this;
    }

    @Override
    public BlendMode getBlendMode() {
        return this.blendMode;
    }

    /**
     * Returns the currently active animation.
     */
    public @Nullable RawAnimation getCurrentAnimation() {
        AnimationGraphState<T> currentState = currentGraphState();
        if (currentState != null) {
            return currentState.animation(this.animatable);
        }
        return this.currentAnimation;
    }

    /**
     * Returns the previous animation still contributing to a transition.
     */
    public @Nullable RawAnimation getPreviousAnimation() {
        AnimationGraphState<T> previousState = previousGraphState();
        if (previousState != null) {
            return previousState.animation(this.animatable);
        }
        return this.previousAnimation;
    }

    /**
     * Returns the last predicate play state returned by this controller.
     */
    public PlayState getLastPlayState() {
        return this.lastPlayState;
    }

    /**
     * Returns the tick when the current animation started.
     */
    public double getAnimationStartedTick() {
        return this.animationStartedTick;
    }

    /**
     * Returns the accumulated animation tick after applying speed scaling.
     */
    public double getAccumulatedAnimationTick() {
        return this.scaledAnimationTick;
    }

    /**
     * Returns the accumulated animation tick captured when the current animation became a transition target.
     */
    public double getCurrentAnimationFrozenTick() {
        return this.currentAnimationFrozenTick;
    }

    @Override
    public double getTransitionStartedTick() {
        return this.transitionStartedTick;
    }

    /**
     * Returns the tick when the previous animation started.
     */
    public double getPreviousAnimationStartedTick() {
        return this.previousAnimationStartedTick;
    }

    /**
     * Returns the accumulated animation tick captured when the previous animation became a transition source.
     */
    public double getPreviousAnimationFrozenTick() {
        return this.previousAnimationFrozenTick;
    }

    public boolean didStartTransitionThisTick() {
        return this.startedTransitionThisTick;
    }

    public Map<String, TransitionBonePose> getTransitionBonePoses() {
        return this.transitionBonePoses;
    }

    public void captureTransitionBonePoses(Map<String, TransitionBonePose> transitionBonePoses) {
        this.transitionBonePoses = transitionBonePoses;
    }

    /**
     * Returns transition progress from the previous animation to the current animation.
     */
    public double getTransitionProgress(double currentTick) {
        int transitionLengthTicks = getTransitionLengthTicks();
        if (getPreviousAnimation() == null || transitionLengthTicks <= 0) {
            return 1.0d;
        }
        return Math.max(0.0d, Math.min(1.0d, (currentTick - this.transitionStartedTick) / transitionLengthTicks));
    }

    public double getAnimationSpeed() {
        return this.animationSpeed;
    }

    public void setAnimationSpeed(double animationSpeed) {
        this.animationSpeed = Math.max(0.0d, animationSpeed);
    }

    /**
     * Clears the controller playback state so the next matching animation starts from the beginning.
     */
    public void reset() {
        this.currentAnimation = null;
        this.previousAnimation = null;
        this.lastPlayState = PlayState.STOP;
        this.animationStartedTick = 0.0d;
        this.previousAnimationStartedTick = 0.0d;
        this.previousAnimationFrozenTick = 0.0d;
        this.transitionStartedTick = 0.0d;
        this.currentAnimationFrozenTick = 0.0d;
        this.scaledAnimationTick = 0.0d;
        this.lastAnimationTick = Double.NaN;
        this.startedTransitionThisTick = false;
        this.transitionBonePoses = Map.of();
        if (this.graphMode != null) {
            this.graphMode.currentStateIndex = -1;
            this.graphMode.previousStateIndex = -1;
        }
    }

    /**
     * Evaluates this controller for the given animation state.
     */
    public PlayState process(AnimationState<T> state) {
        if (this.graphMode != null) {
            return processGraphState(state);
        }

        this.startedTransitionThisTick = false;
        AnimationState<T> controllerState = state.forController(this);
        PlayState playState = this.predicate.test(controllerState);
        RawAnimation desiredAnimation = controllerState.getCurrentAnimation();
        double animationTick = state.getAnimationTick();
        double scaledAnimationTick = this.advanceAnimationTick(animationTick);

        if (playState == PlayState.STOP && desiredAnimation == null) {
            if (this.currentAnimation != null) {
                this.previousAnimation = this.currentAnimation;
                this.previousAnimationStartedTick = this.animationStartedTick;
                this.previousAnimationFrozenTick = scaledAnimationTick;
                this.transitionStartedTick = animationTick;
                this.startedTransitionThisTick = true;
            }
            this.currentAnimation = null;
            this.animationStartedTick = scaledAnimationTick;
        } else if (desiredAnimation != null && !desiredAnimation.equals(this.currentAnimation)) {
            this.previousAnimation = this.currentAnimation;
            this.previousAnimationStartedTick = this.animationStartedTick;
            this.previousAnimationFrozenTick = scaledAnimationTick;
            this.currentAnimation = desiredAnimation;
            this.animationStartedTick = scaledAnimationTick;
            this.currentAnimationFrozenTick = scaledAnimationTick;
            this.transitionStartedTick = animationTick;
            this.startedTransitionThisTick = true;
        }

        if (this.previousAnimation != null && transitionElapsed(animationTick) > this.transitionLengthTicks) {
            if (this.currentAnimation != null) {
                this.animationStartedTick = scaledAnimationTick;
                this.currentAnimationFrozenTick = scaledAnimationTick;
            }
            this.previousAnimation = null;
            this.previousAnimationFrozenTick = 0.0d;
            this.transitionBonePoses = Map.of();
        }
        this.lastPlayState = playState;
        return playState;
    }

    public boolean usesGraphMode() {
        return this.graphMode != null;
    }

    public @Nullable AnimationGraphState<T> currentGraphState() {
        if (this.graphMode == null || this.graphMode.currentStateIndex < 0) {
            return null;
        }
        return currentGraphState(this.graphMode);
    }

    public @Nullable AnimationGraphState<T> previousGraphState() {
        if (this.graphMode == null || this.graphMode.previousStateIndex < 0) {
            return null;
        }
        return previousGraphState(this.graphMode);
    }

    @SuppressWarnings("unchecked")
    private PlayState processGraphState(AnimationState<T> state) {
        return processGraphState(state, (GraphMode<T, AnimationGraphState<T>>) this.graphMode);
    }

    private <S extends AnimationGraphState<T>> PlayState processGraphState(AnimationState<T> state, GraphMode<T, S> graphMode) {
        this.startedTransitionThisTick = false;
        ensureGraphInitialized(state.getAnimationTick(), graphMode);
        S currentState = currentGraphState(graphMode);
        this.animationSpeed = Math.max(0.0d, graphMode.speedResolver.resolve(state, currentState));
        double animationTick = state.getAnimationTick();
        double scaledAnimationTick = advanceAnimationTick(animationTick);

        for (AnimationGraph.Transition<T, S> transition : graphMode.graph.transitions(currentState)) {
            if (!transition.condition().test(state, this, animationTick)) {
                continue;
            }

            int nextStateIndex = graphMode.graph.stateIndex(transition.targetState());
            if (nextStateIndex == graphMode.currentStateIndex) {
                break;
            }

            graphMode.previousStateIndex = graphMode.currentStateIndex;
            this.previousAnimationStartedTick = this.animationStartedTick;
            this.previousAnimationFrozenTick = scaledAnimationTick;
            graphMode.currentStateIndex = nextStateIndex;
            this.animationStartedTick = scaledAnimationTick;
            this.currentAnimationFrozenTick = scaledAnimationTick;
            this.transitionStartedTick = animationTick;
            this.startedTransitionThisTick = true;
            break;
        }

        if (graphMode.previousStateIndex >= 0 && transitionElapsed(animationTick) > getTransitionLengthTicks()) {
            this.animationStartedTick = scaledAnimationTick;
            this.currentAnimationFrozenTick = scaledAnimationTick;
            graphMode.previousStateIndex = -1;
            this.previousAnimationStartedTick = 0.0d;
            this.previousAnimationFrozenTick = 0.0d;
            this.transitionBonePoses = Map.of();
        }

        this.lastPlayState = getCurrentAnimation() == null ? PlayState.STOP : PlayState.CONTINUE;
        return this.lastPlayState;
    }

    private double advanceAnimationTick(double animationTick) {
        if (Double.isNaN(this.lastAnimationTick)) {
            this.lastAnimationTick = animationTick;
            this.scaledAnimationTick = animationTick;
            return this.scaledAnimationTick;
        }

        double delta = Math.max(0.0d, animationTick - this.lastAnimationTick);
        this.lastAnimationTick = animationTick;
        this.scaledAnimationTick += delta * this.animationSpeed;
        return this.scaledAnimationTick;
    }

    private double transitionElapsed(double animationTick) {
        return animationTick - this.transitionStartedTick;
    }

    void setCurrentAnimation(@Nullable RawAnimation currentAnimation) {
        this.currentAnimation = currentAnimation;
    }

    private int currentGraphTransitionLength() {
        if (this.graphMode == null) {
            return this.transitionLengthTicks;
        }

        AnimationGraphState<T> previousState = previousGraphState();
        AnimationGraphState<T> currentState = currentGraphState();
        if (previousState == null || currentState == null) {
            return 0;
        }

        return currentGraphTransitionLength(this.graphMode, previousState, currentState);
    }

    private <S extends AnimationGraphState<T>> int currentGraphTransitionLength(GraphMode<T, S> graphMode, AnimationGraphState<T> previousState, AnimationGraphState<T> currentState) {
        @SuppressWarnings("unchecked")
        S typedPreviousState = (S) previousState;
        @SuppressWarnings("unchecked")
        S typedCurrentState = (S) currentState;
        for (AnimationGraph.Transition<T, S> transition : graphMode.graph.transitions(typedPreviousState)) {
            if (transition.targetState().equals(typedCurrentState)) {
                return transition.transitionLengthTicks();
            }
        }
        return 0;
    }

    private <S extends AnimationGraphState<T>> void ensureGraphInitialized(double animationTick, GraphMode<T, S> graphMode) {
        if (graphMode.currentStateIndex >= 0) {
            return;
        }
        graphMode.currentStateIndex = graphMode.graph.initialStateIndex();
        this.animationStartedTick = animationTick;
        this.currentAnimationFrozenTick = animationTick;
        this.scaledAnimationTick = animationTick;
        this.lastAnimationTick = animationTick;
    }

    private <S extends AnimationGraphState<T>> S currentGraphState(GraphMode<T, S> graphMode) {
        return graphMode.graph.state(graphMode.currentStateIndex);
    }

    private <S extends AnimationGraphState<T>> S previousGraphState(GraphMode<T, S> graphMode) {
        return graphMode.graph.state(graphMode.previousStateIndex);
    }

    @FunctionalInterface
    /**
     * Chooses the animation and play state for a controller evaluation.
     */
    public interface AnimationPredicate<T extends GeoAnimatable> {
        PlayState test(AnimationState<T> state);
    }

    private static final class GraphMode<T extends GeoAnimatable, S extends AnimationGraphState<T>> {
        private final AnimationGraph<T, S> graph;
        private final AnimationGraph.SpeedResolver<T, S> speedResolver;
        private int currentStateIndex = -1;
        private int previousStateIndex = -1;

        private GraphMode(AnimationGraph<T, S> graph, AnimationGraph.SpeedResolver<T, S> speedResolver) {
            this.graph = graph;
            this.speedResolver = speedResolver;
        }
    }

    private static <T extends GeoAnimatable> AnimationGraph<T, AnimationGraphState<T>> fixedAnimationGraph(RawAnimation animation) {
        AnimationGraphState<T> state = AnimationGraphState.of(animatable -> animation);
        return AnimationGraph.<T, AnimationGraphState<T>>builder(state)
                .state(state)
                .build();
    }
}
