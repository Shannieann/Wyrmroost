package dev.elifian.chaoslib.api.animation;

import dev.elifian.chaoslib.api.animatable.GeoAnimatable;

/**
 * Built-in transition conditions supported by declarative animation graphs.
 */
public enum AnimationCondition {
    ALWAYS {
        @Override
        public <T extends GeoAnimatable> boolean test(AnimationState<T> state, AnimationPlaybackController<T> controller, double animationTick) {
            return true;
        }
    },
    MOVING {
        @Override
        public <T extends GeoAnimatable> boolean test(AnimationState<T> state, AnimationPlaybackController<T> controller, double animationTick) {
            return state.isMoving();
        }
    },
    IDLE {
        @Override
        public <T extends GeoAnimatable> boolean test(AnimationState<T> state, AnimationPlaybackController<T> controller, double animationTick) {
            return !state.isMoving();
        }
    };

    public abstract <T extends GeoAnimatable> boolean test(AnimationState<T> state, AnimationPlaybackController<T> controller, double animationTick);
}
