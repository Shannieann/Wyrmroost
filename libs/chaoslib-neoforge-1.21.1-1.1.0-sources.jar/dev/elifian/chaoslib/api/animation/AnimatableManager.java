package dev.elifian.chaoslib.api.animation;

import dev.elifian.chaoslib.api.animatable.GeoAnimatable;

import java.util.ArrayList;
import java.util.List;

/**
 * Owns the animation controllers registered for one animatable instance and coordinates their
 * per-tick processing.
 *
 * <p>This is the runtime bridge between a {@link GeoAnimatable} and its declared
 * {@link AnimationController} set. It builds the controller list once, exposes playback-oriented
 * views for render backends, and advances every controller against the current
 * {@link AnimationState}.</p>
 */
public final class AnimatableManager<T extends GeoAnimatable> {
    private final List<AnimationController<T>> controllers;
    private final List<AnimationPlaybackController<T>> playbackControllers;

    private AnimatableManager(List<AnimationController<T>> controllers) {
        this.controllers = List.copyOf(controllers);
        ArrayList<AnimationPlaybackController<T>> playbackControllers = new ArrayList<>(this.controllers.size());
        playbackControllers.addAll(this.controllers);
        this.playbackControllers = List.copyOf(playbackControllers);
    }

    public static <T extends GeoAnimatable> AnimatableManager<T> create(T animatable) {
        RegistrarImpl<T> registrar = new RegistrarImpl<>();
        animatable.registerControllers(registrar);
        return new AnimatableManager<>(registrar.controllers);
    }

    public List<AnimationController<T>> getControllers() {
        return this.controllers;
    }

    public List<AnimationPlaybackController<T>> getPlaybackControllers() {
        return this.playbackControllers;
    }

    public void process(AnimationState<T> state) {
        for (AnimationController<T> controller : this.controllers) {
            controller.process(state);
        }
    }

    /**
     * Collects controllers declared by an animatable during manager creation.
     */
    public interface ControllerRegistrar {
        <T extends GeoAnimatable> void add(AnimationController<T> controller);
    }

    private static final class RegistrarImpl<T extends GeoAnimatable> implements ControllerRegistrar {
        private final List<AnimationController<T>> controllers = new ArrayList<>();

        @Override
        @SuppressWarnings("unchecked")
        public <A extends GeoAnimatable> void add(AnimationController<A> controller) {
            this.controllers.add((AnimationController<T>) controller);
        }
    }
}
