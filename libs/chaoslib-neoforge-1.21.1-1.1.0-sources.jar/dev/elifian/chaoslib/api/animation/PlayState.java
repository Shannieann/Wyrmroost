package dev.elifian.chaoslib.api.animation;

/**
 * Result returned by animation predicates and controllers to indicate whether playback should keep
 * advancing or stop for the current tick.
 */
public enum PlayState {
    CONTINUE,
    STOP
}
