package dev.elifian.chaoslib.api.renderer;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import dev.elifian.chaoslib.api.animatable.GeoAnimatable;
import dev.elifian.chaoslib.api.animatable.GeoBoneTrackingAnimatable;
import dev.elifian.chaoslib.api.animation.AnimationState;
import dev.elifian.chaoslib.api.model.GeoModel;
import dev.elifian.chaoslib.api.model.render.GeoRenderColor;
import dev.elifian.chaoslib.api.model.render.GeoRenderPass;
import dev.elifian.chaoslib.api.multipart.GeoMultipartEntity;
import dev.elifian.chaoslib.api.multipart.GeoTrackedBonePose;
import dev.elifian.chaoslib.cache.object.BakedGeoModel;
import dev.elifian.chaoslib.client.animation.GeoBoneTrackingHelper;
import dev.elifian.chaoslib.client.multipart.GeoMultipartSyncHelper;
import dev.elifian.chaoslib.client.texture.AnimatedTextureSupport;
import dev.elifian.chaoslib.compat.iris.IrisCompatInternal;
import dev.elifian.chaoslib.compat.sodium.ChaosSodiumDebugOverlay;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuBoneResolveDispatcher;
import dev.elifian.chaoslib.gpu.mesh.ChaosGpuGeoMesh;
import dev.elifian.chaoslib.gpu.render.*;
import dev.elifian.chaoslib.model.AnimatedBoneSelection;
import dev.elifian.chaoslib.platform.ClientOnly;
import dev.elifian.chaoslib.renderer.entity.GeoEntityRenderPipeline;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

import java.util.*;

@ClientOnly
/**
 * Base entity renderer for ChaosLib geo models.
 *
 * <p>This renderer resolves model resources, runs animation state through the GPU path, captures
 * tracked bone transforms, and synchronizes multipart bone data for
 * {@link GeoMultipartEntity} owners. Extend it to customize entity-specific transforms, render
 * layers, or render hooks while keeping the standard ChaosLib pipeline.</p>
 */
public class GeoEntityRenderer<T extends Entity & GeoAnimatable> extends EntityRenderer<T> {
    private static final float DEFAULT_MOTION_ANIM_THRESHOLD = 0.015f;
    private static final int MOVING_STATE_HOLD_TICKS = 2;
    private static final Map<Entity, Integer> LAST_MOVING_TICKS = new WeakHashMap<>();
    private static final Map<GeoBoneTrackingAnimatable, TrackedBoneReadbackState> TRACKED_BONE_READBACK_STATE = new WeakHashMap<>();
    protected final GeoModel<T> model;
    protected Set<String> dynamicRenderBones;
    protected Set<String> emissiveRenderBones;
    protected boolean dynamicSelectionAll;
    protected Matrix4f entityRenderTranslations = new Matrix4f();
    protected Matrix4f modelRenderTranslations = new Matrix4f();
    private final GeoEntityRenderPipeline<T> renderPipeline = new GeoEntityRenderPipeline<>();

    public GeoEntityRenderer(EntityRendererProvider.Context context, GeoModel<T> model) {
        super(context);
        this.model = model;
        this.shadowRadius = 0.5f;
    }

    public GeoModel<T> getGeoModel() {
        return this.model;
    }

    public void primeResolvedRenderBones(Set<String> dynamicRenderBones, Set<String> emissiveRenderBones, boolean dynamicSelectionAll) {
        this.dynamicRenderBones = dynamicRenderBones;
        this.emissiveRenderBones = emissiveRenderBones;
        this.dynamicSelectionAll = dynamicSelectionAll;
    }

    @Override
    public ResourceLocation getTextureLocation(T animatable) {
        return this.model.getResourceSet().getTextureResource(animatable);
    }

    protected RenderType getRenderType(T animatable, ResourceLocation texture) {
        return IrisCompatInternal.wrapEntityRenderLayer(this.model.getRenderPolicy().getRenderType(animatable, texture));
    }

    @Override
    public void render(T entity, float entityYaw, float partialTick, PoseStack poseStack, MultiBufferSource bufferSource, int packedLight) {
        this.renderPipeline.render(this, entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);

        this.dynamicRenderBones = null;
        this.emissiveRenderBones = null;
        this.dynamicSelectionAll = false;
        super.render(entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);
    }

    public void preRender(PoseStack poseStack, T animatable, BakedGeoModel model, MultiBufferSource bufferSource, VertexConsumer buffer, boolean isReRender, float partialTick, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.entityRenderTranslations.set(poseStack.last().pose());
    }

    public void postRender(PoseStack poseStack, T animatable, BakedGeoModel model, MultiBufferSource bufferSource, VertexConsumer buffer, boolean isReRender, float partialTick, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
    }

    public int getPackedOverlay(T animatable, float whiteOverlayProgress) {
        if (animatable instanceof LivingEntity livingEntity) {
            return LivingEntityRenderer.getOverlayCoords(livingEntity, whiteOverlayProgress);
        }

        return OverlayTexture.NO_OVERLAY;
    }

    public float getRenderAlpha(T animatable, float partialTick) {
        return 1.0f;
    }

    public void actuallyRender(PoseStack poseStack, T animatable, BakedGeoModel model, RenderType renderType, MultiBufferSource bufferSource, VertexConsumer buffer, boolean isReRender, float partialTick, int packedLight, int packedOverlay, float red, float green, float blue, float alpha, ResourceLocation texture, float entityYaw) {
        Object poseCacheKey = animatable.getPoseKey();
        AnimationState<T> animationState = createAnimationState(animatable, partialTick);
        EntityAnimationPreparationDecision decision = new EntityAnimationPreparationDecision(EntityAnimationPreparationPath.CPU);
        if (!isReRender) {
            rotateEntity(animatable, entityYaw, partialTick, poseStack);
            poseStack.mulPose(this.model.getRenderPolicy().getEntityRootTransform(animatable));
            decision = determineEntityAnimationPreparation(animatable, model);
            if (decision.path() == EntityAnimationPreparationPath.GPU_LIVE) {
                this.model.prepareLiveRenderAnimations(animatable, animatable.getId(), animationState);
            } else if (decision.path() == EntityAnimationPreparationPath.CPU) {
                this.model.prepareCpuRenderAnimations(animatable, animatable.getId(), animationState);
            } else {
                model.resetPose();
            }
        }

        this.modelRenderTranslations.set(poseStack.last().pose());
        if (this.dynamicRenderBones == null) {
            this.dynamicRenderBones = resolveDynamicBones(animatable, model);
        }
        PoseStack lightPoseStack = createEntityLightPoseStack(animatable, entityYaw, partialTick);
        Vec3 worldOrigin = resolveEntityWorldOrigin(animatable, partialTick);
        ChaosGpuRenderCapture trackedBoneCapture = null;
        if (this.model.usesCustomRenderPasses()) {
            trackedBoneCapture = renderCustomPasses(poseStack, lightPoseStack, worldOrigin, animatable, model, animationState, poseCacheKey, decision.path() == EntityAnimationPreparationPath.GPU_LIVE, bufferSource, packedLight, packedOverlay, partialTick, red, green, blue, alpha);
            captureTrackedBonePositions(poseStack, animatable, model, animationState, poseCacheKey, trackedBoneCapture);
            return;
        }
        ResourceLocation emissiveTexture = resolveEmissiveTexture(animatable);
        Set<String> emissiveBones = this.emissiveRenderBones;
        if (emissiveBones == null && emissiveTexture != null) {
            emissiveBones = resolveEmissiveBones(model, animatable);
            this.emissiveRenderBones = emissiveBones;
        }
        if (emissiveBones == null) {
            emissiveBones = Set.of();
            this.emissiveRenderBones = emissiveBones;
        }
        float emissiveStrength = 1.0f;
        ResourceLocation renderTexture = AnimatedTextureSupport.resolveRenderTexture(texture);
        if (renderType == null) {
            renderType = getRenderType(animatable, renderTexture);
        }
        float[] shaderColor = RenderSystem.getShaderColor();
        float shaderRed = shaderColor[0];
        float shaderGreen = shaderColor[1];
        float shaderBlue = shaderColor[2];
        float shaderAlpha = shaderColor[3];
        Matrix4f previousTextureMatrix = AnimatedTextureSupport.pushTextureMatrix(renderTexture);
        try {
            RenderSystem.setShaderColor(shaderRed, shaderGreen, shaderBlue, shaderAlpha * alpha);
            trackedBoneCapture = renderWorldLitPass(
                    model,
                    poseStack,
                    lightPoseStack,
                    animatable,
                    animationState,
                    poseCacheKey,
                    decision.path() == EntityAnimationPreparationPath.GPU_LIVE,
                    bufferSource,
                    renderType,
                    renderTexture,
                    null,
                    0.0f,
                    animatable.level(),
                    worldOrigin,
                    packedLight,
                    packedOverlay,
                    this.dynamicSelectionAll ? null : this.dynamicRenderBones,
                    red,
                    green,
                    blue,
                    alpha
            );
        } finally {
            RenderSystem.setShaderColor(shaderRed, shaderGreen, shaderBlue, shaderAlpha);
            AnimatedTextureSupport.popTextureMatrix(previousTextureMatrix);
        }
        if (emissiveTexture != null && emissiveBones != null && !emissiveBones.isEmpty()) {
            ResourceLocation renderEmissiveTexture = AnimatedTextureSupport.resolveRenderTexture(emissiveTexture);
            RenderType emissiveRenderType = IrisCompatInternal.wrapEntityRenderLayer(this.model.getEmissiveRenderType(animatable, renderEmissiveTexture));
            previousTextureMatrix = AnimatedTextureSupport.pushTextureMatrix(renderEmissiveTexture);
            try {
                RenderSystem.setShaderColor(shaderRed, shaderGreen, shaderBlue, shaderAlpha * alpha);
                renderWorldLitPass(
                        model,
                        poseStack,
                        lightPoseStack,
                        animatable,
                        animationState,
                        poseCacheKey,
                        decision.path() == EntityAnimationPreparationPath.GPU_LIVE,
                        bufferSource,
                        emissiveRenderType,
                        renderEmissiveTexture,
                        null,
                        0.0f,
                        animatable.level(),
                        worldOrigin,
                        LightTexture.FULL_BRIGHT,
                        packedOverlay,
                        emissiveBones,
                        emissiveStrength,
                        emissiveStrength,
                        emissiveStrength,
                        alpha
                );
            } finally {
                RenderSystem.setShaderColor(shaderRed, shaderGreen, shaderBlue, shaderAlpha);
                AnimatedTextureSupport.popTextureMatrix(previousTextureMatrix);
            }
        }

        captureTrackedBonePositions(poseStack, animatable, model, animationState, poseCacheKey, trackedBoneCapture);
    }

    protected void rotateEntity(T entity, float entityYaw, float partialTick, PoseStack poseStack) {
        poseStack.mulPose(Axis.YP.rotationDegrees(180.0f - entityYaw));
    }

    protected float getMotionAnimThreshold(T animatable) {
        return DEFAULT_MOTION_ANIM_THRESHOLD;
    }

    protected AnimationState<T> createAnimationState(T animatable, float partialTick) {
        if (!(animatable instanceof LivingEntity livingEntity)) {
            return new AnimationState<>(animatable, partialTick);
        }

        float limbSwingAmount = Math.min(livingEntity.walkAnimation.speed(partialTick), 1.0f);
        float limbSwing = livingEntity.walkAnimation.position(partialTick);
        if (livingEntity.isBaby()) {
            limbSwing *= 3.0f;
        }

        return new AnimationState<>(animatable, limbSwing, limbSwingAmount, partialTick, isMovingAnimation(animatable, limbSwingAmount));
    }

    protected boolean isMovingAnimation(T animatable, float limbSwingAmount) {
        Vec3 velocity = animatable.getDeltaMovement();
        float threshold = getMotionAnimThreshold(animatable);
        double dx = animatable.getX() - animatable.xo;
        double dz = animatable.getZ() - animatable.zo;
        double horizontalDisplacementSquared = dx * dx + dz * dz;
        double horizontalVelocitySquared = velocity.x * velocity.x + velocity.z * velocity.z;
        double thresholdSquared = threshold * threshold;
        boolean movingNow = Math.abs(limbSwingAmount) > threshold
                || horizontalDisplacementSquared >= thresholdSquared
                || horizontalVelocitySquared >= thresholdSquared;

        if (movingNow) {
            LAST_MOVING_TICKS.put(animatable, animatable.tickCount);
            return true;
        }

        int lastMovingTick = LAST_MOVING_TICKS.getOrDefault(animatable, Integer.MIN_VALUE);
        return animatable.tickCount - lastMovingTick <= MOVING_STATE_HOLD_TICKS;
    }

    protected ResourceLocation resolveEmissiveTexture(T animatable) {
        if (!this.model.shouldRenderEmissive(animatable)) {
            return null;
        }

        ResourceLocation emissiveTexture = this.model.getRenderPolicy().getEmissiveTextureResource(animatable);
        return emissiveTexture != null && this.model.hasClientResource(emissiveTexture) ? emissiveTexture : null;
    }

    protected Set<String> resolveEmissiveBones(BakedGeoModel model, T animatable) {
        return this.model.getRenderPolicy().getResolvedEmissiveBones(animatable, model, this.dynamicRenderBones);
    }

    protected Set<String> resolveDynamicBones(T animatable, BakedGeoModel model) {
        AnimatedBoneSelection selection = this.model.getRenderPolicy().getLiveRenderBones(animatable);
        if (selection.isAll() || selection.isNone()) {
            return null;
        }

        Set<String> resolved = selection.resolve(model);
        return resolved.isEmpty() ? null : resolved;
    }

    private ChaosGpuRenderCapture renderCustomPasses(
            PoseStack poseStack,
            PoseStack lightPoseStack,
            Vec3 worldOrigin,
            T animatable,
            BakedGeoModel model,
            @Nullable AnimationState<T> animationState,
            @Nullable Object poseCacheKey,
            boolean useGpuLiveAnimation,
            MultiBufferSource bufferSource,
            int packedLight,
            int packedOverlay,
            float partialTick,
            float red,
            float green,
            float blue,
            float alpha
    ) {
        LinkedHashMap<LivePassBatchKey, LivePassBatch> batches = new LinkedHashMap<>();
        ChaosGpuRenderCapture trackedBoneCapture = null;

        for (GeoRenderPass<T> pass : this.model.getRenderPasses()) {
            if (!pass.shouldRenderLive(animatable)) {
                continue;
            }

            ResourceLocation texture = pass.getLiveTexture(animatable);
            if (texture == null || !this.model.hasClientResource(texture)) {
                continue;
            }
            ResourceLocation renderTexture = AnimatedTextureSupport.resolveRenderTexture(texture);

            Set<String> includedBones = this.model.resolveLiveRenderPassBones(pass, model, animatable, this.dynamicSelectionAll ? null : this.dynamicRenderBones);
            if (includedBones != null && includedBones.isEmpty()) {
                continue;
            }

            RenderType renderLayer = IrisCompatInternal.wrapEntityRenderLayer(pass.getLiveRenderLayer(animatable, renderTexture));
            int passPackedLight = pass.resolvePackedLight(animatable, packedLight);
            int passColor = pass.getLiveColor(animatable, partialTick);
            ResourceLocation passEmissiveTexture = pass.getLiveEmissiveTexture(animatable, texture);
            if (passEmissiveTexture != null && !this.model.hasClientResource(passEmissiveTexture)) {
                passEmissiveTexture = null;
            }
            if (passEmissiveTexture != null) {
                passEmissiveTexture = AnimatedTextureSupport.resolveRenderTexture(passEmissiveTexture);
            }
            float passEmissiveStrength = passEmissiveTexture != null ? pass.getLiveEmissiveStrength(animatable) : 0.0f;
            LivePassBatchKey key = new LivePassBatchKey(renderLayer, renderTexture, passEmissiveTexture, passPackedLight, passColor, passEmissiveStrength);
            LivePassBatch batch = batches.get(key);
            if (batch == null) {
                batches.put(key, new LivePassBatch(includedBones));
            } else {
                batch.include(includedBones);
            }
        }

        LinkedHashSet<String> renderedBones = new LinkedHashSet<>();
        boolean renderedAllBones = false;
        for (Map.Entry<LivePassBatchKey, LivePassBatch> entry : batches.entrySet()) {
            LivePassBatchKey key = entry.getKey();
            Set<String> includedBones = entry.getValue().includedBones();
            int passColor = key.color();
            float passRed = GeoRenderColor.red(passColor);
            float passGreen = GeoRenderColor.green(passColor);
            float passBlue = GeoRenderColor.blue(passColor);
            float passAlpha = GeoRenderColor.alpha(passColor);
            float[] shaderColor = RenderSystem.getShaderColor();
            float shaderRed = shaderColor[0];
            float shaderGreen = shaderColor[1];
            float shaderBlue = shaderColor[2];
            float shaderAlpha = shaderColor[3];
            Matrix4f previousTextureMatrix = AnimatedTextureSupport.pushTextureMatrix(key.texture());
            RenderSystem.setShaderColor(shaderRed * passRed, shaderGreen * passGreen, shaderBlue * passBlue, shaderAlpha * passAlpha);
            ChaosGpuRenderCapture currentCapture;
            try {
                currentCapture = renderWorldLitPass(
                        model,
                        poseStack,
                        lightPoseStack,
                        animatable,
                        animationState,
                        poseCacheKey,
                        useGpuLiveAnimation,
                        bufferSource,
                        key.renderLayer(),
                        key.texture(),
                        key.emissiveTexture(),
                        key.emissiveStrength(),
                        animatable.level(),
                        worldOrigin,
                        key.packedLight(),
                        packedOverlay,
                        includedBones,
                        red * passRed,
                        green * passGreen,
                        blue * passBlue,
                        alpha * passAlpha
                );
            } finally {
                AnimatedTextureSupport.popTextureMatrix(previousTextureMatrix);
                RenderSystem.setShaderColor(shaderRed, shaderGreen, shaderBlue, shaderAlpha);
            }
            if (trackedBoneCapture == null) {
                trackedBoneCapture = currentCapture;
            }

            if (includedBones == null) {
                renderedAllBones = true;
            } else {
                renderedBones.addAll(includedBones);
            }
        }

        this.dynamicRenderBones = renderedAllBones ? null : (renderedBones.isEmpty() ? Set.of() : Set.copyOf(renderedBones));
        this.dynamicSelectionAll = renderedAllBones;
        return trackedBoneCapture;
    }

    private void captureTrackedBonePositions(
            PoseStack poseStack,
            T animatable,
            BakedGeoModel model,
            @Nullable AnimationState<T> animationState,
            @Nullable Object poseCacheKey,
            @Nullable ChaosGpuRenderCapture renderCapture
    ) {
        if (!(animatable instanceof GeoBoneTrackingAnimatable trackedAnimatable)) {
            return;
        }

        if (trackedAnimatable.getTrackedBones().isEmpty()) {
            return;
        }

        TrackedBoneReadbackState readbackState = TRACKED_BONE_READBACK_STATE.computeIfAbsent(trackedAnimatable, ignored -> new TrackedBoneReadbackState());
        if (shouldCaptureTrackedBonesOnCpu(animatable, trackedAnimatable)
                && captureTrackedBonePositionsOnCpu(poseStack, animatable, model, animationState, trackedAnimatable, readbackState)) {
            return;
        }

        ChaosGpuRenderCapture trackingCapture = prepareTrackedBoneCapture(animatable, model, trackedAnimatable, animationState, poseCacheKey, renderCapture);
        float[] resolvedMatrices = null;
        if (trackedAnimatable.requiresGpuBoneTrackingReadback()
                && trackingCapture != null
                && trackingCapture.mesh() != null
                && trackingCapture.bonePoseData() != null) {
            if (shouldResolveTrackedBones(animatable, trackedAnimatable, trackingCapture.bonePoseData(), readbackState)) {
                resolvedMatrices = ChaosGpuBoneResolveDispatcher.resolveAndRead(trackingCapture.mesh(), trackingCapture.bonePoseData());
            }
        }
        if (resolvedMatrices != null) {
            Map<String, GeoTrackedBonePose> poses = GeoBoneTrackingHelper.collectResolvedEntityBonePoses(
                    trackingCapture.mesh().getIndexedBones(),
                    resolvedMatrices,
                    trackedAnimatable.getTrackedBones(),
                    poseStack.last().pose(),
                    this.entityRenderTranslations,
                    animatable
            );
            if (readbackState != null && !poses.isEmpty()) {
                readbackState.record(animatable.tickCount, trackingCapture.bonePoseData(), poses);
            }
            applyTrackedBonePoses(animatable, trackedAnimatable, poses);
            return;
        }

        if (readbackState.canReuse(animatable.tickCount, trackingCapture != null ? trackingCapture.bonePoseData() : null)) {
            applyTrackedBonePoses(animatable, trackedAnimatable, readbackState.cachedPoses());
            return;
        }

        if (animatable instanceof GeoMultipartEntity multipart) {
            GeoMultipartSyncHelper.sync(
                    (Entity & GeoMultipartEntity) multipart,
                    GeoBoneTrackingHelper.captureTrackedEntityBonePoses(
                            model.topLevelBones(),
                            trackedAnimatable.getTrackedBones(),
                            poseStack.last().pose(),
                            this.entityRenderTranslations,
                            this.modelRenderTranslations,
                            animatable
                    )
            );
            return;
        }

        GeoBoneTrackingHelper.captureTrackedEntityBoneMatrices(
                model.topLevelBones(),
                trackedAnimatable.getTrackedBones(),
                poseStack.last().pose(),
                this.entityRenderTranslations,
                this.modelRenderTranslations,
                animatable
        );
    }

    private boolean shouldCaptureTrackedBonesOnCpu(T animatable, GeoBoneTrackingAnimatable trackedAnimatable) {
        if (animatable instanceof GeoMultipartEntity) {
            return true;
        }

        if (!trackedAnimatable.requiresGpuBoneTrackingReadback()) {
            return true;
        }

        return false;
    }

    private boolean captureTrackedBonePositionsOnCpu(
            PoseStack poseStack,
            T animatable,
            BakedGeoModel model,
            @Nullable AnimationState<T> animationState,
            GeoBoneTrackingAnimatable trackedAnimatable,
            TrackedBoneReadbackState readbackState
    ) {
        if (animationState == null) {
            return false;
        }

        Map<String, GeoTrackedBonePose> poses = GeoBoneTrackingHelper.captureTrackedEntityBonePoses(
                model.topLevelBones(),
                trackedAnimatable.getTrackedBones(),
                poseStack.last().pose(),
                this.entityRenderTranslations,
                this.modelRenderTranslations,
                animatable
        );
        if (poses.isEmpty()) {
            return false;
        }

        applyTrackedBonePoses(animatable, trackedAnimatable, poses);
        return true;
    }

    private void applyTrackedBonePoses(T animatable, GeoBoneTrackingAnimatable trackedAnimatable, Map<String, GeoTrackedBonePose> poses) {
        if (animatable instanceof GeoMultipartEntity multipart) {
            GeoMultipartSyncHelper.sync((Entity & GeoMultipartEntity) multipart, poses);
            return;
        }

        trackedAnimatable.receiveTrackedBonePoses(poses);
    }

    private boolean shouldResolveTrackedBones(T animatable, GeoBoneTrackingAnimatable trackedAnimatable, Object bonePoseData, TrackedBoneReadbackState state) {
        if (state.wasResolvedThisTick(animatable.tickCount)) {
            return false;
        }
        if (animatable instanceof GeoMultipartEntity && Minecraft.getInstance().getEntityRenderDispatcher().shouldRenderHitBoxes()) {
            return true;
        }
        int intervalTicks = Math.max(1, trackedAnimatable.getGpuBoneTrackingReadbackIntervalTicks());
        return !state.canReuse(animatable.tickCount, bonePoseData) || animatable.tickCount - state.lastResolvedAge() >= intervalTicks;
    }

    private static final class TrackedBoneReadbackState {
        private int lastResolvedAge = Integer.MIN_VALUE;
        private Object lastPoseData;
        private Map<String, GeoTrackedBonePose> cachedPoses = Map.of();

        private boolean canReuse(int currentAge, @Nullable Object poseData) {
            return this.lastResolvedAge != Integer.MIN_VALUE
                    && currentAge - this.lastResolvedAge >= 0
                    && !this.cachedPoses.isEmpty()
                    && (currentAge == this.lastResolvedAge || Objects.equals(this.lastPoseData, poseData));
        }

        private boolean wasResolvedThisTick(int currentAge) {
            return this.lastResolvedAge != Integer.MIN_VALUE
                    && currentAge == this.lastResolvedAge
                    && !this.cachedPoses.isEmpty();
        }

        private int lastResolvedAge() {
            return this.lastResolvedAge;
        }

        private Map<String, GeoTrackedBonePose> cachedPoses() {
            return this.cachedPoses;
        }

        private void record(int age, Object poseData, Map<String, GeoTrackedBonePose> poses) {
            this.lastResolvedAge = age;
            this.lastPoseData = poseData;
            this.cachedPoses = Map.copyOf(poses);
        }
    }

    private PoseStack createEntityLightPoseStack(T animatable, float entityYaw, float partialTick) {
        PoseStack lightPoseStack = new PoseStack();
        rotateEntity(animatable, entityYaw, partialTick, lightPoseStack);
        lightPoseStack.mulPose(this.model.getRenderPolicy().getEntityRootTransform(animatable));
        return lightPoseStack;
    }

    private Vec3 resolveEntityWorldOrigin(T animatable, float partialTick) {
        return new Vec3(
                Mth.lerp(partialTick, animatable.xo, animatable.getX()),
                Mth.lerp(partialTick, animatable.yo, animatable.getY()),
                Mth.lerp(partialTick, animatable.zo, animatable.getZ())
        );
    }

    private EntityAnimationPreparationDecision determineEntityAnimationPreparation(T animatable, BakedGeoModel model) {
        ChaosGpuGeoMesh mesh = ChaosGpuGeoMesh.getOrCreate(model);
        GeoModel.GpuLiveRenderAnimationSupport gpuLiveSupport = this.model.getGpuLiveRenderAnimationSupport(animatable, mesh);
        if (this.model.requiresCpuPoseSampling(animatable, mesh)) {
            return recordEntityDecision(animatable, EntityAnimationPreparationPath.CPU, false, false, gpuLiveSupportReason(gpuLiveSupport));
        }

        if (gpuLiveSupport.hasNoLiveAnimationWork()) {
            return recordEntityDecision(animatable, EntityAnimationPreparationPath.NONE, true, false, "no_animation");
        }
        if (!model.properties().gpuPipeline()) {
            return recordEntityDecision(animatable, EntityAnimationPreparationPath.CPU, false, false, "model_gpu_pipeline_disabled");
        }
        if (!ChaosGpuRenderRuntime.isGpuPathSupported(model)) {
            return recordEntityDecision(animatable, EntityAnimationPreparationPath.CPU, false, false, "gpu_backend_unavailable");
        }
        if (!gpuLiveSupport.isGpuLiveCapable()) {
            return recordEntityDecision(animatable, EntityAnimationPreparationPath.CPU, true, false, gpuLiveSupportReason(gpuLiveSupport));
        }

        return recordEntityDecision(animatable, EntityAnimationPreparationPath.GPU_LIVE, true, true, "gpu_animation");
    }

    private EntityAnimationPreparationDecision recordEntityDecision(T animatable, EntityAnimationPreparationPath path, boolean gpuPathSupported, boolean gpuLiveCapable, String reasonKey) {
        ChaosSodiumDebugOverlay.recordEntityDecision(animatable, path.name(), gpuPathSupported, gpuLiveCapable, reasonKey);
        return new EntityAnimationPreparationDecision(path);
    }

    private String gpuLiveSupportReason(GeoModel.GpuLiveRenderAnimationSupport gpuLiveSupport) {
        return switch (gpuLiveSupport) {
            case CUSTOM_CPU_POSE -> "custom_cpu_pose";
            case ANIMATION_RESOURCE_REQUIRES_CPU -> "animation_requires_cpu";
            case NO_ANIMATION_DATA_AND_NO_GPU_PROCEDURAL -> "no_animation";
            case GPU_PROCEDURAL_ONLY, GPU_LIVE_SAFE -> "gpu_animation";
        };
    }

    private ChaosGpuRenderCapture renderWorldLitPass(
            BakedGeoModel model,
            PoseStack poseStack,
            PoseStack lightPoseStack,
            T animatable,
            @Nullable AnimationState<T> animationState,
            @Nullable Object poseCacheKey,
            boolean useGpuLiveAnimation,
            MultiBufferSource bufferSource,
            RenderType renderLayer,
            ResourceLocation texture,
            @Nullable ResourceLocation emissiveTexture,
            float emissiveStrength,
            net.minecraft.world.level.BlockAndTintGetter world,
            Vec3 worldOrigin,
            int packedLight,
            int packedOverlay,
            Set<String> includedBones,
            float red,
            float green,
            float blue,
            float alpha
    ) {
        if (useGpuLiveAnimation && animationState != null && poseCacheKey != null) {
            if (ChaosGpuRenderRuntime.isShaderPackPipelineActive()) {
                return ChaosGpuShaderPackRenderer.renderCapture(
                        poseStack,
                        animatable,
                        this.model,
                        animationState,
                        texture,
                        emissiveTexture,
                        model,
                        packedLight,
                        null,
                        includedBones,
                        emissiveTexture != null && emissiveStrength > 0.0f ? null : Set.of(),
                        emissiveStrength,
                        packedOverlay,
                        renderLayer,
                        emissiveTexture != null && emissiveStrength > 0.0f ? renderLayer : null,
                        ChaosShaderRenderPhase.ENTITIES,
                        poseCacheKey
                );
            }

            return ChaosGpuGeoRenderer.renderCapture(
                    poseStack,
                    animatable,
                    this.model,
                    animationState,
                    bufferSource,
                    renderLayer,
                    texture,
                    emissiveTexture,
                    model,
                    packedLight,
                    null,
                    includedBones,
                    emissiveTexture != null && emissiveStrength > 0.0f ? null : Set.of(),
                    emissiveStrength,
                    poseCacheKey
            );
        }

        if (!ChaosGpuRenderRuntime.isGpuPathSupported(model)) {
            return null;
        }

        ChaosGpuGeoMesh mesh = ChaosGpuGeoMesh.getOrCreate(model, includedBones, includedBones != null && !includedBones.isEmpty() && AnimatedTextureSupport.requiresUvNormalization(texture));
        if (mesh.getInstancedVertexCount() <= 0) {
            return ChaosGpuRenderCapture.empty(includedBones);
        }

        int[] boneLightData = resolveBoneLightData(animatable, mesh, null, lightPoseStack.last().pose(), packedLight);
        Object animatedPoseCacheKey = animationState != null
                ? this.model.createAnimatedPoseCacheKey(animatable, animationState)
                : (poseCacheKey != null ? poseCacheKey : animatable.getPoseKey());
        return ChaosGpuGeoRenderer.renderCapture(
                poseStack,
                renderLayer,
                texture,
                emissiveTexture,
                model,
                mesh,
                packedLight,
                boneLightData,
                ChaosGpuPoseDataCache.prepareBonePoseData(animatedPoseCacheKey, model, mesh),
                includedBones,
                emissiveTexture != null && emissiveStrength > 0.0f ? null : Set.of(),
                emissiveStrength
        );
    }

    private ChaosGpuRenderCapture prepareTrackedBoneCapture(
            T animatable,
            BakedGeoModel model,
            GeoBoneTrackingAnimatable trackedAnimatable,
            @Nullable AnimationState<T> animationState,
            @Nullable Object poseCacheKey,
            @Nullable ChaosGpuRenderCapture renderCapture
    ) {
        if (renderCapture != null && renderCapture.canResolve(trackedAnimatable.getTrackedBones())) {
            return renderCapture;
        }
        if (animationState == null || poseCacheKey == null || !ChaosGpuRenderRuntime.isGpuPathSupported(model)) {
            return null;
        }

        ChaosGpuGeoMesh trackingMesh = ChaosGpuGeoMesh.getOrCreate(model);
        if (this.model.requiresCpuPoseSampling(animatable, trackingMesh)) {
            return null;
        }

        Object trackingPoseData = this.model.prepareGpuBonePoseData(animatable, trackingMesh, animationState, poseCacheKey);
        return new ChaosGpuRenderCapture(trackingMesh, trackingPoseData, null);
    }

    protected int[] resolveBoneLightData(T animatable, ChaosGpuGeoMesh mesh, Object bonePoseData, Matrix4f rootTransform, int fallbackLight) {
        if (fallbackLight == LightTexture.FULL_BRIGHT) {
            return ChaosGpuBoneLightSampler.fullBright(mesh.getIndexedBones().size());
        }

        if (animatable.level() == null) {
            return null;
        }

        BlockPos.MutableBlockPos samplePos = new BlockPos.MutableBlockPos();
        return ChaosGpuBoneLightSampler.sampleEntityBoneLights(
                mesh,
                bonePoseData,
                rootTransform,
                this.entityRenderTranslations,
                animatable.getX(),
                animatable.getY(),
                animatable.getZ(),
                fallbackLight,
                (worldX, worldY, worldZ) -> {
                    samplePos.set(Mth.floor(worldX), Mth.floor(worldY), Mth.floor(worldZ));
                    return LightTexture.pack(getBlockLightLevel(animatable, samplePos), getSkyLightLevel(animatable, samplePos));
                }
        );
    }

    private record LivePassBatchKey(RenderType renderLayer, ResourceLocation texture,
                                    @Nullable ResourceLocation emissiveTexture, int packedLight, int color,
                                    float emissiveStrength) {
    }

    private static final class LivePassBatch {
        private Set<String> includedBones;

        private LivePassBatch(Set<String> includedBones) {
            this.includedBones = includedBones == null ? null : new LinkedHashSet<>(includedBones);
        }

        private void include(Set<String> includedBones) {
            if (this.includedBones == null || includedBones == null) {
                this.includedBones = null;
                return;
            }

            if (!includedBones.isEmpty()) {
                this.includedBones.addAll(includedBones);
            }
        }

        private Set<String> includedBones() {
            return this.includedBones;
        }
    }

    private enum EntityAnimationPreparationPath {
        NONE,
        CPU,
        GPU_LIVE
    }

    private record EntityAnimationPreparationDecision(EntityAnimationPreparationPath path) {
    }
}
