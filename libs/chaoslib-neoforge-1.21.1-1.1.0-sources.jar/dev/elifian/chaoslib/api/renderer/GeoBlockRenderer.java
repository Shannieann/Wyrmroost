package dev.elifian.chaoslib.api.renderer;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import dev.elifian.chaoslib.animatable.state.GeoRenderStateAccess;
import dev.elifian.chaoslib.animatable.state.GeoRenderStateTracker;
import dev.elifian.chaoslib.api.animatable.GeoBlockEntity;
import dev.elifian.chaoslib.api.animatable.GeoBoneTrackingAnimatable;
import dev.elifian.chaoslib.api.animation.AnimationState;
import dev.elifian.chaoslib.api.model.GeoModel;
import dev.elifian.chaoslib.api.model.render.GeoRenderColor;
import dev.elifian.chaoslib.api.model.render.GeoRenderPass;
import dev.elifian.chaoslib.cache.object.BakedGeoModel;
import dev.elifian.chaoslib.cache.object.GeoBone;
import dev.elifian.chaoslib.client.animation.GeoBoneTrackingHelper;
import dev.elifian.chaoslib.client.texture.AnimatedTextureSupport;
import dev.elifian.chaoslib.compat.iris.IrisCompatInternal;
import dev.elifian.chaoslib.compat.sodium.ChaosSodiumBlockEntitySettings;
import dev.elifian.chaoslib.compat.sodium.ChaosSodiumDebugOverlay;
import dev.elifian.chaoslib.compat.sodium.ChaosSodiumGpuSkinningMode;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuAnimationPoseStorage;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuBoneResolveDispatcher;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuRuntimePolicy;
import dev.elifian.chaoslib.gpu.mesh.ChaosGpuGeoMesh;
import dev.elifian.chaoslib.gpu.render.*;
import dev.elifian.chaoslib.model.AnimatedBoneSelection;
import dev.elifian.chaoslib.model.GeoBlockRenderMode;
import dev.elifian.chaoslib.model.baked.StaticGeoRenderMode;
import dev.elifian.chaoslib.platform.ClientOnly;
import dev.elifian.chaoslib.platform.Services;
import dev.elifian.chaoslib.platform.render.GeoFrozenRenderSupport;
import dev.elifian.chaoslib.util.RenderUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockAndTintGetter;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

import java.util.*;
import java.util.function.Consumer;

@ClientOnly
/**
 * Default block-entity renderer for {@link GeoBlockEntity} implementations backed by a
 * {@link GeoModel}.
 *
 * <p>This renderer coordinates live animation playback, static baked rendering, emissive passes,
 * tracked bone export, and GPU backend selection for block entities implementing
 * {@link GeoBlockEntity}. Extend it when a block entity needs custom transforms or additional
 * render-time hooks on top of the default ChaosLib block pipeline.</p>
 *
 * @param <T> block entity type rendered by this renderer
 */
public class GeoBlockRenderer<T extends BlockEntity & GeoBlockEntity> implements BlockEntityRenderer<T> {
    private static final float ANIMATION_EPSILON = 1.0e-4f;
    private static final int MAX_ENCLOSED_CULL_SHELL_BLOCKS = 64;
    protected final GeoModel<T> model;
    protected T animatable;
    protected Set<String> dynamicRenderBones;
    protected Set<String> emissiveRenderBones;
    protected Matrix4f blockRenderTranslations = new Matrix4f();
    protected Matrix4f modelRenderTranslations = new Matrix4f();
    private final LinkedHashMap<LivePassBatchKey, LivePassBatch> reusableLivePassBatches = new LinkedHashMap<>();
    private AnimationState<T> reusableAnimationState;
    private final GeoFrozenRenderSupport<T> frozenRenderHelper = Services.STATIC_MODELS.createFrozenRenderSupport();
    private BakedGeoModel currentRenderModel;
    private final Map<BakedGeoModel, Set<String>> autoAnimatedBoneCache = new WeakHashMap<>();
    private final Map<BlockState, Boolean> visibleBlockRenderTypeCache = new WeakHashMap<>();
    private Boolean staticResourceFallback;
    private BlockState lastInvisibleRenderTypeState;
    private boolean lastInvisibleRenderTypeValue;
    private Double cachedExtendedRenderDistance;

    /**
     * Creates a renderer backed by the supplied geo model.
     */
    public GeoBlockRenderer(GeoModel<T> model) {
        this.model = model;
    }

    /**
     * Returns the geo model used by this renderer.
     */
    public GeoModel<T> getGeoModel() {
        return this.model;
    }

    /**
     * Returns the stable render-instance id used for animation caching.
     */
    public long getInstanceId(T animatable) {
        long identity = (long) System.identityHashCode(animatable) & 0xFFFFFFFFL;
        return (identity << 32) ^ animatable.getBlockPos().hashCode();
    }

    /**
     * Returns a reusable {@link AnimationState} for the current block entity render, avoiding a fresh
     * allocation per visible block entity each frame. Safe because block-entity rendering runs on the
     * render thread one entity at a time and the live and frozen render paths never nest, and the state is
     * only read transiently during the render call.
     */
    private AnimationState<T> acquireAnimationState(T animatable, float partialTick) {
        AnimationState<T> state = this.reusableAnimationState;
        if (state == null) {
            state = new AnimationState<>(animatable, partialTick);
            this.reusableAnimationState = state;
            return state;
        }
        state.reset(animatable, partialTick);
        return state;
    }

    /**
     * Resolves the primary texture used for rendering the given block entity.
     */
    public ResourceLocation getTextureLocation(T animatable) {
        return this.model.getResourceSet().getTextureResource(animatable);
    }

    /**
     * Resolves the render layer used for the primary pass of the given block entity.
     */
    protected RenderType getRenderType(T animatable, ResourceLocation texture) {
        return IrisCompatInternal.wrapBlockEntityRenderLayer(this.model.getRenderPolicy().getRenderType(animatable, texture));
    }

    /**
     * Returns whether the block entity dispatcher can skip this instance before any BER culling or
     * render work. Used by ChaosLib's dispatcher mixin for fully static block entities.
     */
    @SuppressWarnings("unchecked")
    public final boolean shouldSkipBlockEntityDispatch(BlockEntity blockEntity) {
        try {
            return isStaticOnly((T) blockEntity);
        } catch (ClassCastException exception) {
            return false;
        }
    }

    /**
     * Returns whether ChaosLib should dispatch this renderer directly instead of letting Minecraft's
     * block entity dispatcher call it. Override only for renderers that depend on a third-party BER
     * wrapper and must stay on the vanilla path.
     */
    @SuppressWarnings("unchecked")
    public final boolean shouldUseChaosBlockEntityDispatch(BlockEntity blockEntity) {
        try {
            return shouldUseChaosBlockEntityDispatchFor((T) blockEntity);
        } catch (ClassCastException exception) {
            return false;
        }
    }

    protected boolean shouldUseChaosBlockEntityDispatchFor(T animatable) {
        return true;
    }

    /**
     * Returns whether the given block entity should still be rendered from the supplied camera
     * position.
     */
    @Override
    public boolean shouldRender(T animatable, Vec3 cameraPos) {
        if (isStaticOnly(animatable)) {
            validateStaticOnlyConfiguration(animatable);
            return false;
        }

        double centerX = animatable.getBlockPos().getX() + 0.5d;
        double centerY = animatable.getBlockPos().getY() + 0.5d;
        double centerZ = animatable.getBlockPos().getZ() + 0.5d;
        double dx = centerX - cameraPos.x;
        double dy = centerY - cameraPos.y;
        double dz = centerZ - cameraPos.z;
        double distanceSquared = dx * dx + dy * dy + dz * dz;

        if (updateModelDataOnlyState(animatable, distanceSquared)) {
            return false;
        }

        if (!shouldRunRenderer(animatable)) {
            return false;
        }

        double renderDistance = resolveRenderDistance(animatable);
        return distanceSquared < renderDistance * renderDistance;
    }

    /**
     * Renders the given block entity through ChaosLib's live/static rendering pipeline.
     */
    @Override
    public void render(T animatable, float partialTick, PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, int packedOverlay) {
        if (animatable == null) {
            throw new IllegalStateException("GeoBlockRenderer requires BlockEntity instances to implement GeoBlockEntity");
        }

        validateVisibleBlockRenderType(animatable);
        if (isStaticOnly(animatable)) {
            validateStaticOnlyConfiguration(animatable);
            return;
        }

        if (shouldSkipEnclosedRender(animatable)) {
            return;
        }

        if (shouldSkipForeignContextGpuRender(animatable)) {
            return;
        }

        this.animatable = animatable;
        this.renderThroughPipeline(partialTick, poseStack, bufferSource, packedLight, packedOverlay);
        this.dynamicRenderBones = null;
        this.emissiveRenderBones = null;
        this.currentRenderModel = null;
        this.animatable = null;
    }

    public void renderThroughPipeline(float partialTick, PoseStack poseStack, MultiBufferSource bufferSource, int packedLight, int packedOverlay) {
        int renderLight = resolveRenderLight(animatable, packedLight);
        boolean shouldRenderLiveModel = shouldRenderLiveModel(animatable);
        if (shouldRenderLiveModel) {
            if (this.frozenRenderHelper.shouldRenderFrozen(this, animatable)) {
                if (!this.frozenRenderHelper.renderFrozen(this, poseStack, animatable, bufferSource, partialTick, renderLight, packedOverlay)) {
                    defaultRender(poseStack, animatable, bufferSource, partialTick, renderLight, packedOverlay);
                    renderAdditions(poseStack, animatable, bufferSource, partialTick, renderLight, packedOverlay, false);
                }
            } else {
                this.frozenRenderHelper.onReturnToLive(animatable);
                defaultRender(poseStack, animatable, bufferSource, partialTick, renderLight, packedOverlay);
                renderAdditions(poseStack, animatable, bufferSource, partialTick, renderLight, packedOverlay, false);
            }
        } else {
            this.frozenRenderHelper.clear(animatable);
            if (hasStaticAdditionsToRender(animatable)) {
                renderStaticAdditionsOnly(poseStack, animatable, bufferSource, partialTick, renderLight, packedOverlay);
            }
        }

        this.dynamicRenderBones = null;
        this.emissiveRenderBones = null;
        this.currentRenderModel = null;
        this.animatable = null;
    }

    /**
     * Returns the box this renderer draws within. On NeoForge this also overrides the loader's own
     * hook, so both platforms cull the block entity against the same box.
     */
    public AABB getRenderBoundingBox(T animatable) {
        return new AABB(animatable.getBlockPos());
    }

    /**
     * Returns whether rendering should be skipped because the block entity is fully enclosed.
     */
    protected boolean shouldSkipEnclosedRender(T animatable) {
        if (!this.model.useEnclosedVisibilityCulling()) {
            return false;
        }

        if (Minecraft.getInstance().player != null && Minecraft.getInstance().player.isSpectator()) {
            return false;
        }

        if (animatable.getLevel() == null) {
            return false;
        }

        BlockState state = animatable.getBlockState();
        BlockPos pos = animatable.getBlockPos();
        GeoRenderStateAccess access = (GeoRenderStateAccess) animatable;
        BlockPos cachedPos = access.getGeoEnclosedCullPos();
        if (access.getGeoEnclosedCullState() == state
                && cachedPos != null
                && cachedPos.equals(pos)) {
            return access.getGeoEnclosedCullValue();
        }

        boolean enclosed = isFullyEnclosed(animatable.getLevel(), this.getRenderBoundingBox(animatable));
        access.setGeoEnclosedCullPos(pos.immutable());
        access.setGeoEnclosedCullState(state);
        access.setGeoEnclosedCullValue(enclosed);
        return enclosed;
    }

    /**
     * Whether the animated GPU pass must be skipped because we are rendering outside ChaosLib's own
     * world render pass.
     *
     * <p>The block-entity pass issues an immediate, raw-GL draw with a custom shader and its own GL
     * state. That is only safe inside the world render, where ChaosLib controls the surrounding draws.
     * When a foreign immediate-mode context renders the BER instead - GuideME's in-world guidebook
     * scene, or any GUI block preview - the leftover GL state corrupts that context's own buffer flush;
     * AMD/ATI drivers then NULL-deref in {@code glDrawElements} ({@code atio6axx.dll}) while other
     * vendors tolerate it. A foreign context is detected by the block entity's level differing from the
     * client level (GuideME builds its scene in a separate {@code GuidebookLevel}).</p>
     *
     * <p>Gated by the same {@link ChaosGpuRuntimePolicy#shouldUseAmdSafeBackend() AMD safety policy} as
     * the rest of the GPU backend, so only affected adapters change behavior ({@code FORCE_DEFAULT}
     * and non-AMD GPUs keep the animated render everywhere). When skipped, the block's static model
     * still renders normally through the block dispatcher, so the block stays visible - just without
     * the animated overlay - instead of crashing.</p>
     */
    private boolean shouldSkipForeignContextGpuRender(T animatable) {
        if (!ChaosGpuRuntimePolicy.shouldUseAmdSafeBackend()) {
            return false;
        }
        net.minecraft.world.level.Level world = animatable.getLevel();
        return world != null && world != Minecraft.getInstance().level;
    }

    private boolean isFullyEnclosed(BlockAndTintGetter world, AABB box) {
        int minX = Mth.floor(box.minX + ANIMATION_EPSILON);
        int minY = Mth.floor(box.minY + ANIMATION_EPSILON);
        int minZ = Mth.floor(box.minZ + ANIMATION_EPSILON);
        int maxX = Mth.floor(box.maxX - ANIMATION_EPSILON);
        int maxY = Mth.floor(box.maxY - ANIMATION_EPSILON);
        int maxZ = Mth.floor(box.maxZ - ANIMATION_EPSILON);

        int sizeX = maxX - minX + 1;
        int sizeY = maxY - minY + 1;
        int sizeZ = maxZ - minZ + 1;
        if (sizeX <= 0 || sizeY <= 0 || sizeZ <= 0) {
            return false;
        }

        int shellBlocks = 2 * (sizeX * sizeY + sizeX * sizeZ + sizeY * sizeZ);
        if (shellBlocks > MAX_ENCLOSED_CULL_SHELL_BLOCKS) {
            return false;
        }

        BlockPos.MutableBlockPos mutablePos = new BlockPos.MutableBlockPos();
        return isFaceClosed(world, mutablePos, minX - 1, minY, maxY, minZ, maxZ, AxisPlane.YZ)
                && isFaceClosed(world, mutablePos, maxX + 1, minY, maxY, minZ, maxZ, AxisPlane.YZ)
                && isFaceClosed(world, mutablePos, minY - 1, minX, maxX, minZ, maxZ, AxisPlane.XZ)
                && isFaceClosed(world, mutablePos, maxY + 1, minX, maxX, minZ, maxZ, AxisPlane.XZ)
                && isFaceClosed(world, mutablePos, minZ - 1, minX, maxX, minY, maxY, AxisPlane.XY)
                && isFaceClosed(world, mutablePos, maxZ + 1, minX, maxX, minY, maxY, AxisPlane.XY);
    }

    private boolean isFaceClosed(BlockAndTintGetter world, BlockPos.MutableBlockPos mutablePos, int fixed, int minA, int maxA, int minB, int maxB, AxisPlane plane) {
        for (int a = minA; a <= maxA; a++) {
            for (int b = minB; b <= maxB; b++) {
                switch (plane) {
                    case XY -> mutablePos.set(a, b, fixed);
                    case XZ -> mutablePos.set(a, fixed, b);
                    case YZ -> mutablePos.set(fixed, a, b);
                }

                if (!world.getBlockState(mutablePos).isSolidRender(world, mutablePos)) {
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * Performs the default live render path for the given block entity.
     */
    protected void defaultRender(PoseStack poseStack, T animatable, MultiBufferSource bufferSource, float partialTick, int packedLight, int packedOverlay) {
        poseStack.pushPose();
        BakedGeoModel bakedModel = this.model.getBakedModel(this.model.getResourceSet().getModelResource(animatable));
        this.currentRenderModel = bakedModel;
        ResourceLocation texture = getTextureLocation(animatable);

        preRender(poseStack, animatable, bakedModel, bufferSource, null, false, partialTick, packedLight, packedOverlay, 1.0f, 1.0f, 1.0f, 1.0f);
        actuallyRender(poseStack, animatable, bakedModel, null, bufferSource, null, false, partialTick, packedLight, packedOverlay, 1.0f, 1.0f, 1.0f, 1.0f, texture);
        postRender(poseStack, animatable, bakedModel, bufferSource, null, false, partialTick, packedLight, packedOverlay, 1.0f, 1.0f, 1.0f, 1.0f);
        poseStack.popPose();
    }

    /**
     * Renders custom additions that should appear only while the frozen render path is active.
     */
    protected void renderFrozenAdditions(PoseStack poseStack, T animatable, MultiBufferSource bufferSource, float partialTick, int packedLight, int packedOverlay) {
    }

    /**
     * Renders custom additions associated with the current model data state.
     */
    protected void renderModelDataAdditions(PoseStack poseStack, T animatable, MultiBufferSource bufferSource, float partialTick, int packedLight, int packedOverlay, boolean frozen) {
        if (frozen) {
            renderFrozenAdditions(poseStack, animatable, bufferSource, partialTick, packedLight, packedOverlay);
        }
    }

    /**
     * Returns whether this renderer exposes additions beyond the geo model mesh itself.
     */
    protected boolean hasStaticAdditionsToRender(T animatable) {
        return true;
    }

    /**
     * Renders only the custom additions path when the main model is handled statically elsewhere.
     */
    protected void renderStaticAdditionsOnly(PoseStack poseStack, T animatable, MultiBufferSource bufferSource, float partialTick, int packedLight, int packedOverlay) {
        this.currentRenderModel = this.model.getBakedModel(this.model.getModelResource(animatable));
        renderAdditions(poseStack, animatable, bufferSource, partialTick, packedLight, packedOverlay, false);
    }

    /**
     * Renders a fixed-display item at the current block-entity location.
     */
    protected final void renderFixedDisplayItem(PoseStack poseStack, MultiBufferSource bufferSource, BlockEntity blockEntity, ItemStack stack, float x, float y, float z, float scale, int packedLight, int packedOverlay) {
        if (stack.isEmpty()) {
            return;
        }

        ItemRenderer itemRenderer = Minecraft.getInstance().getItemRenderer();
        poseStack.pushPose();
        poseStack.translate(x, y, z);
        poseStack.scale(scale, scale, scale);
        itemRenderer.renderStatic(stack, ItemDisplayContext.FIXED, packedLight, packedOverlay, poseStack, bufferSource, blockEntity.getLevel(), 0);
        poseStack.popPose();
    }

    /**
     * Invokes a renderer callback with the transform of the named bone applied.
     */
    protected final void renderForBone(PoseStack poseStack, String boneName, Consumer<GeoBone> renderer) {
        if (renderer == null) {
            return;
        }

        getCurrentRenderBone(boneName).ifPresent(bone -> {
            poseStack.pushPose();
            applyBoneTransform(poseStack, bone);
            renderer.accept(bone);
            poseStack.popPose();
        });
    }

    /**
     * Returns the currently active render bone with the given name.
     */
    protected final Optional<GeoBone> getCurrentRenderBone(String boneName) {
        if (boneName == null || this.currentRenderModel == null) {
            return Optional.empty();
        }

        return this.currentRenderModel.getBone(boneName);
    }

    private void renderAdditions(PoseStack poseStack, T animatable, MultiBufferSource bufferSource, float partialTick, int packedLight, int packedOverlay, boolean frozen) {
        poseStack.pushPose();
        applyBlockEntityRenderTransform(poseStack, animatable);
        renderModelDataAdditions(poseStack, animatable, bufferSource, partialTick, packedLight, packedOverlay, frozen);
        poseStack.popPose();
    }

    private void applyBoneTransform(PoseStack poseStack, GeoBone bone) {
        if (bone.getParent() != null) {
            applyBoneTransform(poseStack, bone.getParent());
        }

        RenderUtils.prepMatrixForBone(poseStack, bone);
    }

    private Set<String> resolveDynamicBones(BakedGeoModel model, AnimatedBoneSelection selection) {
        if (this.model.getStaticRenderModeSelector().select(this.animatable.getBlockState()) == StaticGeoRenderMode.NONE) {
            return null;
        }

        if (selection.isNone()) {
            return Set.of();
        }

        if (selection.isAuto()) {
            Set<String> autoBones = autoDetectAnimatedBones(model);
            return autoBones.isEmpty() ? Set.of() : autoBones;
        }

        Set<String> resolved = selection.resolve(model);
        if (!resolved.isEmpty() || selection.isAll()) {
            return resolved.isEmpty() ? null : resolved;
        }

        return Set.of();
    }

    public Set<String> resolveDynamicRenderBones(T animatable, BakedGeoModel model) {
        this.animatable = animatable;
        try {
            return resolveDynamicBones(model, this.model.getLiveRenderBones(animatable));
        } finally {
            this.animatable = null;
        }
    }

    public Set<String> resolveFrozenLiveRenderBones(T animatable, BakedGeoModel model) {
        this.animatable = animatable;
        try {
            return resolveDynamicBones(model, this.model.getFrozenRenderBones(animatable));
        } finally {
            this.animatable = null;
        }
    }

    public Set<String> resolveFrozenEmissiveBones(T animatable, BakedGeoModel model, Set<String> dynamicBones) {
        return this.model.getResolvedEmissiveBones(animatable, model, dynamicBones);
    }

    private Set<String> autoDetectAnimatedBones(BakedGeoModel model) {
        Set<String> cached = this.autoAnimatedBoneCache.get(model);
        if (cached != null) {
            return cached;
        }

        Set<String> result = new HashSet<>();
        for (GeoBone bone : model.orderedBones()) {
            if (isBoneAnimated(bone)) {
                result.add(bone.getName());
            }
        }

        Set<String> resolved = result.isEmpty() ? Set.of() : Set.copyOf(result);
        this.autoAnimatedBoneCache.put(model, resolved);
        return resolved;
    }

    private boolean isBoneAnimated(GeoBone bone) {
        return differs(bone.getPosX(), 0.0f)
                || differs(bone.getPosY(), 0.0f)
                || differs(bone.getPosZ(), 0.0f)
                || differs(bone.getScaleX(), 1.0f)
                || differs(bone.getScaleY(), 1.0f)
                || differs(bone.getScaleZ(), 1.0f)
                || differs(bone.getPivotX(), bone.getInitialPivotX())
                || differs(bone.getPivotY(), bone.getInitialPivotY())
                || differs(bone.getPivotZ(), bone.getInitialPivotZ())
                || differs(bone.getRotX(), bone.getInitialRotX())
                || differs(bone.getRotY(), bone.getInitialRotY())
                || differs(bone.getRotZ(), bone.getInitialRotZ())
                || bone.isHidden()
                || bone.isHidingChildren();
    }

    private boolean differs(float a, float b) {
        return Math.abs(a - b) > ANIMATION_EPSILON;
    }

    /**
     * Hook invoked before the main recursive geo render starts.
     */
    public void preRender(PoseStack poseStack, T animatable, BakedGeoModel model, MultiBufferSource bufferSource, VertexConsumer buffer, boolean isReRender, float partialTick, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        this.blockRenderTranslations.set(poseStack.last().pose());
    }

    /**
     * Hook invoked after the main recursive geo render completes.
     */
    public void postRender(PoseStack poseStack, T animatable, BakedGeoModel model, MultiBufferSource bufferSource, VertexConsumer buffer, boolean isReRender, float partialTick, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
    }

    /**
     * Renders the baked model using the animatable's default texture.
     */
    public void actuallyRender(PoseStack poseStack, T animatable, BakedGeoModel model, RenderType renderType, MultiBufferSource bufferSource, VertexConsumer buffer, boolean isReRender, float partialTick, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
        actuallyRender(poseStack, animatable, model, renderType, bufferSource, buffer, isReRender, partialTick, packedLight, packedOverlay, red, green, blue, alpha, getTextureLocation(animatable));
    }

    /**
     * Renders the baked model using the supplied texture resource.
     */
    public void actuallyRender(PoseStack poseStack, T animatable, BakedGeoModel model, RenderType renderType, MultiBufferSource bufferSource, VertexConsumer buffer, boolean isReRender, float partialTick, int packedLight, int packedOverlay, float red, float green, float blue, float alpha, ResourceLocation texture) {
        Object poseCacheKey = animatable.getPoseKey();
        AnimationState<T> animationState = acquireAnimationState(animatable, partialTick);
        if (!isReRender) {
            applyBlockEntityRenderTransform(poseStack, animatable);
            BerAnimationPreparationDecision decision = determineBerAnimationPreparation(animatable, model);
            if (decision.path() == BerAnimationPreparationPath.GPU_LIVE) {
                this.model.prepareLiveRenderAnimations(animatable, getInstanceId(animatable), animationState);
            } else if (decision.path() == BerAnimationPreparationPath.CPU) {
                this.model.prepareCpuRenderAnimations(animatable, getInstanceId(animatable), animationState);
                this.frozenRenderHelper.applyThawTransitionIfActive(this, animatable, partialTick);
            }
        }

        this.modelRenderTranslations.set(poseStack.last().pose());
        AnimatedBoneSelection dynamicSelection = this.model.getLiveRenderBones(animatable);
        this.dynamicRenderBones = resolveDynamicBones(model, dynamicSelection);
        if (this.dynamicRenderBones != null) {
            Set<String> splitBones = this.model.getDynamicStaticSplitBones(model);
            this.dynamicRenderBones = mergeDynamicBones(this.dynamicRenderBones, splitBones);
        }
        PoseStack lightPoseStack = createBlockLightPoseStack(animatable);
        Vec3 worldOrigin = Vec3.atLowerCornerOf(animatable.getBlockPos());
        if (this.model.usesCustomRenderPasses()) {
            renderCustomPasses(poseStack, lightPoseStack, worldOrigin, animatable, model, animationState, poseCacheKey, bufferSource, packedLight, packedOverlay, partialTick, red, green, blue, alpha);
            captureTrackedBonePositions(poseStack, animatable, model, null, null);
            return;
        }
        ResourceLocation emissiveTexture = resolveEmissiveTexture(animatable);
        Set<String> emissiveBones = this.emissiveRenderBones;
        if (emissiveBones == null && emissiveTexture != null) {
            emissiveBones = resolveEmissiveBones(model, animatable);
            this.emissiveRenderBones = emissiveBones;
        }
        if (emissiveBones == null) {
            emissiveBones = Set.of();
            this.emissiveRenderBones = emissiveBones;
        }
        float emissiveStrength = this.model.getBlockEntityEmissiveStrength(animatable);
        ResourceLocation renderTexture = AnimatedTextureSupport.resolveRenderTexture(texture);
        if (renderType == null) {
            renderType = getRenderType(animatable, renderTexture);
        }
        Matrix4f previousTextureMatrix = AnimatedTextureSupport.pushTextureMatrix(renderTexture);
        try {
            renderWorldLitPass(
                    model,
                    poseStack,
                    lightPoseStack,
                    animatable,
                    animationState,
                    poseCacheKey,
                    bufferSource,
                    renderType,
                    renderTexture,
                    null,
                    0.0f,
                    animatable.getLevel(),
                    worldOrigin,
                    packedLight,
                    packedOverlay,
                    dynamicSelection.isAll() ? null : this.dynamicRenderBones,
                    red,
                    green,
                    blue,
                    alpha
            );
        } finally {
            AnimatedTextureSupport.popTextureMatrix(previousTextureMatrix);
        }
        if (emissiveTexture != null && emissiveBones != null && !emissiveBones.isEmpty()) {
            ResourceLocation renderEmissiveTexture = AnimatedTextureSupport.resolveRenderTexture(emissiveTexture);
            RenderType emissiveRenderType = IrisCompatInternal.wrapBlockEntityRenderLayer(this.model.getEmissiveRenderType(animatable, renderEmissiveTexture));
            previousTextureMatrix = AnimatedTextureSupport.pushTextureMatrix(renderEmissiveTexture);
            try {
                renderWorldLitPass(
                        model,
                        poseStack,
                        lightPoseStack,
                        animatable,
                        animationState,
                        poseCacheKey,
                        bufferSource,
                        emissiveRenderType,
                        renderEmissiveTexture,
                        null,
                        0.0f,
                        animatable.getLevel(),
                        worldOrigin,
                        LightTexture.FULL_BRIGHT,
                        packedOverlay,
                        emissiveBones,
                        emissiveStrength,
                        emissiveStrength,
                        emissiveStrength,
                        alpha
                );
            } finally {
                AnimatedTextureSupport.popTextureMatrix(previousTextureMatrix);
            }
        }

        captureTrackedBonePositions(poseStack, animatable, model, null, null);
    }

    public void renderFrozenLiveBones(PoseStack poseStack, T animatable, MultiBufferSource bufferSource, float partialTick, int packedLight, int packedOverlay, Set<String> liveBones) {
        if (liveBones == null || liveBones.isEmpty()) {
            return;
        }

        T previousAnimatable = this.animatable;
        Set<String> previousDynamicRenderBones = this.dynamicRenderBones;
        Set<String> previousEmissiveRenderBones = this.emissiveRenderBones;
        BakedGeoModel previousRenderModel = this.currentRenderModel;
        try {
            this.animatable = animatable;
            poseStack.pushPose();
            try {
                BakedGeoModel bakedModel = this.model.getBakedModel(this.model.getModelResource(animatable));
                this.currentRenderModel = bakedModel;
                ResourceLocation texture = getTextureLocation(animatable);
                Object poseCacheKey = animatable.getPoseKey();

                applyBlockEntityRenderTransform(poseStack, animatable);
                AnimationState<T> animationState = acquireAnimationState(animatable, partialTick);
                BerAnimationPreparationDecision decision = determineBerAnimationPreparation(animatable, bakedModel);
                if (decision.path() == BerAnimationPreparationPath.GPU_LIVE) {
                    this.model.prepareLiveRenderAnimations(animatable, getInstanceId(animatable), animationState);
                } else if (decision.path() == BerAnimationPreparationPath.CPU) {
                    this.model.prepareCpuRenderAnimations(animatable, getInstanceId(animatable), animationState);
                }
                this.modelRenderTranslations.set(poseStack.last().pose());

                Set<String> splitBones = this.model.getDynamicStaticSplitBones(bakedModel);
                this.dynamicRenderBones = mergeDynamicBones(liveBones, splitBones);
                this.emissiveRenderBones = null;

                if (this.model.usesCustomRenderPasses()) {
                    PoseStack lightPoseStack = createBlockLightPoseStack(animatable);
                    Vec3 worldOrigin = Vec3.atLowerCornerOf(animatable.getBlockPos());
                    renderCustomPasses(
                            poseStack,
                            lightPoseStack,
                            worldOrigin,
                            animatable,
                            bakedModel,
                            animationState,
                            poseCacheKey,
                            bufferSource,
                            packedLight,
                            packedOverlay,
                            partialTick,
                            1.0f,
                            1.0f,
                            1.0f,
                            1.0f
                    );
                    captureTrackedBonePositions(poseStack, animatable, bakedModel, null, null);
                    return;
                }

                ResourceLocation emissiveTexture = resolveEmissiveTexture(animatable);
                Set<String> emissiveBones = emissiveTexture == null
                        ? Set.of()
                        : resolveFrozenEmissiveBones(animatable, bakedModel, this.dynamicRenderBones);
                this.emissiveRenderBones = emissiveBones;
                float emissiveStrength = this.model.getBlockEntityEmissiveStrength(animatable);
                RenderType renderType = getRenderType(animatable, texture);
                RenderType emissiveRenderType = emissiveTexture == null || emissiveBones.isEmpty()
                        ? null
                        : IrisCompatInternal.wrapBlockEntityRenderLayer(this.model.getEmissiveRenderType(animatable, emissiveTexture));
                boolean rendered;
                if (ChaosGpuRenderRuntime.isShaderPackPipelineActive()) {
                    rendered = ChaosGpuShaderPackRenderer.render(
                            poseStack,
                            animatable,
                            this.model,
                            animationState,
                            texture,
                            emissiveTexture,
                            bakedModel,
                            packedLight,
                            null,
                            this.dynamicRenderBones,
                            emissiveBones,
                            emissiveStrength,
                            packedOverlay,
                            renderType,
                            emissiveRenderType,
                            ChaosShaderRenderPhase.BLOCK_ENTITIES,
                            poseCacheKey
                    );
                    if (!rendered) {
                        return;
                    }
                } else {
                    rendered = ChaosGpuGeoRenderer.render(
                            poseStack,
                            animatable,
                            this.model,
                            animationState,
                            bufferSource,
                            renderType,
                            texture,
                            emissiveTexture,
                            bakedModel,
                            packedLight,
                            null,
                            this.dynamicRenderBones,
                            emissiveBones,
                            emissiveStrength,
                            poseCacheKey
                    );
                }
                if (!rendered) {
                    PoseStack lightPoseStack = createBlockLightPoseStack(animatable);
                    Vec3 worldOrigin = Vec3.atLowerCornerOf(animatable.getBlockPos());
                    renderWorldLitPass(
                            bakedModel,
                            poseStack,
                            lightPoseStack,
                            animatable,
                            animationState,
                            poseCacheKey,
                            bufferSource,
                            renderType,
                            texture,
                            null,
                            0.0f,
                            animatable.getLevel(),
                            worldOrigin,
                            packedLight,
                            packedOverlay,
                            this.dynamicRenderBones,
                            1.0f,
                            1.0f,
                            1.0f,
                            1.0f
                    );
                    if (emissiveTexture != null && !emissiveBones.isEmpty()) {
                        RenderType fallbackEmissiveRenderType = emissiveRenderType != null
                                ? emissiveRenderType
                                : IrisCompatInternal.wrapBlockEntityRenderLayer(this.model.getEmissiveRenderType(animatable, emissiveTexture));
                        renderWorldLitPass(
                                bakedModel,
                                poseStack,
                                lightPoseStack,
                                animatable,
                                animationState,
                                poseCacheKey,
                                bufferSource,
                                fallbackEmissiveRenderType,
                                emissiveTexture,
                                null,
                                0.0f,
                                animatable.getLevel(),
                                worldOrigin,
                                LightTexture.FULL_BRIGHT,
                                packedOverlay,
                                emissiveBones,
                                emissiveStrength,
                                emissiveStrength,
                                emissiveStrength,
                                1.0f
                        );
                    }
                }
                captureTrackedBonePositions(poseStack, animatable, bakedModel, null, null);
            } finally {
                poseStack.popPose();
            }
        } finally {
            this.currentRenderModel = previousRenderModel;
            this.emissiveRenderBones = previousEmissiveRenderBones;
            this.dynamicRenderBones = previousDynamicRenderBones;
            this.animatable = previousAnimatable;
        }
    }

    private void captureTrackedBonePositions(PoseStack poseStack, T animatable, BakedGeoModel model, ChaosGpuGeoMesh mesh, Object poseToken) {
        if (!(animatable instanceof GeoBoneTrackingAnimatable trackedAnimatable)) {
            return;
        }

        if (trackedAnimatable.getTrackedBones().isEmpty()) {
            return;
        }

        float[] resolvedMatrices = trackedAnimatable.requiresGpuBoneTrackingReadback() && mesh != null && poseToken != null
                ? ChaosGpuBoneResolveDispatcher.resolveAndRead(mesh, poseToken)
                : null;
        if (resolvedMatrices != null) {
            GeoBoneTrackingHelper.updateTrackedBonePoses(
                    trackedAnimatable,
                    mesh.getIndexedBones(),
                    resolvedMatrices,
                    poseStack.last().pose(),
                    Vec3.atLowerCornerOf(animatable.getBlockPos())
            );
            return;
        }

        if (!(poseToken instanceof ChaosGpuAnimationPoseStorage.LocalPoseHandle)) {
            GeoBoneTrackingHelper.captureTrackedBoneMatrices(
                    model.topLevelBones(),
                    trackedAnimatable.getTrackedBones(),
                    poseStack.last().pose(),
                    Vec3.atLowerCornerOf(animatable.getBlockPos())
            );
            GeoBoneTrackingHelper.updateTrackedBonePoses(trackedAnimatable, this.model::getBone);
        }
    }

    /**
     * Resolves the emissive texture resource for the given block entity, or {@code null} if
     * emissive rendering is disabled or the texture is missing.
     */
    public ResourceLocation resolveEmissiveTexture(T animatable) {
        if (!this.model.shouldRenderEmissive(animatable)) {
            return null;
        }

        ResourceLocation emissiveTexture = this.model.getEmissiveTextureResource(animatable);
        return emissiveTexture != null && this.model.hasClientResource(emissiveTexture) ? emissiveTexture : null;
    }

    private Set<String> resolveEmissiveBones(BakedGeoModel model, T animatable) {
        return this.model.getResolvedEmissiveBones(animatable, model, this.dynamicRenderBones);
    }

    private Set<String> mergeDynamicBones(Set<String> dynamicBones, Set<String> splitBones) {
        if (splitBones.isEmpty()) {
            return dynamicBones;
        }

        if (dynamicBones.isEmpty()) {
            return splitBones;
        }

        if (dynamicBones.containsAll(splitBones)) {
            return dynamicBones;
        }

        if (splitBones.containsAll(dynamicBones)) {
            return splitBones;
        }

        HashSet<String> combined = new HashSet<>(dynamicBones);
        combined.addAll(splitBones);
        return Set.copyOf(combined);
    }

    /**
     * Applies block-facing rotation to the matrix stack before rendering.
     */
    public void rotateBlock(Direction facing, PoseStack poseStack) {
        switch (facing) {
            case SOUTH -> poseStack.mulPose(Axis.YP.rotationDegrees(180.0f));
            case WEST -> poseStack.mulPose(Axis.YP.rotationDegrees(90.0f));
            case NORTH -> poseStack.mulPose(Axis.YP.rotationDegrees(0.0f));
            case EAST -> poseStack.mulPose(Axis.YP.rotationDegrees(270.0f));
            case UP -> poseStack.mulPose(Axis.XP.rotationDegrees(90.0f));
            case DOWN -> poseStack.mulPose(Axis.XN.rotationDegrees(90.0f));
        }
    }

    protected final void applyBlockEntityRenderTransform(PoseStack poseStack, T animatable) {
        poseStack.translate(0.5d, 0.0d, 0.5d);
        rotateBlock(getFacing(animatable), poseStack);
        poseStack.mulPose(this.model.getBlockEntityRootTransform(animatable));
    }

    private enum AxisPlane {
        XY,
        XZ,
        YZ
    }

    private record LivePassBatchKey(RenderType renderLayer, ResourceLocation texture,
                                    @Nullable ResourceLocation emissiveTexture,
                                    int packedLight, int color, float emissiveStrength) {
    }

    private static final class LivePassBatch {
        private Set<String> includedBones;

        private LivePassBatch(Set<String> includedBones) {
            this.includedBones = includedBones == null ? null : new LinkedHashSet<>(includedBones);
        }

        private void include(Set<String> includedBones) {
            if (this.includedBones == null || includedBones == null) {
                this.includedBones = null;
                return;
            }

            if (!includedBones.isEmpty()) {
                this.includedBones.addAll(includedBones);
            }
        }

        private Set<String> includedBones() {
            return this.includedBones;
        }
    }

    /**
     * Resolves the facing used for block rotation, with per-state caching.
     */
    public Direction getFacing(T block) {
        GeoRenderStateAccess access = (GeoRenderStateAccess) block;
        BlockState state = block.getBlockState();
        if (access.getGeoCachedFacingState() == state) {
            return (Direction) access.getGeoCachedFacingValue();
        }

        Direction facing = resolveFacing(state);
        access.setGeoCachedFacingState(state);
        access.setGeoCachedFacingValue(facing);
        return facing;
    }

    private static Direction resolveFacing(BlockState blockState) {
        if (blockState.hasProperty(HorizontalDirectionalBlock.FACING)) {
            return blockState.getValue(HorizontalDirectionalBlock.FACING);
        }

        if (blockState.hasProperty(BlockStateProperties.FACING)) {
            return blockState.getValue(BlockStateProperties.FACING);
        }

        return Direction.NORTH;
    }

    /**
     * Resolves packed light across the render bounding box of the block entity.
     */
    protected int resolveRenderLight(T animatable, int fallbackLight) {
        return fallbackLight;
    }

    private boolean updateModelDataOnlyState(T animatable, double distanceSquared) {
        if (!hasStaticModelFallback()) {
            return false;
        }

        BlockEntity blockEntity = animatable;
        if (blockEntity.getLevel() == null || !blockEntity.getLevel().isClientSide()) {
            return false;
        }

        GeoRenderStateAccess state = (GeoRenderStateAccess) blockEntity;
        boolean previous = state.isGeoModelDataOnly();
        boolean current = shouldUseModelDataOnly(animatable, distanceSquared);
        if (previous != current) {
            state.setGeoModelDataOnly(current);
            state.setGeoShouldRenderLastFrameId(0);
            GeoRenderStateTracker.refreshClientStaticState(blockEntity);
        }
        return current;
    }

    private boolean shouldUseModelDataOnly(T animatable, double distanceSquared) {
        if (ChaosSodiumBlockEntitySettings.shouldKeepFrozenLiveBonesOnBer(this.model, animatable)) {
            return false;
        }

        double transitionDistance = ChaosSodiumBlockEntitySettings.resolveModelDataTransitionDistance(animatable, animatable.getStaticHandoffDistance());
        if (transitionDistance <= 0.0d) {
            return false;
        }

        return distanceSquared > transitionDistance * transitionDistance;
    }

    private boolean hasStaticModelFallback() {
        try {
            if (this.animatable != null && isInvisibleBlockRenderType(this.animatable)) {
                return false;
            }

            Boolean cached = this.staticResourceFallback;
            if (cached != null) {
                return cached;
            }

            boolean resolved = this.model.getStaticModelId() != null
                    && this.model.getStaticGeoModelResource() != null
                    && this.model.getStaticTextureResource() != null;
            this.staticResourceFallback = resolved;
            return resolved;
        } catch (RuntimeException exception) {
            return false;
        }
    }

    private boolean isStaticOnly(T animatable) {
        return this.model.getBlockRenderMode(animatable) == GeoBlockRenderMode.STATIC_ONLY;
    }

    private void validateStaticOnlyConfiguration(T animatable) {
        if (animatable.getBlockState().getRenderShape() != RenderShape.MODEL) {
            throw new IllegalStateException(
                    "GeoBlockRenderMode.STATIC_ONLY requires RenderShape.MODEL: " +
                            animatable.getClass().getName()
            );
        }

        if (!hasStaticModelFallback()) {
            throw new IllegalStateException(
                    "GeoBlockRenderMode.STATIC_ONLY requires static model, geo model, and texture resources: " +
                            animatable.getClass().getName()
            );
        }
    }

    private double resolveRenderDistance(T animatable) {
        double renderDistance = this.getViewDistance();
        double frozenRenderRadius = this.model.getFrozenBlockEntityRenderRadius();
        boolean hasStaticAdditions = hasStaticAdditionsToRender(animatable);
        if (frozenRenderRadius <= 0.0d && !hasStaticAdditions) {
            return renderDistance;
        }

        Double cached = this.cachedExtendedRenderDistance;
        if (cached != null) {
            return cached;
        }

        Minecraft client = Minecraft.getInstance();
        if (client == null) {
            return renderDistance;
        }

        double worldVisibilityRadius = client.options.renderDistance().get() * 16.0d;
        double configuredFrozenVisibility = this.model.getFrozenBlockEntityVisibilityRadius();
        double frozenVisibilityRadius = Double.isFinite(configuredFrozenVisibility)
                ? Math.min(configuredFrozenVisibility, worldVisibilityRadius)
                : worldVisibilityRadius;
        double resolved = Math.max(renderDistance, frozenVisibilityRadius);
        this.cachedExtendedRenderDistance = resolved;
        return resolved;
    }

    private boolean shouldRunRenderer(T animatable) {
        return !hasStaticModelFallback() || animatable.shouldRunBlockEntityRenderer();
    }

    private boolean shouldRenderLiveModel(T animatable) {
        return !hasStaticModelFallback() || animatable.isGeoRenderActive() || animatable.isGeoRenderDeactivateGraceActive();
    }

    private void validateVisibleBlockRenderType(T animatable) {
        BlockState state = animatable.getBlockState();
        Boolean cached = this.visibleBlockRenderTypeCache.get(state);
        if (cached != null) {
            if (cached) {
                return;
            }
            throw invisibleBlockRenderException(animatable);
        }

        if (!isInvisibleBlockRenderType(state) || this.model.allowInvisibleBlockRender(animatable)) {
            this.visibleBlockRenderTypeCache.put(state, true);
            return;
        }

        this.visibleBlockRenderTypeCache.put(state, false);
        throw invisibleBlockRenderException(animatable);
    }

    private IllegalStateException invisibleBlockRenderException(T animatable) {
        return new IllegalStateException(
                "ChaosLib blocks must not use RenderShape.INVISIBLE by default. " +
                        "Switch the block to MODEL or explicitly opt in via GeoModel.allowInvisibleBlockRender(...): " +
                        animatable.getClass().getName()
        );
    }

    private boolean isInvisibleBlockRenderType(T animatable) {
        return isInvisibleBlockRenderType(animatable.getBlockState());
    }

    private boolean isInvisibleBlockRenderType(BlockState state) {
        if (state == this.lastInvisibleRenderTypeState) {
            return this.lastInvisibleRenderTypeValue;
        }

        boolean invisible = state.getRenderShape() == RenderShape.INVISIBLE;
        this.lastInvisibleRenderTypeState = state;
        this.lastInvisibleRenderTypeValue = invisible;
        return invisible;
    }

    private void renderCustomPasses(
            PoseStack poseStack,
            PoseStack lightPoseStack,
            Vec3 worldOrigin,
            T animatable,
            BakedGeoModel model,
            @Nullable AnimationState<T> animationState,
            @Nullable Object poseCacheKey,
            MultiBufferSource bufferSource,
            int packedLight,
            int packedOverlay,
            float partialTick,
            float red,
            float green,
            float blue,
            float alpha
    ) {
        LinkedHashMap<LivePassBatchKey, LivePassBatch> batches = this.reusableLivePassBatches;
        batches.clear();

        for (GeoRenderPass<T> pass : this.model.getRenderPasses()) {
            if (!pass.shouldRenderLive(animatable)) {
                continue;
            }

            ResourceLocation texture = pass.getLiveTexture(animatable);
            if (texture == null || !this.model.hasClientResource(texture)) {
                continue;
            }
            ResourceLocation renderTexture = AnimatedTextureSupport.resolveRenderTexture(texture);

            Set<String> includedBones = this.model.resolveLiveRenderPassBones(pass, model, animatable, this.dynamicRenderBones);
            if (includedBones != null && includedBones.isEmpty()) {
                continue;
            }

            RenderType renderLayer = IrisCompatInternal.wrapBlockEntityRenderLayer(pass.getLiveRenderLayer(animatable, renderTexture));
            int passPackedLight = pass.resolvePackedLight(animatable, packedLight);
            int passColor = pass.getLiveColor(animatable, partialTick);
            ResourceLocation passEmissiveTexture = pass.getLiveEmissiveTexture(animatable, texture);
            if (passEmissiveTexture != null && !this.model.hasClientResource(passEmissiveTexture)) {
                passEmissiveTexture = null;
            }
            if (passEmissiveTexture != null) {
                passEmissiveTexture = AnimatedTextureSupport.resolveRenderTexture(passEmissiveTexture);
            }
            float passEmissiveStrength = passEmissiveTexture != null ? pass.getLiveEmissiveStrength(animatable) : 0.0f;
            LivePassBatchKey key = new LivePassBatchKey(renderLayer, renderTexture, passEmissiveTexture, passPackedLight, passColor, passEmissiveStrength);
            LivePassBatch batch = batches.get(key);
            if (batch == null) {
                batches.put(key, new LivePassBatch(includedBones));
            } else {
                batch.include(includedBones);
            }
        }

        LinkedHashSet<String> renderedBones = new LinkedHashSet<>();
        boolean renderedAllBones = false;
        for (Map.Entry<LivePassBatchKey, LivePassBatch> entry : batches.entrySet()) {
            LivePassBatchKey key = entry.getKey();
            Set<String> includedBones = entry.getValue().includedBones();
            int passColor = key.color();
            float passRed = GeoRenderColor.red(passColor);
            float passGreen = GeoRenderColor.green(passColor);
            float passBlue = GeoRenderColor.blue(passColor);
            float passAlpha = GeoRenderColor.alpha(passColor);
            float[] shaderColor = RenderSystem.getShaderColor();
            float shaderRed = shaderColor[0];
            float shaderGreen = shaderColor[1];
            float shaderBlue = shaderColor[2];
            float shaderAlpha = shaderColor[3];
            Matrix4f previousTextureMatrix = AnimatedTextureSupport.pushTextureMatrix(key.texture());
            RenderSystem.setShaderColor(shaderRed * passRed, shaderGreen * passGreen, shaderBlue * passBlue, shaderAlpha * passAlpha);
            try {
                renderWorldLitPass(
                        model,
                        poseStack,
                        lightPoseStack,
                        animatable,
                        animationState,
                        poseCacheKey,
                        bufferSource,
                        key.renderLayer(),
                        key.texture(),
                        key.emissiveTexture(),
                        key.emissiveStrength(),
                        animatable.getLevel(),
                        worldOrigin,
                        key.packedLight(),
                        packedOverlay,
                        includedBones,
                        red * passRed,
                        green * passGreen,
                        blue * passBlue,
                        alpha * passAlpha
                );
            } finally {
                AnimatedTextureSupport.popTextureMatrix(previousTextureMatrix);
                RenderSystem.setShaderColor(shaderRed, shaderGreen, shaderBlue, shaderAlpha);
            }

            if (includedBones == null) {
                renderedAllBones = true;
            } else {
                renderedBones.addAll(includedBones);
            }
        }

        this.dynamicRenderBones = renderedAllBones ? null : (renderedBones.isEmpty() ? Set.of() : Set.copyOf(renderedBones));
    }

    private PoseStack createBlockLightPoseStack(T animatable) {
        PoseStack lightPoseStack = new PoseStack();
        applyBlockEntityRenderTransform(lightPoseStack, animatable);
        return lightPoseStack;
    }

    private BerAnimationPreparationDecision determineBerAnimationPreparation(T animatable, BakedGeoModel model) {
        ChaosSodiumGpuSkinningMode gpuSkinningMode = ChaosSodiumBlockEntitySettings.resolveGpuSkinningMode(animatable);
        if (this.frozenRenderHelper.hasActiveThawTransition(animatable)) {
            return recordBerDecision(animatable, gpuSkinningMode, BerAnimationPreparationPath.CPU, false, false, "thaw_transition");
        }
        if (gpuSkinningMode == ChaosSodiumGpuSkinningMode.FORCE_CPU) {
            return recordBerDecision(animatable, gpuSkinningMode, BerAnimationPreparationPath.CPU, false, false, "forced_cpu");
        }
        if (!model.properties().gpuPipeline()) {
            return recordBerDecision(animatable, gpuSkinningMode, BerAnimationPreparationPath.CPU, false, false, "model_gpu_pipeline_disabled");
        }
        if (!ChaosGpuRenderRuntime.isGpuPathSupported(model)) {
            return recordBerDecision(animatable, gpuSkinningMode, BerAnimationPreparationPath.CPU, false, false, "gpu_backend_unavailable");
        }

        ChaosGpuGeoMesh mesh = ChaosGpuGeoMesh.getOrCreate(model);
        GeoModel.GpuLiveRenderAnimationSupport gpuLiveSupport = this.model.getGpuLiveRenderAnimationSupport(animatable, mesh);
        if (gpuLiveSupport.hasNoLiveAnimationWork()) {
            return recordBerDecision(animatable, gpuSkinningMode, BerAnimationPreparationPath.NONE, true, false, "no_animation");
        }
        if (!gpuLiveSupport.isGpuLiveCapable()) {
            return recordBerDecision(animatable, gpuSkinningMode, BerAnimationPreparationPath.CPU, true, false, gpuLiveSupportReason(gpuLiveSupport));
        }

        return recordBerDecision(animatable, gpuSkinningMode, BerAnimationPreparationPath.GPU_LIVE, true, true, "gpu_animation");
    }

    private BerAnimationPreparationDecision recordBerDecision(T animatable, ChaosSodiumGpuSkinningMode gpuSkinningMode, BerAnimationPreparationPath path, boolean gpuPathSupported, boolean gpuLiveCapable, String reasonKey) {
        ChaosSodiumDebugOverlay.recordBlockEntityDecision(animatable, gpuSkinningMode, path.name(), gpuPathSupported, gpuLiveCapable, reasonKey);
        return new BerAnimationPreparationDecision(path);
    }

    private String gpuLiveSupportReason(GeoModel.GpuLiveRenderAnimationSupport gpuLiveSupport) {
        return switch (gpuLiveSupport) {
            case CUSTOM_CPU_POSE -> "custom_cpu_pose";
            case ANIMATION_RESOURCE_REQUIRES_CPU -> "animation_requires_cpu";
            case NO_ANIMATION_DATA_AND_NO_GPU_PROCEDURAL -> "no_animation";
            case GPU_PROCEDURAL_ONLY, GPU_LIVE_SAFE -> "gpu_animation";
        };
    }

    private void renderWorldLitPass(
            BakedGeoModel model,
            PoseStack poseStack,
            PoseStack lightPoseStack,
            T animatable,
            @Nullable AnimationState<T> animationState,
            @Nullable Object poseCacheKey,
            MultiBufferSource bufferSource,
            RenderType renderLayer,
            ResourceLocation texture,
            @Nullable ResourceLocation emissiveTexture,
            float emissiveStrength,
            net.minecraft.world.level.BlockAndTintGetter world,
            Vec3 worldOrigin,
            int packedLight,
            int packedOverlay,
            Set<String> includedBones,
            float red,
            float green,
            float blue,
            float alpha
    ) {
        if (animationState != null && poseCacheKey != null) {
            if (ChaosGpuRenderRuntime.isShaderPackPipelineActive()) {
                ChaosGpuShaderPackRenderer.render(
                        poseStack,
                        animatable,
                        this.model,
                        animationState,
                        texture,
                        emissiveTexture,
                        model,
                        packedLight,
                        null,
                        includedBones,
                        emissiveTexture != null && emissiveStrength > 0.0f ? null : Set.of(),
                        emissiveStrength,
                        packedOverlay,
                        renderLayer,
                        emissiveTexture != null && emissiveStrength > 0.0f ? renderLayer : null,
                        ChaosShaderRenderPhase.BLOCK_ENTITIES,
                        poseCacheKey
                );
                return;
            }

            if (ChaosGpuGeoRenderer.render(
                    poseStack,
                    animatable,
                    this.model,
                    animationState,
                    bufferSource,
                    renderLayer,
                    texture,
                    emissiveTexture,
                    model,
                    packedLight,
                    null,
                    includedBones,
                    emissiveTexture != null && emissiveStrength > 0.0f ? null : Set.of(),
                    emissiveStrength,
                    poseCacheKey
            )) {
                return;
            }
        }
    }

    public int[] resolveBoneLightData(T animatable, ChaosGpuGeoMesh mesh, Object bonePoseData, Matrix4f rootTransform, int fallbackLight) {
        if (fallbackLight == LightTexture.FULL_BRIGHT) {
            return ChaosGpuBoneLightSampler.fullBright(mesh.getIndexedBones().size());
        }

        if (animatable.getLevel() == null) {
            return null;
        }

        BlockPos.MutableBlockPos samplePos = new BlockPos.MutableBlockPos();
        return ChaosGpuBoneLightSampler.sampleBlockEntityBoneLights(
                mesh,
                bonePoseData,
                rootTransform,
                Vec3.atLowerCornerOf(animatable.getBlockPos()),
                fallbackLight,
                (worldX, worldY, worldZ) -> {
                    samplePos.set(Mth.floor(worldX), Mth.floor(worldY), Mth.floor(worldZ));
                    return LevelRenderer.getLightColor(animatable.getLevel(), animatable.getLevel().getBlockState(samplePos), samplePos);
                }
        );
    }

    private enum BerAnimationPreparationPath {
        NONE("none"),
        CPU("cpu"),
        GPU_LIVE("gpu-live");

        private final String logName;

        BerAnimationPreparationPath(String logName) {
            this.logName = logName;
        }

        public String logName() {
            return this.logName;
        }
    }

    private record BerAnimationPreparationDecision(BerAnimationPreparationPath path) {
    }
}
