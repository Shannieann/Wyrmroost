package dev.elifian.chaoslib.api.example;

import dev.elifian.chaoslib.ChaosLib;
import dev.elifian.chaoslib.api.animation.AnimationState;
import dev.elifian.chaoslib.api.model.GeoModel;
import dev.elifian.chaoslib.model.AnimatedBoneSelection;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.Nullable;

/**
 * Procedural CPU/GPU bone pose, written every frame from block-entity state rather than sampled from
 * an animation file. Only the bones listed in {@link #getLiveRenderBones} leave the baked static
 * mesh, so the rest of the block stays on the fast static path.
 */
public final class ProceduralBlockModelExample extends GeoModel<ProceduralBlockEntityExample> {
    public static final ProceduralBlockModelExample INSTANCE = new ProceduralBlockModelExample();

    static final String PLATFORM_BONE = "platform";
    static final String ITEM_ANCHOR_BONE = "item_anchor";
    static final float PLATFORM_TRAVEL = 6.0f;

    private static final ResourceLocation MODEL = ChaosLib.id("geo/example_procedural_block.geo.json");
    private static final ResourceLocation TEXTURE = ChaosLib.id("textures/block/example_procedural_block.png");
    private static final AnimatedBoneSelection LIVE_BONES = AnimatedBoneSelection.of(PLATFORM_BONE, ITEM_ANCHOR_BONE);

    private ProceduralBlockModelExample() {
    }

    @Override
    public ResourceLocation getModelResource(ProceduralBlockEntityExample animatable) {
        return MODEL;
    }

    @Override
    public ResourceLocation getTextureResource(ProceduralBlockEntityExample animatable) {
        return TEXTURE;
    }

    @Override
    public @Nullable ResourceLocation getAnimationResource(ProceduralBlockEntityExample animatable) {
        return null;
    }

    @Override
    public AnimatedBoneSelection getBakeExcludedBones() {
        return LIVE_BONES;
    }

    @Override
    public AnimatedBoneSelection getLiveRenderBones(ProceduralBlockEntityExample animatable) {
        return LIVE_BONES;
    }

    @Override
    public AnimatedBoneSelection getFrozenRenderBones(ProceduralBlockEntityExample animatable) {
        return LIVE_BONES;
    }

    @Override
    public void applyGpuPose(ProceduralBlockEntityExample animatable, AnimationState<ProceduralBlockEntityExample> state) {
        super.applyGpuPose(animatable, state);
        float progress = animatable.getPlatformProgress(state.getPartialTick());
        this.getBoneHandle(PLATFORM_BONE).ifPresent(bone -> {
            bone.setTrackingMatrices(true);
            bone.setPosY(PLATFORM_TRAVEL * progress);
        });
    }

    @Override
    public void applyCpuPose(ProceduralBlockEntityExample animatable, long instanceId, AnimationState<ProceduralBlockEntityExample> state) {
        super.applyCpuPose(animatable, instanceId, state);
        float progress = animatable.getPlatformProgress(state.getPartialTick());
        this.getBone(PLATFORM_BONE).ifPresent(bone -> {
            bone.setTrackingMatrices(true);
            bone.setPosY(PLATFORM_TRAVEL * progress);
        });
    }
}
