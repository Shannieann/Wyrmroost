package dev.elifian.chaoslib.api.example;

import dev.elifian.chaoslib.api.model.GeoModel;
import dev.elifian.chaoslib.model.AnimatedBoneSelection;
import net.minecraft.resources.ResourceLocation;

/**
 * Client model for {@link AnimatedEntityExample}: every bone is posed from the animation file.
 */
public final class AnimatedEntityModelExample extends GeoModel<AnimatedEntityExample> {
    public static final AnimatedEntityModelExample INSTANCE = new AnimatedEntityModelExample();

    private AnimatedEntityModelExample() {
    }

    @Override
    public ResourceLocation getModelResource(AnimatedEntityExample animatable) {
        return AnimatedEntityExample.MODEL;
    }

    @Override
    public ResourceLocation getTextureResource(AnimatedEntityExample animatable) {
        return AnimatedEntityExample.TEXTURE;
    }

    @Override
    public ResourceLocation getAnimationResource(AnimatedEntityExample animatable) {
        return AnimatedEntityExample.ANIMATION;
    }

    @Override
    public AnimatedBoneSelection getLiveRenderBones(AnimatedEntityExample animatable) {
        return AnimatedBoneSelection.all();
    }
}
