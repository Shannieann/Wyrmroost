package dev.elifian.chaoslib.api.example;

import dev.elifian.chaoslib.api.renderer.GeoEntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

/**
 * Entity renderer for {@link MultipartMobExample}.
 */
public final class MultipartMobRendererExample extends GeoEntityRenderer<MultipartMobExample> {
    public MultipartMobRendererExample(EntityRendererProvider.Context context) {
        super(context, MultipartMobModelExample.INSTANCE);
        this.shadowRadius = 0.5f;
    }
}
