package dev.elifian.chaoslib.api.example;

import dev.elifian.chaoslib.api.renderer.GeoEntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

/**
 * Entity renderer for {@link AnimatedEntityExample}.
 */
public final class AnimatedEntityRendererExample extends GeoEntityRenderer<AnimatedEntityExample> {
    public AnimatedEntityRendererExample(EntityRendererProvider.Context context) {
        super(context, AnimatedEntityModelExample.INSTANCE);
        this.shadowRadius = 0.0f;
    }
}
