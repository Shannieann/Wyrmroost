package dev.elifian.chaoslib.api.example;

import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;
import org.jetbrains.annotations.Nullable;

/**
 * Host block of the procedural example: it stores a facing and hands the item you right-click with
 * to the block entity, so the rising platform has something to carry. Right-clicking with an empty
 * hand takes the item back.
 *
 * <p>Place it with {@code /setblock ~ ~ ~ chaoslib:example_procedural_block[facing=up]}, or with the
 * block item, which renders as the baked static geo model in hand and in the inventory.</p>
 */
public class ProceduralBlockExample extends BaseEntityBlock {
    public static final MapCodec<ProceduralBlockExample> CODEC = simpleCodec(ProceduralBlockExample::new);
    public static final DirectionProperty FACING = BlockStateProperties.FACING;

    public ProceduralBlockExample(Properties properties) {
        super(properties);
        this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.UP));
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return this.defaultBlockState().setValue(FACING, context.getClickedFace());
    }

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public @Nullable BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new ProceduralBlockEntityExample(pos, state);
    }

    @Override
    public @Nullable <T extends BlockEntity> BlockEntityTicker<T> getTicker(
            Level level, BlockState state, BlockEntityType<T> type) {
        return createTickerHelper(type, ChaosExampleContent.proceduralBlockEntity(), ProceduralBlockEntityExample::tick);
    }

    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hit) {
        if (!(level.getBlockEntity(pos) instanceof ProceduralBlockEntityExample block)) {
            return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }

        if (level.isClientSide) {
            return ItemInteractionResult.SUCCESS;
        }

        if (stack.isEmpty()) {
            ItemStack held = block.getHeldStack();
            if (!held.isEmpty()) {
                player.getInventory().placeItemBackInInventory(held);
                block.setHeldStack(ItemStack.EMPTY);
            }
            return ItemInteractionResult.SUCCESS;
        }

        ItemStack single = stack.copyWithCount(1);
        ItemStack previous = block.getHeldStack();
        block.setHeldStack(single);
        if (!player.getAbilities().instabuild) {
            stack.shrink(1);
        }
        if (!previous.isEmpty()) {
            player.getInventory().placeItemBackInInventory(previous);
        }
        return ItemInteractionResult.SUCCESS;
    }
}
