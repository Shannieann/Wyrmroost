package dev.elifian.chaoslib.api.example;

import dev.elifian.chaoslib.ChaosLib;
import dev.elifian.chaoslib.api.animatable.GeoLivingEntity;
import dev.elifian.chaoslib.api.animation.AnimatableManager;
import dev.elifian.chaoslib.api.animation.AnimationController;
import dev.elifian.chaoslib.api.animation.RawAnimation;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * Reference entity animated from an animation file, spawnable with
 * {@code /summon chaoslib:example_animated_entity}.
 *
 * <p>The server flips {@link #setActive(boolean)} when the entity is right-clicked, tracked data
 * replicates the value, and the animation predicate picks the idle or the active clip from it: the
 * standard shape for state-driven animation, where gameplay owns a synced field and the controller
 * only reads it.</p>
 */
public class AnimatedEntityExample extends PathfinderMob implements GeoLivingEntity {
    static final ResourceLocation MODEL = ChaosLib.id("geo/example_animated_entity.geo.json");
    static final ResourceLocation TEXTURE = ChaosLib.id("textures/entity/example_animated_entity.png");
    static final ResourceLocation ANIMATION = ChaosLib.id("animations/example_animated_entity.animation.json");

    private static final EntityDataAccessor<Boolean> ACTIVE =
            SynchedEntityData.defineId(AnimatedEntityExample.class, EntityDataSerializers.BOOLEAN);

    public AnimatedEntityExample(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 40.0d)
                .add(Attributes.MOVEMENT_SPEED, 0.2d)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0d);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(4, new WaterAvoidingRandomStrollGoal(this, 0.7d));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 10.0f));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, 5, state -> state.setAndContinue(
                RawAnimation.begin().thenLoop(this.isActive()
                        ? "animation.example_animated_entity.active"
                        : "animation.example_animated_entity.idle"))));
    }

    @Override
    public double getTick() {
        return this.tickCount;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(ACTIVE, false);
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (!this.level().isClientSide) {
            this.setActive(!this.isActive());
        }

        return InteractionResult.sidedSuccess(this.level().isClientSide);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.setActive(tag.getBoolean("Active"));
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Active", this.isActive());
    }

    public boolean isActive() {
        return this.entityData.get(ACTIVE);
    }

    public void setActive(boolean active) {
        this.entityData.set(ACTIVE, active);
    }
}
