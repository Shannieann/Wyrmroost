package dev.elifian.chaoslib.api.example;

import dev.elifian.chaoslib.ChaosLib;
import dev.elifian.chaoslib.api.animatable.GeoLivingEntity;
import dev.elifian.chaoslib.api.animation.*;
import dev.elifian.chaoslib.api.multipart.GeoEntityPart;
import dev.elifian.chaoslib.api.multipart.GeoMultipartEntity;
import dev.elifian.chaoslib.api.multipart.GeoMultipartPartRegistrar;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/**
 * Reference multipart mob, spawnable with {@code /summon chaoslib:example_multipart_entity}.
 *
 * <p>The model is built like a nesting doll: the shells are parented into each other
 * ({@code shell_bottom -> shell_mid -> shell_top -> head}), so a rotation applied to an outer shell
 * carries every inner one with it. Each shell owns one virtual hitbox, which shows that hitboxes
 * follow animated bone poses rather than the entity bounding box (see them with F3+B).</p>
 *
 * <p>The vanilla bounding box is excluded from picking ({@link #isPickable()}), so every hit has to
 * land on a bone-bound part. Multipart collisions have to stay enabled for that: the multipart
 * raycast skips parts without collision, and the mob would become impossible to hit.</p>
 */
public class MultipartMobExample extends PathfinderMob implements GeoLivingEntity, GeoMultipartEntity {
    public static final String BONE_SHELL_BOTTOM = "shell_bottom";
    public static final String BONE_SHELL_MID = "shell_mid";
    public static final String BONE_SHELL_TOP = "shell_top";
    public static final String BONE_HEAD = "head";
    public static final String BONE_ARM_LEFT = "arm_left";
    public static final String BONE_ARM_RIGHT = "arm_right";

    static final ResourceLocation MODEL = ChaosLib.id("geo/example_multipart_entity.geo.json");
    static final ResourceLocation TEXTURE = ChaosLib.id("textures/entity/example_multipart_entity.png");
    static final ResourceLocation ANIMATION = ChaosLib.id("animations/example_multipart_entity.animation.json");

    private static final int ATTACK_ANIMATION_TICKS = 12;

    private static final EntityDataAccessor<Integer> ATTACK_TICKS =
            SynchedEntityData.defineId(MultipartMobExample.class, EntityDataSerializers.INT);

    public MultipartMobExample(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 80.0d)
                .add(Attributes.MOVEMENT_SPEED, 0.24d)
                .add(Attributes.ATTACK_DAMAGE, 5.0d)
                .add(Attributes.FOLLOW_RANGE, 32.0d)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.6d);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.0d, false));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8d));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 12.0f));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(ATTACK_TICKS, 0);
    }

    @Override
    public void tick() {
        super.tick();

        if (!this.level().isClientSide) {
            int attackTicks = this.entityData.get(ATTACK_TICKS);
            if (attackTicks > 0) {
                this.entityData.set(ATTACK_TICKS, attackTicks - 1);
            }
        }
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        if (!this.level().isClientSide) {
            this.entityData.set(ATTACK_TICKS, ATTACK_ANIMATION_TICKS);
        }

        return super.doHurtTarget(target);
    }

    public boolean isAttackAnimationActive() {
        return this.entityData.get(ATTACK_TICKS) > 0;
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, 5, this::movementAnimation)
                .priority(0)
                .blendMode(AnimationPlaybackController.BlendMode.MIX));
        controllers.add(new AnimationController<>(this, 0, this::attackAnimation)
                .priority(10)
                .blendMode(AnimationPlaybackController.BlendMode.OVERRIDE));
    }

    private PlayState movementAnimation(AnimationState<MultipartMobExample> state) {
        boolean moving = this.getDeltaMovement().horizontalDistanceSqr() > 0.0015d;
        return state.setAndContinue(RawAnimation.begin().thenLoop(moving
                ? "animation.example_multipart_entity.walk"
                : "animation.example_multipart_entity.idle"));
    }

    private PlayState attackAnimation(AnimationState<MultipartMobExample> state) {
        if (!this.isAttackAnimationActive()) {
            return PlayState.STOP;
        }

        return state.setAndContinue(RawAnimation.begin().thenPlayAndHold("animation.example_multipart_entity.attack"));
    }

    @Override
    public void registerMultipartParts(GeoMultipartPartRegistrar registrar) {
        registrar.trackDetailed(BONE_SHELL_BOTTOM);
        registrar.track(BONE_SHELL_MID);
        registrar.track(BONE_SHELL_TOP);
        registrar.track(BONE_HEAD);
        registrar.track(BONE_ARM_LEFT);
        registrar.track(BONE_ARM_RIGHT);
    }

    @Override
    public ResourceLocation getMultipartModelResource() {
        return MODEL;
    }

    @Override
    public boolean damageMultipartPart(GeoEntityPart<?> part, DamageSource source, float amount) {
        float multiplier = switch (part.getTrackedBoneName()) {
            case BONE_HEAD -> 3.0f;
            case BONE_SHELL_TOP -> 1.5f;
            case BONE_ARM_LEFT, BONE_ARM_RIGHT -> 1.0f;
            case BONE_SHELL_MID -> 0.5f;
            default -> 0.25f;
        };

        return this.hurt(source, amount * multiplier);
    }

    @Override
    public int getMultipartDebugHitboxColor(String trackedBoneName) {
        return switch (trackedBoneName) {
            case BONE_HEAD -> 0xFFFF0000;
            case BONE_SHELL_TOP -> 0xFF4884C4;
            case BONE_SHELL_MID -> 0xFFD68E2C;
            case BONE_SHELL_BOTTOM -> 0xFFB22A30;
            default -> 0xFFFFA500;
        };
    }

    @Override
    public boolean isPickable() {
        return false;
    }

    @Override
    public boolean shouldRenderRootDebugHitbox() {
        return false;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }
}
