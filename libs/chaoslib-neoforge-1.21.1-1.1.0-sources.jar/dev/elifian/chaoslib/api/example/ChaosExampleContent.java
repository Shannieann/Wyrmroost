package dev.elifian.chaoslib.api.example;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;

/**
 * Registry objects for the bundled examples. Each loader registers the content its own way
 * and stores the results here, so the example classes themselves stay loader-independent.
 */
public final class ChaosExampleContent {
    public static final String MULTIPART_ENTITY_ID = "example_multipart_entity";
    public static final String ANIMATED_ENTITY_ID = "example_animated_entity";
    public static final String PROCEDURAL_BLOCK_ID = "example_procedural_block";

    private static EntityType<MultipartMobExample> multipartEntity;
    private static EntityType<AnimatedEntityExample> animatedEntity;
    private static Block proceduralBlock;
    private static BlockEntityType<ProceduralBlockEntityExample> proceduralBlockEntity;

    private ChaosExampleContent() {
    }

    public static EntityType<MultipartMobExample> multipartEntity() {
        return multipartEntity;
    }

    public static EntityType<AnimatedEntityExample> animatedEntity() {
        return animatedEntity;
    }

    public static Block proceduralBlock() {
        return proceduralBlock;
    }

    public static BlockEntityType<ProceduralBlockEntityExample> proceduralBlockEntity() {
        return proceduralBlockEntity;
    }

    public static void setMultipartEntity(EntityType<MultipartMobExample> type) {
        multipartEntity = type;
    }

    public static void setAnimatedEntity(EntityType<AnimatedEntityExample> type) {
        animatedEntity = type;
    }

    public static void setProceduralBlock(Block block) {
        proceduralBlock = block;
    }

    public static void setProceduralBlockEntity(BlockEntityType<ProceduralBlockEntityExample> type) {
        proceduralBlockEntity = type;
    }
}
