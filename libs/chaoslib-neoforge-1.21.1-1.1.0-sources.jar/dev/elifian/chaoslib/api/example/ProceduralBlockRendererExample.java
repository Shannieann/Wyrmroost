package dev.elifian.chaoslib.api.example;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import dev.elifian.chaoslib.api.renderer.GeoBlockRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.core.Direction;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;

/**
 * Renders the procedural example block and the item it carries.
 *
 * <p>The item is not part of the geo mesh, so it is drawn as a render addition. Two hooks are needed:
 * {@link ProceduralBlockEntityExample#hasRenderAdditions()} keeps the block entity visible to the
 * renderer while its mesh is served from the baked static path, and {@link #hasStaticAdditionsToRender}
 * tells the renderer there is still something to draw, which routes the call into
 * {@link #renderModelDataAdditions}.</p>
 *
 * <p>Additions are drawn in block space (centered on X/Z, resting on the bottom of the block, with the
 * block facing already applied), so the item is placed at the platform's rest height plus the travel
 * the pose applies this frame. Reading the bone back from the model would not work: on the baked and
 * GPU paths the CPU bone tree is never posed, and the item would stay put while the platform moves.</p>
 */
public final class ProceduralBlockRendererExample extends GeoBlockRenderer<ProceduralBlockEntityExample> {
    private static final float HELD_ITEM_SCALE = 0.5f;
    private static final float HELD_ITEM_REST_Y = 12.0f / 16.0f;
    private static final float HELD_ITEM_TRAVEL = ProceduralBlockModelExample.PLATFORM_TRAVEL / 16.0f;

    public ProceduralBlockRendererExample(BlockEntityRendererProvider.Context context) {
        super(ProceduralBlockModelExample.INSTANCE);
    }

    @Override
    public void rotateBlock(Direction facing, PoseStack poseStack) {
        poseStack.translate(0.0f, 0.5f, 0.0f);
        switch (facing) {
            case DOWN -> poseStack.mulPose(Axis.XP.rotationDegrees(180.0f));
            case NORTH -> {
                poseStack.mulPose(Axis.YP.rotationDegrees(180.0f));
                poseStack.mulPose(Axis.XP.rotationDegrees(90.0f));
                poseStack.mulPose(Axis.YP.rotationDegrees(180.0f));
            }
            case SOUTH -> {
                poseStack.mulPose(Axis.XP.rotationDegrees(90.0f));
                poseStack.mulPose(Axis.YP.rotationDegrees(180.0f));
            }
            case WEST -> {
                poseStack.mulPose(Axis.YP.rotationDegrees(270.0f));
                poseStack.mulPose(Axis.XP.rotationDegrees(90.0f));
                poseStack.mulPose(Axis.YP.rotationDegrees(180.0f));
            }
            case EAST -> {
                poseStack.mulPose(Axis.YP.rotationDegrees(90.0f));
                poseStack.mulPose(Axis.XP.rotationDegrees(90.0f));
                poseStack.mulPose(Axis.YP.rotationDegrees(180.0f));
            }
            default -> {
            }
        }
        poseStack.translate(0.0f, -0.5f, 0.0f);
    }

    public AABB getRenderBoundingBox(ProceduralBlockEntityExample animatable) {
        return animatable.getRenderBoundingBox();
    }

    @Override
    protected boolean hasStaticAdditionsToRender(ProceduralBlockEntityExample animatable) {
        return !animatable.getHeldStack().isEmpty();
    }

    @Override
    protected void renderModelDataAdditions(PoseStack poseStack, ProceduralBlockEntityExample animatable,
                                            MultiBufferSource bufferSource, float partialTick,
                                            int packedLight, int packedOverlay, boolean frozen) {
        ItemStack stack = animatable.getHeldStack();
        if (stack.isEmpty()) {
            return;
        }

        float progress = animatable.getPlatformProgress(partialTick);
        renderFixedDisplayItem(
                poseStack,
                bufferSource,
                animatable,
                stack,
                0.0f,
                HELD_ITEM_REST_Y + HELD_ITEM_TRAVEL * progress,
                0.0f,
                HELD_ITEM_SCALE,
                packedLight,
                packedOverlay
        );
    }
}
