package dev.elifian.chaoslib.api.example;

import dev.elifian.chaoslib.api.model.GeoModel;
import dev.elifian.chaoslib.model.AnimatedBoneSelection;
import net.minecraft.resources.ResourceLocation;

import java.util.Set;

/**
 * Client model for {@link MultipartMobExample}.
 *
 * <p>Multipart owners have to export their tracked bones every frame, so {@link #getTrackedBones}
 * forwards the bones registered by the entity and the pose cache stays off; otherwise the hitboxes
 * would lag a frame behind the rendered pose.</p>
 */
public final class MultipartMobModelExample extends GeoModel<MultipartMobExample> {
    public static final MultipartMobModelExample INSTANCE = new MultipartMobModelExample();

    private MultipartMobModelExample() {
    }

    @Override
    public ResourceLocation getModelResource(MultipartMobExample animatable) {
        return MultipartMobExample.MODEL;
    }

    @Override
    public ResourceLocation getTextureResource(MultipartMobExample animatable) {
        return MultipartMobExample.TEXTURE;
    }

    @Override
    public ResourceLocation getAnimationResource(MultipartMobExample animatable) {
        return MultipartMobExample.ANIMATION;
    }

    @Override
    public AnimatedBoneSelection getLiveRenderBones(MultipartMobExample animatable) {
        return AnimatedBoneSelection.all();
    }

    @Override
    public Set<String> getTrackedBones(MultipartMobExample animatable) {
        return animatable.getTrackedBones();
    }

    @Override
    public boolean usePoseCache(MultipartMobExample animatable) {
        return false;
    }
}
