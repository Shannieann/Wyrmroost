package dev.elifian.chaoslib.api.example;

import dev.elifian.chaoslib.api.animatable.GeoBlockEntity;
import dev.elifian.chaoslib.api.animation.AnimatableManager;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import org.jetbrains.annotations.Nullable;

/**
 * Block entity whose bone pose is written directly from gameplay state instead of an animation file.
 * Use this shape when an animation controller would only mirror a numeric field such as progress,
 * rotation, pressure, or fill level.
 *
 * <p>The platform rises and sinks on a loop, and the item placed on it rides along with the
 * {@code platform} bone; {@link ProceduralBlockRendererExample} shows how an item is anchored.</p>
 *
 * <p>{@link #getPoseKey()} returns the animation tick: the GPU pose cache reuses one uploaded pose
 * per key, so every block at the same point of its cycle shares a single pose buffer.</p>
 */
public class ProceduralBlockEntityExample extends BlockEntity implements GeoBlockEntity {
    private static final int RISE_TICKS = 16;
    private static final int HOLD_TICKS = 12;
    private static final int SINK_TICKS = 16;
    private static final int IDLE_TICKS = 16;
    private static final int CYCLE_TICKS = RISE_TICKS + HOLD_TICKS + SINK_TICKS + IDLE_TICKS;

    private final AABB renderBoundingBox;
    private int animTick;
    private ItemStack heldStack = ItemStack.EMPTY;

    public ProceduralBlockEntityExample(BlockPos pos, BlockState state) {
        super(ChaosExampleContent.proceduralBlockEntity(), pos, state);
        this.renderBoundingBox = new AABB(pos).inflate(0.5d);
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
    }

    @Override
    public boolean hasLivePose() {
        return true;
    }

    @Override
    public Object getPoseKey() {
        return this.animTick;
    }

    @Override
    public boolean hasRenderAdditions() {
        return !this.heldStack.isEmpty();
    }

    public AABB getRenderBoundingBox() {
        return this.renderBoundingBox;
    }

    public float getPlatformProgress(float partialTick) {
        float tick = (this.animTick + partialTick) % CYCLE_TICKS;

        if (tick < RISE_TICKS) {
            return easeInOutCubic(tick / RISE_TICKS);
        }
        tick -= RISE_TICKS;

        if (tick < HOLD_TICKS) {
            return 1.0f;
        }
        tick -= HOLD_TICKS;

        if (tick < SINK_TICKS) {
            return 1.0f - easeInOutCubic(tick / SINK_TICKS);
        }
        return 0.0f;
    }

    public ItemStack getHeldStack() {
        return this.heldStack;
    }

    public void setHeldStack(ItemStack stack) {
        this.heldStack = stack.copy();
        this.setChanged();
        if (this.level != null && !this.level.isClientSide) {
            this.level.sendBlockUpdated(this.worldPosition, this.getBlockState(), this.getBlockState(), 3);
        }
    }

    public static void tick(Level level, BlockPos pos, BlockState state, ProceduralBlockEntityExample blockEntity) {
        blockEntity.animTick = (blockEntity.animTick + 1) % CYCLE_TICKS;
    }

    private static float easeInOutCubic(float t) {
        return t < 0.5f
                ? 4.0f * t * t * t
                : 1.0f - (float) Math.pow(-2.0f * t + 2.0f, 3.0d) / 2.0f;
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        if (!this.heldStack.isEmpty()) {
            tag.put("HeldItem", this.heldStack.save(registries));
        }
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        this.heldStack = tag.contains("HeldItem")
                ? ItemStack.parse(registries, tag.getCompound("HeldItem")).orElse(ItemStack.EMPTY)
                : ItemStack.EMPTY;
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return this.saveWithoutMetadata(registries);
    }

    @Override
    public @Nullable Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
