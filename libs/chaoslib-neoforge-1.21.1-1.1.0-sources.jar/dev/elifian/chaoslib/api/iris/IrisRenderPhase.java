package dev.elifian.chaoslib.api.iris;

/**
 * Iris pipeline phase used while custom geometry is submitted.
 *
 * <p>The phase tells Iris which shader-pack program and material context should be used for a
 * custom draw. Use the most specific phase that matches the rendered object.</p>
 */
public enum IrisRenderPhase {
    /** No entity-specific pipeline state. Intended for generic or already-managed draws. */
    NONE,

    /** Entity and item geometry, including custom entity models and dropped-item renderers. */
    ENTITIES,

    /** Block-entity geometry rendered outside the vanilla block-entity buffer path. */
    BLOCK_ENTITIES,

    /** Outline-only geometry. */
    OUTLINE
}
