package dev.elifian.chaoslib.api.iris;

import dev.elifian.chaoslib.compat.iris.IrisCompatInternal;
import dev.elifian.chaoslib.gpu.render.ChaosShaderRenderPhase;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.world.level.block.entity.BlockEntity;
import org.jetbrains.annotations.Nullable;

import java.util.function.Supplier;

/**
 * Entry point for optional Iris shader-pack integration.
 *
 * <p>Callers do not need a compile-time or runtime dependency on Iris. Every operation falls back
 * to vanilla behavior when Iris is missing or shader packs are disabled.</p>
 *
 * <p>Buffered entity renderers should normally obtain their vertex consumer like this:</p>
 * <pre>{@code
 * RenderType normal = MyRenderTypes.effect(texture);
 * RenderType shadow = RenderType.entityCutoutNoCull(texture);
 * VertexConsumer vertices = buffers.getBuffer(
 *         IrisCompat.wrapEntityRenderLayer(normal, shadow));
 * }</pre>
 *
 * <p>The dedicated shadow layer must write depth. It lets translucent or custom-effect geometry
 * cast a stable shader-pack shadow without changing its normal appearance.</p>
 */
public final class IrisCompat {
    private IrisCompat() {
    }

    /**
     * Checks whether the Iris mod is loaded.
     *
     * @return {@code true} when Iris is present, regardless of shader-pack state
     */
    public static boolean isIrisLoaded() {
        return IrisCompatInternal.isIrisLoaded();
    }

    /**
     * Checks whether Iris is currently using a shader pack.
     *
     * @return {@code true} only when Iris is loaded and a shader pack is enabled
     */
    public static boolean isShaderPackActive() {
        return IrisCompatInternal.isIrisShaderPackActive();
    }

    /**
     * Checks whether Iris is currently rendering its shadow map.
     *
     * @return {@code true} during the Iris shadow pass
     */
    public static boolean isShadowPassActive() {
        return IrisCompatInternal.isShadowPassActive();
    }

    /**
     * Associates a render layer with an Iris pipeline phase.
     *
     * <p>The original layer is returned when Iris integration is inactive. Prefer the specialized
     * entity, block-entity, and outline methods when possible.</p>
     *
     * @param renderLayer layer used to submit geometry
     * @param phase pipeline phase represented by the geometry
     * @return an Iris-aware layer, or {@code renderLayer} when integration is inactive
     */
    public static RenderType wrapRenderLayer(RenderType renderLayer, IrisRenderPhase phase) {
        return IrisCompatInternal.wrapRenderLayer(renderLayer, internalPhase(phase));
    }

    /**
     * Associates a render layer with the Iris entity phase.
     *
     * @param renderLayer entity render layer
     * @return an Iris-aware entity layer, or {@code renderLayer} when integration is inactive
     */
    public static RenderType wrapEntityRenderLayer(RenderType renderLayer) {
        return IrisCompatInternal.wrapEntityRenderLayer(renderLayer);
    }

    /**
     * Selects a dedicated entity layer during the Iris shadow pass and associates the selected
     * layer with the Iris entity phase.
     *
     * <p>Use this overload for translucent layers and custom shaders. The shadow layer should use
     * the same silhouette texture and must write depth; {@link RenderType#entityCutoutNoCull} is a
     * suitable default for textured models.</p>
     *
     * @param renderLayer layer used during normal world rendering
     * @param shadowRenderLayer depth-writing layer used while Iris renders its shadow map
     * @return the selected Iris-aware layer; returns {@code renderLayer} unchanged without an
     *         active shader pack
     */
    public static RenderType wrapEntityRenderLayer(RenderType renderLayer, RenderType shadowRenderLayer) {
        return IrisCompatInternal.wrapEntityRenderLayer(renderLayer, shadowRenderLayer);
    }

    /**
     * Associates a render layer with the Iris block-entity phase.
     *
     * @param renderLayer block-entity render layer
     * @return an Iris-aware block-entity layer, or the original layer when integration is inactive
     */
    public static RenderType wrapBlockEntityRenderLayer(RenderType renderLayer) {
        return IrisCompatInternal.wrapBlockEntityRenderLayer(renderLayer);
    }

    /**
     * Associates a render layer with the Iris outline phase.
     *
     * @param renderLayer outline render layer
     * @return an Iris-aware outline layer, or the original layer when integration is inactive
     */
    public static RenderType wrapOutlineRenderLayer(RenderType renderLayer) {
        return IrisCompatInternal.wrapOutlineRenderLayer(renderLayer);
    }

    /**
     * Executes an immediate custom draw inside an Iris pipeline phase.
     *
     * <p>For geometry submitted through {@link RenderType} buffers, prefer wrapping the render
     * layer instead.</p>
     *
     * @param phase phase active while {@code action} runs
     * @param action rendering operation to execute
     */
    public static void withPhase(IrisRenderPhase phase, Runnable action) {
        IrisCompatInternal.withPhase(internalPhase(phase), action);
    }

    /**
     * Executes an operation inside an Iris pipeline phase and returns its result.
     *
     * @param phase phase active while {@code action} runs
     * @param action operation to execute
     * @param <T> result type
     * @return value returned by {@code action}
     */
    public static <T> T withPhase(IrisRenderPhase phase, Supplier<T> action) {
        return IrisCompatInternal.withPhase(internalPhase(phase), action);
    }

    /**
     * Executes block-entity rendering with the Iris material id for the supplied block state.
     *
     * @param blockEntity block entity whose material context should be exposed to Iris
     * @param action rendering operation to execute
     */
    public static void withBlockEntityContext(BlockEntity blockEntity, Runnable action) {
        IrisCompatInternal.withBlockEntityContext(blockEntity, action);
    }

    /**
     * Returns the Iris material-map id of the entity currently being rendered.
     *
     * @return current entity id, or {@code 0} when Iris integration is inactive
     */
    public static int currentRenderedEntityId() {
        return IrisCompatInternal.currentRenderedEntityId();
    }

    /**
     * Returns the Iris material-map id of the block entity currently being rendered.
     *
     * @return current block-entity id, or {@code 0} when Iris integration is inactive
     */
    public static int currentRenderedBlockEntityId() {
        return IrisCompatInternal.currentRenderedBlockEntityId();
    }

    /**
     * Returns the Iris material-map id of the item currently being rendered.
     *
     * @return current item id, or {@code 0} when Iris integration is inactive
     */
    public static int currentRenderedItemId() {
        return IrisCompatInternal.currentRenderedItemId();
    }

    /**
     * Runs vertex submission with Iris extended vertex-format writes temporarily disabled.
     *
     * <p>Use this around custom buffers that explicitly emit the vanilla vertex format and cannot
     * provide Iris extended attributes.</p>
     *
     * @param action vertex submission operation
     */
    public static void withVanillaVertexFormatState(Runnable action) {
        IrisCompatInternal.withVanillaVertexFormatState(action);
    }

    /**
     * Clears cached Iris wrappers and compiled shader-pack delegates.
     *
     * <p>Mods normally do not need to call this. It is intended for renderer/resource reload
     * integration.</p>
     */
    public static void invalidateCaches() {
        IrisCompatInternal.invalidateCaches();
    }

    static @Nullable ShaderInstance shadowShader(IrisRenderPhase phase) {
        return IrisCompatInternal.getShadowShader(internalPhase(phase));
    }

    private static ChaosShaderRenderPhase internalPhase(IrisRenderPhase phase) {
        return switch (phase) {
            case NONE -> ChaosShaderRenderPhase.NONE;
            case ENTITIES -> ChaosShaderRenderPhase.ENTITIES;
            case BLOCK_ENTITIES -> ChaosShaderRenderPhase.BLOCK_ENTITIES;
            case OUTLINE -> ChaosShaderRenderPhase.OUTLINE;
        };
    }
}
