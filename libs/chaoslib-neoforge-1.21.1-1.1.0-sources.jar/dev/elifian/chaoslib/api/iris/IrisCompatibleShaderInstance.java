package dev.elifian.chaoslib.api.iris;

import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceProvider;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.util.Objects;

/**
 * Vanilla-compatible core shader with automatic Iris shadow-program delegation.
 *
 * <p>The configured core shader is used during normal rendering. While Iris renders its shadow
 * map, {@link #apply()} activates the shader pack's matching shadow program instead. When Iris is
 * absent or shader packs are disabled, this class behaves like a regular {@link ShaderInstance}.</p>
 *
 * <p>Buffered translucent or effect renderers should also use
 * {@link IrisCompat#wrapEntityRenderLayer(RenderType, RenderType)} with a depth-writing shadow
 * layer. Shader delegation alone cannot add depth writes that the original render layer disabled.</p>
 */
public class IrisCompatibleShaderInstance extends ShaderInstance {
    private final IrisRenderPhase phase;
    private @Nullable ShaderInstance shadowDelegate;

    /**
     * Creates an entity-phase compatible shader.
     *
     * @param resourceProvider provider used to load the core shader resources
     * @param shaderLocation shader id, resolved as {@code shaders/core/<namespace>:<path>.json}
     * @param vertexFormat vertex format consumed by the shader
     * @throws IOException when the core shader resources cannot be loaded or compiled
     */
    public IrisCompatibleShaderInstance(
            ResourceProvider resourceProvider, ResourceLocation shaderLocation, VertexFormat vertexFormat)
            throws IOException {
        this(resourceProvider, shaderLocation, vertexFormat, IrisRenderPhase.ENTITIES);
    }

    /**
     * Creates a compatible shader for an explicit Iris pipeline phase.
     *
     * @param resourceProvider provider used to load the core shader resources
     * @param shaderLocation shader id, passed to vanilla as its {@code namespace:path} string
     * @param vertexFormat vertex format consumed by the shader
     * @param phase Iris phase whose shader-pack program should be used during shadow rendering
     * @throws IOException when the core shader resources cannot be loaded or compiled
     */
    public IrisCompatibleShaderInstance(
            ResourceProvider resourceProvider,
            ResourceLocation shaderLocation,
            VertexFormat vertexFormat,
            IrisRenderPhase phase
    ) throws IOException {
        super(resourceProvider, shaderLocation.toString(), vertexFormat);
        this.phase = Objects.requireNonNull(phase, "phase");
    }

    @Override
    public void apply() {
        ShaderInstance delegate = IrisCompat.shadowShader(this.phase);
        this.shadowDelegate = delegate;
        if (delegate != null) {
            delegate.apply();
        } else {
            super.apply();
        }
    }

    @Override
    public void clear() {
        ShaderInstance delegate = this.shadowDelegate;
        this.shadowDelegate = null;
        if (delegate != null) {
            delegate.clear();
        } else {
            super.clear();
        }
    }

    /**
     * Iris compatibility hook matching the virtual method injected into {@link ShaderInstance}.
     *
     * @return always {@code false}; the instance must remain active so it can delegate shadow draws
     */
    @SuppressWarnings("unused")
    public boolean iris$shouldSkipThis() {
        return false;
    }
}
