package dev.elifian.chaoslib.api.animatable;

import net.minecraft.world.entity.LivingEntity;

/**
 * Marker interface for living entities rendered through ChaosLib geo models.
 *
 * <p>The default implementation exposes the entity age as the animation clock so controllers and
 * model hooks can evaluate against the same tick source used by vanilla living entities.</p>
 */
public interface GeoLivingEntity extends GeoAnimatable {
    /**
     * Returns the animation clock for the current living entity instance.
     */
    @Override
    default double getTick() {
        if (this instanceof LivingEntity livingEntity) {
            return livingEntity.tickCount;
        }

        return 0.0d;
    }
}
