package dev.elifian.chaoslib.api.animatable;

import dev.elifian.chaoslib.api.multipart.GeoTrackedBonePose;
import net.minecraft.world.phys.Vec3;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/**
 * Contract for animatables that receive tracked bone transforms from the client.
 */
public interface GeoBoneTrackingAnimatable {
    /**
     * Returns the bone names that should be tracked for this animatable.
     */
    Set<String> getTrackedBones();

    /**
     * Returns whether this animatable wants tracked bone poses resolved back from the GPU path.
     */
    default boolean requiresGpuBoneTrackingReadback() {
        return false;
    }

    /**
     * Returns the minimum number of ticks between GPU tracked-bone readbacks.
     */
    default int getGpuBoneTrackingReadbackIntervalTicks() {
        return 1;
    }

    /**
     * Applies tracked bone positions without rotation data.
     */
    default void receiveTrackedBonePositions(Map<String, Vec3> positions) {
        if (positions == null || positions.isEmpty()) {
            this.receiveTrackedBonePoses(Map.of());
            return;
        }

        LinkedHashMap<String, GeoTrackedBonePose> poses = new LinkedHashMap<>();
        for (Map.Entry<String, Vec3> entry : positions.entrySet()) {
            poses.put(entry.getKey(), GeoTrackedBonePose.atPosition(entry.getValue()));
        }
        this.receiveTrackedBonePoses(Map.copyOf(poses));
    }

    /**
     * Applies tracked bone poses with position and rotation data.
     */
    default void receiveTrackedBonePoses(Map<String, GeoTrackedBonePose> poses) {
        if (poses == null || poses.isEmpty()) {
            return;
        }

        LinkedHashMap<String, Vec3> positions = new LinkedHashMap<>();
        for (Map.Entry<String, GeoTrackedBonePose> entry : poses.entrySet()) {
            positions.put(entry.getKey(), entry.getValue().position());
        }
        this.receiveTrackedBonePositions(Map.copyOf(positions));
    }
}
