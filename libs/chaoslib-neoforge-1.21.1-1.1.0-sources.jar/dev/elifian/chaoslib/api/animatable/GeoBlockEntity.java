package dev.elifian.chaoslib.api.animatable;

import dev.elifian.chaoslib.animatable.state.GeoRenderStateAccess;
import dev.elifian.chaoslib.animatable.state.GeoRenderStateTracker;
import dev.elifian.chaoslib.animatable.state.GeoTransientSyncState;
import dev.elifian.chaoslib.animatable.sync.GeoBlockTransientSyncHelper;
import dev.elifian.chaoslib.api.renderer.GeoBlockRenderer;
import dev.elifian.chaoslib.compat.sodium.ChaosSodiumBlockEntitySettings;
import dev.elifian.chaoslib.model.baked.StaticGeoRenderMode;
import dev.elifian.chaoslib.renderer.block.ChaosBlockEntityRenderFrameClock;
import net.minecraft.client.Minecraft;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.Consumer;

/**
 * Extends a block entity with ChaosLib animation, renderer-state, static-bake, and transient-sync
 * hooks.
 *
 * <p>Implement this interface on block entities that are rendered through
 * {@link GeoBlockRenderer}. The interface centralizes decisions about
 * when live geo rendering is active, when static baked rendering may be used, and how temporary
 * visual state is synchronized to tracking clients.</p>
 */
public interface GeoBlockEntity extends GeoAnimatable {
    /**
     * Returns whether this block entity is currently changing its live pose.
     */
    boolean hasLivePose();

    /**
     * Returns the pose key used for GPU/local pose caching.
     */
    @Override
    Object getPoseKey();

    /**
     * Returns the animation clock for the current block entity instance.
     */
    @Override
    default double getTick() {
        if (this instanceof BlockEntity blockEntity && blockEntity.getLevel() != null) {
            return blockEntity.getLevel().getGameTime();
        }

        return 0.0d;
    }

    /**
     * Returns how long the block entity should remain on BER after the last active animation tick.
     */
    default int getGeoRenderPostAnimationHoldTicks() {
        return 20;
    }

    /**
     * Returns the number of additional client ticks to keep BER alive after the live geo state
     * deactivates, giving static ModelData/chunk rebuilds one frame to catch up.
     */
    default int getGeoRenderStaticHandoffGraceTicks() {
        return 1;
    }

    /**
     * Returns whether this block entity has extra renderer additions outside the geo model itself.
     */
    default boolean hasRenderAdditions() {
        return false;
    }

    /**
     * Returns whether the geo renderer should currently be considered active.
     */
    default boolean isGeoRenderActive() {
        if (this instanceof BlockEntity blockEntity
                && blockEntity.getLevel() != null
                && blockEntity.getLevel().isClientSide()
                && ((GeoRenderStateAccess) blockEntity).isGeoModelDataOnly()) {
            return false;
        }

        if (this instanceof BlockEntity blockEntity && (blockEntity.getLevel() == null || !blockEntity.getLevel().isClientSide())) {
            return this.hasLivePose();
        }

        GeoRenderStateAccess state = (GeoRenderStateAccess) this;
        int frameId = ChaosBlockEntityRenderFrameClock.frameId();
        if (state.getGeoRenderActiveLastFrameId() == frameId) {
            return state.getGeoRenderActiveCachedValue();
        }

        boolean active = GeoRenderStateTracker.isActive(this);
        state.setGeoRenderActiveLastFrameId(frameId);
        state.setGeoRenderActiveCachedValue(active);
        return active;
    }

    /**
     * Returns whether a short BER grace window is active after live geo rendering deactivated,
     * allowing static chunk/modeldata rendering to catch up without a visible hole.
     */
    default boolean isGeoRenderDeactivateGraceActive() {
        if (!(this instanceof BlockEntity blockEntity)
                || blockEntity.getLevel() == null
                || !blockEntity.getLevel().isClientSide()) {
            return false;
        }

        return ((GeoRenderStateAccess) blockEntity).getGeoRenderDeactivateGraceRemainingTicks() > 0;
    }

    /**
     * Returns whether the block entity renderer should execute for this tick.
     */
    default boolean shouldRunBlockEntityRenderer() {
        if (!(this instanceof BlockEntity blockEntity) || blockEntity.getLevel() == null) {
            return this.isGeoRenderActive() || this.hasRenderAdditions();
        }

        if (!blockEntity.getLevel().isClientSide()) {
            return this.hasLivePose() || this.hasRenderAdditions();
        }

        GeoRenderStateAccess state = (GeoRenderStateAccess) blockEntity;
        if (state.isGeoModelDataOnly() && shouldExitGeoModelDataOnly(blockEntity)) {
            state.setGeoModelDataOnly(false);
            GeoRenderStateTracker.refreshClientStaticState(blockEntity);
        }

        if (state.isGeoModelDataOnly()) {
            return false;
        }

        int frameId = ChaosBlockEntityRenderFrameClock.frameId();
        if (state.getGeoShouldRenderLastFrameId() == frameId) {
            return state.getGeoShouldRenderCachedValue();
        }

        boolean shouldRender = this.isGeoRenderActive() || this.isGeoRenderDeactivateGraceActive() || this.hasRenderAdditions();
        state.setGeoShouldRenderLastFrameId(frameId);
        state.setGeoShouldRenderCachedValue(shouldRender);
        return shouldRender;
    }

    /**
     * Returns the static render mode to use for the current block state.
     */
    @Nullable
    default StaticGeoRenderMode getGeoStaticRenderMode(BlockState state) {
        if (this instanceof BlockEntity blockEntity
                && blockEntity.getLevel() != null
                && blockEntity.getLevel().isClientSide()
                && ((GeoRenderStateAccess) blockEntity).isGeoModelDataOnly()) {
            return StaticGeoRenderMode.ALL_BONES;
        }

        return this.isGeoRenderActive() ? StaticGeoRenderMode.STATIC_ONLY : null;
    }

    /**
     * Returns the client-side distance after which BER should hand off fully to ModelData-backed
     * static chunk rendering.
     */
    default double getStaticHandoffDistance() {
        return 64.0d;
    }

    /**
     * Returns whether transient client sync should invalidate static ModelData and rebuild the
     * surrounding chunk section.
     *
     * <p>Disabled by default because most transient BER animation updates only affect the live geo
     * path and do not need chunk rebuilds.</p>
     */
    default boolean rebuildStaticModelOnTransientSync() {
        return false;
    }

    private boolean shouldExitGeoModelDataOnly(BlockEntity blockEntity) {
        Minecraft client = Minecraft.getInstance();
        if (client == null || client.gameRenderer == null || client.gameRenderer.getMainCamera() == null) {
            return false;
        }

        double transitionDistance = ChaosSodiumBlockEntitySettings.resolveModelDataTransitionDistance(blockEntity, this.getStaticHandoffDistance());
        if (transitionDistance <= 0.0d) {
            return true;
        }

        Vec3 cameraPos = client.gameRenderer.getMainCamera().getPosition();
        double centerX = blockEntity.getBlockPos().getX() + 0.5d;
        double centerY = blockEntity.getBlockPos().getY() + 0.5d;
        double centerZ = blockEntity.getBlockPos().getZ() + 0.5d;
        double dx = centerX - cameraPos.x;
        double dy = centerY - cameraPos.y;
        double dz = centerZ - cameraPos.z;
        return dx * dx + dy * dy + dz * dz <= transitionDistance * transitionDistance;
    }

    /**
     * Returns the static pose variant key to use for the current block state.
     */
    @Nullable
    default String getStaticPoseKey(BlockState state) {
        return null;
    }

    /**
     * Returns the transient sync state used to rate-limit server-to-client visual sync.
     */
    default GeoTransientSyncState getTransientState() {
        return null;
    }

    /**
     * Returns the minimum number of ticks between transient sync flushes.
     */
    default long getTransientSyncIntervalTicks() {
        return 2L;
    }

    /**
     * Marks transient visual state as dirty for later server-to-client sync.
     */
    default void requestTransientSync() {
        GeoBlockTransientSyncHelper.request(this.getTransientState());
    }

    /**
     * Flushes transient visual state if a sync is pending and the interval has elapsed.
     */
    default void flushTransientSyncIfNeeded() {
        if (!(this instanceof BlockEntity blockEntity)) {
            return;
        }

        GeoBlockTransientSyncHelper.flushIfNeeded(
                blockEntity,
                this.getTransientState(),
                this.getTransientSyncIntervalTicks(),
                () -> this.sendTransientSync((ServerLevel) blockEntity.getLevel())
        );
    }

    /**
     * Sends transient visual state to clients tracking this block entity.
     */
    default void sendTransientSync(ServerLevel serverWorld) {
    }

    /**
     * Returns players currently tracking the chunk that contains this block entity.
     */
    default List<ServerPlayer> getChunkTrackingPlayers(ServerLevel serverWorld) {
        if (!(this instanceof BlockEntity blockEntity)) {
            return List.of();
        }

        return GeoBlockTransientSyncHelper.getChunkTrackingPlayers(blockEntity, serverWorld);
    }

    /**
     * Invokes a callback for each tracked player inside the given radius.
     */
    default void forEachTransientSyncPlayer(ServerLevel serverWorld, double radiusSquared, Consumer<ServerPlayer> consumer) {
        if (!(this instanceof BlockEntity blockEntity)) {
            return;
        }

        GeoBlockTransientSyncHelper.forEachPlayerInRange(blockEntity, serverWorld, radiusSquared, consumer);
    }
}
