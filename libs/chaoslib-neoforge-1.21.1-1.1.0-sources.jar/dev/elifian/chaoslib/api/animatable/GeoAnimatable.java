package dev.elifian.chaoslib.api.animatable;

import dev.elifian.chaoslib.animatable.cache.AnimatableInstanceCache;
import dev.elifian.chaoslib.animatable.cache.AnimatableInstanceCacheStore;
import dev.elifian.chaoslib.api.animation.AnimatableManager;

/**
 * Base contract for animatable objects used by ChaosLib animation and model systems.
 */
public interface GeoAnimatable {
    /**
     * Registers animation controllers for this animatable instance.
     */
    void registerControllers(AnimatableManager.ControllerRegistrar controllers);

    /**
     * Returns the instance cache that stores runtime animation state.
     */
    default AnimatableInstanceCache getAnimatableInstanceCache() {
        return AnimatableInstanceCacheStore.get(this);
    }

    /**
     * Returns the current animation tick for this animatable.
     */
    default double getTick() {
        return 0.0d;
    }

    /**
     * Returns a stable key that changes whenever the visible pose changes.
     */
    default Object getPoseKey() {
        return this;
    }
}
