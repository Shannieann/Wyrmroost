package dev.elifian.chaoslib.api.molang;

import org.jetbrains.annotations.Nullable;

import java.util.List;

public interface MolangApiQueryResolver {
    @Nullable MolangValue resolveValue(String normalizedPath, MolangContext context);

    @Nullable MolangValue resolveCall(String normalizedName, List<MolangValue> args, MolangContext context);
}
