package dev.elifian.chaoslib.api.molang;

import dev.elifian.chaoslib.molang.MolangQueryResolvers;
import dev.elifian.chaoslib.molang.MolangRuntime;

import java.util.List;
import java.util.Map;

public final class Molang {
    private Molang() {
    }

    public static MolangExpression parse(String source) {
        MolangRuntime.MolangExpression expression = MolangRuntime.parse(source);
        return new WrappedMolangExpression(expression);
    }

    public static MolangExpression constant(double value) {
        MolangRuntime.MolangExpression expression = MolangRuntime.constant(value);
        return new WrappedMolangExpression(expression);
    }

    public static MolangExpression constant(String value) {
        MolangRuntime.MolangExpression expression = MolangRuntime.constant(value);
        return new WrappedMolangExpression(expression);
    }

    public static boolean isConstant(MolangExpression expression) {
        if (expression instanceof WrappedMolangExpression wrapped) {
            return MolangRuntime.isConstant(wrapped.delegate());
        }
        return false;
    }

    public static MolangValue constantValue(MolangExpression expression) {
        if (expression instanceof WrappedMolangExpression wrapped) {
            return MolangAdapters.wrap(MolangRuntime.constantValue(wrapped.delegate()));
        }
        return MolangValue.NULL;
    }

    public static MolangMutableContext mutableContext() {
        return new MolangMutableContext();
    }

    public static MolangApiQueryResolver emptyResolver() {
        return MolangAdapters.wrap(MolangQueryResolvers.empty());
    }

    public static MolangApiQueryResolver standardResolver() {
        return MolangAdapters.wrap(MolangQueryResolvers.standard());
    }

    public static MolangApiQueryResolver queryResolver(MolangApiQueryProvider provider) {
        return new MolangApiQueryResolver() {
            @Override
            public MolangValue resolveValue(String normalizedPath, MolangContext context) {
                return provider == null ? null : provider.getQueryValue(normalizedPath);
            }

            @Override
            public MolangValue resolveCall(String normalizedName, List<MolangValue> args, MolangContext context) {
                return provider == null ? null : provider.callQuery(normalizedName, args);
            }
        };
    }

    public static MolangApiQueryProvider compositeProvider(MolangApiQueryProvider... providers) {
        return new MolangApiQueryProvider() {
            @Override
            public MolangValue getQueryValue(String normalizedPath) {
                for (MolangApiQueryProvider provider : providers) {
                    if (provider == null) {
                        continue;
                    }
                    MolangValue value = provider.getQueryValue(normalizedPath);
                    if (value != null) {
                        return value;
                    }
                }
                return null;
            }

            @Override
            public MolangValue callQuery(String normalizedName, List<MolangValue> args) {
                for (MolangApiQueryProvider provider : providers) {
                    if (provider == null) {
                        continue;
                    }
                    MolangValue value = provider.callQuery(normalizedName, args);
                    if (value != null) {
                        return value;
                    }
                }
                return null;
            }
        };
    }

    public static MolangValue number(double value) {
        return MolangValue.number(value);
    }

    public static MolangValue string(String value) {
        return MolangValue.string(value);
    }

    public static MolangValue bool(boolean value) {
        return value ? MolangValue.TRUE : MolangValue.FALSE;
    }

    public static MolangValue array(List<MolangValue> values) {
        return MolangValue.array(values);
    }

    public static MolangValue object(Map<String, MolangValue> values) {
        return MolangValue.object(values);
    }

    private record WrappedMolangExpression(MolangRuntime.MolangExpression delegate) implements MolangExpression {
        @Override
        public MolangValue evaluate(MolangContext context) {
            return MolangAdapters.wrap(this.delegate.evaluate(MolangAdapters.unwrap(context)));
        }
    }
}
