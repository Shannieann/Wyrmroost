package dev.elifian.chaoslib.api.molang;

import dev.elifian.chaoslib.molang.MolangRuntime;

import java.util.List;
import java.util.function.Supplier;

public final class MolangMutableContext implements MolangContext {
    private final MolangRuntime.MutableContext delegate;

    public MolangMutableContext() {
        this(new MolangRuntime.MutableContext());
    }

    private MolangMutableContext(MolangRuntime.MutableContext delegate) {
        this.delegate = delegate;
    }

    MolangRuntime.MutableContext delegate() {
        return this.delegate;
    }

    public MolangMutableContext withValue(String path, double value) {
        this.delegate.withValue(path, value);
        return this;
    }

    public MolangMutableContext withValue(String path, String value) {
        this.delegate.withValue(path, value);
        return this;
    }

    public MolangMutableContext withValue(String path, MolangValue value) {
        this.delegate.withValue(path, value == null ? MolangRuntime.MolangValue.NULL : value.delegate());
        return this;
    }

    public MolangMutableContext withValueSupplier(String path, Supplier<MolangValue> valueSupplier) {
        this.delegate.withValueSupplier(path, () -> MolangAdapters.unwrap(valueSupplier == null ? null : valueSupplier.get()));
        return this;
    }

    public MolangMutableContext withReadonlyValue(String path, double value) {
        this.delegate.withReadonlyValue(path, value);
        return this;
    }

    public MolangMutableContext withReadonlyValue(String path, String value) {
        this.delegate.withReadonlyValue(path, value);
        return this;
    }

    public MolangMutableContext withReadonlyValue(String path, MolangValue value) {
        this.delegate.withReadonlyValue(path, value == null ? MolangRuntime.MolangValue.NULL : value.delegate());
        return this;
    }

    public MolangMutableContext withReadonlyValueSupplier(String path, Supplier<MolangValue> valueSupplier) {
        this.delegate.withReadonlyValueSupplier(path, () -> MolangAdapters.unwrap(valueSupplier == null ? null : valueSupplier.get()));
        return this;
    }

    public MolangMutableContext withThis(MolangValue value) {
        this.delegate.withThis(value == null ? MolangRuntime.MolangValue.NULL : value.delegate());
        return this;
    }

    public MolangMutableContext withQueryResolver(MolangApiQueryResolver queryResolver) {
        this.delegate.withQueryResolver(MolangAdapters.adapt(queryResolver));
        return this;
    }

    public MolangMutableContext withQueryProvider(MolangApiQueryProvider queryProvider) {
        return this.withQueryResolver(Molang.queryResolver(queryProvider));
    }

    public MolangMutableContext reset() {
        this.delegate.reset();
        return this;
    }

    @Override
    public MolangValue get(String path) {
        return MolangAdapters.wrap(this.delegate.get(path));
    }

    @Override
    public void set(String path, MolangValue value) {
        this.delegate.set(path, MolangAdapters.unwrap(value));
    }

    @Override
    public void setLazy(String path, Supplier<MolangValue> valueSupplier) {
        this.delegate.setLazy(path, () -> MolangAdapters.unwrap(valueSupplier == null ? null : valueSupplier.get()));
    }

    @Override
    public MolangValue call(String name, List<MolangValue> args) {
        return MolangAdapters.wrap(this.delegate.call(name, MolangAdapters.unwrapList(args)));
    }

    @Override
    public MolangContext branch(MolangValue thisValue) {
        return new WrappedMolangContext(this.delegate.branch(MolangAdapters.unwrap(thisValue)));
    }
}
