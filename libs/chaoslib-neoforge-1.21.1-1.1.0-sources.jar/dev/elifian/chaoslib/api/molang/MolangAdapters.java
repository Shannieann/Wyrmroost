package dev.elifian.chaoslib.api.molang;

import dev.elifian.chaoslib.molang.MolangQueryResolver;
import dev.elifian.chaoslib.molang.MolangQueryResolvers;
import dev.elifian.chaoslib.molang.MolangRuntime;
import org.jetbrains.annotations.Nullable;

import java.util.List;

final class MolangAdapters {
    private MolangAdapters() {
    }

    static MolangValue wrap(MolangRuntime.MolangValue value) {
        return new MolangValue(value);
    }

    static MolangRuntime.MolangValue unwrap(@Nullable MolangValue value) {
        return value == null ? MolangRuntime.MolangValue.NULL : value.delegate();
    }

    static List<MolangRuntime.MolangValue> unwrapList(List<MolangValue> values) {
        return values.stream().map(MolangAdapters::unwrap).toList();
    }

    static MolangRuntime.Context unwrap(MolangContext context) {
        if (context instanceof MolangMutableContext mutableContext) {
            return mutableContext.delegate();
        }
        if (context instanceof WrappedMolangContext wrapped) {
            return wrapped.delegate();
        }
        throw new IllegalArgumentException("Unsupported MolangContext implementation: " + context.getClass().getName());
    }

    static MolangQueryResolver adapt(MolangApiQueryResolver resolver) {
        if (resolver == null) {
            return MolangQueryResolvers.empty();
        }
        return new MolangQueryResolver() {
            @Override
            public MolangRuntime.MolangValue resolveValue(String normalizedPath, MolangRuntime.Context context) {
                return unwrap(resolver.resolveValue(normalizedPath, new WrappedMolangContext(context)));
            }

            @Override
            public MolangRuntime.MolangValue resolveCall(String normalizedName, List<MolangRuntime.MolangValue> args, MolangRuntime.Context context) {
                List<MolangValue> wrappedArgs = args.stream().map(MolangAdapters::wrap).toList();
                return unwrap(resolver.resolveCall(normalizedName, wrappedArgs, new WrappedMolangContext(context)));
            }
        };
    }

    static MolangApiQueryResolver wrap(MolangQueryResolver resolver) {
        return new MolangApiQueryResolver() {
            @Override
            public MolangValue resolveValue(String normalizedPath, MolangContext context) {
                return MolangAdapters.wrap(resolver.resolveValue(normalizedPath, unwrap(context)));
            }

            @Override
            public MolangValue resolveCall(String normalizedName, List<MolangValue> args, MolangContext context) {
                return MolangAdapters.wrap(resolver.resolveCall(normalizedName, unwrapList(args), unwrap(context)));
            }
        };
    }
}
