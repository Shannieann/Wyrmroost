package dev.elifian.chaoslib.api.molang;

@FunctionalInterface
public interface MolangExpression {
    MolangValue evaluate(MolangContext context);

    default double evaluateNumber(MolangContext context) {
        return this.evaluate(context).asNumber();
    }
}

