package dev.elifian.chaoslib.api.molang;

import java.util.List;
import java.util.function.Supplier;

public interface MolangContext {
    MolangValue get(String path);

    void set(String path, MolangValue value);

    void setLazy(String path, Supplier<MolangValue> valueSupplier);

    MolangValue call(String name, List<MolangValue> args);

    MolangContext branch(MolangValue thisValue);
}

