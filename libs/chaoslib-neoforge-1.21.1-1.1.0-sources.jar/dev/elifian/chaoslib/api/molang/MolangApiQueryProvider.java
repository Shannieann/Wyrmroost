package dev.elifian.chaoslib.api.molang;

import org.jetbrains.annotations.Nullable;

import java.util.List;

public interface MolangApiQueryProvider {
    default @Nullable MolangValue getQueryValue(String normalizedPath) {
        return null;
    }

    default @Nullable MolangValue callQuery(String normalizedName, List<MolangValue> args) {
        return null;
    }
}
