package dev.elifian.chaoslib.api.molang;

import dev.elifian.chaoslib.molang.MolangRuntime;

import java.util.List;
import java.util.function.Supplier;

final class WrappedMolangContext implements MolangContext {
    private final MolangRuntime.Context delegate;

    WrappedMolangContext(MolangRuntime.Context delegate) {
        this.delegate = delegate;
    }

    MolangRuntime.Context delegate() {
        return this.delegate;
    }

    @Override
    public MolangValue get(String path) {
        return MolangAdapters.wrap(this.delegate.get(path));
    }

    @Override
    public void set(String path, MolangValue value) {
        this.delegate.set(path, MolangAdapters.unwrap(value));
    }

    @Override
    public void setLazy(String path, Supplier<MolangValue> valueSupplier) {
        this.delegate.setLazy(path, () -> MolangAdapters.unwrap(valueSupplier == null ? null : valueSupplier.get()));
    }

    @Override
    public MolangValue call(String name, List<MolangValue> args) {
        return MolangAdapters.wrap(this.delegate.call(name, MolangAdapters.unwrapList(args)));
    }

    @Override
    public MolangContext branch(MolangValue thisValue) {
        return new WrappedMolangContext(this.delegate.branch(MolangAdapters.unwrap(thisValue)));
    }
}
