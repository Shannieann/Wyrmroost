package dev.elifian.chaoslib.api.molang;

import dev.elifian.chaoslib.molang.MolangRuntime;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class MolangValue {
    public enum Type {
        NULL,
        NUMBER,
        STRING,
        ARRAY,
        OBJECT
    }

    public static final MolangValue NULL = new MolangValue(MolangRuntime.MolangValue.NULL);
    public static final MolangValue ZERO = new MolangValue(MolangRuntime.MolangValue.ZERO);
    public static final MolangValue ONE = new MolangValue(MolangRuntime.MolangValue.ONE);
    public static final MolangValue TRUE = ONE;
    public static final MolangValue FALSE = ZERO;

    private final MolangRuntime.MolangValue delegate;

    MolangValue(MolangRuntime.MolangValue delegate) {
        this.delegate = delegate == null ? MolangRuntime.MolangValue.NULL : delegate;
    }

    MolangRuntime.MolangValue delegate() {
        return this.delegate;
    }

    public static MolangValue number(double value) {
        return new MolangValue(MolangRuntime.MolangValue.number(value));
    }

    public static MolangValue string(String value) {
        return new MolangValue(MolangRuntime.MolangValue.string(value));
    }

    public static MolangValue array(List<MolangValue> values) {
        return new MolangValue(MolangRuntime.MolangValue.array(
                values.stream().map(MolangValue::delegate).toList()
        ));
    }

    public static MolangValue object(Map<String, MolangValue> values) {
        LinkedHashMap<String, MolangRuntime.MolangValue> map = new LinkedHashMap<>();
        for (Map.Entry<String, MolangValue> entry : values.entrySet()) {
            map.put(entry.getKey(), entry.getValue() == null ? MolangRuntime.MolangValue.NULL : entry.getValue().delegate());
        }
        return new MolangValue(MolangRuntime.MolangValue.object(map));
    }

    public Type type() {
        return switch (this.delegate.type()) {
            case NULL -> Type.NULL;
            case NUMBER -> Type.NUMBER;
            case STRING -> Type.STRING;
            case ARRAY -> Type.ARRAY;
            case OBJECT -> Type.OBJECT;
        };
    }

    public boolean isNull() {
        return this.delegate.isNull();
    }

    public double asNumber() {
        return this.delegate.asNumber();
    }

    public String asString() {
        return this.delegate.asString();
    }

    public List<MolangValue> asArray() {
        return this.delegate.asArray().stream().map(MolangValue::new).toList();
    }

    public Map<String, MolangValue> asObjectMap() {
        LinkedHashMap<String, MolangValue> map = new LinkedHashMap<>();
        for (Map.Entry<String, MolangRuntime.MolangValue> entry : this.delegate.asObjectMap().entrySet()) {
            map.put(entry.getKey(), new MolangValue(entry.getValue()));
        }
        return Map.copyOf(map);
    }

}
