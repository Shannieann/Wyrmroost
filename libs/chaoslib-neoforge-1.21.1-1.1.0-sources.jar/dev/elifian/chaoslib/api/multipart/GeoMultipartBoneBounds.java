package dev.elifian.chaoslib.api.multipart;

/**
 * Stores the local voxel bounds of a tracked bone.
 */
public record GeoMultipartBoneBounds(
        float width,
        float height,
        float depth,
        float centerX,
        float centerY,
        float centerZ,
        float qx,
        float qy,
        float qz,
        float qw
) {
}
