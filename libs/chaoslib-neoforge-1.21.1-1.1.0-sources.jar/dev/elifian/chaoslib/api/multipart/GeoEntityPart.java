package dev.elifian.chaoslib.api.multipart;

import dev.elifian.chaoslib.multipart.interaction.GeoMultipartHitboxMath;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.List;
import java.util.Optional;

/**
 * Runtime representation of a single virtual multipart hitbox bound to a tracked bone.
 *
 * <p>Each part stores its local box dimensions, interpolated world pose, and forwarding behavior
 * for interaction and damage so multipart owners can expose multiple logical hit targets without
 * spawning separate entities.</p>
 */
public class GeoEntityPart<T extends LivingEntity & GeoMultipartEntity> {
    protected final T owner;
    private final String trackedBoneName;
    private final double boxWidth;
    private final double boxHeight;
    private final double boxDepth;
    private final double localOffsetX;
    private final double localOffsetY;
    private final double localOffsetZ;
    private final float localRotationQx;
    private final float localRotationQy;
    private final float localRotationQz;
    private final float localRotationQw;
    private GeoTrackedBonePose pose = GeoTrackedBonePose.IDENTITY;
    private GeoTrackedBonePose previousPose = GeoTrackedBonePose.IDENTITY;
    private boolean poseAlreadyInterpolated;
    private int ownerEntityId = -1;
    private int partIndex = -1;

    public GeoEntityPart(T owner, String trackedBoneName, float width, float height) {
        this(owner, trackedBoneName, width, height, width, 0.0f, 0.0f, 0.0f);
    }

    public GeoEntityPart(T owner, String trackedBoneName, float width, float height, float depth) {
        this(owner, trackedBoneName, width, height, depth, 0.0f, 0.0f, 0.0f);
    }

    public GeoEntityPart(
            T owner,
            String trackedBoneName,
            float width,
            float height,
            float depth,
            float offsetX,
            float offsetY,
            float offsetZ
    ) {
        this(owner, trackedBoneName, width, height, depth, offsetX, offsetY, offsetZ, 0.0f, 0.0f, 0.0f, 1.0f);
    }

    public GeoEntityPart(
            T owner,
            String trackedBoneName,
            float width,
            float height,
            float depth,
            float offsetX,
            float offsetY,
            float offsetZ,
            float localRotationQx,
            float localRotationQy,
            float localRotationQz,
            float localRotationQw
    ) {
        this.owner = owner;
        this.trackedBoneName = trackedBoneName;
        this.boxWidth = width;
        this.boxHeight = height;
        this.boxDepth = depth;
        this.localOffsetX = offsetX;
        this.localOffsetY = offsetY;
        this.localOffsetZ = offsetZ;
        this.localRotationQx = localRotationQx;
        this.localRotationQy = localRotationQy;
        this.localRotationQz = localRotationQz;
        this.localRotationQw = localRotationQw;
    }

    public T getOwner() {
        return this.owner;
    }

    public String getTrackedBoneName() {
        return this.trackedBoneName;
    }

    public GeoTrackedBonePose getTrackedPose() {
        return this.pose;
    }

    public int getOwnerEntityId() {
        return this.ownerEntityId;
    }

    public int getPartIndex() {
        return this.partIndex;
    }

    public int getRuntimeId() {
        if (this.ownerEntityId < 0 || this.partIndex < 0) {
            return -1;
        }
        return 31 * this.ownerEntityId + this.partIndex;
    }

    public double getX() {
        return this.pose.x();
    }

    public double getY() {
        return this.pose.y();
    }

    public double getZ() {
        return this.pose.z();
    }

    public double getBoxWidth() {
        return this.boxWidth;
    }

    public double getBoxHeight() {
        return this.boxHeight;
    }

    public double getBoxDepth() {
        return this.boxDepth;
    }

    public double getLocalOffsetX() {
        return this.localOffsetX;
    }

    public double getLocalOffsetY() {
        return this.localOffsetY;
    }

    public double getLocalOffsetZ() {
        return this.localOffsetZ;
    }

    public GeoTrackedBonePose getInterpolatedPose(float partialTick) {
        if (this.poseAlreadyInterpolated) {
            return this.pose;
        }
        return this.previousPose.lerp(this.pose, partialTick);
    }

    public boolean damage(DamageSource source, float amount) {
        return this.owner.damageMultipartPart(this, source, amount);
    }

    public InteractionResult interact(Player player, InteractionHand hand, Vec3 localHitPos, Vec3 worldHitPos) {
        return this.owner.interactMultipartPart(this, player, hand, localHitPos);
    }

    public boolean hasCollision() {
        return this.owner.hasMultipartCollision(this);
    }

    public void tick() {
    }

    public void setTrackedPose(GeoTrackedBonePose pose) {
        this.setTrackedPose(pose, false);
    }

    public void setTrackedPose(GeoTrackedBonePose pose, boolean alreadyInterpolated) {
        GeoTrackedBonePose resolvedPose = this.resolveTrackedPose(pose);
        if (!alreadyInterpolated && !this.shouldApplyPose(resolvedPose)) {
            return;
        }
        GeoTrackedBonePose previousResolvedPose = this.pose;
        if (alreadyInterpolated) {
            this.previousPose = resolvedPose;
        }
        this.pose = resolvedPose;
        this.poseAlreadyInterpolated = alreadyInterpolated;
        this.onPoseUpdated(previousResolvedPose, resolvedPose, alreadyInterpolated);
    }

    public void syncPreviousPose() {
        this.previousPose = this.pose;
        this.poseAlreadyInterpolated = false;
    }

    public void resetPreviousPose() {
        this.previousPose = this.pose;
        this.poseAlreadyInterpolated = false;
    }

    public void offsetPose(double deltaX, double deltaY, double deltaZ) {
        this.setTrackedPose(this.pose.withOffset(deltaX, deltaY, deltaZ));
    }

    public GeoTrackedBonePose resolveTrackedPose(GeoTrackedBonePose pose) {
        GeoTrackedBonePose offsetPose = pose.withLocalOffset(this.localOffsetX, this.localOffsetY, this.localOffsetZ);
        if (this.localRotationQx == 0.0f && this.localRotationQy == 0.0f && this.localRotationQz == 0.0f && this.localRotationQw == 1.0f) {
            return offsetPose;
        }
        return offsetPose.withLocalRotation(this.localRotationQx, this.localRotationQy, this.localRotationQz, this.localRotationQw);
    }

    public AABB computeEnclosingBox(GeoTrackedBonePose pose) {
        return pose.computeEnclosingBox(this.boxWidth, this.boxHeight, this.boxDepth);
    }

    public AABB getOrientedEnclosingBox(float partialTick) {
        return this.computeEnclosingBox(this.getInterpolatedPose(partialTick));
    }

    public Quaternionf getRotation() {
        return this.pose.rotation();
    }

    public Optional<Vec3> raycast(Vec3 from, Vec3 to) {
        return this.raycast(this.pose, from, to);
    }

    public Optional<Vec3> raycast(GeoTrackedBonePose pose, Vec3 from, Vec3 to) {
        return GeoMultipartHitboxMath.raycast(
                pose,
                this.boxWidth,
                this.boxHeight,
                this.boxDepth,
                from,
                to
        );
    }

    public boolean containsPoint(GeoTrackedBonePose pose, Vec3 point) {
        return GeoMultipartHitboxMath.containsPoint(pose, this.boxWidth, this.boxHeight, this.boxDepth, point);
    }

    public Optional<Vec3> sweepAabbAgainst(GeoTrackedBonePose pose, Vec3 from, Vec3 to, double halfExtentX, double halfExtentY, double halfExtentZ) {
        return GeoMultipartHitboxMath.sweepAabbAgainstOrientedBox(
                pose,
                this.boxWidth,
                this.boxHeight,
                this.boxDepth,
                from,
                to,
                halfExtentX,
                halfExtentY,
                halfExtentZ
        );
    }

    public boolean intersectsAabb(GeoTrackedBonePose pose, Vec3 center, double halfExtentX, double halfExtentY, double halfExtentZ) {
        return GeoMultipartHitboxMath.intersectsAabbAndOrientedBox(
                pose,
                this.boxWidth,
                this.boxHeight,
                this.boxDepth,
                center,
                halfExtentX,
                halfExtentY,
                halfExtentZ
        );
    }

    public void appendCollisionBoxes(GeoTrackedBonePose pose, AABB filter, List<AABB> target) {
        AABB box = this.computeEnclosingBox(pose);
        if (filter == null || box.intersects(filter)) {
            target.add(box);
        }
    }

    public void appendDebugBoxes(GeoTrackedBonePose pose, List<Vec3[]> target) {
        target.add(computeDebugCorners(pose, this.boxWidth, this.boxHeight, this.boxDepth));
    }

    protected void onPoseUpdated(GeoTrackedBonePose previousPose, GeoTrackedBonePose currentPose, boolean alreadyInterpolated) {
    }

    public void assignIdentity(int ownerEntityId, int partIndex) {
        this.ownerEntityId = ownerEntityId;
        this.partIndex = partIndex;
    }

    private boolean shouldApplyPose(GeoTrackedBonePose resolvedPose) {
        double positionThreshold = this.owner.getMultipartServerPosePositionThreshold();
        if (positionThreshold <= 0.0d) {
            return true;
        }

        double positionThresholdSquared = positionThreshold * positionThreshold;
        if (this.pose.squaredDistanceTo(resolvedPose) > positionThresholdSquared) {
            return true;
        }

        return this.pose.rotationDot(resolvedPose) < this.owner.getMultipartServerPoseRotationThresholdDot();
    }

    public static Vec3[] computeDebugCorners(GeoTrackedBonePose pose, double width, double height, double depth) {
        Vec3 center = pose.position();
        Vector3f[] corners = pose.computeCorners(width, height, depth);
        Vec3[] worldCorners = new Vec3[corners.length];
        for (int i = 0; i < corners.length; i++) {
            worldCorners[i] = center.add(corners[i].x, corners[i].y, corners[i].z);
        }
        return worldCorners;
    }
}
