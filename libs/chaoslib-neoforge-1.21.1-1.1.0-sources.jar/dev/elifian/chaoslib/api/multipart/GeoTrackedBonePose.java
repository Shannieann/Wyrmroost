package dev.elifian.chaoslib.api.multipart;

import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/**
 * Stores a tracked bone world pose as position plus quaternion rotation.
 */
public record GeoTrackedBonePose(double x, double y, double z, float qx, float qy, float qz, float qw) {
    public static final GeoTrackedBonePose IDENTITY = new GeoTrackedBonePose(0.0d, 0.0d, 0.0d, 0.0f, 0.0f, 0.0f, 1.0f);

    /**
     * Creates a pose from a world position and quaternion rotation.
     */
    public GeoTrackedBonePose(Vec3 position, Quaternionf rotation) {
        this(position.x, position.y, position.z, rotation.x, rotation.y, rotation.z, rotation.w);
    }

    /**
     * Extracts a tracked pose from a model matrix and pivot.
     */
    public static GeoTrackedBonePose fromMatrix(Matrix4f matrix, float pivotX, float pivotY, float pivotZ) {
        Vector3f position = matrix.transformPosition(pivotX / 16.0f, pivotY / 16.0f, pivotZ / 16.0f, new Vector3f());
        Quaternionf rotation = matrix.getNormalizedRotation(new Quaternionf()).normalize();
        return new GeoTrackedBonePose(position.x, position.y, position.z, rotation.x, rotation.y, rotation.z, rotation.w);
    }

    /**
     * Creates a position-only pose with identity rotation.
     */
    public static GeoTrackedBonePose atPosition(Vec3 position) {
        return new GeoTrackedBonePose(position.x, position.y, position.z, 0.0f, 0.0f, 0.0f, 1.0f);
    }

    /**
     * Returns this pose position as a vector.
     */
    public Vec3 position() {
        return new Vec3(this.x, this.y, this.z);
    }

    /**
     * Returns this pose rotation as a normalized quaternion.
     */
    public Quaternionf rotation() {
        return new Quaternionf(this.qx, this.qy, this.qz, this.qw).normalize();
    }

    /**
     * Returns a copy of this pose with a different position.
     */
    public GeoTrackedBonePose withPosition(Vec3 position) {
        return new GeoTrackedBonePose(position.x, position.y, position.z, this.qx, this.qy, this.qz, this.qw);
    }

    /**
     * Returns a copy of this pose offset by the given world delta.
     */
    public GeoTrackedBonePose withOffset(double dx, double dy, double dz) {
        return new GeoTrackedBonePose(this.x + dx, this.y + dy, this.z + dz, this.qx, this.qy, this.qz, this.qw);
    }

    /**
     * Returns a copy of this pose offset by a local-space vector rotated by this pose.
     */
    public GeoTrackedBonePose withLocalOffset(double localX, double localY, double localZ) {
        Vector3f rotated = this.rotation().transform(new Vector3f((float) localX, (float) localY, (float) localZ));
        return this.withOffset(rotated.x, rotated.y, rotated.z);
    }

    /**
     * Returns a copy of this pose with a different rotation.
     */
    public GeoTrackedBonePose withRotation(Quaternionf rotation) {
        Quaternionf normalized = new Quaternionf(rotation).normalize();
        return new GeoTrackedBonePose(this.x, this.y, this.z, normalized.x, normalized.y, normalized.z, normalized.w);
    }

    /**
     * Returns a copy of this pose with an additional local-space rotation applied after the current pose rotation.
     */
    public GeoTrackedBonePose withLocalRotation(float qx, float qy, float qz, float qw) {
        Quaternionf rotation = this.rotation().mul(new Quaternionf(qx, qy, qz, qw)).normalize();
        return new GeoTrackedBonePose(this.x, this.y, this.z, rotation.x, rotation.y, rotation.z, rotation.w);
    }

    /**
     * Interpolates this pose toward another pose.
     */
    public GeoTrackedBonePose lerp(GeoTrackedBonePose target, float delta) {
        Quaternionf fromRotation = this.rotation();
        Quaternionf toRotation = target.rotation();
        Quaternionf rotation = fromRotation.slerp(toRotation, delta, new Quaternionf()).normalize();
        return new GeoTrackedBonePose(
                this.x + (target.x - this.x) * delta,
                this.y + (target.y - this.y) * delta,
                this.z + (target.z - this.z) * delta,
                rotation.x,
                rotation.y,
                rotation.z,
                rotation.w
        );
    }

    /**
     * Returns squared world-space distance to another pose.
     */
    public double squaredDistanceTo(GeoTrackedBonePose other) {
        double dx = this.x - other.x;
        double dy = this.y - other.y;
        double dz = this.z - other.z;
        return dx * dx + dy * dy + dz * dz;
    }

    /**
     * Returns the absolute quaternion dot product to another pose.
     */
    public float rotationDot(GeoTrackedBonePose other) {
        return Math.abs(this.qx * other.qx + this.qy * other.qy + this.qz * other.qz + this.qw * other.qw);
    }

    /**
     * Computes the enclosing axis-aligned box for an oriented hitbox with this pose.
     */
    public AABB computeEnclosingBox(double width, double height, double depth) {
        double halfWidth = width * 0.5d;
        double halfHeight = height * 0.5d;
        double halfDepth = depth * 0.5d;

        double xx = this.qx * this.qx;
        double yy = this.qy * this.qy;
        double zz = this.qz * this.qz;
        double xy = this.qx * this.qy;
        double xz = this.qx * this.qz;
        double yz = this.qy * this.qz;
        double wx = this.qw * this.qx;
        double wy = this.qw * this.qy;
        double wz = this.qw * this.qz;

        double m00 = 1.0d - 2.0d * (yy + zz);
        double m01 = 2.0d * (xy - wz);
        double m02 = 2.0d * (xz + wy);
        double m10 = 2.0d * (xy + wz);
        double m11 = 1.0d - 2.0d * (xx + zz);
        double m12 = 2.0d * (yz - wx);
        double m20 = 2.0d * (xz - wy);
        double m21 = 2.0d * (yz + wx);
        double m22 = 1.0d - 2.0d * (xx + yy);

        double extentX = Math.abs(m00) * halfWidth + Math.abs(m01) * halfHeight + Math.abs(m02) * halfDepth;
        double extentY = Math.abs(m10) * halfWidth + Math.abs(m11) * halfHeight + Math.abs(m12) * halfDepth;
        double extentZ = Math.abs(m20) * halfWidth + Math.abs(m21) * halfHeight + Math.abs(m22) * halfDepth;

        return new AABB(
                this.x - extentX,
                this.y - extentY,
                this.z - extentZ,
                this.x + extentX,
                this.y + extentY,
                this.z + extentZ
        );
    }

    /**
     * Computes the oriented hitbox corners for this pose.
     */
    public Vector3f[] computeCorners(double width, double height, double depth) {
        return this.computeCorners(this.rotation(), width, height, depth);
    }

    private Vector3f[] computeCorners(Quaternionf rotation, double width, double height, double depth) {
        float halfWidth = (float) (width * 0.5d);
        float halfHeight = (float) (height * 0.5d);
        float halfDepth = (float) (depth * 0.5d);
        Vector3f[] corners = new Vector3f[8];
        int index = 0;
        for (int xSign = -1; xSign <= 1; xSign += 2) {
            for (int ySign = -1; ySign <= 1; ySign += 2) {
                for (int zSign = -1; zSign <= 1; zSign += 2) {
                    corners[index++] = rotation.transform(new Vector3f(
                            halfWidth * xSign,
                            halfHeight * ySign,
                            halfDepth * zSign
                    ));
                }
            }
        }
        return corners;
    }
}
