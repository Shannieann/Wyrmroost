package dev.elifian.chaoslib.api.multipart;

import dev.elifian.chaoslib.multipart.interaction.GeoMultipartHitboxMath;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.Optional;

/**
 * Local cube-derived hitbox definition stored relative to a tracked bone pose.
 */
public record GeoMultipartLocalBox(
        float width,
        float height,
        float depth,
        float centerX,
        float centerY,
        float centerZ,
        float qx,
        float qy,
        float qz,
        float qw
) {
    public GeoTrackedBonePose resolve(GeoTrackedBonePose pose) {
        GeoTrackedBonePose resolved = pose.withLocalOffset(this.centerX, this.centerY, this.centerZ);
        if (this.qx == 0.0f && this.qy == 0.0f && this.qz == 0.0f && this.qw == 1.0f) {
            return resolved;
        }
        return resolved.withLocalRotation(this.qx, this.qy, this.qz, this.qw);
    }

    public AABB computeEnclosingBox(GeoTrackedBonePose pose) {
        return this.resolve(pose).computeEnclosingBox(this.width, this.height, this.depth);
    }

    public Optional<Vec3> raycast(GeoTrackedBonePose pose, Vec3 from, Vec3 to) {
        GeoTrackedBonePose resolved = this.resolve(pose);
        return GeoMultipartHitboxMath.raycast(resolved, this.width, this.height, this.depth, from, to);
    }

    public boolean containsPoint(GeoTrackedBonePose pose, Vec3 point) {
        GeoTrackedBonePose resolved = this.resolve(pose);
        return GeoMultipartHitboxMath.containsPoint(resolved, this.width, this.height, this.depth, point);
    }

    public Optional<Vec3> sweepAabbAgainst(GeoTrackedBonePose pose, Vec3 from, Vec3 to, double halfExtentX, double halfExtentY, double halfExtentZ) {
        GeoTrackedBonePose resolved = this.resolve(pose);
        return GeoMultipartHitboxMath.sweepAabbAgainstOrientedBox(
                resolved,
                this.width,
                this.height,
                this.depth,
                from,
                to,
                halfExtentX,
                halfExtentY,
                halfExtentZ
        );
    }

    public boolean intersectsAabb(GeoTrackedBonePose pose, Vec3 center, double halfExtentX, double halfExtentY, double halfExtentZ) {
        GeoTrackedBonePose resolved = this.resolve(pose);
        return GeoMultipartHitboxMath.intersectsAabbAndOrientedBox(
                resolved,
                this.width,
                this.height,
                this.depth,
                center,
                halfExtentX,
                halfExtentY,
                halfExtentZ
        );
    }
}
