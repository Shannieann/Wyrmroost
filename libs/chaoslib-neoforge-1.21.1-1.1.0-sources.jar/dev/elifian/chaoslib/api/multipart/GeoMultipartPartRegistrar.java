package dev.elifian.chaoslib.api.multipart;

/**
 * Registration helper used by {@link GeoMultipartEntity} implementations to declare tracked
 * multipart hitboxes during manager construction.
 *
 * <p>The registrar supports both fully custom {@link GeoEntityPart} instances and convenience
 * overloads that derive size and anchor information from tracked geo bones.</p>
 */
public interface GeoMultipartPartRegistrar {
    /**
     * Registers a custom virtual multipart part object with its own logic.
     */
    <P extends GeoEntityPart<?>> P trackPart(P part);

    /**
     * Registers a multipart hitbox for a tracked bone.
     * Size is resolved from the bone voxel bounds and centered on the voxel bounds center.
     *
     * @param trackedBoneName name of the tracked bone
     */
    default void track(String trackedBoneName) {
        this.track(trackedBoneName, GeoMultipartAnchor.BONE_BOUNDS_CENTER);
    }

    /**
     * Registers a multipart hitbox for a tracked bone.
     * Size is resolved from the bone voxel bounds and centered on the selected anchor.
     *
     * @param trackedBoneName name of the tracked bone
     * @param anchor          local point used as the hitbox center before offsets are applied
     */
    default void track(String trackedBoneName, GeoMultipartAnchor anchor) {
        this.track(trackedBoneName, anchor, GeoMultipartOffset.ZERO);
    }

    /**
     * Registers a multipart hitbox for a tracked bone.
     * Size is resolved from the bone voxel bounds and offset from the selected anchor.
     * Offset uses local bone space in block units after ChaosLib geo coordinate conversion.
     *
     * @param trackedBoneName name of the tracked bone
     * @param anchor          local point used as the hitbox center before offsets are applied
     * @param offset          local hitbox offset from the selected anchor
     */
    void track(String trackedBoneName, GeoMultipartAnchor anchor, GeoMultipartOffset offset);

    /**
     * Registers a multipart hitbox that keeps the tracked bone's cube relief instead of collapsing
     * all geometry into a single box.
     *
     * @param trackedBoneName name of the tracked bone
     */
    default void trackDetailed(String trackedBoneName) {
        this.trackDetailed(trackedBoneName, GeoMultipartOffset.ZERO);
    }

    /**
     * Registers a multipart hitbox that keeps the tracked bone's cube relief instead of collapsing
     * all geometry into a single box, with an additional local offset applied to the whole shape.
     *
     * @param trackedBoneName name of the tracked bone
     * @param offset          local offset applied to the detailed hitbox
     */
    void trackDetailed(String trackedBoneName, GeoMultipartOffset offset);

    /**
     * Registers an axis-aligned multipart hitbox bound to a tracked bone.
     * Width is X, height is Y, depth defaults to width, centered on the bone pivot.
     *
     * @param trackedBoneName name of the tracked bone
     * @param width           hitbox width on the local X axis
     * @param height          hitbox height on the local Y axis
     */
    default void track(String trackedBoneName, float width, float height) {
        this.track(trackedBoneName, GeoMultipartAnchor.PIVOT, width, height, width, 0.0f, 0.0f, 0.0f);
    }

    /**
     * Registers an axis-aligned multipart hitbox bound to a tracked bone.
     * Width is X, height is Y, depth is Z, centered on the bone pivot.
     *
     * @param trackedBoneName name of the tracked bone
     * @param width           hitbox width on the local X axis
     * @param height          hitbox height on the local Y axis
     * @param depth           hitbox depth on the local Z axis
     */
    default void track(String trackedBoneName, float width, float height, float depth) {
        this.track(trackedBoneName, GeoMultipartAnchor.PIVOT, width, height, depth, 0.0f, 0.0f, 0.0f);
    }

    /**
     * Registers an axis-aligned multipart hitbox bound to a tracked bone.
     * Width is X, height is Y, depth defaults to width, offset from the bone pivot.
     * Offset uses local bone space in block units.
     *
     * @param trackedBoneName name of the tracked bone
     * @param width           hitbox width on the local X axis
     * @param height          hitbox height on the local Y axis
     * @param offsetX         local offset on the X axis
     * @param offsetY         local offset on the Y axis
     * @param offsetZ         local offset on the Z axis
     */
    default void track(String trackedBoneName, float width, float height, float offsetX, float offsetY, float offsetZ) {
        this.track(trackedBoneName, GeoMultipartAnchor.PIVOT, width, height, width, offsetX, offsetY, offsetZ);
    }

    /**
     * Registers an axis-aligned multipart hitbox bound to a tracked bone.
     * Width is X, height is Y, depth is Z, offset from the bone pivot.
     * Offset uses local bone space in block units.
     *
     * @param trackedBoneName name of the tracked bone
     * @param width           hitbox width on the local X axis
     * @param height          hitbox height on the local Y axis
     * @param depth           hitbox depth on the local Z axis
     * @param offsetX         local offset on the X axis
     * @param offsetY         local offset on the Y axis
     * @param offsetZ         local offset on the Z axis
     */
    default void track(
            String trackedBoneName,
            float width,
            float height,
            float depth,
            float offsetX,
            float offsetY,
            float offsetZ
    ) {
        this.track(trackedBoneName, GeoMultipartAnchor.PIVOT, width, height, depth, offsetX, offsetY, offsetZ);
    }

    /**
     * Registers an axis-aligned multipart hitbox bound to a tracked bone.
     * Width is X, height is Y, depth defaults to width, centered on the selected anchor.
     *
     * @param trackedBoneName name of the tracked bone
     * @param anchor          local point used as the hitbox center before offsets are applied
     * @param width           hitbox width on the local X axis
     * @param height          hitbox height on the local Y axis
     */
    default void track(String trackedBoneName, GeoMultipartAnchor anchor, float width, float height) {
        this.track(trackedBoneName, anchor, width, height, width, 0.0f, 0.0f, 0.0f);
    }

    /**
     * Registers an axis-aligned multipart hitbox bound to a tracked bone.
     * Width is X, height is Y, depth is Z, centered on the selected anchor.
     *
     * @param trackedBoneName name of the tracked bone
     * @param anchor          local point used as the hitbox center before offsets are applied
     * @param width           hitbox width on the local X axis
     * @param height          hitbox height on the local Y axis
     * @param depth           hitbox depth on the local Z axis
     */
    default void track(String trackedBoneName, GeoMultipartAnchor anchor, float width, float height, float depth) {
        this.track(trackedBoneName, anchor, width, height, depth, 0.0f, 0.0f, 0.0f);
    }

    /**
     * Registers an axis-aligned multipart hitbox bound to a tracked bone.
     * Width is X, height is Y, depth defaults to width, offset from the selected anchor.
     * Offset uses local bone space in block units.
     *
     * @param trackedBoneName name of the tracked bone
     * @param anchor          local point used as the hitbox center before offsets are applied
     * @param width           hitbox width on the local X axis
     * @param height          hitbox height on the local Y axis
     * @param offsetX         local offset on the X axis
     * @param offsetY         local offset on the Y axis
     * @param offsetZ         local offset on the Z axis
     */
    default void track(
            String trackedBoneName,
            GeoMultipartAnchor anchor,
            float width,
            float height,
            float offsetX,
            float offsetY,
            float offsetZ
    ) {
        this.track(trackedBoneName, anchor, width, height, width, offsetX, offsetY, offsetZ);
    }

    /**
     * Registers an axis-aligned multipart hitbox bound to a tracked bone.
     * Width is X, height is Y, depth is Z, offset from the selected anchor.
     * Offset uses local bone space in block units.
     *
     * @param trackedBoneName name of the tracked bone
     * @param anchor          local point used as the hitbox center before offsets are applied
     * @param width           hitbox width on the local X axis
     * @param height          hitbox height on the local Y axis
     * @param depth           hitbox depth on the local Z axis
     * @param offsetX         local offset on the X axis
     * @param offsetY         local offset on the Y axis
     * @param offsetZ         local offset on the Z axis
     */
    void track(
            String trackedBoneName,
            GeoMultipartAnchor anchor,
            float width,
            float height,
            float depth,
            float offsetX,
            float offsetY,
            float offsetZ
    );
}
