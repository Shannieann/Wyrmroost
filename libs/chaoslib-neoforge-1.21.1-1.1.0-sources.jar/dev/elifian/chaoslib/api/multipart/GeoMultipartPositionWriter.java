package dev.elifian.chaoslib.api.multipart;

import dev.elifian.chaoslib.multipart.runtime.GeoMultipartPartManager;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;

/**
 * Helper used by multipart entities to write part positions and full poses.
 */
public final class GeoMultipartPositionWriter<T extends LivingEntity & GeoMultipartEntity> {
    private final GeoMultipartPartManager<T> manager;

    public GeoMultipartPositionWriter(GeoMultipartPartManager<T> manager) {
        this.manager = manager;
    }

    /**
     * Sets a tracked part position without rotation.
     */
    public void set(String trackedBoneName, Vec3 position) {
        this.manager.setPartPose(trackedBoneName, GeoTrackedBonePose.atPosition(position));
    }

    /**
     * Sets a tracked part position without rotation.
     */
    public void set(String trackedBoneName, double x, double y, double z) {
        this.set(trackedBoneName, new Vec3(x, y, z));
    }

    /**
     * Sets a tracked part pose from a yaw-relative offset around the owner body yaw.
     */
    public void setYawOffset(String trackedBoneName, double x, double y, double z) {
        Vec3 position = this.manager.resolveYawOffset(x, y, z);
        Quaternionf rotation = new Quaternionf().rotateY((float) Math.toRadians(-this.getOwner().yBodyRot));
        this.setPose(trackedBoneName, new GeoTrackedBonePose(position, rotation));
    }

    /**
     * Sets a tracked part pose with full position and rotation data.
     */
    public void setPose(String trackedBoneName, GeoTrackedBonePose pose) {
        this.manager.setPartPose(trackedBoneName, pose);
    }

    /**
     * Sets a tracked part pose with full position and rotation data.
     */
    public void setPose(String trackedBoneName, Vec3 position, Quaternionf rotation) {
        this.setPose(trackedBoneName, new GeoTrackedBonePose(position, rotation));
    }

    /**
     * Returns the multipart owner currently being written.
     */
    public T getOwner() {
        return this.manager.getOwner();
    }
}
