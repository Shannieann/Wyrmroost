package dev.elifian.chaoslib.api.multipart;

/**
 * Stores a local multipart hitbox offset in block units.
 */
public record GeoMultipartOffset(float x, float y, float z) {
    public static final GeoMultipartOffset ZERO = new GeoMultipartOffset(0.0f, 0.0f, 0.0f);
}
