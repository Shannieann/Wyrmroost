package dev.elifian.chaoslib.api.multipart;

import dev.elifian.chaoslib.api.animatable.GeoBoneTrackingAnimatable;
import dev.elifian.chaoslib.multipart.runtime.GeoMultipartPartManager;
import dev.elifian.chaoslib.multipart.runtime.GeoMultipartRuntimeCoordinator;
import dev.elifian.chaoslib.util.TrackingPlayerUtil;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Extends a living entity with ChaosLib-managed virtual multipart hitboxes.
 *
 * <p>Implementations register logical parts bound to tracked geo bones, write updated part poses
 * on the server, and optionally customize how damage, interaction, collision, and debug rendering
 * are forwarded from a virtual part back to the owning entity.</p>
 */
public interface GeoMultipartEntity extends GeoBoneTrackingAnimatable {
    /**
     * Registers multipart hitboxes for this entity.
     */
    void registerMultipartParts(GeoMultipartPartRegistrar registrar);

    /**
     * Returns the multipart manager that owns all registered parts for this entity.
     */
    @SuppressWarnings("unchecked")
    default <T extends LivingEntity & GeoMultipartEntity> GeoMultipartPartManager<T> getMultipartPartManager() {
        return GeoMultipartRuntimeCoordinator.getManager((T) this);
    }

    /**
     * Writes server-side multipart poses for the current tick.
     */
    default void writeMultipartPositions(GeoMultipartPositionWriter<?> writer) {
    }

    /**
     * Returns the geo model resource used to resolve automatic multipart voxel bounds.
     */
    ResourceLocation getMultipartModelResource();

    /**
     * Returns the current virtual multipart hitboxes for this owner.
     */
    default List<? extends GeoEntityPart<?>> getMultipartParts() {
        return this.getMultipartPartManager().getParts();
    }

    /**
     * Returns the broad-phase AABB used by targeted multipart systems such as projectile candidate selection.
     */
    default AABB getMultipartBroadPhaseBoundingBox() {
        return GeoMultipartRuntimeCoordinator.getBroadPhaseBoundingBox(this);
    }

    /**
     * Returns the pose that should be used for collision and broad-phase queries for the given part.
     */
    default GeoTrackedBonePose getMultipartCollisionPose(GeoEntityPart<?> part) {
        return GeoMultipartRuntimeCoordinator.getCollisionPose(this, part);
    }

    /**
     * Returns the tracked bone names exposed for synchronization and bone-world queries.
     */
    @Override
    default Set<String> getTrackedBones() {
        return this.getMultipartPartManager().getTrackedBones();
    }

    @Override
    default boolean requiresGpuBoneTrackingReadback() {
        return true;
    }

    @Override
    default int getGpuBoneTrackingReadbackIntervalTicks() {
        return 1;
    }

    /**
     * Applies tracked bone positions received from a sync source.
     */
    @Override
    default void receiveTrackedBonePositions(Map<String, Vec3> positions) {
        GeoMultipartRuntimeCoordinator.receiveTrackedBonePositions(this, positions);
    }

    /**
     * Applies tracked bone poses received from a sync source.
     */
    @Override
    default void receiveTrackedBonePoses(Map<String, GeoTrackedBonePose> poses) {
        GeoMultipartRuntimeCoordinator.receiveTrackedBonePoses(this, poses);
    }

    /**
     * Assigns runtime entity ids to multipart parts after the owner id is known.
     */
    default void assignMultipartPartIds(int entityId) {
        GeoMultipartRuntimeCoordinator.assignPartIds(this, entityId);
    }

    /**
     * Copies the current part state into the previous tick state.
     */
    default void syncMultipartPreviousPartPositions() {
        GeoMultipartRuntimeCoordinator.syncPreviousPartPositions(this);
    }

    /**
     * Resets previous tick state after teleports or hard position resets.
     */
    default void resetMultipartPreviousPartPositions() {
        GeoMultipartRuntimeCoordinator.resetPreviousPartPositions(this);
    }

    /**
     * Recomputes multipart poses for the current tick.
     */
    default void tickMultipartPartPositions() {
        GeoMultipartRuntimeCoordinator.tickPartPositions(this);
    }

    /**
     * Executes multipart bookkeeping before the owner tick updates poses.
     */
    default void onMultipartTickStart() {
        GeoMultipartRuntimeCoordinator.onTickStart(this);
    }

    /**
     * Executes multipart bookkeeping after the owner tick updates poses.
     */
    default void onMultipartTickEnd() {
        GeoMultipartRuntimeCoordinator.onTickEnd(this);
    }

    /**
     * Handles damage forwarded from a multipart hitbox to the owner entity.
     */
    default boolean damageMultipartPart(GeoEntityPart<?> part, DamageSource source, float amount) {
        if ((Object) this instanceof LivingEntity livingEntity) {
            return livingEntity.hurt(source, amount);
        }

        return false;
    }

    /**
     * Handles use interactions forwarded from a multipart hitbox to the owner entity.
     */
    default InteractionResult interactMultipartPart(GeoEntityPart<?> part, Player player, InteractionHand hand, Vec3 hitPos) {
        if ((Object) this instanceof Entity entity) {
            return entity.interactAt(player, hitPos, hand);
        }

        return InteractionResult.PASS;
    }

    /**
     * Returns how far the attacker's swing must have recovered before a melee hit is allowed to land
     * on a multipart hitbox, on vanilla's 0..1 attack strength scale.
     *
     * <p>Defaults to vanilla's own melee pacing: a swing that has not recovered does not reach the
     * parts, and the hit is dropped. Return {@code 0.0f} to let every swing through.</p>
     */
    default float getMultipartMinAttackStrength() {
        return 0.9f;
    }

    /**
     * Returns whether virtual multipart parts should contribute collision shapes.
     */
    default boolean hasMultipartCollisions() {
        return true;
    }

    /**
     * Returns whether the given multipart part should contribute a collision shape.
     */
    default boolean hasMultipartCollision(GeoEntityPart<?> part) {
        return this.hasMultipartCollisions();
    }

    /**
     * Returns whether the owner hitbox should be shown in the F3+B debug renderer.
     */
    default boolean shouldRenderRootDebugHitbox() {
        return true;
    }

    /**
     * Returns whether the given multipart hitbox should be shown in the F3+B debug renderer.
     */
    default boolean shouldRenderMultipartDebugHitbox(GeoEntityPart<?> part) {
        return this.shouldRenderMultipartDebugHitbox(part.getTrackedBoneName());
    }

    /**
     * Returns whether the multipart hitbox bound to the given tracked bone id should be shown in F3+B.
     */
    default boolean shouldRenderMultipartDebugHitbox(String trackedBoneName) {
        return true;
    }

    /**
     * Returns the ARGB color used for the given multipart hitbox in the F3+B debug renderer.
     */
    default int getMultipartDebugHitboxColor(GeoEntityPart<?> part) {
        return this.getMultipartDebugHitboxColor(part.getTrackedBoneName());
    }

    /**
     * Returns the ARGB color used for the multipart hitbox bound to the given tracked bone id in F3+B.
     */
    default int getMultipartDebugHitboxColor(String trackedBoneName) {
        return 0xFF00FF00;
    }

    /**
     * Returns the minimum number of ticks between client multipart sync packets.
     */
    default int getMultipartSyncIntervalTicks() {
        return 4;
    }

    /**
     * Returns the minimum position delta required to trigger multipart sync.
     */
    default double getMultipartSyncPositionThreshold() {
        return 0.0625d;
    }

    /**
     * Returns the maximum number of ticks before a multipart sync is forced.
     */
    default int getMultipartForcedSyncIntervalTicks() {
        return 20;
    }

    /**
     * Returns the quaternion dot threshold used to skip small rotation sync changes.
     */
    default float getMultipartSyncRotationThresholdDot() {
        return 0.9998f;
    }

    /**
     * Returns whether multipart sync packets from the given player should be accepted.
     */
    default boolean acceptsMultipartSync(ServerPlayer sender) {
        return true;
    }

    /**
     * Returns the minimum movement delta required before a server-side part pose is updated.
     */
    default double getMultipartServerPosePositionThreshold() {
        return 1.0d / 1024.0d;
    }

    /**
     * Returns the quaternion dot threshold below which a server-side part rotation is considered changed.
     */
    default float getMultipartServerPoseRotationThresholdDot() {
        return 0.9999995f;
    }

    /**
     * Returns the minimum distance from a tracking player at which multipart updates may be throttled.
     */
    default double getMultipartReducedUpdateDistanceSquared() {
        return 32.0d * 32.0d;
    }

    /**
     * Returns the tick interval used for throttled multipart updates when all tracking players are far away.
     */
    default int getMultipartReducedUpdateIntervalTicks() {
        return 2;
    }

    /**
     * Returns the extra margin used when searching projectile collisions against virtual multipart hitboxes.
     */
    default double getMultipartProjectileSearchMargin() {
        return 4.0d;
    }

    /**
     * Returns players currently tracking the chunk that contains this multipart entity.
     */
    default List<ServerPlayer> getMultipartTrackingPlayers(ServerLevel serverWorld) {
        if (!((Object) this instanceof Entity entity)) {
            return List.of();
        }

        return TrackingPlayerUtil.getChunkTrackingPlayers(entity, serverWorld);
    }

    /**
     * Returns whether multipart parts should be updated on this server tick.
     */
    default boolean shouldTickMultipartServerNow(ServerLevel serverWorld) {
        if (!((Object) this instanceof Entity entity)) {
            return false;
        }

        List<ServerPlayer> trackingPlayers = this.getMultipartTrackingPlayers(serverWorld);
        if (trackingPlayers.isEmpty()) {
            return false;
        }

        if (this.shouldForceMultipartFullUpdates(serverWorld, trackingPlayers)) {
            return true;
        }

        double reducedDistanceSquared = this.getMultipartReducedUpdateDistanceSquared();
        for (ServerPlayer player : trackingPlayers) {
            if (player.distanceToSqr(entity) <= reducedDistanceSquared) {
                return true;
            }
        }

        int interval = this.getMultipartReducedUpdateIntervalTicks();
        return interval <= 1 || entity.tickCount % interval == 0;
    }

    /**
     * Returns whether multipart updates should stay at full tick rate regardless of watcher distance.
     */
    default boolean shouldForceMultipartFullUpdates(ServerLevel serverWorld, List<ServerPlayer> trackingPlayers) {
        if ((Object) this instanceof LivingEntity livingEntity) {
            return livingEntity.hurtTime > 0 || livingEntity.getLastHurtByMob() != null;
        }

        return false;
    }
}
