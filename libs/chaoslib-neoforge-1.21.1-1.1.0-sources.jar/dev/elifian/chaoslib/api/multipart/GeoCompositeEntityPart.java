package dev.elifian.chaoslib.api.multipart;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;
import java.util.Optional;

/**
 * Multipart part that resolves to multiple local cube hitboxes instead of a single oriented box.
 */
public class GeoCompositeEntityPart<T extends LivingEntity & GeoMultipartEntity> extends GeoEntityPart<T> {
    private final List<GeoMultipartLocalBox> localBoxes;

    public GeoCompositeEntityPart(
            T owner,
            String trackedBoneName,
            float width,
            float height,
            float depth,
            float offsetX,
            float offsetY,
            float offsetZ,
            float localRotationQx,
            float localRotationQy,
            float localRotationQz,
            float localRotationQw,
            List<GeoMultipartLocalBox> localBoxes
    ) {
        super(owner, trackedBoneName, width, height, depth, offsetX, offsetY, offsetZ, localRotationQx, localRotationQy, localRotationQz, localRotationQw);
        this.localBoxes = List.copyOf(localBoxes);
    }

    public List<GeoMultipartLocalBox> getLocalBoxes() {
        return this.localBoxes;
    }

    @Override
    public AABB computeEnclosingBox(GeoTrackedBonePose pose) {
        AABB union = null;
        for (GeoMultipartLocalBox localBox : this.localBoxes) {
            AABB box = localBox.computeEnclosingBox(pose);
            union = union == null ? box : union.minmax(box);
        }
        return union != null ? union : super.computeEnclosingBox(pose);
    }

    @Override
    public Optional<Vec3> raycast(GeoTrackedBonePose pose, Vec3 from, Vec3 to) {
        Optional<Vec3> bestHit = Optional.empty();
        double bestDistanceSquared = Double.POSITIVE_INFINITY;
        for (GeoMultipartLocalBox localBox : this.localBoxes) {
            Optional<Vec3> hit = localBox.raycast(pose, from, to);
            if (hit.isEmpty()) {
                continue;
            }
            double distanceSquared = from.distanceToSqr(hit.get());
            if (distanceSquared < bestDistanceSquared) {
                bestDistanceSquared = distanceSquared;
                bestHit = hit;
            }
        }
        return bestHit;
    }

    @Override
    public boolean containsPoint(GeoTrackedBonePose pose, Vec3 point) {
        for (GeoMultipartLocalBox localBox : this.localBoxes) {
            if (localBox.containsPoint(pose, point)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public Optional<Vec3> sweepAabbAgainst(GeoTrackedBonePose pose, Vec3 from, Vec3 to, double halfExtentX, double halfExtentY, double halfExtentZ) {
        Optional<Vec3> bestHit = Optional.empty();
        double bestDistanceSquared = Double.POSITIVE_INFINITY;
        for (GeoMultipartLocalBox localBox : this.localBoxes) {
            Optional<Vec3> hit = localBox.sweepAabbAgainst(pose, from, to, halfExtentX, halfExtentY, halfExtentZ);
            if (hit.isEmpty()) {
                continue;
            }
            double distanceSquared = from.distanceToSqr(hit.get());
            if (distanceSquared < bestDistanceSquared) {
                bestDistanceSquared = distanceSquared;
                bestHit = hit;
            }
        }
        return bestHit;
    }

    @Override
    public boolean intersectsAabb(GeoTrackedBonePose pose, Vec3 center, double halfExtentX, double halfExtentY, double halfExtentZ) {
        for (GeoMultipartLocalBox localBox : this.localBoxes) {
            if (localBox.intersectsAabb(pose, center, halfExtentX, halfExtentY, halfExtentZ)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void appendCollisionBoxes(GeoTrackedBonePose pose, AABB filter, List<AABB> target) {
        for (GeoMultipartLocalBox localBox : this.localBoxes) {
            AABB box = localBox.computeEnclosingBox(pose);
            if (filter == null || box.intersects(filter)) {
                target.add(box);
            }
        }
    }

    @Override
    public void appendDebugBoxes(GeoTrackedBonePose pose, List<Vec3[]> target) {
        for (GeoMultipartLocalBox localBox : this.localBoxes) {
            GeoTrackedBonePose resolvedPose = localBox.resolve(pose);
            target.add(GeoEntityPart.computeDebugCorners(resolvedPose, localBox.width(), localBox.height(), localBox.depth()));
        }
    }
}
