package dev.elifian.chaoslib.api.multipart;

/**
 * Selects which local point of a tracked bone is used as the hitbox anchor.
 */
public enum GeoMultipartAnchor {
    /**
     * Uses the bone pivot as the local hitbox center.
     */
    PIVOT,
    /**
     * Uses the center of the bone voxel bounds as the local hitbox center.
     */
    BONE_BOUNDS_CENTER
}
