package dev.elifian.chaoslib.api.model;

import org.joml.Vector3d;

/**
 * Read-only view over a locator attached to a geo bone.
 *
 * <p>Locators provide named attachment points in model space that can be queried for offsets,
 * local rotation, and world-space position relative to a specific {@link GeoBoneHandle}.</p>
 */
public interface GeoLocatorHandle {
    String getName();

    float getOffsetX();

    float getOffsetY();

    float getOffsetZ();

    float getRotX();

    float getRotY();

    float getRotZ();

    Vector3d getWorldPosition(GeoBoneHandle bone);
}
