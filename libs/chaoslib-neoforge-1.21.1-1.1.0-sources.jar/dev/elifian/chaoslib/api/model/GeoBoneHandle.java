package dev.elifian.chaoslib.api.model;

import org.joml.Matrix4f;
import org.joml.Vector3d;

import java.util.List;
import java.util.Optional;

/**
 * Mutable runtime view over a baked geo bone.
 *
 * <p>This handle exposes hierarchical structure, transform components, visibility flags, and
 * world-space queries so model hooks can inspect or modify individual bones during rendering and
 * animation evaluation.</p>
 */
public interface GeoBoneHandle {
    String getName();

    GeoBoneHandle getParent();

    List<? extends GeoBoneHandle> getChildBones();

    List<? extends GeoLocatorHandle> getLocators();

    Optional<? extends GeoLocatorHandle> getLocator(String locatorName);

    float getPosX();

    float getPosY();

    float getPosZ();

    void setPosX(float value);

    void setPosY(float value);

    void setPosZ(float value);

    float getPivotX();

    float getPivotY();

    float getPivotZ();

    void setPivotX(float value);

    void setPivotY(float value);

    void setPivotZ(float value);

    float getRotX();

    float getRotY();

    float getRotZ();

    float getInitialPivotX();

    float getInitialPivotY();

    float getInitialPivotZ();

    float getInitialRotX();

    float getInitialRotY();

    float getInitialRotZ();

    void setRotX(float value);

    void setRotY(float value);

    void setRotZ(float value);

    float getScaleX();

    float getScaleY();

    float getScaleZ();

    void setScaleX(float value);

    void setScaleY(float value);

    void setScaleZ(float value);

    boolean isHidden();

    void setHidden(boolean hidden);

    boolean isHidingChildren();

    void setChildrenHidden(boolean hideChildren);

    boolean isTrackingMatrices();

    void setTrackingMatrices(boolean trackingMatrices);

    Matrix4f getModelSpaceMatrix();

    Matrix4f getLocalSpaceMatrix();

    Matrix4f getWorldSpaceMatrix();

    Vector3d getWorldPosition();

    Vector3d transformModelPoint(float x, float y, float z);

    void resetPose();
}
