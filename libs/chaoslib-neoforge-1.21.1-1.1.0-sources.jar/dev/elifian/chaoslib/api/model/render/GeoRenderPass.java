package dev.elifian.chaoslib.api.model.render;

import dev.elifian.chaoslib.api.animatable.GeoAnimatable;
import dev.elifian.chaoslib.client.render.LiveRenderColorInterpolator;
import dev.elifian.chaoslib.model.AnimatedBoneSelection;
import dev.elifian.chaoslib.platform.ClientOnly;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import java.util.function.*;

@ClientOnly
public final class GeoRenderPass<T extends GeoAnimatable> {
    private final String name;
    private final Predicate<T> livePredicate;
    private final Function<T, AnimatedBoneSelection> liveBoneSelectionResolver;
    private final LiveBoneScope liveBoneScope;
    private final Function<T, @Nullable ResourceLocation> liveTextureResolver;
    private final BiFunction<T, ResourceLocation, RenderType> liveRenderLayerResolver;
    private final ToIntFunction<T> liveColorResolver;
    private final ToDoubleFunction<T> liveOpacityResolver;
    private final float liveColorTransitionRate;
    private final Function<T, @Nullable ResourceLocation> liveEmissiveTextureResolver;
    private final boolean liveEmissiveUsesLiveTexture;
    private final ToDoubleFunction<T> liveEmissiveStrengthResolver;
    private final LightMode lightMode;
    private final boolean bakeIntoBlockModel;
    private final boolean bakeIntoItemModel;
    private final Function<String, AnimatedBoneSelection> staticBlockBoneSelectionResolver;
    private final Function<String, AnimatedBoneSelection> staticItemBoneSelectionResolver;
    private final Supplier<@Nullable ResourceLocation> staticTextureResolver;
    private final Function<ResourceLocation, @Nullable RenderType> staticRenderLayerResolver;
    private final boolean staticEmissive;
    private final int staticBakePassCount;

    private GeoRenderPass(Builder<T> builder) {
        this.name = builder.name;
        this.livePredicate = builder.livePredicate;
        this.liveBoneSelectionResolver = builder.liveBoneSelectionResolver;
        this.liveBoneScope = builder.liveBoneScope;
        this.liveTextureResolver = builder.liveTextureResolver;
        this.liveRenderLayerResolver = builder.liveRenderLayerResolver;
        this.liveColorResolver = builder.liveColorResolver;
        this.liveOpacityResolver = builder.liveOpacityResolver;
        this.liveColorTransitionRate = builder.liveColorTransitionRate;
        this.liveEmissiveTextureResolver = builder.liveEmissiveTextureResolver;
        this.liveEmissiveUsesLiveTexture = builder.liveEmissiveUsesLiveTexture;
        this.liveEmissiveStrengthResolver = builder.liveEmissiveStrengthResolver;
        this.lightMode = builder.lightMode;
        this.bakeIntoBlockModel = builder.bakeIntoBlockModel;
        this.bakeIntoItemModel = builder.bakeIntoItemModel;
        this.staticBlockBoneSelectionResolver = builder.staticBlockBoneSelectionResolver;
        this.staticItemBoneSelectionResolver = builder.staticItemBoneSelectionResolver;
        this.staticTextureResolver = builder.staticTextureResolver;
        this.staticRenderLayerResolver = builder.staticRenderLayerResolver;
        this.staticEmissive = builder.staticEmissive;
        this.staticBakePassCount = builder.staticBakePassCount;
    }

    public static <T extends GeoAnimatable> Builder<T> builder(String name) {
        return new Builder<>(name);
    }

    public String getName() {
        return this.name;
    }

    public boolean shouldRenderLive(T animatable) {
        return this.livePredicate.test(animatable);
    }

    public AnimatedBoneSelection getLiveBoneSelection(T animatable) {
        return this.liveBoneSelectionResolver.apply(animatable);
    }

    public LiveBoneScope getLiveBoneScope() {
        return this.liveBoneScope;
    }

    public @Nullable ResourceLocation getLiveTexture(T animatable) {
        return this.liveTextureResolver.apply(animatable);
    }

    public RenderType getLiveRenderLayer(T animatable, ResourceLocation texture) {
        return this.liveRenderLayerResolver.apply(animatable, texture);
    }

    public int getLiveColor(T animatable, float partialTick) {
        float opacity = (float) this.liveOpacityResolver.applyAsDouble(animatable);
        int color = GeoRenderColor.multiplyAlpha(this.liveColorResolver.applyAsInt(animatable), opacity);
        if (this.liveColorTransitionRate <= 0.0f) {
            return color;
        }

        return LiveRenderColorInterpolator.resolve(animatable, this.name, color, partialTick, this.liveColorTransitionRate);
    }

    public @Nullable ResourceLocation getLiveEmissiveTexture(T animatable, ResourceLocation liveTexture) {
        if (this.liveEmissiveUsesLiveTexture) {
            return liveTexture;
        }

        return this.liveEmissiveTextureResolver.apply(animatable);
    }

    public float getLiveEmissiveStrength(T animatable) {
        float strength = (float) this.liveEmissiveStrengthResolver.applyAsDouble(animatable);
        return Float.isFinite(strength) && strength > 0.0f ? strength : 0.0f;
    }

    public int resolvePackedLight(T animatable, int packedLight) {
        return this.lightMode == LightMode.FULL_BRIGHT ? LightTexture.FULL_BRIGHT : packedLight;
    }

    public boolean shouldBakeIntoBlockModel() {
        return this.bakeIntoBlockModel;
    }

    public boolean shouldBakeIntoItemModel() {
        return this.bakeIntoItemModel;
    }

    public AnimatedBoneSelection getStaticBlockBoneSelection(String variantKey) {
        return this.staticBlockBoneSelectionResolver.apply(variantKey);
    }

    public AnimatedBoneSelection getStaticItemBoneSelection(String variantKey) {
        return this.staticItemBoneSelectionResolver.apply(variantKey);
    }

    public @Nullable ResourceLocation getStaticTexture() {
        return this.staticTextureResolver.get();
    }

    public @Nullable RenderType getStaticRenderLayer(ResourceLocation texture) {
        return this.staticRenderLayerResolver.apply(texture);
    }

    public boolean isStaticEmissive() {
        return this.staticEmissive;
    }

    public int getStaticBakePassCount() {
        return this.staticBakePassCount;
    }

    public enum LiveBoneScope {
        SELECTED_BONES,
        DYNAMIC_BONES
    }

    public enum LightMode {
        WORLD,
        FULL_BRIGHT
    }

    public static final class Builder<T extends GeoAnimatable> {
        private final String name;
        private Predicate<T> livePredicate = animatable -> true;
        private Function<T, AnimatedBoneSelection> liveBoneSelectionResolver = animatable -> AnimatedBoneSelection.all();
        private LiveBoneScope liveBoneScope = LiveBoneScope.SELECTED_BONES;
        private Function<T, @Nullable ResourceLocation> liveTextureResolver = animatable -> null;
        private BiFunction<T, ResourceLocation, RenderType> liveRenderLayerResolver = (animatable, texture) -> RenderType.entityCutoutNoCull(texture);
        private ToIntFunction<T> liveColorResolver = animatable -> 0xFFFFFFFF;
        private ToDoubleFunction<T> liveOpacityResolver = animatable -> 1.0d;
        private float liveColorTransitionRate;
        private Function<T, @Nullable ResourceLocation> liveEmissiveTextureResolver = animatable -> null;
        private boolean liveEmissiveUsesLiveTexture;
        private ToDoubleFunction<T> liveEmissiveStrengthResolver = animatable -> 0.0d;
        private LightMode lightMode = LightMode.WORLD;
        private boolean bakeIntoBlockModel = true;
        private boolean bakeIntoItemModel = true;
        private Function<String, AnimatedBoneSelection> staticBlockBoneSelectionResolver = variantKey -> AnimatedBoneSelection.all();
        private Function<String, AnimatedBoneSelection> staticItemBoneSelectionResolver = variantKey -> AnimatedBoneSelection.all();
        private Supplier<@Nullable ResourceLocation> staticTextureResolver = () -> null;
        private Function<ResourceLocation, @Nullable RenderType> staticRenderLayerResolver = texture -> null;
        private boolean staticEmissive;
        private int staticBakePassCount = 1;

        private Builder(String name) {
            this.name = Objects.requireNonNull(name, "name");
        }

        public Builder<T> when(Predicate<T> predicate) {
            this.livePredicate = Objects.requireNonNull(predicate, "predicate");
            return this;
        }

        public Builder<T> disableLiveRender() {
            this.livePredicate = animatable -> false;
            return this;
        }

        public Builder<T> liveBones(AnimatedBoneSelection selection) {
            Objects.requireNonNull(selection, "selection");
            this.liveBoneSelectionResolver = animatable -> selection;
            return this;
        }

        public Builder<T> liveBones(Function<T, AnimatedBoneSelection> resolver) {
            this.liveBoneSelectionResolver = Objects.requireNonNull(resolver, "resolver");
            return this;
        }

        public Builder<T> liveBoneScope(LiveBoneScope scope) {
            this.liveBoneScope = Objects.requireNonNull(scope, "scope");
            return this;
        }

        public Builder<T> liveTexture(ResourceLocation texture) {
            this.liveTextureResolver = animatable -> texture;
            return this;
        }

        public Builder<T> liveTexture(Function<T, @Nullable ResourceLocation> resolver) {
            this.liveTextureResolver = Objects.requireNonNull(resolver, "resolver");
            return this;
        }

        public Builder<T> liveRenderLayer(Function<ResourceLocation, RenderType> resolver) {
            Objects.requireNonNull(resolver, "resolver");
            this.liveRenderLayerResolver = (animatable, texture) -> resolver.apply(texture);
            return this;
        }

        public Builder<T> liveRenderLayer(BiFunction<T, ResourceLocation, RenderType> resolver) {
            this.liveRenderLayerResolver = Objects.requireNonNull(resolver, "resolver");
            return this;
        }

        public Builder<T> liveColor(int color) {
            this.liveColorResolver = animatable -> color;
            return this;
        }

        public Builder<T> liveTint(int color) {
            return this.liveColor(color);
        }

        public Builder<T> liveColor(ToIntFunction<T> resolver) {
            this.liveColorResolver = Objects.requireNonNull(resolver, "resolver");
            return this;
        }

        public Builder<T> liveTint(ToIntFunction<T> resolver) {
            return this.liveColor(resolver);
        }

        public Builder<T> liveTranslucent() {
            this.liveRenderLayerResolver = (animatable, texture) -> RenderType.entityTranslucent(texture);
            return this;
        }

        public Builder<T> liveAlpha(float alpha) {
            return this.liveOpacity(alpha);
        }

        public Builder<T> liveOpacity(float opacity) {
            if (!Float.isFinite(opacity) || opacity < 0.0f || opacity > 1.0f) {
                throw new IllegalArgumentException("live opacity must be finite and between 0 and 1");
            }

            this.liveOpacityResolver = animatable -> opacity;
            return this;
        }

        public Builder<T> liveOpacity(ToDoubleFunction<T> resolver) {
            this.liveOpacityResolver = Objects.requireNonNull(resolver, "resolver");
            return this;
        }

        public Builder<T> liveColorTransition(float transitionRate) {
            if (!Float.isFinite(transitionRate) || transitionRate < 0.0f) {
                throw new IllegalArgumentException("live color transition rate must be finite and non-negative");
            }

            this.liveColorTransitionRate = transitionRate;
            return this;
        }

        public Builder<T> liveEmissiveTexture(ResourceLocation texture) {
            this.liveEmissiveUsesLiveTexture = false;
            ResourceLocation resolvedTexture = Objects.requireNonNull(texture, "texture");
            this.liveEmissiveTextureResolver = animatable -> resolvedTexture;
            return this;
        }

        public Builder<T> liveEmissiveTexture(Function<T, @Nullable ResourceLocation> resolver) {
            this.liveEmissiveUsesLiveTexture = false;
            this.liveEmissiveTextureResolver = Objects.requireNonNull(resolver, "resolver");
            return this;
        }

        public Builder<T> liveEmissiveTextureFromLiveTexture() {
            this.liveEmissiveUsesLiveTexture = true;
            this.liveEmissiveTextureResolver = animatable -> null;
            return this;
        }

        public Builder<T> liveEmissiveStrength(float strength) {
            if (!Float.isFinite(strength) || strength < 0.0f) {
                throw new IllegalArgumentException("live emissive strength must be finite and non-negative");
            }

            this.liveEmissiveStrengthResolver = animatable -> strength;
            return this;
        }

        public Builder<T> liveEmissiveStrength(ToDoubleFunction<T> resolver) {
            this.liveEmissiveStrengthResolver = Objects.requireNonNull(resolver, "resolver");
            return this;
        }

        public Builder<T> liveEmissive(float strength) {
            return this.liveEmissiveTextureFromLiveTexture().liveEmissiveStrength(strength);
        }

        public Builder<T> liveEmissive(ToDoubleFunction<T> resolver) {
            return this.liveEmissiveTextureFromLiveTexture().liveEmissiveStrength(resolver);
        }

        public Builder<T> lightMode(LightMode mode) {
            this.lightMode = Objects.requireNonNull(mode, "mode");
            return this;
        }

        public Builder<T> excludeFromBlockBake() {
            this.bakeIntoBlockModel = false;
            return this;
        }

        public Builder<T> excludeFromItemBake() {
            this.bakeIntoItemModel = false;
            return this;
        }

        public Builder<T> staticBlockBones(AnimatedBoneSelection selection) {
            Objects.requireNonNull(selection, "selection");
            this.staticBlockBoneSelectionResolver = variantKey -> selection;
            return this;
        }

        public Builder<T> staticBlockBones(Function<String, AnimatedBoneSelection> resolver) {
            this.staticBlockBoneSelectionResolver = Objects.requireNonNull(resolver, "resolver");
            return this;
        }

        public Builder<T> staticItemBones(AnimatedBoneSelection selection) {
            Objects.requireNonNull(selection, "selection");
            this.staticItemBoneSelectionResolver = variantKey -> selection;
            return this;
        }

        public Builder<T> staticItemBones(Function<String, AnimatedBoneSelection> resolver) {
            this.staticItemBoneSelectionResolver = Objects.requireNonNull(resolver, "resolver");
            return this;
        }

        public Builder<T> staticTexture(ResourceLocation texture) {
            this.staticTextureResolver = () -> texture;
            return this;
        }

        public Builder<T> staticTexture(Supplier<@Nullable ResourceLocation> supplier) {
            this.staticTextureResolver = Objects.requireNonNull(supplier, "supplier");
            return this;
        }

        public Builder<T> staticRenderLayer(RenderType layer) {
            this.staticRenderLayerResolver = texture -> layer;
            return this;
        }

        public Builder<T> staticRenderLayer(Function<ResourceLocation, @Nullable RenderType> resolver) {
            this.staticRenderLayerResolver = Objects.requireNonNull(resolver, "resolver");
            return this;
        }

        public Builder<T> staticEmissive() {
            this.staticEmissive = true;
            return this;
        }

        public Builder<T> staticBakePassCount(int count) {
            if (count < 1) {
                throw new IllegalArgumentException("static bake pass count must be at least 1");
            }

            this.staticBakePassCount = count;
            return this;
        }

        public GeoRenderPass<T> build() {
            return new GeoRenderPass<>(this);
        }
    }
}
