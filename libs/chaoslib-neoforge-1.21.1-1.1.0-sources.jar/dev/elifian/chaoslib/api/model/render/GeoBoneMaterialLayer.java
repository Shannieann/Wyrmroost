package dev.elifian.chaoslib.api.model.render;

import dev.elifian.chaoslib.api.animatable.GeoAnimatable;
import dev.elifian.chaoslib.model.AnimatedBoneSelection;
import dev.elifian.chaoslib.platform.ClientOnly;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import java.util.function.ToDoubleFunction;
import java.util.function.ToIntFunction;

@ClientOnly
public final class GeoBoneMaterialLayer {
    private final String name;
    private final AnimatedBoneSelection liveBones;
    private final AnimatedBoneSelection staticBlockBones;
    private final AnimatedBoneSelection staticItemBones;
    private final GeoBoneMaterial material;
    private final @Nullable ResourceLocation liveTexture;
    private final @Nullable ResourceLocation staticTexture;
    private final ToIntFunction<GeoAnimatable> liveColorResolver;
    private final ToDoubleFunction<GeoAnimatable> liveOpacityResolver;
    private final float liveColorTransitionRate;
    private final boolean liveRequiresTranslucentLayer;
    private final boolean renderLive;
    private final boolean bakeIntoBlockModel;
    private final boolean bakeIntoItemModel;
    private final boolean staticEmissive;

    private GeoBoneMaterialLayer(Builder builder) {
        this.name = builder.name;
        this.liveBones = builder.liveBones;
        this.staticBlockBones = builder.staticBlockBones == null ? builder.liveBones : builder.staticBlockBones;
        this.staticItemBones = builder.staticItemBones == null ? builder.liveBones : builder.staticItemBones;
        this.material = builder.material;
        this.liveTexture = builder.liveTexture;
        this.staticTexture = builder.staticTexture;
        this.liveColorResolver = builder.liveColorResolver;
        this.liveOpacityResolver = builder.liveOpacityResolver;
        this.liveColorTransitionRate = builder.liveColorTransitionRate;
        this.liveRequiresTranslucentLayer = builder.liveRequiresTranslucentLayer || builder.material == GeoBoneMaterial.TRANSLUCENT;
        this.renderLive = builder.renderLive;
        this.bakeIntoBlockModel = builder.bakeIntoBlockModel;
        this.bakeIntoItemModel = builder.bakeIntoItemModel;
        this.staticEmissive = builder.staticEmissive;
    }

    public static Builder builder(String name, AnimatedBoneSelection liveBones, GeoBoneMaterial material) {
        return new Builder(name, liveBones, material);
    }

    public static GeoBoneMaterialLayer of(String name, AnimatedBoneSelection liveBones, GeoBoneMaterial material) {
        return builder(name, liveBones, material).build();
    }

    public static GeoBoneMaterialLayer liveOnly(String name, AnimatedBoneSelection liveBones, GeoBoneMaterial material) {
        return builder(name, liveBones, material)
                .excludeFromBlockBake()
                .excludeFromItemBake()
                .build();
    }

    public static GeoBoneMaterialLayer staticOnly(String name, AnimatedBoneSelection liveBones, GeoBoneMaterial material) {
        return builder(name, liveBones, material)
                .disableLiveRender()
                .build();
    }

    public static GeoBoneMaterialLayer cutout(String name, AnimatedBoneSelection liveBones) {
        return of(name, liveBones, GeoBoneMaterial.CUTOUT);
    }

    public static GeoBoneMaterialLayer translucent(String name, AnimatedBoneSelection liveBones) {
        return of(name, liveBones, GeoBoneMaterial.TRANSLUCENT);
    }

    public static GeoBoneMaterialLayer solid(String name, AnimatedBoneSelection liveBones) {
        return of(name, liveBones, GeoBoneMaterial.SOLID);
    }

    public static GeoBoneMaterialLayer liveOnlyCutout(String name, AnimatedBoneSelection liveBones) {
        return liveOnly(name, liveBones, GeoBoneMaterial.CUTOUT);
    }

    public static GeoBoneMaterialLayer staticOnlyCutout(String name, AnimatedBoneSelection liveBones) {
        return staticOnly(name, liveBones, GeoBoneMaterial.CUTOUT);
    }

    public static GeoBoneMaterialLayer liveOnlyTranslucent(String name, AnimatedBoneSelection liveBones) {
        return liveOnly(name, liveBones, GeoBoneMaterial.TRANSLUCENT);
    }

    public static GeoBoneMaterialLayer staticOnlyTranslucent(String name, AnimatedBoneSelection liveBones) {
        return staticOnly(name, liveBones, GeoBoneMaterial.TRANSLUCENT);
    }

    public static GeoBoneMaterialLayer liveOnlySolid(String name, AnimatedBoneSelection liveBones) {
        return liveOnly(name, liveBones, GeoBoneMaterial.SOLID);
    }

    public static GeoBoneMaterialLayer staticOnlySolid(String name, AnimatedBoneSelection liveBones) {
        return staticOnly(name, liveBones, GeoBoneMaterial.SOLID);
    }

    public String getName() {
        return this.name;
    }

    public AnimatedBoneSelection getLiveBones() {
        return this.liveBones;
    }

    public AnimatedBoneSelection getStaticBlockBones() {
        return this.staticBlockBones;
    }

    public AnimatedBoneSelection getStaticItemBones() {
        return this.staticItemBones;
    }

    public GeoBoneMaterial getMaterial() {
        return this.material;
    }

    public @Nullable ResourceLocation getLiveTexture() {
        return this.liveTexture;
    }

    public @Nullable ResourceLocation getStaticTexture() {
        return this.staticTexture;
    }

    public RenderType getLiveRenderLayer(ResourceLocation texture) {
        return this.liveRequiresTranslucentLayer
                ? RenderType.entityTranslucent(texture)
                : this.material.getLiveRenderLayer(texture);
    }

    public int getLiveColor(GeoAnimatable animatable) {
        int color = this.liveColorResolver.applyAsInt(animatable);
        float opacity = (float) this.liveOpacityResolver.applyAsDouble(animatable);
        return GeoRenderColor.multiplyAlpha(color, opacity);
    }

    public float getLiveColorTransitionRate() {
        return this.liveColorTransitionRate;
    }

    public boolean shouldRenderLive() {
        return this.renderLive;
    }

    public boolean shouldBakeIntoBlockModel() {
        return this.bakeIntoBlockModel;
    }

    public boolean shouldBakeIntoItemModel() {
        return this.bakeIntoItemModel;
    }

    public boolean isStaticEmissive() {
        return this.staticEmissive;
    }

    public static final class Builder {
        private final String name;
        private final AnimatedBoneSelection liveBones;
        private final GeoBoneMaterial material;
        private AnimatedBoneSelection staticBlockBones;
        private AnimatedBoneSelection staticItemBones;
        private @Nullable ResourceLocation liveTexture;
        private @Nullable ResourceLocation staticTexture;
        private ToIntFunction<GeoAnimatable> liveColorResolver = animatable -> 0xFFFFFFFF;
        private ToDoubleFunction<GeoAnimatable> liveOpacityResolver = animatable -> 1.0d;
        private float liveColorTransitionRate;
        private boolean liveRequiresTranslucentLayer;
        private boolean renderLive = true;
        private boolean bakeIntoBlockModel = true;
        private boolean bakeIntoItemModel = true;
        private boolean staticEmissive;

        private Builder(String name, AnimatedBoneSelection liveBones, GeoBoneMaterial material) {
            this.name = Objects.requireNonNull(name, "name");
            this.liveBones = Objects.requireNonNull(liveBones, "liveBones");
            this.material = Objects.requireNonNull(material, "material");
        }

        public Builder staticBlockBones(AnimatedBoneSelection selection) {
            this.staticBlockBones = Objects.requireNonNull(selection, "selection");
            return this;
        }

        public Builder staticItemBones(AnimatedBoneSelection selection) {
            this.staticItemBones = Objects.requireNonNull(selection, "selection");
            return this;
        }

        public Builder liveTexture(ResourceLocation texture) {
            this.liveTexture = Objects.requireNonNull(texture, "texture");
            return this;
        }

        public Builder staticTexture(ResourceLocation texture) {
            this.staticTexture = Objects.requireNonNull(texture, "texture");
            return this;
        }

        public Builder liveColor(int color) {
            this.liveColorResolver = animatable -> color;
            this.liveRequiresTranslucentLayer |= ((color >>> 24) & 0xFF) < 255;
            return this;
        }

        public Builder liveTint(int color) {
            return this.liveColor(color);
        }

        public Builder liveColor(ToIntFunction<GeoAnimatable> resolver) {
            this.liveColorResolver = Objects.requireNonNull(resolver, "resolver");
            this.liveRequiresTranslucentLayer = true;
            return this;
        }

        public Builder liveTint(ToIntFunction<GeoAnimatable> resolver) {
            return this.liveColor(resolver);
        }

        public Builder liveTranslucent() {
            this.liveRequiresTranslucentLayer = true;
            return this;
        }

        public Builder liveColorTransition(float transitionRate) {
            if (!Float.isFinite(transitionRate) || transitionRate < 0.0f) {
                throw new IllegalArgumentException("live color transition rate must be finite and non-negative");
            }

            this.liveColorTransitionRate = transitionRate;
            return this;
        }

        public Builder liveAlpha(float alpha) {
            return this.liveOpacity(alpha);
        }

        public Builder liveOpacity(float opacity) {
            if (!Float.isFinite(opacity) || opacity < 0.0f || opacity > 1.0f) {
                throw new IllegalArgumentException("live opacity must be finite and between 0 and 1");
            }

            this.liveOpacityResolver = animatable -> opacity;
            this.liveRequiresTranslucentLayer |= opacity < 1.0f;
            return this;
        }

        public Builder liveOpacity(ToDoubleFunction<GeoAnimatable> resolver) {
            this.liveOpacityResolver = Objects.requireNonNull(resolver, "resolver");
            this.liveRequiresTranslucentLayer = true;
            return this;
        }

        public Builder disableLiveRender() {
            this.renderLive = false;
            return this;
        }

        public Builder excludeFromBlockBake() {
            this.bakeIntoBlockModel = false;
            return this;
        }

        public Builder excludeFromItemBake() {
            this.bakeIntoItemModel = false;
            return this;
        }

        public Builder staticEmissive() {
            this.staticEmissive = true;
            return this;
        }

        public GeoBoneMaterialLayer build() {
            return new GeoBoneMaterialLayer(this);
        }
    }
}
