package dev.elifian.chaoslib.api.model.render;


import dev.elifian.chaoslib.platform.ClientOnly;

@ClientOnly
public final class GeoRenderColor {
    private GeoRenderColor() {
    }

    public static float red(int argb) {
        return ((argb >>> 16) & 0xFF) / 255.0f;
    }

    public static float green(int argb) {
        return ((argb >>> 8) & 0xFF) / 255.0f;
    }

    public static float blue(int argb) {
        return (argb & 0xFF) / 255.0f;
    }

    public static float alpha(int argb) {
        return ((argb >>> 24) & 0xFF) / 255.0f;
    }

    public static int multiplyAlpha(int argb, float alphaMultiplier) {
        if (!Float.isFinite(alphaMultiplier)) {
            alphaMultiplier = 1.0f;
        }

        int alpha = (argb >>> 24) & 0xFF;
        int scaledAlpha = Math.max(0, Math.min(255, Math.round(alpha * Math.max(0.0f, Math.min(1.0f, alphaMultiplier)))));
        return (argb & 0x00FFFFFF) | (scaledAlpha << 24);
    }
}
