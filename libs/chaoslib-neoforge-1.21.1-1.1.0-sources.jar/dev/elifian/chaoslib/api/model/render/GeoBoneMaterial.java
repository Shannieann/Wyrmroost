package dev.elifian.chaoslib.api.model.render;

import dev.elifian.chaoslib.platform.ClientOnly;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.Nullable;

@ClientOnly
public enum GeoBoneMaterial {
    SOLID {
        @Override
        public RenderType getLiveRenderLayer(ResourceLocation texture) {
            return RenderType.entitySolid(texture);
        }

        @Override
        public @Nullable RenderType getStaticRenderLayer(ResourceLocation texture) {
            return RenderType.solid();
        }
    },
    CUTOUT {
        @Override
        public RenderType getLiveRenderLayer(ResourceLocation texture) {
            return RenderType.entityCutoutNoCull(texture);
        }

        @Override
        public @Nullable RenderType getStaticRenderLayer(ResourceLocation texture) {
            return RenderType.cutout();
        }
    },
    TRANSLUCENT {
        @Override
        public RenderType getLiveRenderLayer(ResourceLocation texture) {
            return RenderType.entityTranslucent(texture);
        }

        @Override
        public @Nullable RenderType getStaticRenderLayer(ResourceLocation texture) {
            return RenderType.translucent();
        }
    };

    public abstract RenderType getLiveRenderLayer(ResourceLocation texture);

    public abstract @Nullable RenderType getStaticRenderLayer(ResourceLocation texture);
}
