package dev.elifian.chaoslib.api.model;

import com.mojang.blaze3d.platform.NativeImage;
import dev.elifian.chaoslib.ChaosLib;
import dev.elifian.chaoslib.api.animatable.GeoAnimatable;
import dev.elifian.chaoslib.api.animatable.GeoBlockEntity;
import dev.elifian.chaoslib.api.animation.AnimatableManager;
import dev.elifian.chaoslib.api.animation.AnimationController;
import dev.elifian.chaoslib.api.animation.AnimationPlaybackController;
import dev.elifian.chaoslib.api.animation.AnimationState;
import dev.elifian.chaoslib.api.model.render.GeoBoneMaterialLayer;
import dev.elifian.chaoslib.api.model.render.GeoRenderPass;
import dev.elifian.chaoslib.cache.ChaosLibCacheRegistry;
import dev.elifian.chaoslib.cache.object.*;
import dev.elifian.chaoslib.client.animation.GeoAnimationData;
import dev.elifian.chaoslib.client.animation.GeoAnimationLoader;
import dev.elifian.chaoslib.client.animation.GeoAnimationRuntime;
import dev.elifian.chaoslib.client.animation.GeoBoneTrackingHelper;
import dev.elifian.chaoslib.gpu.animation.ChaosGpuAnimationPayload;
import dev.elifian.chaoslib.gpu.animation.ChaosGpuAnimationPayloadCache;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuAnimationPoseStorage;
import dev.elifian.chaoslib.gpu.backend.GpuProceduralPoseLayer;
import dev.elifian.chaoslib.gpu.mesh.ChaosGpuGeoMesh;
import dev.elifian.chaoslib.gpu.render.ChaosGpuPoseDataCache;
import dev.elifian.chaoslib.model.*;
import dev.elifian.chaoslib.model.baked.*;
import dev.elifian.chaoslib.platform.ClientOnly;
import dev.elifian.chaoslib.renderer.block.ChaosBlockEntityRenderFrameClock;
import dev.elifian.chaoslib.util.IdentifierUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Vector3d;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.IntToDoubleFunction;

@ClientOnly
/**
 * Base client-side geo model definition for a {@link GeoAnimatable}.
 *
 * <p>A {@code GeoModel} resolves model, texture, and animation resources, exposes render policy
 * for blocks, items, block entities, and living entities, and owns the baked-model and pose-cache
 * utilities used by ChaosLib renderers. Implementations usually override a small subset of
 * resource and render hooks while inheriting the default animation and static-render behavior.</p>
 *
 * @param <T> animatable type rendered by this model
 */
public abstract class GeoModel<T extends GeoAnimatable> {
    private static final ChaosLibCacheRegistry CACHE_REGISTRY = ChaosLibCacheRegistry.getInstance();
    private static final Map<Class<?>, Boolean> CUSTOM_ANIMATION_OVERRIDE_CACHE = Collections.synchronizedMap(new WeakHashMap<>());
    private static final Map<Class<?>, Boolean> GPU_PROCEDURAL_OVERRIDE_CACHE = Collections.synchronizedMap(new WeakHashMap<>());
    private static final Set<String> LOGGED_GPU_FALLBACKS = Collections.synchronizedSet(new HashSet<>());
    private static final Object REST_POSE_CPU_CACHE_KEY = new Object();
    private static BakedGeoModel lastPoseCacheModel;
    private static Map<Object, PoseCacheEntry> lastPoseCache;
    // Per-frame dedup of GPU procedural pose preparation, shared across every block entity of a model that
    // resolves to the same pose key in a frame (e.g. Chaos Transducers spinning in lockstep). preparePoseToken
    // already content-shares the GPU bone buffer, but each instance still re-ran applyGpuPose capture plus
    // collectActiveStates just to rediscover the same key; this skips both for duplicate pose keys. Render
    // thread only; cleared every frame by clearPoseCache().
    private static final Map<ProceduralFramePoseDedupKey, Object> PROCEDURAL_FRAME_POSE_DEDUP = new HashMap<>();
    private BakedGeoModel currentModel;
    private StaticGeoStatePoseProfile autoStaticStatePoseProfile;
    // Tracks the content pose the shared (singleton) CPU model is currently posed to, scoped to a render
    // frame. When the next block entity in the same frame needs the identical content pose, the model's
    // bone matrices are already correct (read downstream for tracked bones, item anchors and frozen
    // rendering), so the redundant CPU re-pose is skipped. Frame-scoped via the render frame id so a stale
    // pose from a previous frame never causes a wrong skip.
    private int liveCpuPoseFrameId;
    private Object liveCpuPoseKey;
    private GeoResourceSet<T> resourceSet;
    private GeoTrackingPolicy<T> trackingPolicy;
    private GeoRenderPolicy<T> renderPolicy;
    private GeoStaticModelPolicy<T> staticModelPolicy;
    private List<GeoRenderPass<T>> renderPasses;
    private ResourceLocation cachedDefaultStaticModelBaseId;
    private boolean defaultStaticModelBaseIdResolved;
    private ResourceLocation cachedStaticModelId;
    private boolean staticModelIdResolved;
    private final Map<BakedGeoModel, Set<String>> autoDynamicBoneCache = new WeakHashMap<>();
    private final Map<BakedGeoModel, Set<String>> dynamicStaticSplitBoneCache = new WeakHashMap<>();
    private final ThreadLocal<GpuProceduralCaptureContext> reusableGpuProceduralContext =
            ThreadLocal.withInitial(GpuProceduralCaptureContext::new);
    private GpuProceduralCaptureContext activeProceduralContext;

    public interface PoseCacheEntry {
    }

    /**
     * Returns the geo model resource used to bake the runtime model for the given animatable.
     */
    public abstract ResourceLocation getModelResource(T animatable);

    /**
     * Returns the primary texture resource used for the given animatable.
     */
    public abstract ResourceLocation getTextureResource(T animatable);

    /**
     * Returns the texture resource used when baking or rendering the static representation of this
     * model.
     */
    public ResourceLocation getStaticTextureResource() {
        ResourceLocation texture = this.resolveStaticTextureResource();
        if (texture != null) {
            return texture;
        }

        throw new IllegalStateException("Static texture resource is not defined for " + this.getClass().getName());
    }

    /**
     * Returns the animation resource containing controller clips for the given animatable.
     */
    public abstract @Nullable ResourceLocation getAnimationResource(T animatable);

    public GeoResourceSet<T> getResourceSet() {
        if (this.resourceSet == null) {
            this.resourceSet = this.createResourceSet();
        }
        return this.resourceSet;
    }

    public GeoTrackingPolicy<T> getTrackingPolicy() {
        if (this.trackingPolicy == null) {
            this.trackingPolicy = this.createTrackingPolicy();
        }
        return this.trackingPolicy;
    }

    public GeoRenderPolicy<T> getRenderPolicy() {
        if (this.renderPolicy == null) {
            this.renderPolicy = this.createRenderPolicy();
        }
        return this.renderPolicy;
    }

    public GeoStaticModelPolicy<T> getStaticModelPolicy() {
        if (this.staticModelPolicy == null) {
            this.staticModelPolicy = this.createStaticModelPolicy();
        }
        return this.staticModelPolicy;
    }

    public final List<GeoRenderPass<T>> getRenderPasses() {
        if (this.renderPasses == null) {
            List<GeoRenderPass<T>> explicitPasses = this.createRenderPasses();
            this.renderPasses = explicitPasses.isEmpty()
                    ? List.copyOf(this.createBoneMaterialRenderPasses())
                    : List.copyOf(explicitPasses);
        }
        return this.renderPasses;
    }

    public final boolean usesCustomRenderPasses() {
        return !this.getRenderPasses().isEmpty();
    }

    protected GeoResourceSet<T> createResourceSet() {
        return new LegacyGeoResourceSet<>(this);
    }

    protected GeoTrackingPolicy<T> createTrackingPolicy() {
        return new LegacyGeoTrackingPolicy<>(this);
    }

    protected GeoRenderPolicy<T> createRenderPolicy() {
        return new LegacyGeoRenderPolicy<>(this);
    }

    protected GeoStaticModelPolicy<T> createStaticModelPolicy() {
        return new LegacyGeoStaticModelPolicy<>(this);
    }

    protected List<GeoRenderPass<T>> createRenderPasses() {
        return List.of();
    }

    protected List<GeoBoneMaterialLayer> createBoneMaterialLayers() {
        return List.of();
    }

    /**
     * Returns the block render mode for the current animatable.
     *
     * <p>Use {@link GeoBlockRenderMode#STATIC_ONLY} for block entities that must render only as
     * baked chunk geometry and never need live bones, renderer additions, tracked bones, or
     * transitions.</p>
     */
    public GeoBlockRenderMode getBlockRenderMode(T animatable) {
        return GeoBlockRenderMode.AUTO;
    }

    private List<GeoRenderPass<T>> createBoneMaterialRenderPasses() {
        List<GeoBoneMaterialLayer> layers = this.createBoneMaterialLayers();
        if (layers.isEmpty()) {
            return List.of();
        }

        ArrayList<GeoRenderPass<T>> passes = new ArrayList<>(layers.size());
        for (GeoBoneMaterialLayer layer : layers) {
            GeoRenderPass.Builder<T> builder = GeoRenderPass.<T>builder(layer.getName())
                    .liveBones(layer.getLiveBones())
                    .liveTexture(animatable -> {
                        ResourceLocation texture = layer.getLiveTexture();
                        return texture != null ? texture : this.getTextureResource(animatable);
                    })
                    .liveRenderLayer((animatable, texture) -> layer.getLiveRenderLayer(texture))
                    .liveColor(layer::getLiveColor)
                    .liveColorTransition(layer.getLiveColorTransitionRate())
                    .staticBlockBones(layer.getStaticBlockBones())
                    .staticItemBones(layer.getStaticItemBones());

            if (!layer.shouldRenderLive()) {
                builder.disableLiveRender();
            }

            if (!layer.shouldBakeIntoBlockModel()) {
                builder.excludeFromBlockBake();
            }

            if (!layer.shouldBakeIntoItemModel()) {
                builder.excludeFromItemBake();
            }

            if (layer.shouldBakeIntoBlockModel() || layer.shouldBakeIntoItemModel()) {
                ResourceLocation staticTexture = layer.getStaticTexture();
                if (staticTexture == null) {
                    staticTexture = this.resolveStaticTextureResource();
                }

                if (staticTexture != null) {
                    ResourceLocation resolvedStaticTexture = staticTexture;
                    builder.staticTexture(resolvedStaticTexture)
                            .staticRenderLayer(texture -> layer.getMaterial().getStaticRenderLayer(texture));
                }
            }

            if (layer.isStaticEmissive()) {
                builder.staticEmissive();
            }

            passes.add(builder.build());
        }

        return List.copyOf(passes);
    }

    /**
     * Returns the generated static block-model id used for baked world rendering, or {@code null}
     * when this model does not expose a static block form.
     */
    public ResourceLocation getStaticModelId() {
        if (!this.staticModelIdResolved) {
            ResourceLocation baseId = this.resolveDefaultStaticModelBaseId();
            this.cachedStaticModelId = baseId == null ? null : ResourceLocation.fromNamespaceAndPath(baseId.getNamespace(), "block/" + baseId.getPath());
            this.staticModelIdResolved = true;
        }

        return this.cachedStaticModelId;
    }

    /**
     * Returns the geo model resource used when baking a static block representation.
     */
    public ResourceLocation getStaticGeoModelResource() {
        ResourceLocation model = this.resolveStaticModelResource();
        if (model != null) {
            return model;
        }

        throw new IllegalStateException("Static geo model resource is not defined for " + this.getClass().getName());
    }

    /**
     * Returns the generated item-model id used for baked inventory and handheld rendering, or
     * {@code null} when this model does not expose a static item form.
     */
    public ResourceLocation getStaticItemModelId() {
        return this.resolveDefaultStaticModelBaseId();
    }

    /**
     * Returns the geo model resource used when baking a static item representation.
     */
    public ResourceLocation getStaticItemGeoModelResource() {
        return this.getStaticGeoModelResource();
    }

    /**
     * Returns the root transform applied to the baked static item representation.
     */
    public Matrix4f getStaticItemRootTransform() {
        return new Matrix4f();
    }

    /**
     * Returns the render-mode selector used when baking a static item representation.
     */
    public StaticGeoRenderModeSelector getStaticItemRenderModeSelector() {
        return state -> StaticGeoRenderMode.ALL_BONES;
    }

    /**
     * Returns the root transform applied to the baked static block representation.
     */
    public Matrix4f getStaticRootTransform() {
        return new Matrix4f();
    }

    /**
     * Returns the root transform applied to the baked static block representation for a specific
     * block state.
     */
    public Matrix4f getStaticRootTransform(@Nullable BlockState state) {
        return new Matrix4f(this.getStaticRootTransform());
    }

    /**
     * Returns the root transform applied before rendering a live block entity instance.
     */
    public Matrix4f getBlockEntityRootTransform(T animatable) {
        return new Matrix4f(this.getStaticRootTransform());
    }

    /**
     * Returns the root transform applied before rendering a live entity instance.
     */
    public Matrix4f getEntityRootTransform(T animatable) {
        return new Matrix4f();
    }

    /**
     * Returns the render-mode selector used when baking static block geometry.
     */
    public StaticGeoRenderModeSelector getStaticRenderModeSelector() {
        return state -> StaticGeoRenderMode.ALL_BONES;
    }

    /**
     * Returns the bones that should remain live instead of being folded into the static baked
     * portion of the model.
     */
    public AnimatedBoneSelection getBakeExcludedBones() {
        return AnimatedBoneSelection.none();
    }

    /**
     * Returns the bones rendered by the live pass for the current animatable.
     */
    public AnimatedBoneSelection getLiveRenderBones(T animatable) {
        return this.getBakeExcludedBones();
    }

    /**
     * Returns bone names whose world transforms should be exported back to the animatable.
     */
    public Set<String> getTrackedBones(T animatable) {
        return Set.of();
    }

    /**
     * Returns the render layer used for the model's primary pass.
     */
    public RenderType getRenderType(T animatable, ResourceLocation texture) {
        TextureTransparencyProfile transparency = TextureTransparencyProfile.get(texture);
        if (transparency.isFullyOpaque()) {
            return RenderType.entitySolid(texture);
        }

        if (transparency.hasTranslucency()) {
            return RenderType.entityTranslucent(texture);
        }

        return RenderType.entityCutoutNoCull(texture);
    }

    /**
     * Returns whether the primary render pass should disable back-face culling when a subclass
     * fully overrides {@link #getRenderType(GeoAnimatable, ResourceLocation)}.
     */
    public boolean useNoCullRenderType(T animatable) {
        return false;
    }

    /**
     * Returns whether this model exposes a separate emissive rendering path.
     */
    public boolean useEmissiveLayer() {
        return false;
    }

    /**
     * Returns whether emissive rendering should be enabled for the current animatable.
     */
    public boolean shouldRenderEmissive(T animatable) {
        return this.useEmissiveLayer();
    }

    /**
     * Returns the bone-selection policy used for the live emissive pass.
     */
    public AnimatedBoneSelection getEmissiveBoneSelection(T animatable) {
        return AnimatedBoneSelection.all();
    }

    /**
     * Returns whether static baked rendering should emit an emissive pass for the given state.
     */
    public boolean shouldRenderStaticEmissive(@Nullable BlockState state) {
        return this.useEmissiveLayer();
    }

    /**
     * Returns the bone-selection policy used for static emissive baking of the given variant.
     */
    public AnimatedBoneSelection getStaticEmissiveBoneSelection(String variantKey) {
        return this.useEmissiveLayer() ? AnimatedBoneSelection.all() : AnimatedBoneSelection.none();
    }

    /**
     * Returns the number of emissive passes emitted for baked static geometry.
     */
    public int getStaticEmissivePassCount() {
        return 1;
    }

    /**
     * Returns the emissive texture resource used for the current live animatable.
     */
    public ResourceLocation getEmissiveTextureResource(T animatable) {
        return IdentifierUtil.deriveEmissiveTexture(this.getTextureResource(animatable));
    }

    /**
     * Returns the emissive texture resource used for static baked rendering.
     */
    public ResourceLocation getStaticEmissiveTextureResource() {
        ResourceLocation emissiveTexture = this.resolveStaticResource(this::getEmissiveTextureResource);
        if (emissiveTexture != null) {
            return emissiveTexture;
        }

        return IdentifierUtil.deriveEmissiveTexture(this.getStaticTextureResource());
    }

    /**
     * Returns the render layer used for the emissive pass.
     */
    public RenderType getEmissiveRenderType(T animatable, ResourceLocation texture) {
        return RenderType.eyes(texture);
    }

    /**
     * Returns the multiplier applied to block-entity emissive color channels.
     */
    public float getBlockEntityEmissiveStrength(T animatable) {
        return 1.0f;
    }

    /**
     * Resolves the final set of emissive bones after combining emissive selection with dynamic
     * render constraints.
     */
    public Set<String> getResolvedEmissiveBones(T animatable, BakedGeoModel model, @Nullable Set<String> dynamicRenderBones) {
        AnimatedBoneSelection selection = this.getEmissiveBoneSelection(animatable);
        if (selection.isNone()) {
            return Set.of();
        }

        if (selection.isAuto()) {
            return dynamicRenderBones == null || dynamicRenderBones.isEmpty() ? Set.of() : dynamicRenderBones;
        }

        if (selection.isAll()) {
            return dynamicRenderBones == null ? model.boneNames() : dynamicRenderBones;
        }

        Set<String> resolved = selection.resolve(model);
        if (resolved == null || resolved.isEmpty()) {
            return Set.of();
        }

        if (dynamicRenderBones == null) {
            return resolved;
        }

        HashSet<String> filtered = new HashSet<>(resolved);
        filtered.retainAll(dynamicRenderBones);
        return filtered.isEmpty() ? Set.of() : Set.copyOf(filtered);
    }

    /**
     * Returns whether live emissive bones should be rendered in the main pass instead of a
     * separate emissive pass.
     */
    public boolean renderEmissiveInBasePass() {
        return true;
    }

    /**
     * Returns whether computed poses for this animatable should be cached.
     */
    public boolean usePoseCache(T animatable) {
        return true;
    }

    /**
     * Returns whether pose-cache entries may be shared across instances with identical animation
     * state.
     */
    public boolean sharePoseCacheAcrossInstances(T animatable) {
        return true;
    }

    /**
     * Returns the render layer used for baked static world geometry.
     */
    public RenderType getStaticRenderLayer(@Nullable BlockState state) {
        return RenderType.cutout();
    }

    /**
     * Returns the quad-culling policy used when baking static world geometry.
     */
    public StaticGeoQuadCullingMode getStaticQuadCullingMode(@Nullable BlockState state) {
        return StaticGeoQuadCullingMode.AUTO;
    }

    /**
     * Returns whether fully enclosed block entities may be skipped during rendering.
     */
    public boolean useEnclosedVisibilityCulling() {
        return true;
    }

    /**
     * Applies X-axis offsets to a sequence of bones from normalized progress values.
     */
    protected final void applyLinearProgressBonesOnX(String[] bones, IntToDoubleFunction progressGetter, float direction, float retractedOffset) {
        applyLinearProgressBones(bones, progressGetter, direction, retractedOffset, GeoBone::setPosX);
    }

    /**
     * Applies Y-axis offsets to a sequence of bones from normalized progress values.
     */
    protected final void applyLinearProgressBonesOnY(String[] bones, IntToDoubleFunction progressGetter, float direction, float retractedOffset) {
        applyLinearProgressBones(bones, progressGetter, direction, retractedOffset, GeoBone::setPosY);
    }

    /**
     * Applies Z-axis offsets to a sequence of bones from normalized progress values.
     */
    protected final void applyLinearProgressBonesOnZ(String[] bones, IntToDoubleFunction progressGetter, float direction, float retractedOffset) {
        applyLinearProgressBones(bones, progressGetter, direction, retractedOffset, GeoBone::setPosZ);
    }

    private void applyLinearProgressBones(String[] bones, IntToDoubleFunction progressGetter, float direction, float retractedOffset, BonePositionSetter positionSetter) {
        for (int i = 0; i < bones.length; i++) {
            float progress = (float) progressGetter.applyAsDouble(i);
            float clamped = Math.max(0.0f, Math.min(1.0f, progress));
            float retraction = retractedOffset * (1.0f - clamped);
            this.getBone(bones[i]).ifPresent(bone -> {
                bone.setTrackingMatrices(true);
                positionSetter.set(bone, direction * retraction);
            });
        }
    }

    @FunctionalInterface
    private interface BonePositionSetter {
        void set(GeoBone bone, float value);
    }

    /**
     * Sets the Y rotation of the named bone if it exists in the current baked model.
     */
    protected final void setBoneRotY(String boneName, float rotation) {
        this.getBone(boneName).ifPresent(bone -> bone.setRotY(rotation));
    }

    /**
     * Returns the maximum radius used to keep frozen block-entity renders active.
     */
    public double getFrozenBlockEntityRenderRadius() {
        return 32.0d;
    }

    /**
     * Returns the maximum radius at which a frozen block-entity render may remain visible.
     *
     * <p>This is separate from {@link #getFrozenBlockEntityRenderRadius()}, which only controls
     * when the live animated render should transition into the frozen/static path.
     *
     * <p>The default keeps frozen renders visible as far as the client can currently see the
     * world, while still allowing live animation to switch off much earlier.
     */
    public double getFrozenBlockEntityVisibilityRadius() {
        return Double.POSITIVE_INFINITY;
    }

    /**
     * Returns the bones that stay live when frozen BER handoff is active.
     */
    public AnimatedBoneSelection getFrozenRenderBones(T animatable) {
        return this.getBakeExcludedBones();
    }

    /**
     * Returns whether this model explicitly opts into rendering an invisible block through BER.
     */
    public boolean allowInvisibleBlockRender(T animatable) {
        return false;
    }

    /**
     * Returns the thaw duration used when transitioning a frozen block entity back to live render.
     */
    public float getFrozenBlockEntityThawDurationTicks() {
        return 8.0f;
    }

    /**
     * Returns whether a client resource is currently present in the active resource manager.
     */
    public final boolean hasClientResource(ResourceLocation resourceId) {
        return CACHE_REGISTRY.clientResourceCache().hasClientResource(resourceId);
    }

    /**
     * Returns whether baked static geometry should participate in ambient occlusion shading.
     */
    public boolean useStaticAmbientOcclusion() {
        return false;
    }

    /**
     * Returns the default rest-pose overrides used for static baking.
     */
    public Map<String, StaticGeoBonePose> getBoneRestPoses() {
        return Map.of();
    }

    /**
     * Returns the automatic static-pose configuration used to derive baked variants.
     */
    public AutoStaticPoseConfig getAutoStaticPoseConfig() {
        return AutoStaticPoseConfig.empty();
    }

    /**
     * Creates the cache key used for frozen-pose reuse.
     */
    public Object createFrozenPoseCacheKey(T animatable, BakedGeoModel model, Map<String, StaticGeoBonePose> frozenBonePoses) {
        AutoStaticPoseConfig config = this.getAutoStaticPoseConfig();
        if (!config.isEmpty()) {
            return config.createCurrentPoseCacheKey(model);
        }

        return null;
    }

    /**
     * Returns the resolved static-state pose profile for this model.
     */
    public StaticGeoStatePoseProfile getStaticStatePoseProfile() {
        if (this.autoStaticStatePoseProfile != null) {
            return this.autoStaticStatePoseProfile;
        }

        AutoStaticPoseConfig config = this.getAutoStaticPoseConfig();
        if (config.isEmpty()) {
            this.autoStaticStatePoseProfile = StaticGeoStatePoseProfile.empty();
            return this.autoStaticStatePoseProfile;
        }

        this.autoStaticStatePoseProfile = config.createStatePoseProfile(resolveStaticBlockStateTemplate());
        return this.autoStaticStatePoseProfile;
    }

    /**
     * Returns the known static pose variant keys supported by this model.
     */
    public Set<String> getStaticPoseVariantKeys() {
        StaticGeoStatePoseProfile profile = this.getStaticStatePoseProfile();
        return profile.isEmpty() ? Set.of("default") : profile.getVariantKeys();
    }

    /**
     * Resolves the static pose variant key for the given block state.
     */
    public String getStaticPoseVariantKey(@Nullable BlockState state) {
        StaticGeoStatePoseProfile profile = this.getStaticStatePoseProfile();
        return profile.isEmpty() ? "default" : profile.getVariantKey(state);
    }

    /**
     * Returns the rest-pose overrides for the given static variant.
     */
    public Map<String, StaticGeoBonePose> getBoneRestPoses(String variantKey) {
        StaticGeoStatePoseProfile profile = this.getStaticStatePoseProfile();
        return profile.isEmpty() ? this.getBoneRestPoses() : profile.getBoneRestPoses(variantKey);
    }

    /**
     * Returns the baked model for the given geo resource, loading it on first access.
     */
    public BakedGeoModel getBakedModel(ResourceLocation location) {
        this.currentModel = CACHE_REGISTRY.modelCache().get(location);
        return this.currentModel;
    }

    /**
     * Returns a bone from the currently active baked model.
     */
    public Optional<GeoBone> getBone(String name) {
        if (this.currentModel == null) {
            return Optional.empty();
        }

        return this.currentModel.getBone(name);
    }

    /**
     * Returns a locator attached to the named bone in the currently active baked model.
     */
    public Optional<GeoLocator> getLocator(String boneName, String locatorName) {
        return this.getBone(boneName).flatMap(bone -> bone.getLocator(locatorName));
    }

    /**
     * Returns a public API handle for a bone from the currently active baked model.
     */
    public Optional<? extends GeoBoneHandle> getBoneHandle(String name) {
        GpuProceduralCaptureContext captureContext = this.activeProceduralContext;
        if (captureContext != null) {
            return captureContext.getBoneHandle(name);
        }
        return this.getBone(name);
    }

    /**
     * Returns a public API handle for a locator attached to the named bone in the currently active baked model.
     */
    public Optional<? extends GeoLocatorHandle> getLocatorHandle(String boneName, String locatorName) {
        return this.getLocator(boneName, locatorName);
    }

    /**
     * Returns the set of bones included in the static baked pass for the given render mode.
     */
    public Set<String> getStaticBoneNames(BakedGeoModel model, StaticGeoRenderMode renderMode) {
        return switch (renderMode) {
            case NONE -> Set.of();
            case ALL_BONES -> model.boneNames();
            case STATIC_ONLY -> {
                Set<String> staticBones = new LinkedHashSet<>(model.boneNames());
                staticBones.removeAll(this.getDynamicStaticSplitSelection(model).resolve(model));
                yield Set.copyOf(staticBones);
            }
        };
    }

    /**
     * Returns the set of bones included in the static emissive pass for the given variant and
     * render mode.
     */
    public Set<String> getStaticEmissiveBoneNames(BakedGeoModel model, String variantKey, StaticGeoRenderMode renderMode) {
        AnimatedBoneSelection selection = this.getStaticEmissiveBoneSelection(variantKey);
        if (selection.isNone()) {
            return Set.of();
        }

        if (renderMode == StaticGeoRenderMode.NONE) {
            return Set.of();
        }

        Set<String> candidates = selection.resolve(model);
        if (renderMode == StaticGeoRenderMode.ALL_BONES || candidates.isEmpty()) {
            return candidates;
        }

        Set<String> staticBones = this.getStaticBoneNames(model, renderMode);
        LinkedHashSet<String> included = new LinkedHashSet<>(candidates);
        included.retainAll(staticBones);
        return Set.copyOf(included);
    }

    public Set<String> resolveLiveRenderPassBones(GeoRenderPass<T> pass, BakedGeoModel model, T animatable, @Nullable Set<String> dynamicRenderBones) {
        AnimatedBoneSelection selection = pass.getLiveBoneSelection(animatable);
        return switch (pass.getLiveBoneScope()) {
            case SELECTED_BONES -> resolveSelectedPassBones(selection, model);
            case DYNAMIC_BONES -> resolveDynamicPassBones(selection, model, dynamicRenderBones);
        };
    }

    public Set<String> resolveStaticRenderPassBones(GeoRenderPass<?> pass, BakedGeoModel model, String variantKey, StaticGeoRenderMode renderMode, boolean itemModel) {
        if (renderMode == StaticGeoRenderMode.NONE) {
            return Set.of();
        }

        AnimatedBoneSelection selection = itemModel
                ? pass.getStaticItemBoneSelection(variantKey)
                : pass.getStaticBlockBoneSelection(variantKey);
        if (selection.isNone()) {
            return Set.of();
        }

        Set<String> selectedBones;
        if (selection.isAll() || selection.isAuto()) {
            selectedBones = renderMode == StaticGeoRenderMode.ALL_BONES ? model.boneNames() : this.getStaticBoneNames(model, renderMode);
        } else {
            selectedBones = selection.resolve(model);
            if (renderMode != StaticGeoRenderMode.ALL_BONES) {
                LinkedHashSet<String> filtered = new LinkedHashSet<>(selectedBones);
                filtered.retainAll(this.getStaticBoneNames(model, renderMode));
                selectedBones = filtered.isEmpty() ? Set.of() : Set.copyOf(filtered);
            }
        }

        return selectedBones;
    }

    /**
     * Resolves the selection used to split live dynamic bones from static baked bones.
     */
    protected AnimatedBoneSelection getDynamicStaticSplitSelection(BakedGeoModel model) {
        AnimatedBoneSelection selection = this.getBakeExcludedBones();
        if (selection.isAuto()) {
            StaticGeoStatePoseProfile profile = this.getStaticStatePoseProfile();
            if (!profile.isEmpty()) {
                Set<String> affectedBones = profile.getAffectedBoneNames();
                if (!affectedBones.isEmpty()) {
                    return AnimatedBoneSelection.of(affectedBones);
                }
            }

            return AnimatedBoneSelection.of(autoDetectDynamicBones(model));
        }

        return selection;
    }

    /**
     * Returns the resolved bone names excluded from static baked rendering.
     */
    public Set<String> getDynamicStaticSplitBones(BakedGeoModel model) {
        Set<String> cached = this.dynamicStaticSplitBoneCache.get(model);
        if (cached != null) {
            return cached;
        }

        Set<String> resolved = this.getDynamicStaticSplitSelection(model).resolve(model);
        this.dynamicStaticSplitBoneCache.put(model, resolved);
        return resolved;
    }

    /**
     * Applies controller-driven and custom animations to the current baked model.
     */
    public void handleAnimations(T animatable, long instanceId, AnimationState<T> animationState) {
        BakedGeoModel model = this.currentModel;
        if (model == null) {
            model = getBakedModel(getModelResource(animatable));
        }

        if (!this.usePoseCache(animatable)) {
            applyControllerAnimations(animatable, animationState, false);
            applyCpuPose(animatable, instanceId, animationState);
            applyTrackedBoneFlags(animatable);
            return;
        }

        applyControllerAnimations(animatable, animationState, true);
        Object animationKey = createAnimationCacheKey(animatable, animationState);
        Object cacheKey = this.sharePoseCacheAcrossInstances(animatable)
                ? animationKey
                : new PoseCacheKey(instanceId, animationKey);

        Map<Object, PoseCacheEntry> modelPoseCache = getPoseCache(model);
        if (modelPoseCache != null) {
            PoseSnapshot cachedPose = (PoseSnapshot) modelPoseCache.get(cacheKey);
            if (cachedPose != null) {
                cachedPose.apply(model);
                return;
            }
        }

        model.resetPose();
        applyControllerAnimations(animatable, animationState, false);
        applyCpuPose(animatable, instanceId, animationState);
        applyTrackedBoneFlags(animatable);
        getOrCreatePoseCache(model).put(cacheKey, PoseSnapshot.capture(model));
    }

    /**
     * Captures the current animated pose as a map of static bone poses.
     */
    public Map<String, StaticGeoBonePose> captureCurrentStaticBonePoses(T animatable, long instanceId, float partialTick) {
        BakedGeoModel model = this.currentModel;
        if (model == null) {
            model = getBakedModel(getModelResource(animatable));
        }

        handleAnimations(animatable, instanceId, new AnimationState<>(animatable, partialTick));

        LinkedHashMap<String, StaticGeoBonePose> poses = new LinkedHashMap<>();
        for (GeoBone bone : model.topLevelBones()) {
            captureCurrentStaticBonePoses(bone, false, poses);
        }
        return Map.copyOf(poses);
    }

    /**
     * Blends the current live pose towards a previously captured static pose map.
     */
    public void blendCurrentPoseWithCaptured(Map<String, StaticGeoBonePose> capturedPoses, float blend) {
        BakedGeoModel model = this.currentModel;
        if (model == null || capturedPoses.isEmpty()) {
            return;
        }

        float clampedBlend = Math.max(0.0f, Math.min(1.0f, blend));
        if (clampedBlend >= 0.9999f) {
            return;
        }

        for (GeoBone bone : model.topLevelBones()) {
            blendCurrentPoseWithCaptured(bone, capturedPoses, clampedBlend, false);
        }
    }

    /**
     * Applies CPU-side pose changes for fallback render paths.
     */
    public void applyCpuPose(T animatable, long instanceId, AnimationState<T> animationState) {
    }

    /**
     * Applies GPU-side pose changes through {@link #getBoneHandle(String)}.
     */
    public void applyGpuPose(T animatable, AnimationState<T> animationState) {
    }

    /**
     * Returns whether any controller is currently blending from a captured transition pose.
     */
    public boolean hasCapturedTransitionPose(T animatable) {
        List<AnimationPlaybackController<T>> playbackControllers = getAnimatableManager(animatable).getPlaybackControllers();
        for (AnimationPlaybackController<T> controller : playbackControllers) {
            if (!controller.getTransitionBonePoses().isEmpty()) {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns a cache key that tracks controller state and transition progress for CPU-prepared poses.
     */
    public Object createAnimatedPoseCacheKey(T animatable, AnimationState<T> animationState) {
        return createAnimationCacheKey(animatable, animationState);
    }

    /**
     * Collects world-space positions for all tracked bones configured by this model.
     */
    public Map<String, Vec3> collectTrackedBoneWorldPositions(T animatable) {
        return GeoBoneTrackingHelper.collectWorldPositions(this.getTrackedBones(animatable), this::getBone);
    }

    /**
     * Prepares GPU-ready pose data for the current animation state.
     */
    public Object prepareGpuBonePoseData(T animatable, ChaosGpuGeoMesh mesh, AnimationState<T> animationState, Object poseCacheKey) {
        GeoAnimationData animationData = getAnimationData(animatable);

        ProceduralFramePoseDedupKey dedupKey = null;
        if (animationData == null && overridesGpuPose()) {
            Object poseKey = animatable.getPoseKey();
            if (poseKey != null) {
                dedupKey = new ProceduralFramePoseDedupKey(this, mesh, poseKey);
                Object shared = PROCEDURAL_FRAME_POSE_DEDUP.get(dedupKey);
                if (shared != null) {
                    return shared;
                }
            }
        }

        Object result = computeGpuBonePoseData(animatable, mesh, animationState, animationData);
        if (dedupKey != null && result != null) {
            PROCEDURAL_FRAME_POSE_DEDUP.put(dedupKey, result);
        }
        return result;
    }

    private Object computeGpuBonePoseData(T animatable, ChaosGpuGeoMesh mesh, AnimationState<T> animationState, GeoAnimationData animationData) {
        GpuProceduralPoseLayer proceduralLayer = createGpuProceduralPoseLayer(animatable, animationState);
        if (animationData == null && proceduralLayer == null) {
            Object restPose = ChaosGpuAnimationPoseStorage.prepareRestPoseToken(mesh);
            if (restPose != null) {
                return restPose;
            }
            return ChaosGpuPoseDataCache.prepareBonePoseData(REST_POSE_CPU_CACHE_KEY, this.currentModel, mesh);
        }
        if (canUseCustomPoseOnGpu()) {
            List<AnimationPlaybackController<T>> playbackControllers = getAnimatableManager(animatable).getPlaybackControllers();
            ChaosGpuAnimationPayload payload = animationData != null
                    ? ChaosGpuAnimationPayloadCache.getOrCreate(mesh, animationData)
                    : ChaosGpuAnimationPayload.empty(mesh.getIndexedBones().size());
            if (animationData != null && payload.requiresCpuPoseSampling()) {
                logGpuFallbackWarning(animatable, "animation requires CPU pose sampling and cannot run on GPU");
                Object animatedPoseCacheKey = createAnimationCacheKey(animatable, animationState);
                float[] poseData = ChaosGpuPoseDataCache.prepareBonePoseData(animatedPoseCacheKey, this.currentModel, mesh);
                Object uploadedPose = ChaosGpuAnimationPoseStorage.prepareUploadedPoseToken(mesh, poseData, animatedPoseCacheKey, animatable);
                return uploadedPose != null ? uploadedPose : poseData;
            }
            ChaosGpuAnimationPoseStorage.LocalPoseHandle token = ChaosGpuAnimationPoseStorage.preparePoseToken(
                    mesh,
                    animationData,
                    payload,
                    playbackControllers,
                    animationState.getAnimationTick(),
                    animationState,
                    this::getBone,
                    proceduralLayer,
                    proceduralLayer == null
                            ? createAnimationCacheKey(animatable, animationState)
                            : resolveProceduralPoseCacheKey(animatable)
            );
            if (token != null) {
                return token;
            }
        } else {
            logGpuFallbackWarning(animatable, "model overrides applyCpuPose(...) without applyGpuPose(...) and cannot use GPU live animation sampling");
        }

        Object animatedPoseCacheKey = createAnimationCacheKey(animatable, animationState);
        float[] poseData = ChaosGpuPoseDataCache.prepareBonePoseData(animatedPoseCacheKey, this.currentModel, mesh);
        Object uploadedPose = ChaosGpuAnimationPoseStorage.prepareUploadedPoseToken(mesh, poseData, animatedPoseCacheKey, animatable);
        return uploadedPose != null ? uploadedPose : poseData;
    }

    /**
     * Prepares live animation state for GPU rendering.
     *
     * <p>When a model does not require a CPU-only pose override, live rendering skips CPU
     * application of controller keyframes and only advances controller state for GPU sampling.
     * Models that override both {@link #applyCpuPose(GeoAnimatable, long, AnimationState)} and
     * {@link #applyGpuPose(GeoAnimatable, AnimationState)} may still stay on the GPU path, with
     * the CPU hook serving only as a fallback for non-GPU rendering paths.</p>
     */
    public void prepareLiveRenderAnimations(T animatable, long instanceId, AnimationState<T> animationState) {
        if (requiresCpuCustomPoseFallback()) {
            if (getAnimationData(animatable) != null) {
                logGpuFallbackWarning(animatable, "model overrides applyCpuPose(...) without applyGpuPose(...) and cannot use GPU live animation sampling");
            }
            handleAnimations(animatable, instanceId, animationState);
            return;
        }

        if (this.currentModel == null) {
            this.currentModel = getBakedModel(getModelResource(animatable));
        }

        GeoAnimationData animationData = getAnimationData(animatable);
        if (animationData != null) {
            ChaosGpuGeoMesh fullMesh = ChaosGpuGeoMesh.getOrCreate(this.currentModel);
            ChaosGpuAnimationPayload payload = ChaosGpuAnimationPayloadCache.getOrCreate(fullMesh, animationData);
            if (payload.requiresCpuPoseSampling()) {
                logGpuFallbackWarning(animatable, "animation requires CPU pose sampling and cannot run on GPU");
                handleAnimations(animatable, instanceId, animationState);
                return;
            }
        }

        if (canDedupLiveCpuPose(animatable, animationData)) {
            Object poseKey = animatable.getPoseKey();
            int frameId = ChaosBlockEntityRenderFrameClock.frameId();
            boolean hit = poseKey != null && frameId == this.liveCpuPoseFrameId && poseKey.equals(this.liveCpuPoseKey);
            if (hit) {
                return;
            }
            handleAnimations(animatable, instanceId, animationState);
            this.liveCpuPoseFrameId = frameId;
            this.liveCpuPoseKey = poseKey;
            return;
        }

        handleAnimations(animatable, instanceId, animationState);
    }

    /**
     * Whether the live CPU pose produced by {@link #handleAnimations} is fully captured by the content
     * pose key, so it can be deduped across instances within a frame. Requires the GPU procedural path
     * (no CPU fallback), no keyframe animation data and no playback controllers - exactly the conditions
     * under which {@link GeoAnimatable#getPoseKey()} determines the entire pose.
     */
    private boolean canDedupLiveCpuPose(T animatable, @Nullable GeoAnimationData animationData) {
        return animationData == null
                && overridesGpuPose()
                && !requiresCpuCustomPoseFallback()
                && getAnimatableManager(animatable).getPlaybackControllers().isEmpty();
    }

    /**
     * Prepares live animation state for CPU mesh rendering.
     *
     * <p>Unlike {@link #prepareLiveRenderAnimations(GeoAnimatable, long, AnimationState)}, this
     * path always resolves controller output into the baked bones so a CPU renderer can consume
     * the final animated pose directly.</p>
     */
    public void prepareCpuRenderAnimations(T animatable, long instanceId, AnimationState<T> animationState) {
        if (this.currentModel == null) {
            this.currentModel = getBakedModel(getModelResource(animatable));
        }

        handleAnimations(animatable, instanceId, animationState);
    }

    public boolean canUseGpuLiveRenderAnimations(T animatable, ChaosGpuGeoMesh mesh) {
        return getGpuLiveRenderAnimationSupport(animatable, mesh).isGpuLiveCapable();
    }

    public GpuLiveRenderAnimationSupport getGpuLiveRenderAnimationSupport(T animatable, ChaosGpuGeoMesh mesh) {
        GeoAnimationData animationData = getAnimationData(animatable);
        if (requiresCpuCustomPoseFallback()) {
            return GpuLiveRenderAnimationSupport.CUSTOM_CPU_POSE;
        }

        if (animationData == null) {
            return overridesGpuPose()
                    ? GpuLiveRenderAnimationSupport.GPU_PROCEDURAL_ONLY
                    : GpuLiveRenderAnimationSupport.NO_ANIMATION_DATA_AND_NO_GPU_PROCEDURAL;
        }

        return ChaosGpuAnimationPayloadCache.getOrCreate(mesh, animationData).requiresCpuPoseSampling()
                ? GpuLiveRenderAnimationSupport.ANIMATION_RESOURCE_REQUIRES_CPU
                : GpuLiveRenderAnimationSupport.GPU_LIVE_SAFE;
    }

    public boolean requiresCpuPoseSampling(T animatable, ChaosGpuGeoMesh mesh) {
        GeoAnimationData animationData = getAnimationData(animatable);
        if (animationData == null) {
            return requiresCpuCustomPoseFallback();
        }

        return requiresCpuCustomPoseFallback() || ChaosGpuAnimationPayloadCache.getOrCreate(mesh, animationData).requiresCpuPoseSampling();
    }

    /**
     * Clears cached baked poses and animation resources across all models.
     */
    public static void clearProceduralFramePoseDedup() {
        PROCEDURAL_FRAME_POSE_DEDUP.clear();
    }

    public static void clearPoseCache() {
        CACHE_REGISTRY.poseCache().clear();
        lastPoseCacheModel = null;
        lastPoseCache = null;
        PROCEDURAL_FRAME_POSE_DEDUP.clear();
    }

    public enum GpuLiveRenderAnimationSupport {
        CUSTOM_CPU_POSE,
        GPU_PROCEDURAL_ONLY,
        NO_ANIMATION_DATA_AND_NO_GPU_PROCEDURAL,
        ANIMATION_RESOURCE_REQUIRES_CPU,
        GPU_LIVE_SAFE;

        public boolean isGpuLiveCapable() {
            return this == GPU_PROCEDURAL_ONLY || this == GPU_LIVE_SAFE;
        }

        public boolean hasNoLiveAnimationWork() {
            return this == NO_ANIMATION_DATA_AND_NO_GPU_PROCEDURAL;
        }
    }

    public static void clearResourceCaches() {
        CACHE_REGISTRY.clearAll();
    }

    public static void clearTextureTransparencyProfiles() {
        TextureTransparencyProfile.clearCache();
    }

    public static void reloadResourceCaches(ResourceManager resourceManager) {
        preloadResourceCaches(resourceManager);
    }

    public static void preloadResourceCaches(ResourceManager resourceManager) {
        GeoAnimationLoader.preloadUsed(resourceManager);

        for (ResourceLocation id : resourceManager.listResources("geo", path -> path.getPath().endsWith(".geo.json")).keySet()) {
            CACHE_REGISTRY.modelCache().get(id, resourceManager);
        }
    }

    /**
     * Returns the total number of cached pose entries currently held across all baked models.
     */
    public static int totalPoseCacheEntries() {
        return CACHE_REGISTRY.poseCache().totalEntries();
    }

    /**
     * Registers static baked block and item model definitions exposed by this geo model.
     */
    public final void registerStaticModelDefinition() {
        GeoStaticModelPolicy<T> policy = this.getStaticModelPolicy();

        ResourceLocation staticModelId = policy.getStaticModelId();
        ResourceLocation staticGeoModelId = policy.getStaticGeoModelResource();
        if (staticModelId != null && staticGeoModelId != null) {
            StaticGeoModelRegistry.register(
                    staticModelId,
                    staticGeoModelId,
                    this.getRenderPolicy().getStaticRootTransform(null),
                    this,
                    policy.getStaticRenderModeSelector()
            );
        }

        ResourceLocation staticItemModelId = policy.getStaticItemModelId();
        ResourceLocation staticItemGeoModelId = policy.getStaticItemGeoModelResource();
        if (staticItemModelId != null && staticItemGeoModelId != null) {
            StaticGeoModelRegistry.register(
                    staticItemModelId,
                    staticItemGeoModelId,
                    policy.getStaticItemRootTransform(),
                    this,
                    policy.getStaticItemRenderModeSelector()
            );
        }
    }

    private BlockState resolveStaticBlockStateTemplate() {
        ResourceLocation staticModelId = this.getStaticModelId();
        if (staticModelId == null) {
            return null;
        }

        String path = staticModelId.getPath();
        if (!path.startsWith("block/")) {
            return null;
        }

        ResourceLocation blockId = ResourceLocation.fromNamespaceAndPath(staticModelId.getNamespace(), path.substring("block/".length()));
        Block block = BuiltInRegistries.BLOCK.get(blockId);
        return block == null ? null : block.defaultBlockState();
    }

    private ResourceLocation resolveDefaultStaticModelBaseId() {
        if (this.defaultStaticModelBaseIdResolved) {
            return this.cachedDefaultStaticModelBaseId;
        }

        ResourceLocation staticGeoModelId = this.getStaticGeoModelResource();
        if (staticGeoModelId == null) {
            this.defaultStaticModelBaseIdResolved = true;
            return null;
        }

        String path = staticGeoModelId.getPath();
        if (!path.startsWith("geo/") || !path.endsWith(".geo.json")) {
            this.defaultStaticModelBaseIdResolved = true;
            return null;
        }

        String basePath = path.substring("geo/".length(), path.length() - ".geo.json".length());
        if (basePath.isBlank()) {
            this.defaultStaticModelBaseIdResolved = true;
            return null;
        }

        this.cachedDefaultStaticModelBaseId = ResourceLocation.fromNamespaceAndPath(staticGeoModelId.getNamespace(), basePath);
        this.defaultStaticModelBaseIdResolved = true;
        return this.cachedDefaultStaticModelBaseId;
    }

    private @Nullable ResourceLocation resolveStaticModelResource() {
        return this.resolveStaticResource(this::getModelResource);
    }

    private @Nullable ResourceLocation resolveStaticTextureResource() {
        return this.resolveStaticResource(this::getTextureResource);
    }

    private @Nullable ResourceLocation resolveStaticResource(StaticResourceResolver<T> resolver) {
        try {
            return resolver.resolve(null);
        } catch (RuntimeException exception) {
            return null;
        }
    }

    private Set<String> resolveSelectedPassBones(AnimatedBoneSelection selection, BakedGeoModel model) {
        if (selection.isNone()) {
            return Set.of();
        }

        return selection.isAll() || selection.isAuto() ? null : selection.resolve(model);
    }

    private Set<String> resolveDynamicPassBones(AnimatedBoneSelection selection, BakedGeoModel model, @Nullable Set<String> dynamicRenderBones) {
        if (selection.isNone()) {
            return Set.of();
        }

        if (dynamicRenderBones == null) {
            return selection.isAll() || selection.isAuto() ? null : selection.resolve(model);
        }

        if (selection.isAll() || selection.isAuto()) {
            return dynamicRenderBones;
        }

        LinkedHashSet<String> filtered = new LinkedHashSet<>(selection.resolve(model));
        filtered.retainAll(dynamicRenderBones);
        return filtered.isEmpty() ? Set.of() : Set.copyOf(filtered);
    }

    private void applyControllerAnimations(T animatable, AnimationState<T> animationState, boolean processOnly) {
        AnimatableManager<T> manager = getAnimatableManager(animatable);
        PoseSnapshot preProcessPose = this.currentModel == null ? null : PoseSnapshot.capture(this.currentModel);
        manager.process(animationState);
        captureTransitionBonePoses(animatable, manager, preProcessPose);
        if (processOnly) {
            return;
        }

        GeoAnimationData animationData = getAnimationData(animatable);
        if (animationData == null) {
            return;
        }

        this.currentModel.resetPose();
        GeoAnimationRuntime.applyAnimations(animationData, manager.getPlaybackControllers(), animationState, this::getBone);
    }

    private void captureTransitionBonePoses(T animatable, AnimatableManager<T> manager, @Nullable PoseSnapshot preProcessPose) {
        GeoAnimationData animationData = getAnimationData(animatable);
        if (animationData == null) {
            return;
        }

        for (AnimationPlaybackController<T> controller : manager.getPlaybackControllers()) {
            if (!controller.didStartTransitionThisTick() || controller.getTransitionLengthTicks() <= 0) {
                continue;
            }
            Map<String, AnimationPlaybackController.TransitionBonePose> transitionBonePoses =
                    preProcessPose != null && this.currentModel != null
                            ? preProcessPose.toTransitionBonePoseMap(this.currentModel)
                            : GeoAnimationRuntime.createTransitionBonePoses(animationData, controller);
            if (controller instanceof AnimationController<T> animationController) {
                animationController.captureTransitionBonePoses(transitionBonePoses);
            }
        }
    }

    private void applyTrackedBoneFlags(T animatable) {
        Set<String> trackedBones = this.getTrackedBones(animatable);
        if (trackedBones.isEmpty()) {
            return;
        }

        for (String boneName : trackedBones) {
            this.getBone(boneName).ifPresent(bone -> bone.setTrackingMatrices(true));
        }
    }

    private AnimatableManager<T> getAnimatableManager(T animatable) {
        return animatable.getAnimatableInstanceCache().getManager();
    }

    private @Nullable GeoAnimationData getAnimationData(T animatable) {
        ResourceLocation animationResource = this.getAnimationResource(animatable);
        return CACHE_REGISTRY.animationCache().get(animationResource);
    }

    private boolean overridesCpuPose() {
        return CUSTOM_ANIMATION_OVERRIDE_CACHE.computeIfAbsent(this.getClass(), GeoModel::hasCpuPoseOverride);
    }

    private boolean overridesGpuPose() {
        return GPU_PROCEDURAL_OVERRIDE_CACHE.computeIfAbsent(this.getClass(), GeoModel::hasGpuPoseOverride);
    }

    private boolean canUseCustomPoseOnGpu() {
        return !overridesCpuPose() || overridesGpuPose();
    }

    private boolean requiresCpuCustomPoseFallback() {
        return overridesCpuPose() && !overridesGpuPose();
    }

    private @Nullable GpuProceduralPoseLayer createGpuProceduralPoseLayer(T animatable, AnimationState<T> animationState) {
        if (!overridesGpuPose()) {
            return null;
        }

        GpuProceduralCaptureContext captureContext = this.reusableGpuProceduralContext.get();
        captureContext.resetForReuse();
        this.activeProceduralContext = captureContext;
        try {
            applyGpuPose(animatable, animationState);
        } finally {
            this.activeProceduralContext = null;
        }
        return captureContext.layer().isEmpty() ? null : captureContext.layer();
    }

    private Object createAnimationCacheKey(T animatable, AnimationState<T> animationState) {
        return createAnimationCacheKey(animatable.getPoseKey(), getAnimatableManager(animatable).getPlaybackControllers(), animationState);
    }

    /**
     * Cache key for the GPU procedural pose token. Previously the procedural path always passed
     * {@code null}, so the resolved bones were re-dispatched (compute/transform-feedback) every single
     * frame for every block entity - even when its pose was static. We now return a stable content key
     * while the block entity is idle ({@code !hasLivePose()}): the procedural pose is then partial-tick
     * independent, so the token is cached and reused across frames, and even shared by every idle
     * instance of the same mesh (they map to the same key + the same cached empty payload). Active block
     * entities keep {@code null} so each frame re-resolves for smooth interpolation.
     */
    private @Nullable Object resolveProceduralPoseCacheKey(T animatable) {
        if (animatable instanceof GeoBlockEntity blockEntity && !blockEntity.hasLivePose()) {
            return new ProceduralIdlePoseKey(animatable.getPoseKey());
        }
        return null;
    }

    private Object createAnimationCacheKey(Object boneMatrixCacheKey, List<? extends AnimationPlaybackController<T>> playbackControllers, AnimationState<T> animationState) {
        return new AnimationCacheKey(
                boneMatrixCacheKey,
                GeoAnimationRuntime.createAnimationStateKey(playbackControllers, animationState.getAnimationTick())
        );
    }

    private void logGpuFallbackWarning(T animatable, String reason) {
        String modelName = this.getClass().getName();
        String animatableName = animatable.getClass().getName();
        String key = modelName + "|" + animatableName + "|" + reason;
        if (!LOGGED_GPU_FALLBACKS.add(key)) {
            return;
        }

        ResourceLocation modelResource = this.getModelResource(animatable);
        ResourceLocation animationResource = this.getAnimationResource(animatable);
        ChaosLib.LOGGER.warn(
                "Chaos GPU fallback: model={} animatable={} modelResource={} animationResource={} reason={}",
                modelName,
                animatableName,
                modelResource,
                animationResource,
                reason
        );
    }

    private static boolean hasCpuPoseOverride(Class<?> modelClass) {
        try {
            return modelClass.getMethod("applyCpuPose", GeoAnimatable.class, long.class, AnimationState.class).getDeclaringClass() != GeoModel.class;
        } catch (NoSuchMethodException exception) {
            return false;
        }
    }

    private static boolean hasGpuPoseOverride(Class<?> modelClass) {
        try {
            return modelClass.getMethod("applyGpuPose", GeoAnimatable.class, AnimationState.class).getDeclaringClass() != GeoModel.class;
        } catch (NoSuchMethodException exception) {
            return false;
        }
    }

    private final class GpuProceduralCaptureContext {
        private final GpuProceduralPoseLayer layer = new GpuProceduralPoseLayer();
        private final Map<String, GeoBoneHandle> handles = new HashMap<>();

        private Optional<? extends GeoBoneHandle> getBoneHandle(String name) {
            GeoBoneHandle cached = this.handles.get(name);
            if (cached != null) {
                return Optional.of(cached);
            }

            Optional<GeoBone> backingBone = GeoModel.this.getBone(name);
            if (backingBone.isEmpty()) {
                return Optional.empty();
            }

            GpuProceduralBoneHandle handle = new GpuProceduralBoneHandle(backingBone.get(), this.layer.bone(name));
            this.handles.put(name, handle);
            return Optional.of(handle);
        }

        /**
         * Prepares this reused context for a new instance/frame: the cached handles and their backing
         * {@link GpuProceduralPoseLayer.BonePose} objects are kept, and only the pose values are cleared,
         * so a fresh {@code applyGpuPose} pass starts from identity without any reallocation.
         */
        private void resetForReuse() {
            this.layer.reset();
        }

        private GpuProceduralPoseLayer layer() {
            return this.layer;
        }
    }

    /**
     * Identity for an idle procedural pose, derived from the block entity's {@link GeoAnimatable#getPoseKey()}.
     * Distinct type from {@link AnimationCacheKey} so the two never collide in the shared pose cache.
     */
    private record ProceduralIdlePoseKey(Object poseKey) {
    }

    /**
     * Identity for the per-frame procedural pose dedup: a given model+mesh fully determines the GPU pose
     * from the animatable's {@link GeoAnimatable#getPoseKey()}, so instances sharing one map to one entry.
     */
    private record ProceduralFramePoseDedupKey(GeoModel<?> model, ChaosGpuGeoMesh mesh, Object poseKey) {
    }

    private static final class AnimationCacheKey {
        private final Object boneMatrixCacheKey;
        private final Object animationStateKey;
        private final int hashCode;

        private AnimationCacheKey(Object boneMatrixCacheKey, Object animationStateKey) {
            this.boneMatrixCacheKey = boneMatrixCacheKey;
            this.animationStateKey = animationStateKey;
            this.hashCode = 31 * boneMatrixCacheKey.hashCode() + animationStateKey.hashCode();
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof AnimationCacheKey key)) {
                return false;
            }
            return this.boneMatrixCacheKey.equals(key.boneMatrixCacheKey)
                    && this.animationStateKey.equals(key.animationStateKey);
        }

        @Override
        public int hashCode() {
            return this.hashCode;
        }
    }

    private static final class GpuProceduralBoneHandle implements GeoBoneHandle {
        private final GeoBone backingBone;
        private final GpuProceduralPoseLayer.BonePose pose;

        private GpuProceduralBoneHandle(GeoBone backingBone, GpuProceduralPoseLayer.BonePose pose) {
            this.backingBone = backingBone;
            this.pose = pose;
        }

        @Override
        public String getName() {
            return this.backingBone.getName();
        }

        @Override
        public GeoBoneHandle getParent() {
            return this.backingBone.getParent();
        }

        @Override
        public List<? extends GeoBoneHandle> getChildBones() {
            return this.backingBone.getChildBones();
        }

        @Override
        public List<? extends GeoLocatorHandle> getLocators() {
            return this.backingBone.getLocators();
        }

        @Override
        public Optional<? extends GeoLocatorHandle> getLocator(String locatorName) {
            return this.backingBone.getLocator(locatorName);
        }

        @Override
        public float getPosX() {
            return this.backingBone.getPosX();
        }

        @Override
        public float getPosY() {
            return this.backingBone.getPosY();
        }

        @Override
        public float getPosZ() {
            return this.backingBone.getPosZ();
        }

        @Override
        public void setPosX(float value) {
            this.pose.position(value, this.getPosY(), this.getPosZ());
        }

        @Override
        public void setPosY(float value) {
            this.pose.position(this.getPosX(), value, this.getPosZ());
        }

        @Override
        public void setPosZ(float value) {
            this.pose.position(this.getPosX(), this.getPosY(), value);
        }

        @Override
        public float getPivotX() {
            return this.backingBone.getPivotX();
        }

        @Override
        public float getPivotY() {
            return this.backingBone.getPivotY();
        }

        @Override
        public float getPivotZ() {
            return this.backingBone.getPivotZ();
        }

        @Override
        public void setPivotX(float value) {
            this.backingBone.setPivotX(value);
        }

        @Override
        public void setPivotY(float value) {
            this.backingBone.setPivotY(value);
        }

        @Override
        public void setPivotZ(float value) {
            this.backingBone.setPivotZ(value);
        }

        @Override
        public float getRotX() {
            return this.backingBone.getRotX();
        }

        @Override
        public float getRotY() {
            return this.backingBone.getRotY();
        }

        @Override
        public float getRotZ() {
            return this.backingBone.getRotZ();
        }

        @Override
        public float getInitialPivotX() {
            return this.backingBone.getInitialPivotX();
        }

        @Override
        public float getInitialPivotY() {
            return this.backingBone.getInitialPivotY();
        }

        @Override
        public float getInitialPivotZ() {
            return this.backingBone.getInitialPivotZ();
        }

        @Override
        public float getInitialRotX() {
            return this.backingBone.getInitialRotX();
        }

        @Override
        public float getInitialRotY() {
            return this.backingBone.getInitialRotY();
        }

        @Override
        public float getInitialRotZ() {
            return this.backingBone.getInitialRotZ();
        }

        @Override
        public void setRotX(float value) {
            this.pose.rotation(value, this.getRotY(), this.getRotZ());
        }

        @Override
        public void setRotY(float value) {
            this.pose.rotation(this.getRotX(), value, this.getRotZ());
        }

        @Override
        public void setRotZ(float value) {
            this.pose.rotation(this.getRotX(), this.getRotY(), value);
        }

        @Override
        public float getScaleX() {
            return this.backingBone.getScaleX();
        }

        @Override
        public float getScaleY() {
            return this.backingBone.getScaleY();
        }

        @Override
        public float getScaleZ() {
            return this.backingBone.getScaleZ();
        }

        @Override
        public void setScaleX(float value) {
            this.pose.scale(value, this.getScaleY(), this.getScaleZ());
        }

        @Override
        public void setScaleY(float value) {
            this.pose.scale(this.getScaleX(), value, this.getScaleZ());
        }

        @Override
        public void setScaleZ(float value) {
            this.pose.scale(this.getScaleX(), this.getScaleY(), value);
        }

        @Override
        public boolean isHidden() {
            return this.backingBone.isHidden();
        }

        @Override
        public void setHidden(boolean hidden) {
            this.backingBone.setHidden(hidden);
        }

        @Override
        public boolean isHidingChildren() {
            return this.backingBone.isHidingChildren();
        }

        @Override
        public void setChildrenHidden(boolean hideChildren) {
            this.backingBone.setChildrenHidden(hideChildren);
        }

        @Override
        public boolean isTrackingMatrices() {
            return this.backingBone.isTrackingMatrices();
        }

        @Override
        public void setTrackingMatrices(boolean trackingMatrices) {
            this.backingBone.setTrackingMatrices(trackingMatrices);
        }

        @Override
        public Matrix4f getModelSpaceMatrix() {
            return this.backingBone.getModelSpaceMatrix();
        }

        @Override
        public Matrix4f getLocalSpaceMatrix() {
            return this.backingBone.getLocalSpaceMatrix();
        }

        @Override
        public Matrix4f getWorldSpaceMatrix() {
            return this.backingBone.getWorldSpaceMatrix();
        }

        @Override
        public Vector3d getWorldPosition() {
            return this.backingBone.getWorldPosition();
        }

        @Override
        public Vector3d transformModelPoint(float x, float y, float z) {
            return this.backingBone.transformModelPoint(x, y, z);
        }

        @Override
        public void resetPose() {
            this.pose.position(this.backingBone.getPosX(), this.backingBone.getPosY(), this.backingBone.getPosZ());
            this.pose.rotation(this.backingBone.getRotX(), this.backingBone.getRotY(), this.backingBone.getRotZ());
            this.pose.scale(this.backingBone.getScaleX(), this.backingBone.getScaleY(), this.backingBone.getScaleZ());
        }
    }

    private record LegacyGeoResourceSet<T extends GeoAnimatable>(GeoModel<T> model) implements GeoResourceSet<T> {
        @Override
        public ResourceLocation getModelResource(T animatable) {
            return this.model.getModelResource(animatable);
        }

        @Override
        public ResourceLocation getTextureResource(T animatable) {
            return this.model.getTextureResource(animatable);
        }

        @Override
        public ResourceLocation getAnimationResource(T animatable) {
            return this.model.getAnimationResource(animatable);
        }
    }

    private record LegacyGeoTrackingPolicy<T extends GeoAnimatable>(GeoModel<T> model) implements GeoTrackingPolicy<T> {
        @Override
        public Set<String> getTrackedBones(T animatable) {
            return this.model.getTrackedBones(animatable);
        }
    }

    private record LegacyGeoRenderPolicy<T extends GeoAnimatable>(GeoModel<T> model) implements GeoRenderPolicy<T> {
        @Override
        public Matrix4f getStaticRootTransform() {
            return this.model.getStaticRootTransform();
        }

        @Override
        public Matrix4f getStaticRootTransform(@Nullable BlockState state) {
            return this.model.getStaticRootTransform(state);
        }

        @Override
        public Matrix4f getBlockEntityRootTransform(T animatable) {
            return this.model.getBlockEntityRootTransform(animatable);
        }

        @Override
        public Matrix4f getEntityRootTransform(T animatable) {
            return this.model.getEntityRootTransform(animatable);
        }

        @Override
        public RenderType getRenderType(T animatable, ResourceLocation texture) {
            return this.model.getRenderType(animatable, texture);
        }

        @Override
        public boolean useEmissiveLayer() {
            return this.model.useEmissiveLayer();
        }

        @Override
        public boolean shouldRenderEmissive(T animatable) {
            return this.model.shouldRenderEmissive(animatable);
        }

        @Override
        public AnimatedBoneSelection getBakeExcludedBones() {
            return this.model.getBakeExcludedBones();
        }

        @Override
        public AnimatedBoneSelection getLiveRenderBones(T animatable) {
            return this.model.getLiveRenderBones(animatable);
        }

        @Override
        public AnimatedBoneSelection getFrozenRenderBones(T animatable) {
            return this.model.getFrozenRenderBones(animatable);
        }

        @Override
        public AnimatedBoneSelection getEmissiveBoneSelection(T animatable) {
            return this.model.getEmissiveBoneSelection(animatable);
        }

        @Override
        public Set<String> getResolvedEmissiveBones(T animatable, BakedGeoModel model, @Nullable Set<String> dynamicRenderBones) {
            return this.model.getResolvedEmissiveBones(animatable, model, dynamicRenderBones);
        }

        @Override
        public ResourceLocation getEmissiveTextureResource(T animatable) {
            return this.model.getEmissiveTextureResource(animatable);
        }

        @Override
        public ResourceLocation getStaticEmissiveTextureResource() {
            return this.model.getStaticEmissiveTextureResource();
        }

        @Override
        public RenderType getEmissiveRenderType(T animatable, ResourceLocation texture) {
            return this.model.getEmissiveRenderType(animatable, texture);
        }

        @Override
        public float getBlockEntityEmissiveStrength(T animatable) {
            return this.model.getBlockEntityEmissiveStrength(animatable);
        }

        @Override
        public boolean renderEmissiveInBasePass() {
            return this.model.renderEmissiveInBasePass();
        }

        @Override
        public boolean usePoseCache(T animatable) {
            return this.model.usePoseCache(animatable);
        }

        @Override
        public boolean sharePoseCacheAcrossInstances(T animatable) {
            return this.model.sharePoseCacheAcrossInstances(animatable);
        }

        @Override
        public boolean useEnclosedVisibilityCulling() {
            return this.model.useEnclosedVisibilityCulling();
        }

        @Override
        public double getFrozenBlockEntityRenderRadius() {
            return this.model.getFrozenBlockEntityRenderRadius();
        }

        @Override
        public double getFrozenBlockEntityVisibilityRadius() {
            return this.model.getFrozenBlockEntityVisibilityRadius();
        }

        @Override
        public float getFrozenBlockEntityThawDurationTicks() {
            return this.model.getFrozenBlockEntityThawDurationTicks();
        }

        @Override
        public boolean useStaticAmbientOcclusion() {
            return this.model.useStaticAmbientOcclusion();
        }
    }

    private record LegacyGeoStaticModelPolicy<T extends GeoAnimatable>(
            GeoModel<T> model) implements GeoStaticModelPolicy<T> {
        @Override
        public ResourceLocation getStaticModelId() {
            return this.model.getStaticModelId();
        }

        @Override
        public ResourceLocation getStaticGeoModelResource() {
            return this.model.getStaticGeoModelResource();
        }

        @Override
        public ResourceLocation getStaticItemModelId() {
            return this.model.getStaticItemModelId();
        }

        @Override
        public ResourceLocation getStaticItemGeoModelResource() {
            return this.model.getStaticItemGeoModelResource();
        }

        @Override
        public ResourceLocation getStaticTextureResource() {
            return this.model.getStaticTextureResource();
        }

        @Override
        public Matrix4f getStaticItemRootTransform() {
            return this.model.getStaticItemRootTransform();
        }

        @Override
        public StaticGeoRenderModeSelector getStaticItemRenderModeSelector() {
            return this.model.getStaticItemRenderModeSelector();
        }

        @Override
        public StaticGeoRenderModeSelector getStaticRenderModeSelector() {
            return this.model.getStaticRenderModeSelector();
        }

        @Override
        public boolean shouldRenderStaticEmissive(@Nullable BlockState state) {
            return this.model.shouldRenderStaticEmissive(state);
        }

        @Override
        public AnimatedBoneSelection getStaticEmissiveBoneSelection(String variantKey) {
            return this.model.getStaticEmissiveBoneSelection(variantKey);
        }

        @Override
        public int getStaticEmissivePassCount() {
            return this.model.getStaticEmissivePassCount();
        }

        @Override
        public RenderType getStaticRenderLayer(@Nullable BlockState state) {
            return this.model.getStaticRenderLayer(state);
        }

        @Override
        public StaticGeoQuadCullingMode getStaticQuadCullingMode(@Nullable BlockState state) {
            return this.model.getStaticQuadCullingMode(state);
        }

        @Override
        public Map<String, StaticGeoBonePose> getBoneRestPoses() {
            return this.model.getBoneRestPoses();
        }

        @Override
        public AutoStaticPoseConfig getAutoStaticPoseConfig() {
            return this.model.getAutoStaticPoseConfig();
        }

        @Override
        public Object createFrozenPoseCacheKey(T animatable, BakedGeoModel model, Map<String, StaticGeoBonePose> frozenBonePoses) {
            return this.model.createFrozenPoseCacheKey(animatable, model, frozenBonePoses);
        }

        @Override
        public StaticGeoStatePoseProfile getStaticStatePoseProfile() {
            return this.model.getStaticStatePoseProfile();
        }

        @Override
        public Set<String> getStaticPoseVariantKeys() {
            return this.model.getStaticPoseVariantKeys();
        }

        @Override
        public String getStaticPoseVariantKey(@Nullable BlockState state) {
            return this.model.getStaticPoseVariantKey(state);
        }

        @Override
        public Map<String, StaticGeoBonePose> getBoneRestPoses(String variantKey) {
            return this.model.getBoneRestPoses(variantKey);
        }

        @Override
        public Set<String> getStaticBoneNames(BakedGeoModel model, StaticGeoRenderMode renderMode) {
            return this.model.getStaticBoneNames(model, renderMode);
        }

        @Override
        public Set<String> getStaticEmissiveBoneNames(BakedGeoModel model, String variantKey, StaticGeoRenderMode renderMode) {
            return this.model.getStaticEmissiveBoneNames(model, variantKey, renderMode);
        }
    }

    @FunctionalInterface
    private interface StaticResourceResolver<T extends GeoAnimatable> {
        @Nullable ResourceLocation resolve(@Nullable T animatable);
    }

    private static final class PoseCacheKey {
        private final long instanceId;
        private final Object animationKey;
        private final int hash;

        private PoseCacheKey(long instanceId, Object animationKey) {
            this.instanceId = instanceId;
            this.animationKey = animationKey;
            this.hash = 31 * Long.hashCode(instanceId) + animationKey.hashCode();
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof PoseCacheKey poseCacheKey) || this.instanceId != poseCacheKey.instanceId) {
                return false;
            }
            return this.animationKey.equals(poseCacheKey.animationKey);
        }

        @Override
        public int hashCode() {
            return this.hash;
        }
    }

    private static Map<Object, PoseCacheEntry> getPoseCache(BakedGeoModel model) {
        if (model == lastPoseCacheModel) {
            return lastPoseCache;
        }

        Map<Object, PoseCacheEntry> cache = CACHE_REGISTRY.poseCache().get(model);
        lastPoseCacheModel = model;
        lastPoseCache = cache;
        return cache;
    }

    private static Map<Object, PoseCacheEntry> getOrCreatePoseCache(BakedGeoModel model) {
        Map<Object, PoseCacheEntry> cache = getPoseCache(model);
        if (cache != null) {
            return cache;
        }

        cache = CACHE_REGISTRY.poseCache().getOrCreate(model);
        lastPoseCacheModel = model;
        lastPoseCache = cache;
        return cache;
    }

    private void captureCurrentStaticBonePoses(GeoBone bone, boolean hiddenByParent, Map<String, StaticGeoBonePose> poses) {
        boolean effectiveHidden = hiddenByParent || bone.isHidden();
        StaticGeoBonePose pose = new StaticGeoBonePose(
                bone.getPosX(),
                bone.getPosY(),
                bone.getPosZ(),
                bone.getRotX() - bone.getInitialRotX(),
                bone.getRotY() - bone.getInitialRotY(),
                bone.getRotZ() - bone.getInitialRotZ(),
                bone.getScaleX(),
                bone.getScaleY(),
                bone.getScaleZ(),
                effectiveHidden
        );
        if (!isIdentityStaticPose(pose)) {
            poses.put(bone.getName(), pose);
        }

        boolean hideChildren = effectiveHidden || bone.isHidingChildren();
        for (GeoBone child : bone.getChildBones()) {
            captureCurrentStaticBonePoses(child, hideChildren, poses);
        }
    }

    private boolean isIdentityStaticPose(StaticGeoBonePose pose) {
        return Math.abs(pose.posX()) <= 1.0e-4f
                && Math.abs(pose.posY()) <= 1.0e-4f
                && Math.abs(pose.posZ()) <= 1.0e-4f
                && Math.abs(pose.rotX()) <= 1.0e-4f
                && Math.abs(pose.rotY()) <= 1.0e-4f
                && Math.abs(pose.rotZ()) <= 1.0e-4f
                && Math.abs(pose.scaleX() - 1.0f) <= 1.0e-4f
                && Math.abs(pose.scaleY() - 1.0f) <= 1.0e-4f
                && Math.abs(pose.scaleZ() - 1.0f) <= 1.0e-4f
                && !pose.hidden();
    }

    private void blendCurrentPoseWithCaptured(GeoBone bone, Map<String, StaticGeoBonePose> capturedPoses, float blend, boolean hiddenByParent) {
        StaticGeoBonePose captured = capturedPoses.getOrDefault(bone.getName(), StaticGeoBonePose.IDENTITY);

        float livePosX = bone.getPosX();
        float livePosY = bone.getPosY();
        float livePosZ = bone.getPosZ();
        float liveRotX = bone.getRotX() - bone.getInitialRotX();
        float liveRotY = bone.getRotY() - bone.getInitialRotY();
        float liveRotZ = bone.getRotZ() - bone.getInitialRotZ();
        float liveScaleX = bone.getScaleX();
        float liveScaleY = bone.getScaleY();
        float liveScaleZ = bone.getScaleZ();

        bone.setPosX(lerp(captured.posX(), livePosX, blend));
        bone.setPosY(lerp(captured.posY(), livePosY, blend));
        bone.setPosZ(lerp(captured.posZ(), livePosZ, blend));
        bone.setRotX(bone.getInitialRotX() + lerp(captured.rotX(), liveRotX, blend));
        bone.setRotY(bone.getInitialRotY() + lerp(captured.rotY(), liveRotY, blend));
        bone.setRotZ(bone.getInitialRotZ() + lerp(captured.rotZ(), liveRotZ, blend));
        bone.setScaleX(lerp(captured.scaleX(), liveScaleX, blend));
        bone.setScaleY(lerp(captured.scaleY(), liveScaleY, blend));
        bone.setScaleZ(lerp(captured.scaleZ(), liveScaleZ, blend));

        boolean blendedHidden = hiddenByParent || (blend < 0.5f ? captured.hidden() : bone.isHidden());
        bone.setHidden(blendedHidden);

        boolean childHidden = hiddenByParent || bone.isHidingChildren();
        for (GeoBone child : bone.getChildBones()) {
            blendCurrentPoseWithCaptured(child, capturedPoses, blend, childHidden);
        }
    }

    private float lerp(float from, float to, float blend) {
        return from + (to - from) * blend;
    }

    private Set<String> autoDetectDynamicBones(BakedGeoModel model) {
        Set<String> cached = this.autoDynamicBoneCache.get(model);
        if (cached != null) {
            return cached;
        }

        LinkedHashSet<String> dynamicBones = new LinkedHashSet<>();
        for (GeoBone bone : model.orderedBones()) {
            if (isAutoDynamicBone(bone)) {
                dynamicBones.add(bone.getName());
            }
        }

        Set<String> resolved = dynamicBones.isEmpty() ? Set.of() : Set.copyOf(dynamicBones);
        this.autoDynamicBoneCache.put(model, resolved);
        return resolved;
    }

    private boolean isAutoDynamicBone(GeoBone bone) {
        return Math.abs(bone.getPosX()) > 1.0e-4f
                || Math.abs(bone.getPosY()) > 1.0e-4f
                || Math.abs(bone.getPosZ()) > 1.0e-4f
                || Math.abs(bone.getRotX() - bone.getInitialRotX()) > 1.0e-4f
                || Math.abs(bone.getRotY() - bone.getInitialRotY()) > 1.0e-4f
                || Math.abs(bone.getRotZ() - bone.getInitialRotZ()) > 1.0e-4f
                || Math.abs(bone.getScaleX() - 1.0f) > 1.0e-4f
                || Math.abs(bone.getScaleY() - 1.0f) > 1.0e-4f
                || Math.abs(bone.getScaleZ() - 1.0f) > 1.0e-4f
                || bone.isHidden()
                || bone.isHidingChildren();
    }

    private static final class PoseSnapshot implements PoseCacheEntry {
        private final float[] positionX;
        private final float[] positionY;
        private final float[] positionZ;
        private final float[] scaleX;
        private final float[] scaleY;
        private final float[] scaleZ;
        private final float[] pivotX;
        private final float[] pivotY;
        private final float[] pivotZ;
        private final float[] rotX;
        private final float[] rotY;
        private final float[] rotZ;
        private final boolean[] hidden;
        private final boolean[] childrenHidden;
        private final boolean[] trackingMatrices;

        private PoseSnapshot(int size) {
            this.positionX = new float[size];
            this.positionY = new float[size];
            this.positionZ = new float[size];
            this.scaleX = new float[size];
            this.scaleY = new float[size];
            this.scaleZ = new float[size];
            this.pivotX = new float[size];
            this.pivotY = new float[size];
            this.pivotZ = new float[size];
            this.rotX = new float[size];
            this.rotY = new float[size];
            this.rotZ = new float[size];
            this.hidden = new boolean[size];
            this.childrenHidden = new boolean[size];
            this.trackingMatrices = new boolean[size];
        }

        private static PoseSnapshot capture(BakedGeoModel model) {
            List<GeoBone> bones = model.orderedBones();
            PoseSnapshot snapshot = new PoseSnapshot(bones.size());

            for (int i = 0; i < bones.size(); i++) {
                GeoBone bone = bones.get(i);
                snapshot.positionX[i] = bone.getPosX();
                snapshot.positionY[i] = bone.getPosY();
                snapshot.positionZ[i] = bone.getPosZ();
                snapshot.scaleX[i] = bone.getScaleX();
                snapshot.scaleY[i] = bone.getScaleY();
                snapshot.scaleZ[i] = bone.getScaleZ();
                snapshot.pivotX[i] = bone.getPivotX();
                snapshot.pivotY[i] = bone.getPivotY();
                snapshot.pivotZ[i] = bone.getPivotZ();
                snapshot.rotX[i] = bone.getRotX();
                snapshot.rotY[i] = bone.getRotY();
                snapshot.rotZ[i] = bone.getRotZ();
                snapshot.hidden[i] = bone.isHidden();
                snapshot.childrenHidden[i] = bone.isHidingChildren();
                snapshot.trackingMatrices[i] = bone.isTrackingMatrices();
            }

            return snapshot;
        }

        private void apply(BakedGeoModel model) {
            List<GeoBone> bones = model.orderedBones();

            for (int i = 0; i < bones.size(); i++) {
                GeoBone bone = bones.get(i);
                bone.setPosX(this.positionX[i]);
                bone.setPosY(this.positionY[i]);
                bone.setPosZ(this.positionZ[i]);
                bone.setScaleX(this.scaleX[i]);
                bone.setScaleY(this.scaleY[i]);
                bone.setScaleZ(this.scaleZ[i]);
                bone.setPivotX(this.pivotX[i]);
                bone.setPivotY(this.pivotY[i]);
                bone.setPivotZ(this.pivotZ[i]);
                bone.setRotX(this.rotX[i]);
                bone.setRotY(this.rotY[i]);
                bone.setRotZ(this.rotZ[i]);
                bone.setHidden(this.hidden[i]);
                bone.setChildrenHidden(this.childrenHidden[i]);
                bone.setTrackingMatrices(this.trackingMatrices[i]);
            }
        }

        private Map<String, AnimationPlaybackController.TransitionBonePose> toTransitionBonePoseMap(BakedGeoModel model) {
            List<GeoBone> bones = model.orderedBones();
            LinkedHashMap<String, AnimationPlaybackController.TransitionBonePose> poses = new LinkedHashMap<>(bones.size());

            for (int i = 0; i < bones.size(); i++) {
                GeoBone bone = bones.get(i);
                poses.put(bone.getName(), new AnimationPlaybackController.TransitionBonePose(
                        this.positionX[i],
                        this.positionY[i],
                        this.positionZ[i],
                        this.rotX[i],
                        this.rotY[i],
                        this.rotZ[i],
                        this.scaleX[i],
                        this.scaleY[i],
                        this.scaleZ[i]
                ));
            }

            return Map.copyOf(poses);
        }
    }

    public static final class TextureTransparencyProfile {
        private static final Map<ResourceLocation, TextureTransparencyProfile> CACHE = new ConcurrentHashMap<>();
        private static final TextureTransparencyProfile EMPTY = new TextureTransparencyProfile(0, 0, new byte[0], false, false);

        private final int width;
        private final int height;
        private final byte[] alpha;
        private final boolean fullyOpaque;
        private final boolean hasTranslucency;

        private TextureTransparencyProfile(int width, int height, byte[] alpha, boolean fullyOpaque, boolean hasTranslucency) {
            this.width = width;
            this.height = height;
            this.alpha = alpha;
            this.fullyOpaque = fullyOpaque;
            this.hasTranslucency = hasTranslucency;
        }

        public static TextureTransparencyProfile get(ResourceLocation textureId) {
            return CACHE.computeIfAbsent(textureId, TextureTransparencyProfile::load);
        }

        public static void clearCache() {
            CACHE.clear();
        }

        public boolean isFullyOpaque() {
            return this.fullyOpaque;
        }

        public boolean hasTranslucency() {
            return this.hasTranslucency;
        }

        public boolean isOpaque(GeoQuad quad) {
            return this.classify(quad) == QuadTransparency.OPAQUE;
        }

        public boolean isTranslucent(GeoQuad quad) {
            return this.classify(quad) == QuadTransparency.TRANSLUCENT;
        }

        private QuadTransparency classify(GeoQuad quad) {
            if (this.alpha.length == 0) {
                return QuadTransparency.CUTOUT;
            }

            float minU = Float.POSITIVE_INFINITY;
            float minV = Float.POSITIVE_INFINITY;
            float maxU = Float.NEGATIVE_INFINITY;
            float maxV = Float.NEGATIVE_INFINITY;
            for (GeoVertex vertex : quad.vertices()) {
                minU = Math.min(minU, vertex.texU());
                minV = Math.min(minV, vertex.texV());
                maxU = Math.max(maxU, vertex.texU());
                maxV = Math.max(maxV, vertex.texV());
            }

            int minX = clamp(Math.round(minU * (this.width - 1)), 0, this.width - 1);
            int minY = clamp(Math.round(minV * (this.height - 1)), 0, this.height - 1);
            int maxX = clamp(Math.round(maxU * (this.width - 1)), 0, this.width - 1);
            int maxY = clamp(Math.round(maxV * (this.height - 1)), 0, this.height - 1);

            boolean sawCutout = false;
            for (int y = minY; y <= maxY; y++) {
                for (int x = minX; x <= maxX; x++) {
                    int alphaValue = this.alpha[y * this.width + x] & 0xFF;
                    if (alphaValue == 255) {
                        continue;
                    }
                    if (alphaValue > 0) {
                        return QuadTransparency.TRANSLUCENT;
                    }
                    sawCutout = true;
                }
            }

            return sawCutout ? QuadTransparency.CUTOUT : QuadTransparency.OPAQUE;
        }

        private static TextureTransparencyProfile load(ResourceLocation textureId) {
            try {
                var resource = Minecraft.getInstance().getResourceManager().getResource(textureId);
                if (resource.isEmpty()) {
                    return EMPTY;
                }

                try (var stream = resource.get().open()) {
                    return from(NativeImage.read(stream));
                }
            } catch (IOException exception) {
                return EMPTY;
            }
        }

        private static TextureTransparencyProfile from(NativeImage image) {
            int width = image.getWidth();
            int height = image.getHeight();
            byte[] alpha = new byte[width * height];
            boolean fullyOpaque = true;
            boolean hasTranslucency = false;

            for (int y = 0; y < height; y++) {
                for (int x = 0; x < width; x++) {
                    int alphaValue = (image.getPixelRGBA(x, y) >>> 24) & 0xFF;
                    alpha[y * width + x] = (byte) alphaValue;
                    if (alphaValue != 255) {
                        fullyOpaque = false;
                    }
                    if (alphaValue > 0 && alphaValue < 255) {
                        hasTranslucency = true;
                    }
                }
            }

            image.close();
            return new TextureTransparencyProfile(width, height, alpha, fullyOpaque, hasTranslucency);
        }

        private static int clamp(int value, int min, int max) {
            return Math.max(min, Math.min(max, value));
        }

        private enum QuadTransparency {
            OPAQUE,
            CUTOUT,
            TRANSLUCENT
        }
    }
}
