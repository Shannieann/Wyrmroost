package dev.elifian.chaoslib.multipart.runtime;

import dev.elifian.chaoslib.api.multipart.GeoMultipartEntity;
import net.minecraft.world.entity.LivingEntity;

import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

public final class GeoMultipartManagerStore {
    private static final Map<GeoMultipartEntity, GeoMultipartPartManager<?>> MANAGERS =
            Collections.synchronizedMap(new IdentityHashMap<>());
    private static volatile List<GeoMultipartEntity> entitySnapshot = List.of();
    private static volatile boolean entitySnapshotDirty = true;

    private GeoMultipartManagerStore() {
    }

    @SuppressWarnings("unchecked")
    public static <T extends LivingEntity & GeoMultipartEntity> GeoMultipartPartManager<T> get(T entity) {
        GeoMultipartPartManager<?> existing = MANAGERS.get(entity);
        if (existing != null) {
            return (GeoMultipartPartManager<T>) existing;
        }

        synchronized (MANAGERS) {
            existing = MANAGERS.get(entity);
            if (existing != null) {
                return (GeoMultipartPartManager<T>) existing;
            }

            GeoMultipartPartManager<T> manager = new GeoMultipartPartManager<>(entity);
            entity.registerMultipartParts(manager);
            MANAGERS.put(entity, manager);
            entitySnapshotDirty = true;
            return manager;
        }
    }

    public static void remove(GeoMultipartEntity entity) {
        if (MANAGERS.remove(entity) != null) {
            entitySnapshotDirty = true;
        }
    }

    public static List<GeoMultipartEntity> snapshotEntities() {
        if (!entitySnapshotDirty) {
            return entitySnapshot;
        }

        synchronized (MANAGERS) {
            if (entitySnapshotDirty) {
                entitySnapshot = MANAGERS.isEmpty() ? List.of() : List.copyOf(MANAGERS.keySet());
                entitySnapshotDirty = false;
            }

            return entitySnapshot;
        }
    }
}
