package dev.elifian.chaoslib.multipart.runtime;

import dev.elifian.chaoslib.loading.json.raw.Bone;
import dev.elifian.chaoslib.loading.json.raw.Cube;
import dev.elifian.chaoslib.loading.json.raw.Model;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.elifian.chaoslib.api.multipart.GeoMultipartBoneBounds;
import dev.elifian.chaoslib.api.multipart.GeoMultipartEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.joml.Vector4f;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

final class GeoMultipartBoneBoundsResolver {
    private static final Map<ResourceLocation, Map<String, GeoMultipartBoneBounds>> CACHE = new ConcurrentHashMap<>();

    private GeoMultipartBoneBoundsResolver() {
    }

    public static Optional<GeoMultipartBoneBounds> resolve(GeoMultipartEntity multipart, String trackedBoneName) {
        if (!(multipart instanceof Entity)) {
            return Optional.empty();
        }

        ResourceLocation modelResource = multipart.getMultipartModelResource();
        if (modelResource == null) {
            return Optional.empty();
        }

        return Optional.ofNullable(CACHE.computeIfAbsent(modelResource, GeoMultipartBoneBoundsResolver::loadBounds).get(trackedBoneName));
    }

    private static Map<String, GeoMultipartBoneBounds> loadBounds(ResourceLocation modelResource) {
        try (InputStream stream = openModelResource(modelResource);
             InputStreamReader reader = new InputStreamReader(stream, StandardCharsets.UTF_8)) {
            JsonObject json = JsonParser.parseReader(reader).getAsJsonObject();
            Model model = Model.fromJson(json);
            LinkedHashMap<String, GeoMultipartBoneBounds> boundsByBone = new LinkedHashMap<>();
            for (Bone bone : model.minecraftGeometry()[0].bones()) {
                GeoMultipartBoneBounds bounds = readBoneBounds(bone);
                if (bounds != null) {
                    boundsByBone.put(bone.name(), bounds);
                }
            }
            return Map.copyOf(boundsByBone);
        } catch (Exception exception) {
            throw new IllegalStateException("Failed to resolve multipart bone bounds for model " + modelResource, exception);
        }
    }

    private static InputStream openModelResource(ResourceLocation modelResource) {
        String resourcePath = "assets/" + modelResource.getNamespace() + "/" + modelResource.getPath();
        ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();
        InputStream stream = contextClassLoader == null ? null : contextClassLoader.getResourceAsStream(resourcePath);
        if (stream == null) {
            stream = GeoMultipartBoneBoundsResolver.class.getClassLoader().getResourceAsStream(resourcePath);
        }
        if (stream == null) {
            throw new IllegalStateException("Resource not found on classpath: " + resourcePath);
        }
        return stream;
    }

    private static GeoMultipartBoneBounds readBoneBounds(Bone bone) {
        if (bone.cubes().length == 0) {
            return null;
        }

        float[] bonePivot = toFloatArray(bone.pivot(), 3);
        float pivotX = -bonePivot[0] / 16.0f;
        float pivotY = bonePivot[1] / 16.0f;
        float pivotZ = bonePivot[2] / 16.0f;
        BoundsAccumulator bounds = new BoundsAccumulator(pivotX, pivotY, pivotZ);
        for (var cube : bone.cubes()) {
            includeCube(bounds, cube);
        }
        if (!bounds.valid) {
            return null;
        }

        float width = bounds.maxX - bounds.minX;
        float height = bounds.maxY - bounds.minY;
        float depth = bounds.maxZ - bounds.minZ;
        float centerX = (bounds.minX + bounds.maxX) * 0.5f - pivotX;
        float centerY = (bounds.minY + bounds.maxY) * 0.5f - pivotY;
        float centerZ = (bounds.minZ + bounds.maxZ) * 0.5f - pivotZ;
        float rotationX = 0.0f;
        float rotationY = 0.0f;
        float rotationZ = 0.0f;
        float rotationW = 1.0f;
        if (bounds.resolveDominantRotation()) {
            width = bounds.orientedMaxX - bounds.orientedMinX;
            height = bounds.orientedMaxY - bounds.orientedMinY;
            depth = bounds.orientedMaxZ - bounds.orientedMinZ;

            Vector3f orientedCenter = new Vector3f(
                    (bounds.orientedMinX + bounds.orientedMaxX) * 0.5f,
                    (bounds.orientedMinY + bounds.orientedMaxY) * 0.5f,
                    (bounds.orientedMinZ + bounds.orientedMaxZ) * 0.5f
            );
            Vector3f boneLocalCenter = bounds.rotation.transform(orientedCenter, new Vector3f());
            centerX = boneLocalCenter.x;
            centerY = boneLocalCenter.y;
            centerZ = boneLocalCenter.z;
            rotationX = bounds.rotation.x;
            rotationY = bounds.rotation.y;
            rotationZ = bounds.rotation.z;
            rotationW = bounds.rotation.w;
        }

        return new GeoMultipartBoneBounds(
                width,
                height,
                depth,
                centerX,
                centerY,
                centerZ,
                rotationX,
                rotationY,
                rotationZ,
                rotationW
        );
    }

    private static void includeCube(BoundsAccumulator bounds, Cube cube) {
        float[] origin = toFloatArray(cube.origin(), 3);
        float[] size = toFloatArray(cube.size(), 3);
        float[] pivot = toFloatArray(cube.pivot(), 3);
        float[] rotation = toFloatArray(cube.rotation(), 3);
        float inflate = cube.inflate() == null ? 0.0f : cube.inflate().floatValue() / 16.0f;

        float minX = -(origin[0] + size[0]) / 16.0f - inflate;
        float maxX = -origin[0] / 16.0f + inflate;
        float minY = origin[1] / 16.0f - inflate;
        float maxY = (origin[1] + size[1]) / 16.0f + inflate;
        float minZ = origin[2] / 16.0f - inflate;
        float maxZ = (origin[2] + size[2]) / 16.0f + inflate;

        Matrix4f cubeMatrix = new Matrix4f()
                .translate(-pivot[0] / 16.0f, pivot[1] / 16.0f, pivot[2] / 16.0f)
                .rotateZ((float) Math.toRadians(rotation[2]))
                .rotateY((float) Math.toRadians(-rotation[1]))
                .rotateX((float) Math.toRadians(-rotation[0]))
                .translate(pivot[0] / 16.0f, -pivot[1] / 16.0f, -pivot[2] / 16.0f);

        bounds.includeRotation(rotation, (maxX - minX) * (maxY - minY) * (maxZ - minZ));
        includeTransformed(bounds, cubeMatrix, minX, minY, minZ);
        includeTransformed(bounds, cubeMatrix, minX, minY, maxZ);
        includeTransformed(bounds, cubeMatrix, minX, maxY, minZ);
        includeTransformed(bounds, cubeMatrix, minX, maxY, maxZ);
        includeTransformed(bounds, cubeMatrix, maxX, minY, minZ);
        includeTransformed(bounds, cubeMatrix, maxX, minY, maxZ);
        includeTransformed(bounds, cubeMatrix, maxX, maxY, minZ);
        includeTransformed(bounds, cubeMatrix, maxX, maxY, maxZ);
    }

    private static void includeTransformed(BoundsAccumulator bounds, Matrix4f matrix, float x, float y, float z) {
        Vector4f transformed = matrix.transform(new Vector4f(x, y, z, 1.0f));
        bounds.include(transformed.x(), transformed.y(), transformed.z());
    }

    private static float[] toFloatArray(double[] source, int size) {
        float[] values = new float[size];
        for (int i = 0; i < Math.min(source.length, size); i++) {
            values[i] = (float) source[i];
        }
        return values;
    }

    private static final class BoundsAccumulator {
        private final float bonePivotX;
        private final float bonePivotY;
        private final float bonePivotZ;
        private boolean valid;
        private float minX = Float.POSITIVE_INFINITY;
        private float minY = Float.POSITIVE_INFINITY;
        private float minZ = Float.POSITIVE_INFINITY;
        private float maxX = Float.NEGATIVE_INFINITY;
        private float maxY = Float.NEGATIVE_INFINITY;
        private float maxZ = Float.NEGATIVE_INFINITY;
        private final Quaternionf rotation = new Quaternionf();
        private float orientedMinX = Float.POSITIVE_INFINITY;
        private float orientedMinY = Float.POSITIVE_INFINITY;
        private float orientedMinZ = Float.POSITIVE_INFINITY;
        private float orientedMaxX = Float.NEGATIVE_INFINITY;
        private float orientedMaxY = Float.NEGATIVE_INFINITY;
        private float orientedMaxZ = Float.NEGATIVE_INFINITY;
        private final List<Vector3f> points = new ArrayList<>();
        private final List<RotationCandidate> rotationCandidates = new ArrayList<>();

        private BoundsAccumulator(float bonePivotX, float bonePivotY, float bonePivotZ) {
            this.bonePivotX = bonePivotX;
            this.bonePivotY = bonePivotY;
            this.bonePivotZ = bonePivotZ;
        }

        private void include(float x, float y, float z) {
            this.valid = true;
            this.minX = Math.min(this.minX, x);
            this.minY = Math.min(this.minY, y);
            this.minZ = Math.min(this.minZ, z);
            this.maxX = Math.max(this.maxX, x);
            this.maxY = Math.max(this.maxY, y);
            this.maxZ = Math.max(this.maxZ, z);
            this.points.add(new Vector3f(x, y, z));
        }

        private void includeRotation(float[] rotationDegrees) {
            this.includeRotation(rotationDegrees, 1.0f);
        }

        private void includeRotation(float[] rotationDegrees, float weight) {
            if (rotationDegrees == null || rotationDegrees.length < 3 || weight <= 0.0f) {
                return;
            }

            Quaternionf cubeRotation = cubeRotation(rotationDegrees);
            for (RotationCandidate candidate : this.rotationCandidates) {
                if (Math.abs(candidate.rotation.dot(cubeRotation)) >= 0.9999f) {
                    candidate.weight += weight;
                    return;
                }
            }

            this.rotationCandidates.add(new RotationCandidate(cubeRotation, weight));
        }

        private boolean resolveDominantRotation() {
            RotationCandidate dominant = null;
            for (RotationCandidate candidate : this.rotationCandidates) {
                if (dominant == null || candidate.weight > dominant.weight) {
                    dominant = candidate;
                }
            }
            if (dominant == null) {
                return false;
            }

            this.rotation.set(dominant.rotation);
            Quaternionf inverseRotation = new Quaternionf(this.rotation).conjugate();
            this.orientedMinX = Float.POSITIVE_INFINITY;
            this.orientedMinY = Float.POSITIVE_INFINITY;
            this.orientedMinZ = Float.POSITIVE_INFINITY;
            this.orientedMaxX = Float.NEGATIVE_INFINITY;
            this.orientedMaxY = Float.NEGATIVE_INFINITY;
            this.orientedMaxZ = Float.NEGATIVE_INFINITY;
            for (Vector3f point : this.points) {
                Vector3f oriented = inverseRotation.transform(new Vector3f(
                        point.x - this.bonePivotX,
                        point.y - this.bonePivotY,
                        point.z - this.bonePivotZ
                ));
                this.orientedMinX = Math.min(this.orientedMinX, oriented.x);
                this.orientedMinY = Math.min(this.orientedMinY, oriented.y);
                this.orientedMinZ = Math.min(this.orientedMinZ, oriented.z);
                this.orientedMaxX = Math.max(this.orientedMaxX, oriented.x);
                this.orientedMaxY = Math.max(this.orientedMaxY, oriented.y);
                this.orientedMaxZ = Math.max(this.orientedMaxZ, oriented.z);
            }

            return this.orientedMinX <= this.orientedMaxX
                    && this.orientedMinY <= this.orientedMaxY
                    && this.orientedMinZ <= this.orientedMaxZ;
        }

        private static final class RotationCandidate {
            private final Quaternionf rotation;
            private float weight;

            private RotationCandidate(Quaternionf rotation, float weight) {
                this.rotation = new Quaternionf(rotation);
                this.weight = weight;
            }
        }
    }

    static Quaternionf cubeRotation(float[] rotationDegrees) {
        return new Quaternionf()
                .rotateZ((float) Math.toRadians(rotationDegrees[2]))
                .rotateY((float) Math.toRadians(-rotationDegrees[1]))
                .rotateX((float) Math.toRadians(-rotationDegrees[0]))
                .normalize();
    }
}
