package dev.elifian.chaoslib.multipart.runtime;

import dev.elifian.chaoslib.api.multipart.GeoMultipartAnchor;
import dev.elifian.chaoslib.api.multipart.GeoMultipartBoneBounds;
import dev.elifian.chaoslib.api.multipart.GeoCompositeEntityPart;
import dev.elifian.chaoslib.api.multipart.GeoEntityPart;
import dev.elifian.chaoslib.api.multipart.GeoMultipartEntity;
import dev.elifian.chaoslib.api.multipart.GeoMultipartLocalBox;
import dev.elifian.chaoslib.api.multipart.GeoMultipartOffset;
import dev.elifian.chaoslib.api.multipart.GeoMultipartPartRegistrar;
import dev.elifian.chaoslib.api.multipart.GeoMultipartPositionWriter;
import dev.elifian.chaoslib.api.multipart.GeoTrackedBonePose;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

public final class GeoMultipartPartManager<T extends LivingEntity & GeoMultipartEntity> implements GeoMultipartPartRegistrar {
    private final T owner;
    private final LinkedHashMap<String, GeoEntityPart<T>> partsByBone = new LinkedHashMap<>();
    private final GeoMultipartPositionWriter<T> positionWriter = new GeoMultipartPositionWriter<>(this);
    private List<GeoEntityPart<T>> cachedParts = List.of();
    private Set<String> cachedTrackedBoneNames = Set.of();
    private List<PartSnapshot> cachedPartSnapshots = List.of();
    private AABB cachedMultipartEnclosingBox;
    private boolean multipartEnclosingBoxDirty = true;
    private boolean partSnapshotsDirty = true;
    private double lastOwnerX;
    private double lastOwnerY;
    private double lastOwnerZ;
    private boolean ownerPositionInitialized;
    private boolean serverUpdateActive;
    private boolean serverActivatedThisTick;

    public GeoMultipartPartManager(T owner) {
        this.owner = owner;
    }

    public T getOwner() {
        return this.owner;
    }

    public <P extends GeoEntityPart<T>> P track(P part) {
        this.partsByBone.put(part.getTrackedBoneName(), part);
        this.cachedParts = List.copyOf(this.partsByBone.values());
        this.cachedTrackedBoneNames = Set.copyOf(this.partsByBone.keySet());
        this.invalidateMultipartEnclosingBox();
        return part;
    }

    @Override
    @SuppressWarnings("unchecked")
    public <P extends GeoEntityPart<?>> P trackPart(P part) {
        return (P) this.track((GeoEntityPart<T>) part);
    }

    @Override
    public void track(String trackedBoneName, GeoMultipartAnchor anchor, GeoMultipartOffset offset) {
        GeoMultipartBoneBounds bounds = this.resolveBoneBounds(trackedBoneName);
        float centerX = anchor == GeoMultipartAnchor.BONE_BOUNDS_CENTER ? bounds.centerX() : 0.0f;
        float centerY = anchor == GeoMultipartAnchor.BONE_BOUNDS_CENTER ? bounds.centerY() : 0.0f;
        float centerZ = anchor == GeoMultipartAnchor.BONE_BOUNDS_CENTER ? bounds.centerZ() : 0.0f;
        this.track(new GeoEntityPart<>(
                this.owner,
                trackedBoneName,
                bounds.width(),
                bounds.height(),
                bounds.depth(),
                centerX + offset.x(),
                centerY + offset.y(),
                centerZ + offset.z(),
                bounds.qx(),
                bounds.qy(),
                bounds.qz(),
                bounds.qw()
        ));
    }

    @Override
    public void trackDetailed(String trackedBoneName, GeoMultipartOffset offset) {
        GeoMultipartBoneBounds bounds = this.resolveBoneBounds(trackedBoneName);
        List<GeoMultipartLocalBox> localBoxes = GeoMultipartBoneShapeResolver.resolve(this.owner, trackedBoneName)
                .orElseThrow(() -> new IllegalStateException(
                        "Missing multipart bone shape for bone '" + trackedBoneName + "' on " + this.owner.getType()
                                + ". Override getMultipartModelResource() and ensure the bone has cubes."
                ));
        this.track(new GeoCompositeEntityPart<>(
                this.owner,
                trackedBoneName,
                bounds.width(),
                bounds.height(),
                bounds.depth(),
                offset.x(),
                offset.y(),
                offset.z(),
                0.0f,
                0.0f,
                0.0f,
                1.0f,
                localBoxes
        ));
    }

    @Override
    public void track(
            String trackedBoneName,
            GeoMultipartAnchor anchor,
            float width,
            float height,
            float depth,
            float offsetX,
            float offsetY,
            float offsetZ
    ) {
        float centerX = 0.0f;
        float centerY = 0.0f;
        float centerZ = 0.0f;
        if (anchor == GeoMultipartAnchor.BONE_BOUNDS_CENTER) {
            GeoMultipartBoneBounds bounds = this.resolveBoneBounds(trackedBoneName);
            centerX = bounds.centerX();
            centerY = bounds.centerY();
            centerZ = bounds.centerZ();
        }
        this.track(new GeoEntityPart<>(
                this.owner,
                trackedBoneName,
                width,
                height,
                depth,
                centerX + offsetX,
                centerY + offsetY,
                centerZ + offsetZ
        ));
    }

    public Set<String> getTrackedBones() {
        return this.cachedTrackedBoneNames;
    }

    public List<GeoEntityPart<T>> getParts() {
        return this.cachedParts;
    }

    public Optional<GeoEntityPart<T>> getPart(String trackedBoneName) {
        return Optional.ofNullable(this.partsByBone.get(trackedBoneName));
    }

    public GeoMultipartPositionWriter<T> getPositionWriter() {
        return this.positionWriter;
    }

    public Iterable<GeoEntityPart<T>> getTrackedParts() {
        return this.partsByBone.values();
    }

    public Optional<AABB> getMultipartEnclosingBox() {
        if (this.multipartEnclosingBoxDirty || this.partSnapshotsDirty) {
            this.rebuildPartSnapshots();
        }

        return Optional.ofNullable(this.cachedMultipartEnclosingBox);
    }

    public List<PartSnapshot> getPartSnapshots() {
        if (this.partSnapshotsDirty) {
            this.rebuildPartSnapshots();
        }

        return this.cachedPartSnapshots;
    }

    public void applyTrackedBonePoses(Map<String, GeoTrackedBonePose> poses) {
        this.applyTrackedBonePoses(poses, false);
    }

    public void applyTrackedBonePoses(Map<String, GeoTrackedBonePose> poses, boolean alreadyInterpolated) {
        if (poses.isEmpty()) {
            return;
        }

        for (Map.Entry<String, GeoTrackedBonePose> entry : poses.entrySet()) {
            this.setPartPose(entry.getKey(), entry.getValue(), alreadyInterpolated);
        }
    }

    public void applyTrackedBonePositions(Map<String, Vec3> positions) {
        if (positions.isEmpty()) {
            return;
        }

        for (Map.Entry<String, Vec3> entry : positions.entrySet()) {
            this.setPartPosition(entry.getKey(), entry.getValue());
        }
    }

    public void setPartPose(String trackedBoneName, GeoTrackedBonePose pose) {
        this.setPartPose(trackedBoneName, pose, false);
    }

    public void setPartPose(String trackedBoneName, GeoTrackedBonePose pose, boolean alreadyInterpolated) {
        if (pose == null) {
            return;
        }

        GeoEntityPart<T> part = this.partsByBone.get(trackedBoneName);
        if (part != null) {
            GeoTrackedBonePose previousPose = part.getTrackedPose();
            part.setTrackedPose(pose, alreadyInterpolated);
            if (part.getTrackedPose() != previousPose) {
                this.invalidateMultipartEnclosingBox();
            }
        }
    }

    public void setPartPosition(String trackedBoneName, Vec3 position) {
        if (position == null) {
            return;
        }

        this.setPartPose(trackedBoneName, GeoTrackedBonePose.atPosition(position));
    }

    public void syncPreviousPartPositions() {
        for (GeoEntityPart<T> part : this.partsByBone.values()) {
            part.syncPreviousPose();
        }
    }

    public void resetPreviousPartPositions() {
        for (GeoEntityPart<T> part : this.partsByBone.values()) {
            part.resetPreviousPose();
        }
    }

    public void followOwnerMovement() {
        double ownerX = this.owner.getX();
        double ownerY = this.owner.getY();
        double ownerZ = this.owner.getZ();
        if (!this.ownerPositionInitialized) {
            this.lastOwnerX = ownerX;
            this.lastOwnerY = ownerY;
            this.lastOwnerZ = ownerZ;
            this.ownerPositionInitialized = true;
            return;
        }

        double deltaX = ownerX - this.lastOwnerX;
        double deltaY = ownerY - this.lastOwnerY;
        double deltaZ = ownerZ - this.lastOwnerZ;
        if (deltaX != 0.0d || deltaY != 0.0d || deltaZ != 0.0d) {
            for (GeoEntityPart<T> part : this.partsByBone.values()) {
                part.offsetPose(deltaX, deltaY, deltaZ);
            }
            this.invalidateMultipartEnclosingBox();
        }

        this.lastOwnerX = ownerX;
        this.lastOwnerY = ownerY;
        this.lastOwnerZ = ownerZ;
    }

    public void resetOwnerPositionTracking() {
        this.ownerPositionInitialized = false;
    }

    public void assignPartIds(int entityId) {
        int index = 0;
        for (GeoEntityPart<T> part : this.partsByBone.values()) {
            part.assignIdentity(entityId, index++);
        }
    }

    public void invalidateMultipartEnclosingBox() {
        this.multipartEnclosingBoxDirty = true;
        this.partSnapshotsDirty = true;
    }

    public void tickParts() {
        for (GeoEntityPart<T> part : this.partsByBone.values()) {
            part.tick();
        }
    }

    public boolean beginServerUpdate(boolean active) {
        boolean wasActive = this.serverUpdateActive;
        this.serverUpdateActive = active;
        this.serverActivatedThisTick = active && !wasActive;
        if (!active) {
            this.resetOwnerPositionTracking();
        }
        return active;
    }

    public boolean isServerUpdateActive() {
        return this.serverUpdateActive;
    }

    public boolean didServerUpdateActivateThisTick() {
        return this.serverActivatedThisTick;
    }

    public void finishServerUpdate() {
        this.serverActivatedThisTick = false;
    }

    public Vec3 resolveYawOffset(double x, double y, double z) {
        double radians = Math.toRadians(-this.owner.yBodyRot);
        double cos = Math.cos(radians);
        double sin = Math.sin(radians);
        double rotatedX = x * cos - z * sin;
        double rotatedZ = x * sin + z * cos;
        return new Vec3(this.owner.getX() + rotatedX, this.owner.getY() + y, this.owner.getZ() + rotatedZ);
    }

    private GeoMultipartBoneBounds resolveBoneBounds(String trackedBoneName) {
        return GeoMultipartBoneBoundsResolver.resolve(this.owner, trackedBoneName)
                .orElseThrow(() -> new IllegalStateException(
                        "Missing multipart bone bounds for bone '" + trackedBoneName + "' on " + this.owner.getType()
                                + ". Override getMultipartModelResource() and ensure the bone has cubes."
                ));
    }

    private void rebuildPartSnapshots() {
        if (this.partsByBone.isEmpty()) {
            this.cachedPartSnapshots = List.of();
            this.cachedMultipartEnclosingBox = null;
            this.multipartEnclosingBoxDirty = false;
            this.partSnapshotsDirty = false;
            return;
        }

        ArrayList<PartSnapshot> snapshots = new ArrayList<>(this.partsByBone.size());
        AABB union = null;
        for (GeoEntityPart<T> part : this.partsByBone.values()) {
            GeoTrackedBonePose pose = part.getTrackedPose();
            AABB enclosingBox = part.computeEnclosingBox(pose);
            snapshots.add(new PartSnapshot(part, pose, enclosingBox));
            union = union == null ? enclosingBox : union.minmax(enclosingBox);
        }

        this.cachedPartSnapshots = List.copyOf(snapshots);
        this.cachedMultipartEnclosingBox = union;
        this.multipartEnclosingBoxDirty = false;
        this.partSnapshotsDirty = false;
    }

    public record PartSnapshot(GeoEntityPart<?> part, GeoTrackedBonePose pose, AABB enclosingBox) {
    }
}
