package dev.elifian.chaoslib.multipart.runtime;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.elifian.chaoslib.api.multipart.GeoMultipartEntity;
import dev.elifian.chaoslib.api.multipart.GeoMultipartLocalBox;
import dev.elifian.chaoslib.loading.json.raw.Bone;
import dev.elifian.chaoslib.loading.json.raw.Cube;
import dev.elifian.chaoslib.loading.json.raw.Model;
import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

final class GeoMultipartBoneShapeResolver {
    private static final Map<ResourceLocation, Map<String, List<GeoMultipartLocalBox>>> CACHE = new ConcurrentHashMap<>();

    private GeoMultipartBoneShapeResolver() {
    }

    public static Optional<List<GeoMultipartLocalBox>> resolve(GeoMultipartEntity multipart, String trackedBoneName) {
        if (!(multipart instanceof Entity)) {
            return Optional.empty();
        }

        ResourceLocation modelResource = multipart.getMultipartModelResource();
        if (modelResource == null) {
            return Optional.empty();
        }

        return Optional.ofNullable(CACHE.computeIfAbsent(modelResource, GeoMultipartBoneShapeResolver::loadShapes).get(trackedBoneName));
    }

    private static Map<String, List<GeoMultipartLocalBox>> loadShapes(ResourceLocation modelResource) {
        try (InputStream stream = openModelResource(modelResource);
             InputStreamReader reader = new InputStreamReader(stream, StandardCharsets.UTF_8)) {
            JsonObject json = JsonParser.parseReader(reader).getAsJsonObject();
            Model model = Model.fromJson(json);
            LinkedHashMap<String, List<GeoMultipartLocalBox>> shapesByBone = new LinkedHashMap<>();
            for (Bone bone : model.minecraftGeometry()[0].bones()) {
                List<GeoMultipartLocalBox> boxes = readBoneBoxes(bone);
                if (!boxes.isEmpty()) {
                    shapesByBone.put(bone.name(), List.copyOf(boxes));
                }
            }
            return Map.copyOf(shapesByBone);
        } catch (Exception exception) {
            throw new IllegalStateException("Failed to resolve multipart bone shape for model " + modelResource, exception);
        }
    }

    private static InputStream openModelResource(ResourceLocation modelResource) {
        String resourcePath = "assets/" + modelResource.getNamespace() + "/" + modelResource.getPath();
        ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();
        InputStream stream = contextClassLoader == null ? null : contextClassLoader.getResourceAsStream(resourcePath);
        if (stream == null) {
            stream = GeoMultipartBoneShapeResolver.class.getClassLoader().getResourceAsStream(resourcePath);
        }
        if (stream == null) {
            throw new IllegalStateException("Resource not found on classpath: " + resourcePath);
        }
        return stream;
    }

    private static List<GeoMultipartLocalBox> readBoneBoxes(Bone bone) {
        if (bone.cubes().length == 0) {
            return List.of();
        }

        float[] bonePivot = toFloatArray(bone.pivot(), 3);
        float pivotX = -bonePivot[0] / 16.0f;
        float pivotY = bonePivot[1] / 16.0f;
        float pivotZ = bonePivot[2] / 16.0f;
        ArrayList<GeoMultipartLocalBox> boxes = new ArrayList<>(bone.cubes().length);
        for (Cube cube : bone.cubes()) {
            GeoMultipartLocalBox localBox = readCubeBox(cube, pivotX, pivotY, pivotZ);
            if (localBox != null) {
                boxes.add(localBox);
            }
        }
        return boxes;
    }

    private static GeoMultipartLocalBox readCubeBox(Cube cube, float bonePivotX, float bonePivotY, float bonePivotZ) {
        float[] origin = toFloatArray(cube.origin(), 3);
        float[] size = toFloatArray(cube.size(), 3);
        float[] pivot = toFloatArray(cube.pivot(), 3);
        float[] rotation = toFloatArray(cube.rotation(), 3);
        float inflate = cube.inflate() == null ? 0.0f : cube.inflate().floatValue() / 16.0f;

        float minX = -(origin[0] + size[0]) / 16.0f - inflate;
        float maxX = -origin[0] / 16.0f + inflate;
        float minY = origin[1] / 16.0f - inflate;
        float maxY = (origin[1] + size[1]) / 16.0f + inflate;
        float minZ = origin[2] / 16.0f - inflate;
        float maxZ = (origin[2] + size[2]) / 16.0f + inflate;

        Matrix4f cubeMatrix = new Matrix4f()
                .translate(-pivot[0] / 16.0f, pivot[1] / 16.0f, pivot[2] / 16.0f)
                .rotateZ((float) Math.toRadians(rotation[2]))
                .rotateY((float) Math.toRadians(-rotation[1]))
                .rotateX((float) Math.toRadians(-rotation[0]))
                .translate(pivot[0] / 16.0f, -pivot[1] / 16.0f, -pivot[2] / 16.0f);

        Vector3f transformedCenter = cubeMatrix.transformPosition(
                (minX + maxX) * 0.5f,
                (minY + maxY) * 0.5f,
                (minZ + maxZ) * 0.5f,
                new Vector3f()
        );

        var quaternion = GeoMultipartBoneBoundsResolver.cubeRotation(rotation);
        return new GeoMultipartLocalBox(
                maxX - minX,
                maxY - minY,
                maxZ - minZ,
                transformedCenter.x - bonePivotX,
                transformedCenter.y - bonePivotY,
                transformedCenter.z - bonePivotZ,
                quaternion.x,
                quaternion.y,
                quaternion.z,
                quaternion.w
        );
    }

    private static float[] toFloatArray(double[] source, int size) {
        float[] values = new float[size];
        for (int i = 0; i < Math.min(source.length, size); i++) {
            values[i] = (float) source[i];
        }
        return values;
    }
}
