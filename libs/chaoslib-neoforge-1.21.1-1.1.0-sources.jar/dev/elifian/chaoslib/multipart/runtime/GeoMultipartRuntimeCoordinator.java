package dev.elifian.chaoslib.multipart.runtime;

import dev.elifian.chaoslib.client.multipart.GeoMultipartClientBroadPhaseCache;
import dev.elifian.chaoslib.client.multipart.GeoMultipartClientPoseStore;
import dev.elifian.chaoslib.client.multipart.GeoMultipartHitboxHelper;
import dev.elifian.chaoslib.api.multipart.GeoEntityPart;
import dev.elifian.chaoslib.api.multipart.GeoMultipartEntity;
import dev.elifian.chaoslib.api.multipart.GeoMultipartPositionWriter;
import dev.elifian.chaoslib.api.multipart.GeoTrackedBonePose;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.Map;

/**
 * Explicit multipart runtime coordinator used by mixin integration and entity facades.
 */
public final class GeoMultipartRuntimeCoordinator {
    private GeoMultipartRuntimeCoordinator() {
    }

    @SuppressWarnings("unchecked")
    public static <T extends LivingEntity & GeoMultipartEntity> GeoMultipartPartManager<T> getManager(T entity) {
        return GeoMultipartManagerStore.get(entity);
    }

    public static AABB getBroadPhaseBoundingBox(GeoMultipartEntity multipart) {
        if ((Object) multipart instanceof Entity entity) {
            if (!entity.level().isClientSide) {
                return multipart.getMultipartPartManager().getMultipartEnclosingBox().orElse(entity.getBoundingBox());
            }

            GeoMultipartClientPoseStore.PoseSnapshot snapshot = GeoMultipartClientPoseStore.snapshot(entity);
            if (snapshot == null) {
                return multipart.getMultipartPartManager().getMultipartEnclosingBox().orElse(entity.getBoundingBox());
            }

            AABB cached = GeoMultipartClientBroadPhaseCache.get(entity, snapshot.cacheToken());
            if (cached != null) {
                return cached;
            }

            AABB union = null;
            for (GeoEntityPart<?> part : multipart.getMultipartParts()) {
                GeoTrackedBonePose trackedPose = snapshot.getCurrentPoseOrNull(part.getTrackedBoneName());
                GeoTrackedBonePose collisionPose = trackedPose != null
                        ? GeoMultipartHitboxHelper.resolvePartPose(trackedPose, part)
                        : part.getTrackedPose();
                AABB partBox = part.computeEnclosingBox(collisionPose);
                union = union == null ? partBox : union.minmax(partBox);
            }

            if (union != null) {
                GeoMultipartClientBroadPhaseCache.put(entity, snapshot.cacheToken(), union);
            }

            return union != null ? union : entity.getBoundingBox();
        }

        return multipart.getMultipartPartManager().getMultipartEnclosingBox()
                .orElseThrow(() -> new IllegalStateException("Multipart broad-phase box requested for non-entity owner"));
    }

    public static GeoTrackedBonePose getCollisionPose(GeoMultipartEntity multipart, GeoEntityPart<?> part) {
        if ((Object) multipart instanceof Entity entity && entity.level().isClientSide) {
            GeoMultipartClientPoseStore.PoseSnapshot snapshot = GeoMultipartClientPoseStore.snapshot(entity);
            if (snapshot != null) {
                GeoTrackedBonePose trackedPose = snapshot.getCurrentPoseOrNull(part.getTrackedBoneName());
                if (trackedPose != null) {
                    return GeoMultipartHitboxHelper.resolvePartPose(trackedPose, part);
                }
            }

            return part.getTrackedPose();
        }

        return part.getTrackedPose();
    }

    public static void receiveTrackedBonePositions(GeoMultipartEntity multipart, Map<String, Vec3> positions) {
        if (positions == null || positions.isEmpty()) {
            return;
        }

        multipart.getMultipartPartManager().applyTrackedBonePositions(positions);
    }

    public static void receiveTrackedBonePoses(GeoMultipartEntity multipart, Map<String, GeoTrackedBonePose> poses) {
        if (poses == null || poses.isEmpty()) {
            return;
        }

        if ((Object) multipart instanceof Entity entity && entity.level().isClientSide) {
            GeoMultipartClientPoseStore.update(entity, poses);
            return;
        }

        GeoMultipartPartManager<?> manager = multipart.getMultipartPartManager();
        manager.applyTrackedBonePoses(poses, false);
        manager.invalidateMultipartEnclosingBox();
    }

    public static void assignPartIds(GeoMultipartEntity multipart, int entityId) {
        multipart.getMultipartPartManager().assignPartIds(entityId);
    }

    public static void syncPreviousPartPositions(GeoMultipartEntity multipart) {
        multipart.getMultipartPartManager().syncPreviousPartPositions();
    }

    public static void resetPreviousPartPositions(GeoMultipartEntity multipart) {
        GeoMultipartPartManager<?> manager = multipart.getMultipartPartManager();
        manager.resetPreviousPartPositions();
        manager.resetOwnerPositionTracking();
    }

    public static void tickPartPositions(GeoMultipartEntity multipart) {
        multipart.writeMultipartPositions((GeoMultipartPositionWriter<?>) multipart.getMultipartPartManager().getPositionWriter());
    }

    public static void onTickStart(GeoMultipartEntity multipart) {
        if (!((Object) multipart instanceof Entity entity) || entity.level().isClientSide) {
            return;
        }

        ServerLevel serverWorld = (ServerLevel) entity.level();
        GeoMultipartPartManager<?> manager = multipart.getMultipartPartManager();
        if (!manager.beginServerUpdate(multipart.shouldTickMultipartServerNow(serverWorld))) {
            return;
        }

        if (!manager.didServerUpdateActivateThisTick()) {
            manager.syncPreviousPartPositions();
        }
    }

    public static void onTickEnd(GeoMultipartEntity multipart) {
        if (!((Object) multipart instanceof Entity entity) || entity.level().isClientSide) {
            return;
        }

        GeoMultipartPartManager<?> manager = multipart.getMultipartPartManager();
        if (!manager.isServerUpdateActive()) {
            manager.finishServerUpdate();
            return;
        }
        if (!manager.didServerUpdateActivateThisTick()) {
            manager.followOwnerMovement();
        }
        multipart.writeMultipartPositions(manager.getPositionWriter());
        if (manager.didServerUpdateActivateThisTick()) {
            resetPreviousPartPositions(multipart);
        }
        manager.tickParts();
        manager.finishServerUpdate();
    }
}
