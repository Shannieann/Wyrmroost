package dev.elifian.chaoslib.multipart.interaction;

import dev.elifian.chaoslib.api.multipart.GeoMultipartEntity;
import dev.elifian.chaoslib.api.multipart.GeoEntityPart;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.Vec3;

import java.util.Optional;

public final class GeoMultipartUseDispatcher {
    private static final ThreadLocal<Boolean> REENTRANT = ThreadLocal.withInitial(() -> false);

    private GeoMultipartUseDispatcher() {
    }

    public static boolean isReentrant() {
        return REENTRANT.get();
    }

    public static <T extends LivingEntity & GeoMultipartEntity> Optional<InteractionResult> dispatch(
            T owner,
            Player player,
            InteractionHand hand,
            Vec3 localHitPos
    ) {
        if (isReentrant()) {
            return Optional.empty();
        }

        Optional<GeoEntityPart<?>> hintedPart = player instanceof net.minecraft.server.level.ServerPlayer serverPlayer
                ? GeoMultipartUseHintStore.take(serverPlayer, owner, player.level().getGameTime())
                : Optional.empty();
        Vec3 worldHitPos = localHitPos.add(owner.getX(), owner.getY(), owner.getZ());
        Optional<GeoEntityPart<?>> part = hintedPart.isPresent()
                ? hintedPart
                : GeoMultipartServerHitHelper.findOwnerCollisionPartAtPoint(owner, worldHitPos);
        if (part.isEmpty()) {
            return Optional.empty();
        }

        REENTRANT.set(true);
        try {
            return Optional.of(part.get().interact(player, hand, localHitPos, worldHitPos));
        } finally {
            REENTRANT.set(false);
        }
    }

    public static <T extends LivingEntity & GeoMultipartEntity> Optional<InteractionResult> dispatch(T owner, Player player, InteractionHand hand) {
        if (isReentrant()) {
            return Optional.empty();
        }

        if (player instanceof net.minecraft.server.level.ServerPlayer serverPlayer) {
            Optional<GeoEntityPart<?>> hintedPart = GeoMultipartUseHintStore.take(serverPlayer, owner, player.level().getGameTime());
            if (hintedPart.isPresent()) {
                Vec3 worldHitPos = hintedPart.get().getTrackedPose().position();
                Vec3 localHitPos = worldHitPos.subtract(owner.getX(), owner.getY(), owner.getZ());
                REENTRANT.set(true);
                try {
                    return Optional.of(hintedPart.get().interact(player, hand, localHitPos, worldHitPos));
                } finally {
                    REENTRANT.set(false);
                }
            }
        }

        Vec3 from = player.getEyePosition();
        Vec3 to = from.add(player.getViewVector(1.0f).scale(6.0d));
        Optional<GeoMultipartHitResult> hit = GeoMultipartServerHitHelper.findOwnerCollisionHit(owner, from, to);
        if (hit.isEmpty()) {
            return Optional.empty();
        }

        Vec3 worldHitPos = hit.get().hitPos();
        Vec3 localHitPos = worldHitPos.subtract(owner.getX(), owner.getY(), owner.getZ());
        REENTRANT.set(true);
        try {
            return Optional.of(hit.get().part().interact(player, hand, localHitPos, worldHitPos));
        } finally {
            REENTRANT.set(false);
        }
    }
}
