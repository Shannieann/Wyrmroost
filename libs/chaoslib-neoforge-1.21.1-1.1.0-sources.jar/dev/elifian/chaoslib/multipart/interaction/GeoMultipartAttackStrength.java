package dev.elifian.chaoslib.multipart.interaction;

import net.minecraft.world.entity.player.Player;

/**
 * The attack strength of the swing currently being resolved.
 *
 * <p>Vanilla resets the swing counter before it applies the damage, so by the time a multipart hit
 * is dispatched the entity's own strength always reads as if the swing had just started. The value
 * is captured at the top of the attack instead.</p>
 */
public final class GeoMultipartAttackStrength {
    private static final ThreadLocal<Float> CURRENT = new ThreadLocal<>();

    private GeoMultipartAttackStrength() {
    }

    public static void begin(Player player) {
        CURRENT.set(player.getAttackStrengthScale(0.5f));
    }

    public static void end() {
        CURRENT.remove();
    }

    /**
     * Returns the strength of the swing being resolved, falling back to the player's current value
     * for damage that does not come from a melee attack.
     */
    public static float resolve(Player player) {
        Float captured = CURRENT.get();
        return captured != null ? captured : player.getAttackStrengthScale(0.5f);
    }
}
