package dev.elifian.chaoslib.multipart.interaction;

import dev.elifian.chaoslib.api.multipart.GeoMultipartEntity;
import dev.elifian.chaoslib.api.multipart.GeoEntityPart;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;

import java.util.Collections;
import java.util.Map;
import java.util.Optional;
import java.util.WeakHashMap;

public final class GeoMultipartMeleeHitHintStore {
    private static final long HINT_LIFETIME_TICKS = 2L;
    private static final Map<ServerPlayer, Hint> HINTS = Collections.synchronizedMap(new WeakHashMap<>());

    private GeoMultipartMeleeHitHintStore() {
    }

    public static void put(ServerPlayer player, int entityId, String trackedBoneName, long worldTime) {
        HINTS.put(player, new Hint(entityId, trackedBoneName, worldTime + HINT_LIFETIME_TICKS));
    }

    public static Optional<GeoEntityPart<?>> take(ServerPlayer player, GeoMultipartEntity owner, long worldTime) {
        Hint hint = HINTS.remove(player);
        if (hint == null || worldTime > hint.expiresAtTick) {
            return Optional.empty();
        }

        if (!(((Object) owner) instanceof Entity entity) || entity.getId() != hint.entityId) {
            return Optional.empty();
        }

        return owner.getMultipartPartManager().getPart(hint.trackedBoneName).map(part -> (GeoEntityPart<?>) part);
    }

    private record Hint(int entityId, String trackedBoneName, long expiresAtTick) {
    }
}
