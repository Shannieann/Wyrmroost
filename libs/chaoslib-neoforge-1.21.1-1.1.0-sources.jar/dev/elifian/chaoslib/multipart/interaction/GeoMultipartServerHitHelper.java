package dev.elifian.chaoslib.multipart.interaction;

import dev.elifian.chaoslib.api.multipart.GeoEntityPart;
import dev.elifian.chaoslib.api.multipart.GeoMultipartEntity;
import dev.elifian.chaoslib.api.multipart.GeoTrackedBonePose;
import dev.elifian.chaoslib.multipart.runtime.GeoMultipartManagerStore;
import dev.elifian.chaoslib.multipart.runtime.GeoMultipartPartManager;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.shapes.BooleanOp;
import net.minecraft.core.Direction;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.level.CollisionGetter;
import net.minecraft.world.level.border.WorldBorder;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.WeakHashMap;
import java.util.function.Predicate;

public final class GeoMultipartServerHitHelper {
    private static final double GLOBAL_MULTIPART_PROJECTILE_SEARCH_MARGIN = 1.0E-7d;
    private static final double GLOBAL_MULTIPART_COLLISION_SEARCH_MARGIN = 1.0E-7d;
    private static final double MOVEMENT_COLLISION_BACKOFF = 1.0E-7d;
    private static final double VERTICAL_SUPPORT_TOLERANCE = 0.25d;
    private static final double MIN_SUPPORT_AXIS_OVERLAP = 1.0E-4d;
    private static final double SNEAK_CLIP_STEP = 0.05d;
    private static final WeakHashMap<CollisionGetter, WorldMultipartSnapshot> WORLD_MULTIPART_SNAPSHOTS = new WeakHashMap<>();

    private GeoMultipartServerHitHelper() {
    }

    public static Optional<GeoMultipartHitResult> findOwnerCollisionHit(GeoMultipartEntity multipart, Vec3 from, Vec3 to) {
        return findOwnerCollisionHit(multipart, from, to, 0.0d);
    }

    public static Optional<GeoMultipartHitResult> findOwnerCollisionHit(GeoMultipartEntity multipart, Vec3 from, Vec3 to, double margin) {
        GeoMultipartHitResult best = null;
        AABB pathBox = createPathBox(from, to, margin, margin, margin);
        for (GeoMultipartPartManager.PartSnapshot snapshot : multipart.getMultipartPartManager().getPartSnapshots()) {
            GeoEntityPart<?> part = snapshot.part();
            if (!part.hasCollision()) {
                continue;
            }

            GeoTrackedBonePose pose = snapshot.pose();
            AABB partBox = snapshot.enclosingBox();
            if (!partBox.intersects(pathBox)) {
                continue;
            }

            Optional<Vec3> hitPos = margin > 0.0d
                    ? partBox.inflate(margin).clip(from, to)
                    : part.raycast(pose, from, to);
            if (hitPos.isEmpty()) {
                continue;
            }

            double distanceSquared = from.distanceToSqr(hitPos.get());
            if (best == null || distanceSquared < best.distanceSquared()) {
                best = new GeoMultipartHitResult(part, hitPos.get(), distanceSquared);
            }
        }
        return Optional.ofNullable(best);
    }

    public static Optional<GeoMultipartHitResult> findOwnerCollisionHit(
            GeoMultipartEntity multipart,
            Vec3 from,
            Vec3 to,
            double halfExtentX,
            double halfExtentY,
            double halfExtentZ
    ) {
        GeoMultipartHitResult best = null;
        AABB pathBox = createPathBox(from, to, halfExtentX, halfExtentY, halfExtentZ);
        for (GeoMultipartPartManager.PartSnapshot snapshot : multipart.getMultipartPartManager().getPartSnapshots()) {
            GeoEntityPart<?> part = snapshot.part();
            if (!part.hasCollision()) {
                continue;
            }

            GeoTrackedBonePose pose = snapshot.pose();
            AABB partBox = snapshot.enclosingBox();
            if (!partBox.inflate(halfExtentX, halfExtentY, halfExtentZ).intersects(pathBox)) {
                continue;
            }

            Optional<Vec3> hitPos = part.sweepAabbAgainst(pose, from, to, halfExtentX, halfExtentY, halfExtentZ);
            if (hitPos.isEmpty()) {
                continue;
            }

            double distanceSquared = from.distanceToSqr(hitPos.get());
            if (best == null || distanceSquared < best.distanceSquared()) {
                best = new GeoMultipartHitResult(part, hitPos.get(), distanceSquared);
            }
        }
        return Optional.ofNullable(best);
    }

    public static Optional<GeoEntityPart<?>> findOwnerCollisionPartAtPoint(GeoMultipartEntity multipart, Vec3 point) {
        GeoEntityPart<?> best = null;
        double bestDistanceSquared = Double.POSITIVE_INFINITY;
        for (GeoMultipartPartManager.PartSnapshot snapshot : multipart.getMultipartPartManager().getPartSnapshots()) {
            GeoEntityPart<?> part = snapshot.part();
            if (!part.hasCollision()) {
                continue;
            }

            GeoTrackedBonePose pose = snapshot.pose();
            if (!snapshot.enclosingBox().contains(point)) {
                continue;
            }
            if (!part.containsPoint(pose, point)) {
                continue;
            }

            double distanceSquared = point.distanceToSqr(pose.x(), pose.y(), pose.z());
            if (distanceSquared < bestDistanceSquared) {
                bestDistanceSquared = distanceSquared;
                best = part;
            }
        }
        return Optional.ofNullable(best);
    }

    public static Optional<GeoMultipartHitResult> findWorldHit(
            CollisionGetter world,
            Entity source,
            Vec3 from,
            Vec3 to,
            AABB searchBox,
            Predicate<Entity> predicate,
            double maxDistanceSquared,
            double collisionMargin,
            Vec3 collisionHalfExtents
    ) {
        GeoMultipartHitResult best = null;
        AABB expandedSearchBox = searchBox.inflate(GLOBAL_MULTIPART_PROJECTILE_SEARCH_MARGIN);
        for (GeoMultipartEntity multipart : collectMultipartCandidates(world, source, expandedSearchBox, predicate)) {
            Optional<GeoMultipartHitResult> ownerHit = collisionHalfExtents != null
                    ? findOwnerCollisionHit(multipart, from, to, collisionHalfExtents.x, collisionHalfExtents.y, collisionHalfExtents.z)
                    : findOwnerCollisionHit(multipart, from, to, collisionMargin);
            if (ownerHit.isEmpty()) {
                continue;
            }

            double distanceSquared = ownerHit.get().distanceSquared();
            if (distanceSquared > maxDistanceSquared) {
                continue;
            }

            if (best == null || distanceSquared < best.distanceSquared()) {
                best = ownerHit.get();
            }
        }
        return Optional.ofNullable(best);
    }

    public static Vec3 adjustMovementForMultipartCollisions(CollisionGetter world, Entity entity, AABB box, Vec3 movement) {
        if (movement.lengthSqr() < 1.0E-12d) {
            return movement;
        }

        double x = movement.x;
        double y = movement.y;
        double z = movement.z;

        if (y != 0.0d) {
            y = calculateMaxOffset(world, entity, box, Direction.Axis.Y, y);
            if (y != 0.0d) {
                box = box.move(0.0d, y, 0.0d);
            }
        }

        boolean zFirst = Math.abs(x) < Math.abs(z);
        if (zFirst && z != 0.0d) {
            z = calculateMaxOffset(world, entity, box, Direction.Axis.Z, z);
            if (z != 0.0d) {
                box = box.move(0.0d, 0.0d, z);
            }
        }

        if (x != 0.0d) {
            x = calculateMaxOffset(world, entity, box, Direction.Axis.X, x);
            if (!zFirst && x != 0.0d) {
                box = box.move(x, 0.0d, 0.0d);
            }
        }

        if (!zFirst && z != 0.0d) {
            z = calculateMaxOffset(world, entity, box, Direction.Axis.Z, z);
        }

        return new Vec3(x, y, z);
    }

    public static boolean hasMultipartCollision(CollisionGetter world, Entity source, AABB box) {
        AABB expandedSearchBox = box.inflate(GLOBAL_MULTIPART_COLLISION_SEARCH_MARGIN);
        for (GeoMultipartEntity multipart : collectMultipartCandidates(world, source, expandedSearchBox, null)) {
            for (GeoMultipartPartManager.PartSnapshot snapshot : multipart.getMultipartPartManager().getPartSnapshots()) {
                GeoEntityPart<?> part = snapshot.part();
                if (!part.hasCollision()) {
                    continue;
                }

                if (intersectsPartWithBox(part, snapshot.pose(), box)) {
                    return true;
                }
            }
        }

        return false;
    }

    public static boolean isVanillaSpaceEmpty(CollisionGetter world, Entity entity, AABB box) {
        for (VoxelShape shape : world.getBlockCollisions(entity, box)) {
            if (!shape.isEmpty()) {
                return false;
            }
        }

        if (!world.getEntityCollisions(entity, box).isEmpty()) {
            return false;
        }

        if (entity == null) {
            return true;
        }

        WorldBorder worldBorder = world.getWorldBorder();
        if (!worldBorder.isInsideCloseToBorder(entity, box)) {
            return true;
        }

        return !Shapes.joinIsNotEmpty(worldBorder.getCollisionShape(), Shapes.create(box), BooleanOp.AND);
    }

    public static boolean isSpaceEmptyIncludingMultipart(CollisionGetter world, Entity entity, AABB box) {
        return isVanillaSpaceEmpty(world, entity, box) && !hasMultipartCollision(world, entity, box);
    }

    public static Vec3 clipMovementForMultipartSneaking(CollisionGetter world, Entity entity, AABB box, Vec3 movement) {
        if (!entity.isShiftKeyDown()
                || !entity.onGround()
                || movement.lengthSqr() < 1.0E-12d
                || entity.maxUpStep() <= 0.0f) {
            return movement;
        }

        double maxDrop = entity.maxUpStep();
        double x = movement.x;
        double z = movement.z;

        while (x != 0.0d && wouldSneakOffMultipartLedge(world, entity, box, x, 0.0d, maxDrop)) {
            x = trimSneakMovement(x);
        }

        while (z != 0.0d && wouldSneakOffMultipartLedge(world, entity, box, 0.0d, z, maxDrop)) {
            z = trimSneakMovement(z);
        }

        while (x != 0.0d && z != 0.0d && wouldSneakOffMultipartLedge(world, entity, box, x, z, maxDrop)) {
            x = trimSneakMovement(x);
            z = trimSneakMovement(z);
        }

        return new Vec3(x, movement.y, z);
    }

    private static List<GeoMultipartEntity> collectMultipartCandidates(
            CollisionGetter world,
            Entity source,
            AABB searchBox,
            Predicate<Entity> predicate
    ) {
        List<GeoMultipartEntity> candidates = new ArrayList<>();
        for (GeoMultipartEntity multipart : snapshotWorldMultipartEntities(world)) {
            if (!isCandidateMultipart(world, source, multipart, searchBox, predicate)) {
                continue;
            }
            candidates.add(multipart);
        }
        return candidates;
    }

    private static List<GeoMultipartEntity> snapshotWorldMultipartEntities(CollisionGetter world) {
        List<GeoMultipartEntity> globalSnapshot = GeoMultipartManagerStore.snapshotEntities();
        if (!(world instanceof ServerLevel serverWorld)) {
            return globalSnapshot;
        }

        WorldMultipartSnapshot cached = WORLD_MULTIPART_SNAPSHOTS.get(world);
        long gameTime = serverWorld.getGameTime();
        if (cached != null && cached.matches(gameTime, globalSnapshot)) {
            return cached.entities();
        }

        ArrayList<GeoMultipartEntity> filtered = new ArrayList<>(globalSnapshot.size());
        for (GeoMultipartEntity multipart : globalSnapshot) {
            if ((Object) multipart instanceof Entity entity && entity.level() == world && !entity.isRemoved()) {
                filtered.add(multipart);
            }
        }

        List<GeoMultipartEntity> worldSnapshot = filtered.isEmpty() ? List.of() : List.copyOf(filtered);
        WORLD_MULTIPART_SNAPSHOTS.put(world, new WorldMultipartSnapshot(gameTime, globalSnapshot, worldSnapshot));
        return worldSnapshot;
    }

    private static boolean isCandidateMultipart(
            CollisionGetter world,
            Entity source,
            GeoMultipartEntity multipart,
            AABB searchBox,
            Predicate<Entity> predicate
    ) {
        if (!((Object) multipart instanceof Entity entity)) {
            return false;
        }
        if (entity.isRemoved()) {
            return false;
        }
        if (entity.level() != world) {
            return false;
        }
        if (source != null && entity == source) {
            return false;
        }
        if (predicate != null && !predicate.test(entity)) {
            return false;
        }
        return multipart.getMultipartBroadPhaseBoundingBox().intersects(searchBox);
    }

    private static double calculateMaxOffset(CollisionGetter world, Entity entity, AABB box, Direction.Axis axis, double desiredOffset) {
        if (Math.abs(desiredOffset) < 1.0E-12d) {
            return desiredOffset;
        }

        AABB searchBox = stretchAlongAxis(box, axis, desiredOffset).inflate(GLOBAL_MULTIPART_COLLISION_SEARCH_MARGIN);
        for (GeoMultipartEntity multipart : collectMultipartCandidates(world, entity, searchBox, null)) {
            for (GeoMultipartPartManager.PartSnapshot snapshot : multipart.getMultipartPartManager().getPartSnapshots()) {
                GeoEntityPart<?> part = snapshot.part();
                if (!part.hasCollision()) {
                    continue;
                }

                GeoTrackedBonePose collisionPose = snapshot.pose();
                AABB partBox = snapshot.enclosingBox();
                if (!partBox.inflate(
                        axis == Direction.Axis.X ? Math.abs(desiredOffset) : 0.0d,
                        axis == Direction.Axis.Y ? Math.abs(desiredOffset) : 0.0d,
                        axis == Direction.Axis.Z ? Math.abs(desiredOffset) : 0.0d
                ).intersects(searchBox)) {
                    continue;
                }

                desiredOffset = calculatePartMaxOffset(part, collisionPose, box, axis, desiredOffset);
                if (Math.abs(desiredOffset) < 1.0E-12d) {
                    return 0.0d;
                }
            }
        }

        return desiredOffset;
    }

    private static double calculatePartMaxOffset(
            GeoEntityPart<?> part,
            GeoTrackedBonePose collisionPose,
            AABB box,
            Direction.Axis axis,
            double desiredOffset
    ) {
        Vec3 from = box.getCenter();
        Vec3 halfExtents = new Vec3(
                (box.maxX - box.minX) * 0.5d,
                (box.maxY - box.minY) * 0.5d,
                (box.maxZ - box.minZ) * 0.5d
        );

        if (axis == Direction.Axis.Y) {
            Double faceOffset = calculateVerticalFaceOffset(part, collisionPose, box, desiredOffset);
            if (faceOffset != null) {
                return faceOffset;
            }
        }

        Vec3 to = offsetAlongAxis(from, axis, desiredOffset);
        boolean intersectsAtStart = part.intersectsAabb(collisionPose, from, halfExtents.x, halfExtents.y, halfExtents.z);

        if (intersectsAtStart) {
            if (axis == Direction.Axis.Y) {
                return hasVerticalBlockingContactAtStart(part, collisionPose, box, desiredOffset) ? 0.0d : desiredOffset;
            }
            return doesNotWorsenCollision(part, collisionPose, box, axis, desiredOffset) ? desiredOffset : 0.0d;
        }

        Optional<Vec3> hitPos = part.sweepAabbAgainst(collisionPose, from, to, halfExtents.x, halfExtents.y, halfExtents.z);
        if (hitPos.isEmpty()) {
            return desiredOffset;
        }

        if (axis == Direction.Axis.Y && !hasVerticalBlockingContact(part, collisionPose, box, desiredOffset)) {
            return desiredOffset;
        }

        double hitOffset = axisValue(hitPos.get(), axis) - axisValue(from, axis);
        if (desiredOffset > 0.0d) {
            return Math.min(desiredOffset, Math.max(0.0d, hitOffset - MOVEMENT_COLLISION_BACKOFF));
        }

        return Math.max(desiredOffset, Math.min(0.0d, hitOffset + MOVEMENT_COLLISION_BACKOFF));
    }

    private static Double calculateVerticalFaceOffset(
            GeoEntityPart<?> part,
            GeoTrackedBonePose collisionPose,
            AABB box,
            double desiredOffset
    ) {
        List<AABB> collisionBoxes = new ArrayList<>();
        part.appendCollisionBoxes(collisionPose, stretchAlongAxis(box, Direction.Axis.Y, desiredOffset), collisionBoxes);

        Double resolvedOffset = null;
        for (AABB collisionBox : collisionBoxes) {
            if (!hasSupportFootprint(box, collisionBox)) {
                continue;
            }

            if (desiredOffset < 0.0d) {
                double top = collisionBox.maxY;
                if (isStandingOnTopFace(box, top) && box.minY + desiredOffset < top) {
                    double candidate = top - box.minY;
                    resolvedOffset = resolvedOffset == null ? candidate : Math.max(resolvedOffset, candidate);
                }
                continue;
            }

            if (desiredOffset > 0.0d) {
                double bottom = collisionBox.minY;
                if (box.maxY <= bottom + MOVEMENT_COLLISION_BACKOFF * 8.0d && box.maxY + desiredOffset > bottom) {
                    double candidate = bottom - box.maxY;
                    resolvedOffset = resolvedOffset == null ? candidate : Math.min(resolvedOffset, candidate);
                }
            }
        }

        if (resolvedOffset == null) {
            return null;
        }

        if (desiredOffset < 0.0d) {
            return Math.max(desiredOffset, resolvedOffset);
        }
        return Math.min(desiredOffset, resolvedOffset);
    }

    private static boolean hasVerticalBlockingContact(
            GeoEntityPart<?> part,
            GeoTrackedBonePose collisionPose,
            AABB box,
            double desiredOffset
    ) {
        List<AABB> collisionBoxes = new ArrayList<>();
        part.appendCollisionBoxes(collisionPose, stretchAlongAxis(box, Direction.Axis.Y, desiredOffset), collisionBoxes);
        for (AABB collisionBox : collisionBoxes) {
            if (!hasSupportFootprint(box, collisionBox)) {
                continue;
            }

            if (desiredOffset > 0.0d && isNearOrPast(box.maxY, collisionBox.minY, MOVEMENT_COLLISION_BACKOFF * 4.0d)) {
                return true;
            }
            if (desiredOffset < 0.0d && isNearOrPast(collisionBox.maxY, box.minY, MOVEMENT_COLLISION_BACKOFF * 4.0d)) {
                return true;
            }
        }
        return false;
    }

    private static boolean hasVerticalBlockingContactAtStart(
            GeoEntityPart<?> part,
            GeoTrackedBonePose collisionPose,
            AABB box,
            double desiredOffset
    ) {
        List<AABB> collisionBoxes = new ArrayList<>();
        part.appendCollisionBoxes(collisionPose, box, collisionBoxes);
        for (AABB collisionBox : collisionBoxes) {
            if (!hasSupportFootprint(box, collisionBox)) {
                continue;
            }
            if (desiredOffset > 0.0d && isNearOrPast(box.maxY, collisionBox.minY, MOVEMENT_COLLISION_BACKOFF * 8.0d)) {
                return true;
            }
            if (desiredOffset < 0.0d && isStandingOnTopFace(box, collisionBox.maxY)) {
                return true;
            }
        }
        return false;
    }

    private static boolean isNearOrPast(double lowerFace, double upperFace, double tolerance) {
        return lowerFace <= upperFace + tolerance;
    }

    private static boolean isStandingOnTopFace(AABB box, double topFaceY) {
        return box.minY >= topFaceY - VERTICAL_SUPPORT_TOLERANCE;
    }

    private static double horizontalOverlap(AABB first, AABB second) {
        return axisOverlap(first, second, Direction.Axis.X) * axisOverlap(first, second, Direction.Axis.Z);
    }

    private static boolean hasSupportFootprint(AABB first, AABB second) {
        double xOverlap = axisOverlap(first, second, Direction.Axis.X);
        double zOverlap = axisOverlap(first, second, Direction.Axis.Z);
        return xOverlap >= MIN_SUPPORT_AXIS_OVERLAP && zOverlap >= MIN_SUPPORT_AXIS_OVERLAP;
    }

    private static boolean wouldSneakOffMultipartLedge(
            CollisionGetter world,
            Entity entity,
            AABB box,
            double offsetX,
            double offsetZ,
            double maxDrop
    ) {
        AABB movedBox = box.move(offsetX, 0.0d, offsetZ);
        if (!isVanillaSpaceEmpty(world, entity, movedBox.move(0.0d, -maxDrop, 0.0d))) {
            return false;
        }

        return !hasMultipartSupportBelow(world, entity, movedBox, maxDrop);
    }

    private static boolean hasMultipartSupportBelow(CollisionGetter world, Entity entity, AABB box, double maxDrop) {
        AABB searchBox = box.move(0.0d, -maxDrop, 0.0d).inflate(GLOBAL_MULTIPART_COLLISION_SEARCH_MARGIN);
        for (GeoMultipartEntity multipart : collectMultipartCandidates(world, entity, searchBox, null)) {
            for (GeoMultipartPartManager.PartSnapshot snapshot : multipart.getMultipartPartManager().getPartSnapshots()) {
                GeoEntityPart<?> part = snapshot.part();
                if (!part.hasCollision()) {
                    continue;
                }

                GeoTrackedBonePose collisionPose = snapshot.pose();
                ArrayList<AABB> collisionBoxes = new ArrayList<>();
                part.appendCollisionBoxes(collisionPose, searchBox, collisionBoxes);
                for (AABB collisionBox : collisionBoxes) {
                    double top = collisionBox.maxY;
                    if (top > box.minY + MOVEMENT_COLLISION_BACKOFF * 8.0d) {
                        continue;
                    }
                    if (top < box.minY - maxDrop - MOVEMENT_COLLISION_BACKOFF * 8.0d) {
                        continue;
                    }
                    if (hasSupportFootprint(box, collisionBox)) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    private static boolean doesNotWorsenCollision(
            GeoEntityPart<?> part,
            GeoTrackedBonePose collisionPose,
            AABB box,
            Direction.Axis axis,
            double desiredOffset
    ) {
        Vec3 startCenter = box.getCenter();
        Vec3 movedCenter = switch (axis) {
            case X -> startCenter.add(desiredOffset, 0.0d, 0.0d);
            case Y -> startCenter.add(0.0d, desiredOffset, 0.0d);
            case Z -> startCenter.add(0.0d, 0.0d, desiredOffset);
        };
        double halfExtentX = (box.maxX - box.minX) * 0.5d;
        double halfExtentY = (box.maxY - box.minY) * 0.5d;
        double halfExtentZ = (box.maxZ - box.minZ) * 0.5d;

        double startOverlap = GeoMultipartHitboxMath.facePenetrationDepthAabbAndOrientedBox(
                collisionPose,
                part.getBoxWidth(),
                part.getBoxHeight(),
                part.getBoxDepth(),
                startCenter,
                halfExtentX,
                halfExtentY,
                halfExtentZ
        );
        double endOverlap = GeoMultipartHitboxMath.facePenetrationDepthAabbAndOrientedBox(
                collisionPose,
                part.getBoxWidth(),
                part.getBoxHeight(),
                part.getBoxDepth(),
                movedCenter,
                halfExtentX,
                halfExtentY,
                halfExtentZ
        );

        return endOverlap <= startOverlap + 1.0E-7d;
    }

    private static double axisOverlap(AABB first, AABB second, Direction.Axis axis) {
        double min = Math.max(axisMin(first, axis), axisMin(second, axis));
        double max = Math.min(axisMax(first, axis), axisMax(second, axis));
        return Math.max(0.0d, max - min);
    }

    private static double axisMin(AABB box, Direction.Axis axis) {
        return switch (axis) {
            case X -> box.minX;
            case Y -> box.minY;
            case Z -> box.minZ;
        };
    }

    private static double axisMax(AABB box, Direction.Axis axis) {
        return switch (axis) {
            case X -> box.maxX;
            case Y -> box.maxY;
            case Z -> box.maxZ;
        };
    }

    private static boolean intersectsPartWithBox(GeoEntityPart<?> part, GeoTrackedBonePose collisionPose, AABB box) {
        Vec3 center = box.getCenter();
        return part.intersectsAabb(
                collisionPose,
                center,
                (box.maxX - box.minX) * 0.5d,
                (box.maxY - box.minY) * 0.5d,
                (box.maxZ - box.minZ) * 0.5d
        );
    }

    private static AABB stretchAlongAxis(AABB box, Direction.Axis axis, double offset) {
        return switch (axis) {
            case X -> box.expandTowards(offset, 0.0d, 0.0d);
            case Y -> box.expandTowards(0.0d, offset, 0.0d);
            case Z -> box.expandTowards(0.0d, 0.0d, offset);
        };
    }

    private static Vec3 offsetAlongAxis(Vec3 value, Direction.Axis axis, double offset) {
        return switch (axis) {
            case X -> value.add(offset, 0.0d, 0.0d);
            case Y -> value.add(0.0d, offset, 0.0d);
            case Z -> value.add(0.0d, 0.0d, offset);
        };
    }

    private static double axisValue(Vec3 value, Direction.Axis axis) {
        return switch (axis) {
            case X -> value.x;
            case Y -> value.y;
            case Z -> value.z;
        };
    }

    private static AABB createPathBox(Vec3 from, Vec3 to, double expandX, double expandY, double expandZ) {
        return new AABB(
                Math.min(from.x, to.x),
                Math.min(from.y, to.y),
                Math.min(from.z, to.z),
                Math.max(from.x, to.x),
                Math.max(from.y, to.y),
                Math.max(from.z, to.z)
        ).inflate(expandX, expandY, expandZ);
    }

    private static double trimSneakMovement(double value) {
        if (value > 0.0d) {
            return Math.max(0.0d, value - SNEAK_CLIP_STEP);
        }
        return Math.min(0.0d, value + SNEAK_CLIP_STEP);
    }

    private record WorldMultipartSnapshot(long gameTime, List<GeoMultipartEntity> sourceSnapshot, List<GeoMultipartEntity> entities) {
        private boolean matches(long gameTime, List<GeoMultipartEntity> sourceSnapshot) {
            return this.gameTime == gameTime && this.sourceSnapshot == sourceSnapshot;
        }
    }
}
