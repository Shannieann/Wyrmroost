package dev.elifian.chaoslib.multipart.interaction;

import dev.elifian.chaoslib.api.multipart.GeoTrackedBonePose;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.Optional;

public final class GeoMultipartHitboxMath {
    private static final double SAT_EPSILON = 1.0E-6d;

    private GeoMultipartHitboxMath() {
    }

    public static Optional<Vec3> raycast(GeoTrackedBonePose pose, double width, double height, double depth, Vec3 from, Vec3 to) {
        Quaternionf inverseRotation = new Quaternionf(pose.rotation()).conjugate();
        Vec3 center = pose.position();
        Vec3 localFrom = toLocalSpace(from.subtract(center), inverseRotation);
        Vec3 localTo = toLocalSpace(to.subtract(center), inverseRotation);
        Optional<Vec3> localHit = new AABB(
                -width * 0.5d,
                -height * 0.5d,
                -depth * 0.5d,
                width * 0.5d,
                height * 0.5d,
                depth * 0.5d
        ).clip(localFrom, localTo);
        if (localHit.isEmpty()) {
            return Optional.empty();
        }

        Vector3f localHitVector = new Vector3f((float) localHit.get().x, (float) localHit.get().y, (float) localHit.get().z);
        pose.rotation().transform(localHitVector);
        return Optional.of(center.add(localHitVector.x, localHitVector.y, localHitVector.z));
    }

    public static boolean containsPoint(GeoTrackedBonePose pose, double width, double height, double depth, Vec3 point) {
        Quaternionf inverseRotation = new Quaternionf(pose.rotation()).conjugate();
        Vec3 localPoint = toLocalSpace(point.subtract(pose.position()), inverseRotation);
        double halfWidth = width * 0.5d;
        double halfHeight = height * 0.5d;
        double halfDepth = depth * 0.5d;
        return localPoint.x >= -halfWidth && localPoint.x <= halfWidth
                && localPoint.y >= -halfHeight && localPoint.y <= halfHeight
                && localPoint.z >= -halfDepth && localPoint.z <= halfDepth;
    }

    public static Optional<Vec3> sweepAabbAgainstOrientedBox(
            GeoTrackedBonePose pose,
            double width,
            double height,
            double depth,
            Vec3 from,
            Vec3 to,
            double halfExtentX,
            double halfExtentY,
            double halfExtentZ
    ) {
        if (intersectsAabbAndOrientedBoxInternal(pose, width, height, depth, from, halfExtentX, halfExtentY, halfExtentZ)) {
            return Optional.of(from);
        }

        double distance = from.distanceTo(to);
        double minHalfExtent = Math.min(halfExtentX, Math.min(halfExtentY, halfExtentZ));
        double stepSize = Math.max(0.03125d, Math.min(0.25d, minHalfExtent));
        int steps = Math.max(1, Math.min(48, (int) Math.ceil(distance / stepSize)));
        Vec3 previousSample = from;

        for (int step = 1; step <= steps; step++) {
            double progress = (double) step / steps;
            Vec3 sample = from.lerp(to, progress);
            if (intersectsAabbAndOrientedBoxInternal(pose, width, height, depth, sample, halfExtentX, halfExtentY, halfExtentZ)) {
                return Optional.of(refineSweepHit(
                        pose,
                        width,
                        height,
                        depth,
                        previousSample,
                        sample,
                        halfExtentX,
                        halfExtentY,
                        halfExtentZ
                ));
            }
            previousSample = sample;
        }

        return Optional.empty();
    }

    public static boolean intersectsAabbAndOrientedBox(
            GeoTrackedBonePose pose,
            double width,
            double height,
            double depth,
            Vec3 aabbCenter,
            double halfExtentX,
            double halfExtentY,
            double halfExtentZ
    ) {
        return intersectsAabbAndOrientedBoxInternal(pose, width, height, depth, aabbCenter, halfExtentX, halfExtentY, halfExtentZ);
    }

    public static double facePenetrationDepthAabbAndOrientedBox(
            GeoTrackedBonePose pose,
            double width,
            double height,
            double depth,
            Vec3 aabbCenter,
            double halfExtentX,
            double halfExtentY,
            double halfExtentZ
    ) {
        Quaternionf rotation = pose.rotation();
        Quaternionf inverseRotation = new Quaternionf(rotation).conjugate();
        Vec3 localCenter = toLocalSpace(aabbCenter.subtract(pose.position()), inverseRotation);
        Vec3 axisX = transformAxis(rotation, 1.0f, 0.0f, 0.0f);
        Vec3 axisY = transformAxis(rotation, 0.0f, 1.0f, 0.0f);
        Vec3 axisZ = transformAxis(rotation, 0.0f, 0.0f, 1.0f);

        double localHalfX = Math.abs(axisX.x) * halfExtentX + Math.abs(axisX.y) * halfExtentY + Math.abs(axisX.z) * halfExtentZ;
        double localHalfY = Math.abs(axisY.x) * halfExtentX + Math.abs(axisY.y) * halfExtentY + Math.abs(axisY.z) * halfExtentZ;
        double localHalfZ = Math.abs(axisZ.x) * halfExtentX + Math.abs(axisZ.y) * halfExtentY + Math.abs(axisZ.z) * halfExtentZ;

        double overlapX = width * 0.5d + localHalfX - Math.abs(localCenter.x);
        double overlapY = height * 0.5d + localHalfY - Math.abs(localCenter.y);
        double overlapZ = depth * 0.5d + localHalfZ - Math.abs(localCenter.z);
        if (overlapX < 0.0d || overlapY < 0.0d || overlapZ < 0.0d) {
            return 0.0d;
        }

        return Math.min(overlapX, Math.min(overlapY, overlapZ));
    }

    private static Vec3 refineSweepHit(
            GeoTrackedBonePose pose,
            double width,
            double height,
            double depth,
            Vec3 safeFrom,
            Vec3 collidingTo,
            double halfExtentX,
            double halfExtentY,
            double halfExtentZ
    ) {
        Vec3 low = safeFrom;
        Vec3 high = collidingTo;
        for (int iteration = 0; iteration < 8; iteration++) {
            Vec3 mid = low.lerp(high, 0.5d);
            if (intersectsAabbAndOrientedBoxInternal(pose, width, height, depth, mid, halfExtentX, halfExtentY, halfExtentZ)) {
                high = mid;
            } else {
                low = mid;
            }
        }
        return high;
    }

    private static Vec3 toLocalSpace(Vec3 worldOffset, Quaternionf inverseRotation) {
        Vector3f rotated = inverseRotation.transform(new Vector3f((float) worldOffset.x, (float) worldOffset.y, (float) worldOffset.z));
        return new Vec3(rotated.x, rotated.y, rotated.z);
    }

    private static boolean intersectsAabbAndOrientedBoxInternal(
            GeoTrackedBonePose pose,
            double width,
            double height,
            double depth,
            Vec3 aabbCenter,
            double halfExtentX,
            double halfExtentY,
            double halfExtentZ
    ) {
        Vec3 obbCenter = pose.position();
        Quaternionf rotation = pose.rotation();
        Vec3[] axes = {
                transformAxis(rotation, 1.0f, 0.0f, 0.0f),
                transformAxis(rotation, 0.0f, 1.0f, 0.0f),
                transformAxis(rotation, 0.0f, 0.0f, 1.0f)
        };
        double[] a = {halfExtentX, halfExtentY, halfExtentZ};
        double[] b = {width * 0.5d, height * 0.5d, depth * 0.5d};
        double[][] r = new double[3][3];
        double[][] absR = new double[3][3];

        for (int j = 0; j < 3; j++) {
            r[0][j] = axes[j].x;
            r[1][j] = axes[j].y;
            r[2][j] = axes[j].z;
            absR[0][j] = Math.abs(r[0][j]) + SAT_EPSILON;
            absR[1][j] = Math.abs(r[1][j]) + SAT_EPSILON;
            absR[2][j] = Math.abs(r[2][j]) + SAT_EPSILON;
        }

        double[] t = {
                obbCenter.x - aabbCenter.x,
                obbCenter.y - aabbCenter.y,
                obbCenter.z - aabbCenter.z
        };

        for (int i = 0; i < 3; i++) {
            double radius = b[0] * absR[i][0] + b[1] * absR[i][1] + b[2] * absR[i][2];
            if (Math.abs(t[i]) > a[i] + radius) {
                return false;
            }
        }

        for (int j = 0; j < 3; j++) {
            double projection = Math.abs(t[0] * r[0][j] + t[1] * r[1][j] + t[2] * r[2][j]);
            double radius = a[0] * absR[0][j] + a[1] * absR[1][j] + a[2] * absR[2][j];
            if (projection > b[j] + radius) {
                return false;
            }
        }

        for (int i = 0; i < 3; i++) {
            int i1 = (i + 1) % 3;
            int i2 = (i + 2) % 3;
            for (int j = 0; j < 3; j++) {
                int j1 = (j + 1) % 3;
                int j2 = (j + 2) % 3;
                double projection = Math.abs(t[i2] * r[i1][j] - t[i1] * r[i2][j]);
                double radiusA = a[i1] * absR[i2][j] + a[i2] * absR[i1][j];
                double radiusB = b[j1] * absR[i][j2] + b[j2] * absR[i][j1];
                if (projection > radiusA + radiusB) {
                    return false;
                }
            }
        }

        return true;
    }

    private static Vec3 transformAxis(Quaternionf rotation, float x, float y, float z) {
        Vector3f vector = rotation.transform(new Vector3f(x, y, z));
        return new Vec3(vector.x, vector.y, vector.z);
    }
}
