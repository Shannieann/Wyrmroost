package dev.elifian.chaoslib.multipart.interaction;

import dev.elifian.chaoslib.api.multipart.GeoMultipartEntity;
import dev.elifian.chaoslib.api.multipart.GeoEntityPart;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.projectile.Projectile;

import java.util.Collections;
import java.util.Map;
import java.util.Optional;
import java.util.WeakHashMap;

public final class GeoMultipartProjectileHitHintStore {
    private static final long HINT_LIFETIME_TICKS = 2L;
    private static final Map<Projectile, Hint> HINTS = Collections.synchronizedMap(new WeakHashMap<>());

    private GeoMultipartProjectileHitHintStore() {
    }

    public static void put(Projectile projectile, Entity owner, String trackedBoneName, long worldTime) {
        HINTS.put(projectile, new Hint(owner.getId(), trackedBoneName, worldTime + HINT_LIFETIME_TICKS));
    }

    public static Optional<GeoEntityPart<?>> take(Projectile projectile, GeoMultipartEntity owner, long worldTime) {
        Hint hint = HINTS.remove(projectile);
        if (hint == null || worldTime > hint.expiresAtTick) {
            return Optional.empty();
        }

        if (!(((Object) owner) instanceof Entity entity) || entity.getId() != hint.entityId) {
            return Optional.empty();
        }

        return owner.getMultipartPartManager().getPart(hint.trackedBoneName).map(part -> (GeoEntityPart<?>) part);
    }

    private record Hint(int entityId, String trackedBoneName, long expiresAtTick) {
    }
}
