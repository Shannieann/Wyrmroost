package dev.elifian.chaoslib.multipart.interaction;

import dev.elifian.chaoslib.api.multipart.GeoMultipartEntity;
import dev.elifian.chaoslib.api.multipart.GeoEntityPart;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;

import java.util.Optional;

public final class GeoMultipartDamageDispatcher {
    private static final ThreadLocal<Boolean> REENTRANT = ThreadLocal.withInitial(() -> false);

    private GeoMultipartDamageDispatcher() {
    }

    public static boolean isReentrant() {
        return REENTRANT.get();
    }

    public static <T extends LivingEntity & GeoMultipartEntity> Optional<Boolean> dispatch(T owner, DamageSource source, float amount) {
        if (isReentrant()) {
            return Optional.empty();
        }

        Optional<GeoEntityPart<T>> part = resolveHitPart(owner, source);
        if (part.isEmpty()) {
            return Optional.empty();
        }
        if (!canApplyMultipartDamage(owner, source)) {
            return Optional.of(false);
        }

        REENTRANT.set(true);
        try {
            return Optional.of(part.get().damage(source, amount));
        } finally {
            REENTRANT.set(false);
        }
    }

    @SuppressWarnings("unchecked")
    private static <T extends LivingEntity & GeoMultipartEntity> Optional<GeoEntityPart<T>> resolveHitPart(T owner, DamageSource source) {
        Entity directSource = source.getDirectEntity();
        if (directSource instanceof Projectile projectile) {
            Optional<GeoEntityPart<?>> hintedPart = GeoMultipartProjectileHitHintStore.take(projectile, owner, projectile.level().getGameTime());
            if (hintedPart.isPresent()) {
                return hintedPart.map(part -> (GeoEntityPart<T>) part);
            }

            Vec3 from = projectile.xo == projectile.getX() && projectile.yo == projectile.getY() && projectile.zo == projectile.getZ()
                    ? projectile.position().subtract(projectile.getDeltaMovement())
                    : new Vec3(projectile.xo, projectile.yo, projectile.zo);
            return GeoMultipartServerHitHelper.findOwnerCollisionHit(owner, from, projectile.position())
                    .map(hit -> (GeoEntityPart<T>) hit.part());
        }

        Entity attacker = source.getEntity();
        if (attacker instanceof ServerPlayer serverPlayer) {
            Optional<GeoEntityPart<?>> hintedPart = GeoMultipartMeleeHitHintStore.take(serverPlayer, owner, serverPlayer.level().getGameTime());
            if (hintedPart.isPresent()) {
                return hintedPart.map(part -> (GeoEntityPart<T>) part);
            }
        }

        if (attacker instanceof LivingEntity livingAttacker) {
            double range = attacker instanceof Player ? 6.0d : 4.0d;
            Vec3 from = livingAttacker.getEyePosition();
            Vec3 to = from.add(livingAttacker.getViewVector(1.0f).scale(range));
            return GeoMultipartServerHitHelper.findOwnerCollisionHit(owner, from, to)
                    .map(hit -> (GeoEntityPart<T>) hit.part());
        }

        return Optional.empty();
    }

    private static <T extends LivingEntity & GeoMultipartEntity> boolean canApplyMultipartDamage(T owner, DamageSource source) {
        if (!(source.getEntity() instanceof Player playerAttacker)) {
            return true;
        }

        float required = owner.getMultipartMinAttackStrength();
        return required <= 0.0f || GeoMultipartAttackStrength.resolve(playerAttacker) >= required;
    }
}
