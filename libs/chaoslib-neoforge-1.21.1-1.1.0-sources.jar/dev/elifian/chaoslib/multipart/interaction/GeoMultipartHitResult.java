package dev.elifian.chaoslib.multipart.interaction;

import dev.elifian.chaoslib.api.multipart.GeoEntityPart;
import net.minecraft.world.phys.Vec3;

public record GeoMultipartHitResult(GeoEntityPart<?> part, Vec3 hitPos, double distanceSquared) {
}
