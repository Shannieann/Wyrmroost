package dev.elifian.chaoslib.molang;

import org.jetbrains.annotations.Nullable;

import java.util.List;

public interface MolangQueryProvider {
    default @Nullable MolangRuntime.MolangValue getQueryValue(String normalizedPath) {
        return null;
    }

    default @Nullable MolangRuntime.MolangValue callQuery(String normalizedName, List<MolangRuntime.MolangValue> args) {
        return null;
    }
}
