package dev.elifian.chaoslib.molang;

import org.jetbrains.annotations.Nullable;

import java.util.List;

final class MolangStandardQueries {
    private MolangStandardQueries() {
    }

    static @Nullable MolangRuntime.MolangValue resolveCall(String name, List<MolangRuntime.MolangValue> args) {
        return switch (name) {
            case MolangQueryNames.ALL -> compareAll(args);
            case MolangQueryNames.ANY -> compareAny(args);
            case MolangQueryNames.APPROX_EQ -> approxEq(args);
            case MolangQueryNames.COUNT -> MolangRuntime.MolangValue.number(count(args));
            case MolangQueryNames.IN_RANGE -> inRange(args);
            case MolangQueryNames.LOG -> logValue(args);
            case MolangQueryNames.NOISE -> noise(args);
            default -> null;
        };
    }

    private static MolangRuntime.MolangValue compareAll(List<MolangRuntime.MolangValue> args) {
        if (args.isEmpty()) {
            return MolangRuntime.MolangValue.FALSE;
        }
        MolangRuntime.MolangValue first = args.get(0);
        for (int i = 1; i < args.size(); i++) {
            if (!equalsValue(first, args.get(i))) {
                return MolangRuntime.MolangValue.FALSE;
            }
        }
        return MolangRuntime.MolangValue.TRUE;
    }

    private static MolangRuntime.MolangValue compareAny(List<MolangRuntime.MolangValue> args) {
        if (args.size() < 2) {
            return MolangRuntime.MolangValue.FALSE;
        }
        MolangRuntime.MolangValue first = args.get(0);
        for (int i = 1; i < args.size(); i++) {
            if (equalsValue(first, args.get(i))) {
                return MolangRuntime.MolangValue.TRUE;
            }
        }
        return MolangRuntime.MolangValue.FALSE;
    }

    private static MolangRuntime.MolangValue approxEq(List<MolangRuntime.MolangValue> args) {
        if (args.size() < 2) {
            return MolangRuntime.MolangValue.FALSE;
        }
        double min = args.get(0).asNumber();
        double max = min;
        for (int i = 1; i < args.size(); i++) {
            double value = args.get(i).asNumber();
            min = Math.min(min, value);
            max = Math.max(max, value);
        }
        double epsilon = Math.max(Math.ulp(min), Math.ulp(max));
        return max - min <= epsilon ? MolangRuntime.MolangValue.TRUE : MolangRuntime.MolangValue.FALSE;
    }

    private static MolangRuntime.MolangValue inRange(List<MolangRuntime.MolangValue> args) {
        double value = args.size() > 0 ? args.get(0).asNumber() : 0.0d;
        double min = args.size() > 1 ? args.get(1).asNumber() : 0.0d;
        double max = args.size() > 2 ? args.get(2).asNumber() : 0.0d;
        return value >= min && value <= max ? MolangRuntime.MolangValue.TRUE : MolangRuntime.MolangValue.FALSE;
    }

    private static MolangRuntime.MolangValue logValue(List<MolangRuntime.MolangValue> args) {
        MolangRuntime.MolangValue value = args.isEmpty() ? MolangRuntime.MolangValue.NULL : args.get(0);
        return value;
    }

    private static MolangRuntime.MolangValue noise(List<MolangRuntime.MolangValue> args) {
        double x = args.size() > 0 ? args.get(0).asNumber() : 0.0d;
        double y = args.size() > 1 ? args.get(1).asNumber() : 0.0d;
        double z = args.size() > 2 ? args.get(2).asNumber() : 0.0d;
        return MolangRuntime.MolangValue.number(sampleNoise(x, y, z));
    }

    private static double count(List<MolangRuntime.MolangValue> args) {
        int count = 0;
        for (MolangRuntime.MolangValue value : args) {
            count += value.type() == MolangRuntime.MolangValue.Type.ARRAY ? value.asArray().size() : 1;
        }
        return count;
    }

    private static boolean equalsValue(MolangRuntime.MolangValue left, MolangRuntime.MolangValue right) {
        if (left.type() == MolangRuntime.MolangValue.Type.STRING || right.type() == MolangRuntime.MolangValue.Type.STRING) {
            return left.asString().equals(right.asString());
        }
        return Double.compare(left.asNumber(), right.asNumber()) == 0;
    }

    private static double sampleNoise(double x, double y, double z) {
        int x0 = fastFloor(x);
        int y0 = fastFloor(y);
        int z0 = fastFloor(z);
        int x1 = x0 + 1;
        int y1 = y0 + 1;
        int z1 = z0 + 1;

        double xf = x - x0;
        double yf = y - y0;
        double zf = z - z0;

        double u = fade(xf);
        double v = fade(yf);
        double w = fade(zf);

        double n000 = grad(hash(x0, y0, z0), xf, yf, zf);
        double n100 = grad(hash(x1, y0, z0), xf - 1.0d, yf, zf);
        double n010 = grad(hash(x0, y1, z0), xf, yf - 1.0d, zf);
        double n110 = grad(hash(x1, y1, z0), xf - 1.0d, yf - 1.0d, zf);
        double n001 = grad(hash(x0, y0, z1), xf, yf, zf - 1.0d);
        double n101 = grad(hash(x1, y0, z1), xf - 1.0d, yf, zf - 1.0d);
        double n011 = grad(hash(x0, y1, z1), xf, yf - 1.0d, zf - 1.0d);
        double n111 = grad(hash(x1, y1, z1), xf - 1.0d, yf - 1.0d, zf - 1.0d);

        double nx00 = lerp(n000, n100, u);
        double nx10 = lerp(n010, n110, u);
        double nx01 = lerp(n001, n101, u);
        double nx11 = lerp(n011, n111, u);
        double nxy0 = lerp(nx00, nx10, v);
        double nxy1 = lerp(nx01, nx11, v);
        return lerp(nxy0, nxy1, w);
    }

    private static int fastFloor(double value) {
        int integer = (int) value;
        return value < integer ? integer - 1 : integer;
    }

    private static double fade(double value) {
        return value * value * value * (value * (value * 6.0d - 15.0d) + 10.0d);
    }

    private static double lerp(double from, double to, double alpha) {
        return from + (to - from) * alpha;
    }

    private static int hash(int x, int y, int z) {
        int hash = x * 374761393 + y * 668265263 + z * 2147483647;
        hash = (hash ^ (hash >>> 13)) * 1274126177;
        return hash ^ (hash >>> 16);
    }

    private static double grad(int hash, double x, double y, double z) {
        return switch (hash & 15) {
            case 0 -> x + y;
            case 1 -> -x + y;
            case 2 -> x - y;
            case 3 -> -x - y;
            case 4 -> x + z;
            case 5 -> -x + z;
            case 6 -> x - z;
            case 7 -> -x - z;
            case 8 -> y + z;
            case 9 -> -y + z;
            case 10 -> y - z;
            case 11 -> -y - z;
            case 12 -> x + y;
            case 13 -> -x + y;
            case 14 -> y - z;
            default -> -y - z;
        };
    }
}
