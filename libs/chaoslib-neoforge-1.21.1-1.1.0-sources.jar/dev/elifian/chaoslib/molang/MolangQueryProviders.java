package dev.elifian.chaoslib.molang;

import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.Supplier;

public final class MolangQueryProviders {
    private MolangQueryProviders() {
    }

    public static MolangQueryProvider animationTiming(
            Supplier<MolangRuntime.MolangValue> animTimeSupplier,
            Supplier<MolangRuntime.MolangValue> lifeTimeSupplier,
            Supplier<MolangRuntime.MolangValue> deltaTimeSupplier,
            @Nullable Supplier<MolangRuntime.MolangValue> keyFrameLerpSupplier
    ) {
        return new MolangQueryProvider() {
            @Override
            public @Nullable MolangRuntime.MolangValue getQueryValue(String normalizedPath) {
                return switch (normalizedPath) {
                    case MolangQueryNames.ANIM_TIME -> safe(animTimeSupplier);
                    case MolangQueryNames.LIFE_TIME -> safe(lifeTimeSupplier);
                    case MolangQueryNames.DELTA_TIME -> safe(deltaTimeSupplier);
                    case MolangQueryNames.KEY_FRAME_LERP_TIME -> keyFrameLerpSupplier == null ? null : safe(keyFrameLerpSupplier);
                    default -> null;
                };
            }
        };
    }

    public static MolangQueryProvider composite(MolangQueryProvider... providers) {
        return new MolangQueryProvider() {
            @Override
            public @Nullable MolangRuntime.MolangValue getQueryValue(String normalizedPath) {
                for (MolangQueryProvider provider : providers) {
                    if (provider == null) {
                        continue;
                    }
                    MolangRuntime.MolangValue value = provider.getQueryValue(normalizedPath);
                    if (value != null) {
                        return value;
                    }
                }
                return null;
            }

            @Override
            public @Nullable MolangRuntime.MolangValue callQuery(String normalizedName, List<MolangRuntime.MolangValue> args) {
                for (MolangQueryProvider provider : providers) {
                    if (provider == null) {
                        continue;
                    }
                    MolangRuntime.MolangValue value = provider.callQuery(normalizedName, args);
                    if (value != null) {
                        return value;
                    }
                }
                return null;
            }
        };
    }

    private static MolangRuntime.MolangValue safe(Supplier<MolangRuntime.MolangValue> supplier) {
        MolangRuntime.MolangValue value = supplier == null ? null : supplier.get();
        return value == null ? MolangRuntime.MolangValue.NULL : value;
    }
}
