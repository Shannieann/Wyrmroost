package dev.elifian.chaoslib.molang;

import java.util.List;

final class MolangBuiltins {
    private MolangBuiltins() {
    }

    static MolangRuntime.MolangValue call(String name, List<MolangRuntime.MolangValue> args) {
        double value = switch (name) {
            case "math.abs" -> Math.abs(arg(args, 0));
            case "math.acos" -> Math.toDegrees(Math.acos(arg(args, 0)));
            case "math.asin" -> Math.toDegrees(Math.asin(arg(args, 0)));
            case "math.atan" -> Math.toDegrees(Math.atan(arg(args, 0)));
            case "math.atan2" -> Math.toDegrees(Math.atan2(arg(args, 0), arg(args, 1)));
            case "math.ceil" -> Math.ceil(arg(args, 0));
            case "math.clamp" -> Math.max(arg(args, 1), Math.min(arg(args, 2), arg(args, 0)));
            case "math.cos" -> Math.cos(Math.toRadians(arg(args, 0)));
            case "math.die_roll", "math.die_roll_integer" -> dieRoll(args, name.endsWith("integer"));
            case "math.exp" -> Math.exp(arg(args, 0));
            case "math.floor" -> Math.floor(arg(args, 0));
            case "math.hermite_blend" -> {
                double t = arg(args, 0);
                yield t * t * (3.0d - 2.0d * t);
            }
            case "math.lerp" -> arg(args, 0) + (arg(args, 1) - arg(args, 0)) * arg(args, 2);
            case "math.lerprotate" -> lerpRotate(arg(args, 0), arg(args, 1), arg(args, 2));
            case "math.ln" -> Math.log(arg(args, 0));
            case "math.max" -> max(args);
            case "math.min" -> min(args);
            case "math.min_angle" -> minAngleDelta(arg(args, 0), arg(args, 1));
            case "math.mod" -> safeMod(arg(args, 0), arg(args, 1));
            case "math.pow" -> Math.pow(arg(args, 0), arg(args, 1));
            case "math.random", "math.random_integer" -> random(args, name.endsWith("integer"));
            case "math.round" -> Math.round(arg(args, 0));
            case "math.sign" -> Math.signum(arg(args, 0));
            case "math.sin" -> Math.sin(Math.toRadians(arg(args, 0)));
            case "math.sqrt" -> Math.sqrt(Math.max(0.0d, arg(args, 0)));
            case "math.tan" -> Math.tan(Math.toRadians(arg(args, 0)));
            case "math.to_deg" -> Math.toDegrees(arg(args, 0));
            case "math.to_rad" -> Math.toRadians(arg(args, 0));
            case "math.trunc" -> arg(args, 0) < 0.0d ? Math.ceil(arg(args, 0)) : Math.floor(arg(args, 0));
            default -> Double.NaN;
        };

        return Double.isNaN(value) ? MolangRuntime.MolangValue.NULL : MolangRuntime.MolangValue.number(value);
    }

    private static double arg(List<MolangRuntime.MolangValue> args, int index) {
        return index < args.size() ? args.get(index).asNumber() : 0.0d;
    }

    private static double min(List<MolangRuntime.MolangValue> args) {
        if (args.isEmpty()) {
            return 0.0d;
        }
        double value = args.get(0).asNumber();
        for (int i = 1; i < args.size(); i++) {
            value = Math.min(value, args.get(i).asNumber());
        }
        return value;
    }

    private static double max(List<MolangRuntime.MolangValue> args) {
        if (args.isEmpty()) {
            return 0.0d;
        }
        double value = args.get(0).asNumber();
        for (int i = 1; i < args.size(); i++) {
            value = Math.max(value, args.get(i).asNumber());
        }
        return value;
    }

    private static double safeMod(double left, double right) {
        if (right == 0.0d) {
            return 0.0d;
        }
        return left - right * Math.floor(left / right);
    }

    private static double lerpRotate(double from, double to, double alpha) {
        return from + minAngleDelta(from, to) * alpha;
    }

    private static double minAngleDelta(double from, double to) {
        return safeMod(to - from + 180.0d, 360.0d) - 180.0d;
    }

    private static double random(List<MolangRuntime.MolangValue> args, boolean integer) {
        double min = args.size() > 0 ? args.get(0).asNumber() : 0.0d;
        double max = args.size() > 1 ? args.get(1).asNumber() : 1.0d;
        double value = min + Math.random() * (max - min);
        return integer ? Math.floor(value) : value;
    }

    private static double dieRoll(List<MolangRuntime.MolangValue> args, boolean integer) {
        int rolls = (int) Math.max(0.0d, arg(args, 0));
        double min = arg(args, 1);
        double max = arg(args, 2);
        double result = 0.0d;
        for (int i = 0; i < rolls; i++) {
            double value = min + Math.random() * (max - min);
            result += integer ? Math.floor(value) : value;
        }
        return result;
    }
}
