package dev.elifian.chaoslib.molang;

import org.jetbrains.annotations.Nullable;

import java.util.List;

public final class MolangQueryResolvers {
    private static final MolangQueryResolver EMPTY = new MolangQueryResolver() {
        @Override
        public @Nullable MolangRuntime.MolangValue resolveValue(String normalizedPath, MolangRuntime.Context context) {
            if (context instanceof MolangQueryProvider provider) {
                return provider.getQueryValue(normalizedPath);
            }
            return null;
        }

        @Override
        public @Nullable MolangRuntime.MolangValue resolveCall(String normalizedName, List<MolangRuntime.MolangValue> args, MolangRuntime.Context context) {
            if (context instanceof MolangQueryProvider provider) {
                return provider.callQuery(normalizedName, args);
            }
            return null;
        }
    };

    private static final MolangQueryResolver STANDARD = new MolangQueryResolver() {
        @Override
        public @Nullable MolangRuntime.MolangValue resolveValue(String normalizedPath, MolangRuntime.Context context) {
            return EMPTY.resolveValue(normalizedPath, context);
        }

        @Override
        public @Nullable MolangRuntime.MolangValue resolveCall(String normalizedName, List<MolangRuntime.MolangValue> args, MolangRuntime.Context context) {
            MolangRuntime.MolangValue builtin = MolangStandardQueries.resolveCall(normalizedName, args);
            if (builtin != null) {
                return builtin;
            }
            return EMPTY.resolveCall(normalizedName, args, context);
        }
    };

    private MolangQueryResolvers() {
    }

    public static MolangQueryResolver empty() {
        return EMPTY;
    }

    public static MolangQueryResolver standard() {
        return STANDARD;
    }
}
