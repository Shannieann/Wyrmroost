package dev.elifian.chaoslib.molang.query.bone;

import dev.elifian.chaoslib.cache.object.GeoBone;
import dev.elifian.chaoslib.cache.object.GeoCube;
import dev.elifian.chaoslib.cache.object.GeoLocator;
import dev.elifian.chaoslib.molang.MolangQueryNames;
import dev.elifian.chaoslib.molang.MolangQueryProvider;
import dev.elifian.chaoslib.molang.MolangRuntime;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.joml.Vector4f;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

public final class MolangBoneQueryProvider implements MolangQueryProvider {
    private final @Nullable GeoBone currentBone;
    private final Function<String, Optional<GeoBone>> boneResolver;

    public MolangBoneQueryProvider(@Nullable GeoBone currentBone, Function<String, Optional<GeoBone>> boneResolver) {
        this.currentBone = currentBone;
        this.boneResolver = boneResolver;
    }

    @Override
    public @Nullable MolangRuntime.MolangValue getQueryValue(String normalizedPath) {
        if (this.currentBone == null) {
            return null;
        }

        return switch (normalizedPath) {
            case MolangQueryNames.BONE_ORIGIN -> vec(this.currentBone.getPivotX(), this.currentBone.getPivotY(), this.currentBone.getPivotZ());
            case MolangQueryNames.BONE_ROTATION -> vec(this.currentBone.getRotX(), this.currentBone.getRotY(), this.currentBone.getRotZ());
            case MolangQueryNames.BONE_ORIENTATION_MATRIX -> matrixValue(this.currentBone);
            case MolangQueryNames.BONE_ORIENTATION_TRS -> trsValue(this.currentBone);
            case MolangQueryNames.BONE_AABB -> boneAabb(this.currentBone);
            default -> null;
        };
    }

    @Override
    public @Nullable MolangRuntime.MolangValue callQuery(String normalizedName, List<MolangRuntime.MolangValue> args) {
        if (this.currentBone == null) {
            return null;
        }

        return switch (normalizedName) {
            case MolangQueryNames.GET_DEFAULT_BONE_PIVOT -> defaultBonePivot(args);
            case MolangQueryNames.GET_LOCATOR_OFFSET -> locatorOffset(args, false);
            case MolangQueryNames.GET_ROOT_LOCATOR_OFFSET -> locatorOffset(args, true);
            default -> null;
        };
    }

    private MolangRuntime.MolangValue defaultBonePivot(List<MolangRuntime.MolangValue> args) {
        GeoBone bone = resolveBoneArg(args).orElse(this.currentBone);
        return vec(bone.getInitialPivotX(), bone.getInitialPivotY(), bone.getInitialPivotZ());
    }

    private MolangRuntime.MolangValue locatorOffset(List<MolangRuntime.MolangValue> args, boolean rootLocator) {
        if (args.isEmpty()) {
            return MolangRuntime.MolangValue.NULL;
        }

        String locatorName = args.get(0).asString();
        GeoBone targetBone = rootLocator ? rootBone(this.currentBone) : this.currentBone;
        Optional<GeoLocator> locator = targetBone.getLocator(locatorName);
        return locator.map(value -> vec(value.getOffsetX(), value.getOffsetY(), value.getOffsetZ()))
                .orElse(MolangRuntime.MolangValue.NULL);
    }

    private Optional<GeoBone> resolveBoneArg(List<MolangRuntime.MolangValue> args) {
        if (args.isEmpty()) {
            return Optional.empty();
        }
        return this.boneResolver.apply(args.get(0).asString());
    }

    private static GeoBone rootBone(GeoBone bone) {
        GeoBone current = bone;
        while (current.getParent() != null) {
            current = current.getParent();
        }
        return current;
    }

    private static MolangRuntime.MolangValue boneAabb(GeoBone bone) {
        Bounds bounds = computeBoneBounds(bone);
        if (!bounds.valid) {
            return MolangRuntime.MolangValue.NULL;
        }

        return MolangRuntime.MolangValue.object(Map.of(
                "min", vec(bounds.minX, bounds.minY, bounds.minZ),
                "max", vec(bounds.maxX, bounds.maxY, bounds.maxZ),
                "size", vec(bounds.maxX - bounds.minX, bounds.maxY - bounds.minY, bounds.maxZ - bounds.minZ),
                "center", vec(
                        (bounds.minX + bounds.maxX) * 0.5f,
                        (bounds.minY + bounds.maxY) * 0.5f,
                        (bounds.minZ + bounds.maxZ) * 0.5f
                )
        ));
    }

    private static Bounds computeBoneBounds(GeoBone bone) {
        Bounds bounds = new Bounds();
        Matrix4f boneMatrix = effectiveModelMatrix(bone);
        for (GeoCube cube : bone.getCubes()) {
            includeCube(bounds, boneMatrix, cube);
        }
        return bounds;
    }

    private static void includeCube(Bounds bounds, Matrix4f boneMatrix, GeoCube cube) {
        float pivotX = (float) cube.pivot().x();
        float pivotY = (float) cube.pivot().y();
        float pivotZ = (float) cube.pivot().z();
        float rotX = (float) cube.rotation().x();
        float rotY = (float) cube.rotation().y();
        float rotZ = (float) cube.rotation().z();
        float inflate = (float) cube.inflate() / 16.0f;
        float minX = (float) (-(cube.size().x()) - cube.pivot().x()) / 16.0f - inflate;
        float maxX = (float) (-cube.pivot().x()) / 16.0f + inflate;
        float minY = (float) (cube.pivot().y() - cube.size().y()) / 16.0f - inflate;
        float maxY = pivotY / 16.0f + inflate;
        float minZ = (float) (pivotZ - 0.0f) / 16.0f - inflate;
        float maxZ = (float) (pivotZ + cube.size().z()) / 16.0f + inflate;

        Matrix4f cubeMatrix = new Matrix4f(boneMatrix)
                .translate(pivotX / 16.0f, pivotY / 16.0f, pivotZ / 16.0f)
                .rotateZ(rotZ)
                .rotateY(rotY)
                .rotateX(rotX)
                .translate(-pivotX / 16.0f, -pivotY / 16.0f, -pivotZ / 16.0f);

        include(bounds, cubeMatrix, minX, minY, minZ);
        include(bounds, cubeMatrix, minX, minY, maxZ);
        include(bounds, cubeMatrix, minX, maxY, minZ);
        include(bounds, cubeMatrix, minX, maxY, maxZ);
        include(bounds, cubeMatrix, maxX, minY, minZ);
        include(bounds, cubeMatrix, maxX, minY, maxZ);
        include(bounds, cubeMatrix, maxX, maxY, minZ);
        include(bounds, cubeMatrix, maxX, maxY, maxZ);
    }

    private static void include(Bounds bounds, Matrix4f matrix, float x, float y, float z) {
        Vector4f transformed = matrix.transform(new Vector4f(x, y, z, 1.0f));
        bounds.include(transformed.x, transformed.y, transformed.z);
    }

    private static MolangRuntime.MolangValue matrixValue(GeoBone bone) {
        Matrix4f matrix = effectiveLocalMatrix(bone);
        LinkedHashMap<String, MolangRuntime.MolangValue> values = new LinkedHashMap<>();
        values.put("m00", number(matrix.m00()));
        values.put("m01", number(matrix.m01()));
        values.put("m02", number(matrix.m02()));
        values.put("m03", number(matrix.m03()));
        values.put("m10", number(matrix.m10()));
        values.put("m11", number(matrix.m11()));
        values.put("m12", number(matrix.m12()));
        values.put("m13", number(matrix.m13()));
        values.put("m20", number(matrix.m20()));
        values.put("m21", number(matrix.m21()));
        values.put("m22", number(matrix.m22()));
        values.put("m23", number(matrix.m23()));
        values.put("m30", number(matrix.m30()));
        values.put("m31", number(matrix.m31()));
        values.put("m32", number(matrix.m32()));
        values.put("m33", number(matrix.m33()));
        values.put("row0", vec4(matrix.m00(), matrix.m01(), matrix.m02(), matrix.m03()));
        values.put("row1", vec4(matrix.m10(), matrix.m11(), matrix.m12(), matrix.m13()));
        values.put("row2", vec4(matrix.m20(), matrix.m21(), matrix.m22(), matrix.m23()));
        values.put("row3", vec4(matrix.m30(), matrix.m31(), matrix.m32(), matrix.m33()));
        values.put("column0", vec4(matrix.m00(), matrix.m10(), matrix.m20(), matrix.m30()));
        values.put("column1", vec4(matrix.m01(), matrix.m11(), matrix.m21(), matrix.m31()));
        values.put("column2", vec4(matrix.m02(), matrix.m12(), matrix.m22(), matrix.m32()));
        values.put("column3", vec4(matrix.m03(), matrix.m13(), matrix.m23(), matrix.m33()));
        return MolangRuntime.MolangValue.object(values);
    }

    private static MolangRuntime.MolangValue trsValue(GeoBone bone) {
        return MolangRuntime.MolangValue.object(Map.of(
                "translation", vec(bone.getPosX(), bone.getPosY(), bone.getPosZ()),
                "rotation", vec(bone.getRotX(), bone.getRotY(), bone.getRotZ()),
                "scale", vec(bone.getScaleX(), bone.getScaleY(), bone.getScaleZ())
        ));
    }

    private static MolangRuntime.MolangValue vec(double x, double y, double z) {
        return MolangRuntime.MolangValue.object(Map.of(
                "x", number(x),
                "y", number(y),
                "z", number(z)
        ));
    }

    private static MolangRuntime.MolangValue vec4(double x, double y, double z, double w) {
        return MolangRuntime.MolangValue.object(Map.of(
                "x", number(x),
                "y", number(y),
                "z", number(z),
                "w", number(w)
        ));
    }

    private static MolangRuntime.MolangValue number(double value) {
        return MolangRuntime.MolangValue.number(value);
    }

    private static Matrix4f effectiveLocalMatrix(GeoBone bone) {
        Matrix4f local = bone.getLocalSpaceMatrix();
        if (!isIdentity(local)) {
            return new Matrix4f(local);
        }
        return new Matrix4f()
                .translate(-bone.getPosX() / 16.0f, bone.getPosY() / 16.0f, bone.getPosZ() / 16.0f)
                .translate(bone.getPivotX() / 16.0f, bone.getPivotY() / 16.0f, bone.getPivotZ() / 16.0f)
                .rotateZ(bone.getRotZ())
                .rotateY(bone.getRotY())
                .rotateX(bone.getRotX())
                .scale(bone.getScaleX(), bone.getScaleY(), bone.getScaleZ())
                .translate(-bone.getPivotX() / 16.0f, -bone.getPivotY() / 16.0f, -bone.getPivotZ() / 16.0f);
    }

    private static Matrix4f effectiveModelMatrix(GeoBone bone) {
        Matrix4f model = bone.getModelSpaceMatrix();
        if (!isIdentity(model)) {
            return new Matrix4f(model);
        }
        return effectiveLocalMatrix(bone);
    }

    private static boolean isIdentity(Matrix4f matrix) {
        return matrix.equals(new Matrix4f(), 1.0e-6f);
    }

    private static final class Bounds {
        private boolean valid;
        private float minX = Float.POSITIVE_INFINITY;
        private float minY = Float.POSITIVE_INFINITY;
        private float minZ = Float.POSITIVE_INFINITY;
        private float maxX = Float.NEGATIVE_INFINITY;
        private float maxY = Float.NEGATIVE_INFINITY;
        private float maxZ = Float.NEGATIVE_INFINITY;

        private void include(float x, float y, float z) {
            this.valid = true;
            this.minX = Math.min(this.minX, x);
            this.minY = Math.min(this.minY, y);
            this.minZ = Math.min(this.minZ, z);
            this.maxX = Math.max(this.maxX, x);
            this.maxY = Math.max(this.maxY, y);
            this.maxZ = Math.max(this.maxZ, z);
        }
    }
}
