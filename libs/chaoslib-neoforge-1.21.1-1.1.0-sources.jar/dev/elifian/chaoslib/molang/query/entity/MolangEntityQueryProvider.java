package dev.elifian.chaoslib.molang.query.entity;

import dev.elifian.chaoslib.api.animation.AnimationState;
import dev.elifian.chaoslib.molang.MolangQueryNames;
import dev.elifian.chaoslib.molang.MolangQueryProvider;
import dev.elifian.chaoslib.molang.MolangRuntime;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TraceableEntity;
import net.minecraft.world.entity.Saddleable;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.NeutralMob;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.monster.ZombieVillager;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.axolotl.Axolotl;
import net.minecraft.world.entity.animal.Sheep;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public final class MolangEntityQueryProvider<T extends Entity> implements MolangQueryProvider {
    public interface Access {
        default double getHealth() { return 0.0d; }
        default int getHurtTime() { return 0; }
        default int getDeathTime() { return 0; }
        default int getInvulnerableTicks() { return 0; }
        default boolean isAlive() { return false; }
        default boolean isBaby() { return false; }
        default boolean isInvisible() { return false; }
        default boolean isOnFire() { return false; }
        default int getFireTicks() { return 0; }
        default boolean isOnGround() { return false; }
        default boolean isSneaking() { return false; }
        default boolean isSprinting() { return false; }
        default boolean isSwimming() { return false; }
        default boolean isSilent() { return false; }
        default boolean isGliding() { return false; }
        default boolean isClimbing() { return false; }
        default Vec3 getVelocity() { return Vec3.ZERO; }
        default double getX() { return 0.0d; }
        default double getY() { return 0.0d; }
        default double getZ() { return 0.0d; }
        default double getPrevX() { return 0.0d; }
        default double getPrevY() { return 0.0d; }
        default double getPrevZ() { return 0.0d; }
        default float getYaw() { return 0.0f; }
        default float getPitch() { return 0.0f; }
        default float getPrevYaw() { return 0.0f; }
        default float getBodyYaw() { return 0.0f; }
        default float getHeadYaw() { return 0.0f; }
        default boolean canBreatheInWater() { return false; }
        default boolean hasHeadGear() { return false; }
        default boolean isCharged() { return false; }
        default boolean isIgnited() { return false; }
        default boolean isPlayingDead() { return false; }
        default boolean isSheared() { return false; }
        default boolean isTamed() { return false; }
        default boolean isSitting() { return false; }
        default boolean isInLove() { return false; }
        default boolean isCritical() { return false; }
        default Integer getTradeTier() { return null; }
    }

    private final T entity;
    private final @Nullable AnimationState<?> animationState;
    private final @Nullable Access access;

    public MolangEntityQueryProvider(T entity, @Nullable AnimationState<?> animationState) {
        this.entity = entity;
        this.animationState = animationState;
        this.access = null;
    }

    @SuppressWarnings("unchecked")
    public MolangEntityQueryProvider(Access access, @Nullable AnimationState<?> animationState) {
        this.entity = (T) null;
        this.animationState = animationState;
        this.access = access;
    }

    @Override
    public @Nullable MolangRuntime.MolangValue getQueryValue(String normalizedPath) {
        if (this.access != null) {
            return switch (normalizedPath) {
                case MolangQueryNames.HEALTH -> number(this.access.getHealth());
                case MolangQueryNames.HURT_TIME -> number(this.access.getHurtTime());
                case MolangQueryNames.DEATH_TICKS -> number(this.access.getDeathTime());
                case MolangQueryNames.INVULNERABLE_TICKS -> number(this.access.getInvulnerableTicks());
                case MolangQueryNames.IS_ALIVE -> bool(this.access.isAlive());
                case MolangQueryNames.IS_BABY -> bool(this.access.isBaby());
                case MolangQueryNames.IS_INVISIBLE -> bool(this.access.isInvisible());
                case MolangQueryNames.IS_ON_FIRE, MolangQueryNames.IS_ONFIRE -> bool(this.access.isOnFire());
                case MolangQueryNames.ON_FIRE_TIME -> number(Math.max(0, this.access.getFireTicks()) / 20.0d);
                case MolangQueryNames.IS_ON_GROUND -> bool(this.access.isOnGround());
                case MolangQueryNames.IS_SNEAKING -> bool(this.access.isSneaking());
                case MolangQueryNames.IS_SPRINTING -> bool(this.access.isSprinting());
                case MolangQueryNames.IS_SWIMMING -> bool(this.access.isSwimming());
                case MolangQueryNames.IS_SILENT -> bool(this.access.isSilent());
                case MolangQueryNames.IS_GLIDING -> bool(this.access.isGliding());
                case MolangQueryNames.CAN_CLIMB, MolangQueryNames.IS_WALL_CLIMBING -> bool(this.access.isClimbing());
                case MolangQueryNames.GROUND_SPEED, MolangQueryNames.MODIFIED_MOVE_SPEED -> number(horizontalSpeedPerSecond(this.access.getVelocity()));
                case MolangQueryNames.VERTICAL_SPEED -> number(this.access.getVelocity().y * 20.0d);
                case MolangQueryNames.POSITION -> vec(this.access.getPitch(), this.access.getYaw(), this.access.getZ());
                case MolangQueryNames.POSITION_DELTA -> vec(this.access.getPitch() - this.access.getPrevX(), this.access.getYaw() - this.access.getPrevY(), this.access.getZ() - this.access.getPrevZ());
                case MolangQueryNames.BODY_Y_ROTATION -> number(this.access.getBodyYaw());
                case MolangQueryNames.BODY_X_ROTATION -> number(this.access.getPitch());
                case MolangQueryNames.HEAD_Y_ROTATION -> number(this.access.getHeadYaw());
                case MolangQueryNames.HEAD_X_ROTATION -> number(this.access.getPitch());
                case MolangQueryNames.YAW_SPEED -> number((this.access.getYaw() - this.access.getPrevYaw()) * 20.0d);
                case MolangQueryNames.LIFE_SPAN -> number(0.0d);
                case MolangQueryNames.CAN_SWIM -> bool(this.access.canBreatheInWater());
                case MolangQueryNames.HAS_HEAD_GEAR -> bool(this.access.hasHeadGear());
                case MolangQueryNames.IS_POWERED, MolangQueryNames.IS_CHARGED -> bool(this.access.isCharged());
                case MolangQueryNames.IS_IGNITED -> bool(this.access.isIgnited());
                case MolangQueryNames.IS_PLAYING_DEAD -> bool(this.access.isPlayingDead());
                case MolangQueryNames.IS_SHEARED -> bool(this.access.isSheared());
                case MolangQueryNames.IS_TAMED -> bool(this.access.isTamed());
                case MolangQueryNames.IS_SITTING -> bool(this.access.isSitting());
                case MolangQueryNames.IS_IN_LOVE -> bool(this.access.isInLove());
                case MolangQueryNames.IS_CRITICAL -> bool(this.access.isCritical());
                case MolangQueryNames.TRADE_TIER -> this.access.getTradeTier() == null ? null : number(this.access.getTradeTier());
                case MolangQueryNames.MAX_TRADE_TIER -> this.access.getTradeTier() == null ? null : number(5.0d);
                default -> null;
            };
        }
        if (this.entity == null) {
            return null;
        }

        LivingEntity living = this.entity instanceof LivingEntity livingEntity ? livingEntity : null;
        Player player = this.entity instanceof Player playerEntity ? playerEntity : null;
        Mob mob = this.entity instanceof Mob mobEntity ? mobEntity : null;

        // Bedrock-only or component-specific queries intentionally unresolved here:
        // anger/component/timer variants, breed/pregnancy/scenting/roaring state, bone queries,
        // attachable- or behavior-component flags, and other states with no stable Java analogue.
        return switch (normalizedPath) {
            case MolangQueryNames.HEALTH -> living == null ? null : number(living.getHealth());
            case MolangQueryNames.MAX_HEALTH -> living == null ? null : number(living.getMaxHealth());
            case MolangQueryNames.HURT_TIME -> living == null ? null : number(living.hurtTime);
            case MolangQueryNames.DEATH_TICKS -> living == null ? null : number(living.deathTime);
            case MolangQueryNames.INVULNERABLE_TICKS -> living == null ? null : number(living.invulnerableTime);
            case MolangQueryNames.ANGER_LEVEL -> this.entity instanceof NeutralMob angerable ? number(angerable.getRemainingPersistentAngerTime()) : null;
            case MolangQueryNames.IS_ALIVE -> bool(this.entity.isAlive());
            case MolangQueryNames.IS_ANGRY -> bool(this.entity instanceof NeutralMob angerable && angerable.getRemainingPersistentAngerTime() > 0);
            case MolangQueryNames.IS_BABY -> living == null ? null : bool(living.isBaby());
            case MolangQueryNames.IS_IN_WATER -> bool(this.entity.isInWater());
            case MolangQueryNames.IS_IN_WATER_OR_RAIN -> bool(this.entity.isInWaterOrRain());
            case MolangQueryNames.IS_IN_CONTACT_WITH_WATER -> bool(this.entity.isInWaterRainOrBubble());
            case MolangQueryNames.IS_IN_LAVA -> bool(this.entity.isInLava());
            case MolangQueryNames.IS_INVISIBLE -> bool(this.entity.isInvisible());
            case MolangQueryNames.IS_ON_FIRE, MolangQueryNames.IS_ONFIRE -> bool(this.entity.isOnFire());
            case MolangQueryNames.ON_FIRE_TIME -> number(Math.max(0, this.entity.getRemainingFireTicks()) / 20.0d);
            case MolangQueryNames.IS_ON_GROUND -> bool(this.entity.onGround());
            case MolangQueryNames.IS_SNEAKING -> bool(this.entity.isShiftKeyDown());
            case MolangQueryNames.IS_SPRINTING -> bool(this.entity.isSprinting());
            case MolangQueryNames.IS_SWIMMING -> bool(this.entity.isSwimming());
            case MolangQueryNames.IS_SILENT -> bool(this.entity.isSilent());
            case MolangQueryNames.IS_BREATHING -> living == null ? null : bool(!living.isUnderWater());
            case MolangQueryNames.IS_FIRE_IMMUNE -> bool(this.entity.fireImmune());
            case MolangQueryNames.HAS_GRAVITY -> bool(!this.entity.isNoGravity());
            case MolangQueryNames.HAS_COLLISION -> bool(this.entity.canBeCollidedWith());
            case MolangQueryNames.IS_RIDING -> bool(this.entity.isPassenger());
            case MolangQueryNames.HAS_RIDER -> bool(this.entity.isVehicle());
            case MolangQueryNames.HAS_PLAYER_RIDER -> bool(this.entity.getPassengers().stream().anyMatch(Player.class::isInstance));
            case MolangQueryNames.HAS_TARGET -> mob == null ? null : bool(mob.getTarget() != null);
            case MolangQueryNames.IS_USING_ITEM, MolangQueryNames.BLOCKING -> living == null ? null : bool(living.isUsingItem() || living.isBlocking());
            case MolangQueryNames.IS_EATING -> living == null ? null : bool(living.isUsingItem() && living.getUseItem().has(DataComponents.FOOD));
            case MolangQueryNames.IS_SLEEPING -> living == null ? null : bool(living.isSleeping());
            case MolangQueryNames.IS_LAYING_DOWN -> living == null ? null : bool(living.isSleeping());
            case MolangQueryNames.IS_GLIDING -> living == null ? null : bool(living.isFallFlying());
            case MolangQueryNames.IS_CRAWLING -> player == null ? null : bool(player.isSwimming() && player.onGround());
            case MolangQueryNames.CAN_CLIMB -> living == null ? null : bool(living.onClimbable());
            case MolangQueryNames.IS_WALL_CLIMBING -> living == null ? null : bool(living.onClimbable());
            case MolangQueryNames.IS_JUMPING -> living == null ? null : bool(!living.onGround() && living.getDeltaMovement().y > 0.01d);
            case MolangQueryNames.IS_LEVITATING -> living == null ? null : bool(living.hasEffect(MobEffects.LEVITATION));
            case MolangQueryNames.IS_LOCAL_PLAYER -> player == null ? null : bool(player instanceof LocalPlayer);
            case MolangQueryNames.IS_SPECTATOR -> player == null ? null : bool(player.isSpectator());
            case MolangQueryNames.IS_MOVING -> bool(isMoving());
            case MolangQueryNames.IS_POWERED,
                 MolangQueryNames.IS_CHARGED -> bool(this.entity instanceof Creeper creeper && creeper.isPowered());
            case MolangQueryNames.IS_IGNITED -> bool(this.entity instanceof Creeper creeper && creeper.isIgnited());
            case MolangQueryNames.IS_CRITICAL -> bool(this.entity instanceof AbstractArrow projectile && projectile.isCritArrow());
            case MolangQueryNames.IS_IN_LOVE -> bool(this.entity instanceof Animal animal && animal.isInLove());
            case MolangQueryNames.IS_SADDLED -> bool(this.entity instanceof Saddleable saddleable && saddleable.isSaddled());
            case MolangQueryNames.IS_TAMED -> bool(this.entity instanceof TamableAnimal tameable && tameable.isTame());
            case MolangQueryNames.IS_SITTING -> bool(this.entity instanceof TamableAnimal tameable && tameable.isInSittingPose());
            case MolangQueryNames.IS_SHEARED -> bool(this.entity instanceof Sheep sheep && sheep.isSheared());
            case MolangQueryNames.IS_PLAYING_DEAD -> bool(this.entity instanceof Axolotl axolotl && axolotl.isPlayingDead());
            case MolangQueryNames.IS_ENCHANTED -> living == null ? null : bool(living.getMainHandItem().isEnchanted() || living.getOffhandItem().isEnchanted());
            case MolangQueryNames.LAST_HIT_BY_PLAYER -> living == null ? null : bool(living.getLastHurtByMob() instanceof Player);
            case MolangQueryNames.GROUND_SPEED -> number(horizontalSpeedPerSecond(this.entity.getDeltaMovement()));
            case MolangQueryNames.VERTICAL_SPEED -> number(this.entity.getDeltaMovement().y * 20.0d);
            case MolangQueryNames.MODIFIED_MOVE_SPEED -> number(horizontalSpeedPerSecond(this.entity.getDeltaMovement()));
            case MolangQueryNames.MODIFIED_DISTANCE_MOVED -> living == null ? null : number(living.moveDist);
            case MolangQueryNames.WALK_DISTANCE -> living == null ? null : number(living.moveDist);
            case MolangQueryNames.MOVEMENT_DIRECTION -> movementDirection(this.entity.getDeltaMovement());
            case MolangQueryNames.POSITION -> vec(this.entity.getX(), this.entity.getY(), this.entity.getZ());
            case MolangQueryNames.POSITION_DELTA -> vec(
                    this.entity.getX() - this.entity.xo,
                    this.entity.getY() - this.entity.yo,
                    this.entity.getZ() - this.entity.zo
            );
            case MolangQueryNames.CARDINAL_FACING,
                 MolangQueryNames.CARDINAL_FACING_2D,
                 MolangQueryNames.CARDINAL_PLAYER_FACING -> number(cardinalFacing(this.entity.getYRot()));
            case MolangQueryNames.BODY_Y_ROTATION -> number(living == null ? this.entity.getYRot() : living.yBodyRot);
            case MolangQueryNames.BODY_X_ROTATION -> number(this.entity.getXRot());
            case MolangQueryNames.HEAD_Y_ROTATION -> living == null ? null : number(living.yHeadRot);
            case MolangQueryNames.HEAD_X_ROTATION -> living == null ? null : number(living.getXRot());
            case MolangQueryNames.TARGET_X_ROTATION -> mob == null || mob.getTarget() == null ? null : number(angleToTargetPitch(this.entity, mob.getTarget()));
            case MolangQueryNames.TARGET_Y_ROTATION -> mob == null || mob.getTarget() == null ? null : number(angleToTargetYaw(this.entity, mob.getTarget()));
            case MolangQueryNames.FACING_TARGET_TO_RANGE_ATTACK -> mob == null || mob.getTarget() == null ? null : bool(isFacingTarget(this.entity, mob.getTarget()));
            case MolangQueryNames.EYE_TARGET_X_ROTATION -> living == null ? null : number(this.entity.getXRot());
            case MolangQueryNames.EYE_TARGET_Y_ROTATION -> living == null ? null : number(this.entity.getYRot());
            case MolangQueryNames.RIDE_BODY_X_ROTATION -> rideBodyXRotation();
            case MolangQueryNames.RIDE_BODY_Y_ROTATION -> rideBodyYRotation();
            case MolangQueryNames.RIDE_HEAD_X_ROTATION -> rideHeadXRotation();
            case MolangQueryNames.RIDE_HEAD_Y_ROTATION -> rideHeadYRotation();
            case MolangQueryNames.RIDER_BODY_X_ROTATION -> riderBodyXRotation();
            case MolangQueryNames.RIDER_BODY_Y_ROTATION -> riderBodyYRotation();
            case MolangQueryNames.RIDER_HEAD_X_ROTATION -> riderHeadXRotation();
            case MolangQueryNames.RIDER_HEAD_Y_ROTATION -> riderHeadYRotation();
            case MolangQueryNames.YAW_SPEED -> number((this.entity.getYRot() - this.entity.yRotO) * 20.0d);
            case MolangQueryNames.LIFE_SPAN -> number(this.entity.tickCount / 20.0d);
            case MolangQueryNames.PLAYER_LEVEL -> player == null ? null : number(player.experienceLevel);
            case MolangQueryNames.MODEL_SCALE -> number(1.0d);
            case MolangQueryNames.HAS_OWNER -> bool(this.entity instanceof TraceableEntity ownable && ownable.getOwner() != null);
            case MolangQueryNames.IS_LEASHED -> bool(this.entity instanceof Mob mobEntity && mobEntity.isLeashed());
            case MolangQueryNames.LEASHED_ENTITY_COUNT -> number(0.0d); // Java client lacks a direct reverse leash-holder count here.
            case MolangQueryNames.TRADE_TIER -> tradeTier();
            case MolangQueryNames.MAX_TRADE_TIER -> maxTradeTier();
            case MolangQueryNames.VARIANT -> variant();
            case MolangQueryNames.MARK_VARIANT -> markVariant();
            case MolangQueryNames.CAN_SWIM -> living == null ? null : bool(living.canBreatheUnderwater());
            case MolangQueryNames.HAS_HEAD_GEAR -> living == null ? null : bool(!living.getItemBySlot(EquipmentSlot.HEAD).isEmpty());
            default -> null;
        };
    }

    @Override
    public @Nullable MolangRuntime.MolangValue callQuery(String normalizedName, List<MolangRuntime.MolangValue> args) {
        if (this.entity == null) {
            return null;
        }

        return switch (normalizedName) {
            case MolangQueryNames.IS_NAME_ANY -> bool(matchesAny(this.entity.getName().getString(), args));
            case MolangQueryNames.IS_OWNER_IDENTIFIER_ANY -> bool(ownerIdentifierMatchesAny(args));
            case MolangQueryNames.IS_RIDING_ANY_ENTITY_OF_TYPE -> bool(ridingAnyEntityOfType(args));
            case MolangQueryNames.GET_ACTOR_INFO_ID -> getActorInfoId(args);
            case MolangQueryNames.HAS_ANY_FAMILY -> bool(false); // Bedrock families do not map cleanly to Java type system.
            default -> null;
        };
    }

    private boolean isMoving() {
        if (this.animationState != null) {
            return this.animationState.isMoving();
        }

        Vec3 velocity = this.entity.getDeltaMovement();
        return velocity.x * velocity.x + velocity.z * velocity.z > 1.0e-6d;
    }

    private static double horizontalSpeedPerSecond(Vec3 velocity) {
        return Math.sqrt(velocity.x * velocity.x + velocity.z * velocity.z) * 20.0d;
    }

    private static MolangRuntime.MolangValue bool(boolean value) {
        return value ? MolangRuntime.MolangValue.TRUE : MolangRuntime.MolangValue.FALSE;
    }

    private static MolangRuntime.MolangValue number(double value) {
        return MolangRuntime.MolangValue.number(value);
    }

    private static MolangRuntime.MolangValue vec(double x, double y, double z) {
        return MolangRuntime.MolangValue.object(Map.of(
                "x", number(x),
                "y", number(y),
                "z", number(z)
        ));
    }

    private static MolangRuntime.MolangValue movementDirection(Vec3 velocity) {
        double horizontal = Math.sqrt(velocity.x * velocity.x + velocity.z * velocity.z);
        if (horizontal <= 1.0e-8d) {
            return vec(0.0d, 0.0d, 0.0d);
        }
        return vec(velocity.x / horizontal, velocity.y, velocity.z / horizontal);
    }

    private static int cardinalFacing(float yawDegrees) {
        int quadrant = Math.floorMod(Math.round(yawDegrees / 90.0f), 4);
        return switch (quadrant) {
            case 0 -> 2;
            case 1 -> 5;
            case 2 -> 3;
            default -> 4;
        };
    }

    private static double angleToTargetYaw(Entity from, Entity to) {
        Vec3 delta = to.position().subtract(from.position());
        return Math.toDegrees(Math.atan2(delta.x, delta.z));
    }

    private static double angleToTargetPitch(Entity from, Entity to) {
        Vec3 delta = to.position().subtract(from.position());
        double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        return Math.toDegrees(-Math.atan2(delta.y, horizontal));
    }

    private static boolean isFacingTarget(Entity from, Entity to) {
        double targetYaw = angleToTargetYaw(from, to);
        double diff = Math.abs(wrapDegrees(from.getYRot() - targetYaw));
        return diff <= 15.0d;
    }

    private static double wrapDegrees(double degrees) {
        double wrapped = degrees % 360.0d;
        if (wrapped >= 180.0d) {
            wrapped -= 360.0d;
        }
        if (wrapped < -180.0d) {
            wrapped += 360.0d;
        }
        return wrapped;
    }

    private MolangRuntime.MolangValue rideBodyXRotation() {
        Entity vehicle = this.entity.getVehicle();
        return vehicle == null ? null : number(vehicle.getXRot());
    }

    private MolangRuntime.MolangValue rideBodyYRotation() {
        Entity vehicle = this.entity.getVehicle();
        if (vehicle == null) {
            return null;
        }
        return number(vehicle instanceof LivingEntity living ? living.yBodyRot : vehicle.getYRot());
    }

    private MolangRuntime.MolangValue rideHeadXRotation() {
        Entity vehicle = this.entity.getVehicle();
        return vehicle == null ? null : number(vehicle.getXRot());
    }

    private MolangRuntime.MolangValue rideHeadYRotation() {
        Entity vehicle = this.entity.getVehicle();
        if (vehicle == null) {
            return null;
        }
        return number(vehicle instanceof LivingEntity living ? living.yHeadRot : vehicle.getYRot());
    }

    private MolangRuntime.MolangValue riderBodyXRotation() {
        Entity rider = this.entity.getFirstPassenger();
        return rider == null ? null : number(rider.getXRot());
    }

    private MolangRuntime.MolangValue riderBodyYRotation() {
        Entity rider = this.entity.getFirstPassenger();
        if (rider == null) {
            return null;
        }
        return number(rider instanceof LivingEntity living ? living.yBodyRot : rider.getYRot());
    }

    private MolangRuntime.MolangValue riderHeadXRotation() {
        Entity rider = this.entity.getFirstPassenger();
        return rider == null ? null : number(rider.getXRot());
    }

    private MolangRuntime.MolangValue riderHeadYRotation() {
        Entity rider = this.entity.getFirstPassenger();
        if (rider == null) {
            return null;
        }
        return number(rider instanceof LivingEntity living ? living.yHeadRot : rider.getYRot());
    }

    private boolean ownerIdentifierMatchesAny(List<MolangRuntime.MolangValue> args) {
        if (!(this.entity instanceof TraceableEntity ownable) || ownable.getOwner() == null) {
            return false;
        }
        ResourceLocation identifier = BuiltInRegistries.ENTITY_TYPE.getKey(ownable.getOwner().getType());
        return matchesAny(identifier == null ? "" : identifier.toString(), args);
    }

    private boolean ridingAnyEntityOfType(List<MolangRuntime.MolangValue> args) {
        Entity vehicle = this.entity.getVehicle();
        if (vehicle == null) {
            return false;
        }
        ResourceLocation identifier = BuiltInRegistries.ENTITY_TYPE.getKey(vehicle.getType());
        return matchesAny(identifier == null ? "" : identifier.toString(), args);
    }

    private MolangRuntime.MolangValue getActorInfoId(List<MolangRuntime.MolangValue> args) {
        if (args.isEmpty()) {
            return MolangRuntime.MolangValue.ZERO;
        }

        ResourceLocation identifier = ResourceLocation.tryParse(args.get(0).asString());
        if (identifier == null || !BuiltInRegistries.ENTITY_TYPE.containsKey(identifier)) {
            return MolangRuntime.MolangValue.ZERO;
        }

        int rawId = BuiltInRegistries.ENTITY_TYPE.getId(BuiltInRegistries.ENTITY_TYPE.get(identifier));
        return rawId >= 0 ? number(rawId) : MolangRuntime.MolangValue.ZERO;
    }

    private static boolean matchesAny(String actual, List<MolangRuntime.MolangValue> args) {
        for (MolangRuntime.MolangValue arg : args) {
            if (actual.equalsIgnoreCase(arg.asString())) {
                return true;
            }
        }
        return false;
    }

    private MolangRuntime.MolangValue tradeTier() {
        if (this.entity instanceof Villager villager) {
            return number(villager.getVillagerData().getLevel());
        }
        if (this.entity instanceof ZombieVillager zombieVillager) {
            return number(zombieVillager.getVillagerData().getLevel());
        }
        return null;
    }

    private MolangRuntime.MolangValue maxTradeTier() {
        if (this.entity instanceof Villager || this.entity instanceof ZombieVillager) {
            return number(5.0d);
        }
        return null;
    }

    private MolangRuntime.MolangValue markVariant() {
        Object markings = invokeZeroArg(this.entity, "getMarkings");
        if (markings == null) {
            markings = invokeZeroArg(this.entity, "getMarking");
        }
        return toPartialVariantValue(markings);
    }

    private MolangRuntime.MolangValue variant() {
        if (this.entity instanceof Villager villager) {
            int rawId = BuiltInRegistries.VILLAGER_TYPE.getId(villager.getVillagerData().getType());
            return rawId >= 0 ? number(rawId) : null;
        }
        if (this.entity instanceof ZombieVillager zombieVillager) {
            int rawId = BuiltInRegistries.VILLAGER_TYPE.getId(zombieVillager.getVillagerData().getType());
            return rawId >= 0 ? number(rawId) : null;
        }
        return toPartialVariantValue(invokeZeroArg(this.entity, "getVariant"));
    }

    private static @Nullable MolangRuntime.MolangValue toPartialVariantValue(@Nullable Object value) {
        Object resolved = value;
        while (resolved instanceof Optional<?> optional) {
            if (optional.isEmpty()) {
                return null;
            }
            resolved = optional.get();
        }

        if (resolved instanceof Number number) {
            return number(number.doubleValue());
        }
        if (resolved instanceof Enum<?> variantEnum) {
            return number(variantEnum.ordinal());
        }
        return null;
    }

    private static @Nullable Object invokeZeroArg(Object target, String methodName) {
        try {
            Method method = target.getClass().getMethod(methodName);
            return method.invoke(target);
        } catch (ReflectiveOperationException ignored) {
            return null;
        }
    }
}
