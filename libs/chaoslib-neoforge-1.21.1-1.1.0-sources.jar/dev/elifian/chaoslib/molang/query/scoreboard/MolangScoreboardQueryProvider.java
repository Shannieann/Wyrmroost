package dev.elifian.chaoslib.molang.query.scoreboard;

import dev.elifian.chaoslib.molang.MolangQueryNames;
import dev.elifian.chaoslib.molang.MolangQueryProvider;
import dev.elifian.chaoslib.molang.MolangRuntime;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.scores.Scoreboard;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.ScoreHolder;
import net.minecraft.world.scores.ReadOnlyScoreInfo;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public final class MolangScoreboardQueryProvider implements MolangQueryProvider {
    public interface Access {
        @Nullable Integer getScore(String objective, String scoreHolder);

        @Nullable String getCurrentScoreHolder();
    }

    private final @Nullable Entity entity;
    private final @Nullable Access access;

    public MolangScoreboardQueryProvider(@Nullable Entity entity) {
        this.entity = entity;
        this.access = entity == null ? null : new Access() {
            @Override
            public @Nullable Integer getScore(String objectiveName, String scoreHolder) {
                Scoreboard scoreboard = entity.level().getScoreboard();
                Objective objective = scoreboard.getObjective(objectiveName);
                if (objective == null || scoreHolder.isEmpty()) {
                    return null;
                }

                ReadOnlyScoreInfo score = scoreboard.getPlayerScoreInfo(
                        ScoreHolder.forNameOnly(scoreHolder), objective);
                return score == null ? null : score.value();
            }

            @Override
            public @Nullable String getCurrentScoreHolder() {
                return entity.getScoreboardName();
            }
        };
    }

    public MolangScoreboardQueryProvider(@Nullable Access access) {
        this.entity = null;
        this.access = access;
    }

    @Override
    public @Nullable MolangRuntime.MolangValue callQuery(String normalizedName, List<MolangRuntime.MolangValue> args) {
        if (this.access == null || !MolangQueryNames.SCOREBOARD.equals(normalizedName) || args.isEmpty()) {
            return null;
        }

        String scoreHolder = args.size() >= 2 ? args.get(1).asString() : this.access.getCurrentScoreHolder();
        if (scoreHolder.isEmpty()) {
            return MolangRuntime.MolangValue.ZERO;
        }

        Integer score = this.access.getScore(args.get(0).asString(), scoreHolder);
        if (score == null) {
            return MolangRuntime.MolangValue.ZERO;
        }
        return MolangRuntime.MolangValue.number(score);
    }
}
