package dev.elifian.chaoslib.molang.query.world;

import dev.elifian.chaoslib.molang.MolangQueryNames;
import dev.elifian.chaoslib.molang.MolangQueryProvider;
import dev.elifian.chaoslib.molang.MolangRuntime;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

public final class MolangWorldQueryProvider implements MolangQueryProvider {
    public interface Access {
        long getTimeOfDay();

        int getMoonPhase();

        int getBottomY();

        int getTopY();

        int getEntityCount();
    }

    private final @Nullable Level world;
    private final @Nullable Access access;

    public MolangWorldQueryProvider(@Nullable Level world) {
        this.world = world;
        this.access = world == null ? null : new Access() {
            @Override
            public long getTimeOfDay() {
                return world.getDayTime();
            }

            @Override
            public int getMoonPhase() {
                return world.getMoonPhase();
            }

            @Override
            public int getBottomY() {
                return world.getMinBuildHeight();
            }

            @Override
            public int getTopY() {
                return world.getMaxBuildHeight();
            }

            @Override
            public int getEntityCount() {
                return world.getEntities(null, new AABB(-30_000_000, world.getMinBuildHeight(), -30_000_000, 30_000_000, world.getMaxBuildHeight(), 30_000_000)).size();
            }
        };
    }

    public MolangWorldQueryProvider(@Nullable Access access) {
        this.world = null;
        this.access = access;
    }

    @Override
    public @Nullable MolangRuntime.MolangValue getQueryValue(String normalizedPath) {
        if (this.access == null) {
            return null;
        }

        long timeOfDay = this.access.getTimeOfDay();
        return switch (normalizedPath) {
            case MolangQueryNames.DAY -> MolangRuntime.MolangValue.number(Math.floorDiv(timeOfDay, 24000L));
            case MolangQueryNames.TIME_OF_DAY -> MolangRuntime.MolangValue.number((timeOfDay % 24000L) / 24000.0d);
            case MolangQueryNames.MOON_PHASE -> MolangRuntime.MolangValue.number(this.access.getMoonPhase());
            case MolangQueryNames.MOON_BRIGHTNESS -> MolangRuntime.MolangValue.number(moonBrightness(this.access.getMoonPhase()));
            case MolangQueryNames.COMBINE_ENTITIES -> MolangRuntime.MolangValue.number(this.access.getEntityCount());
            case MolangQueryNames.EFFECT_EMITTER_COUNT,
                 MolangQueryNames.EFFECT_PARTICLE_COUNT,
                 MolangQueryNames.TOTAL_EMITTER_COUNT,
                 MolangQueryNames.TOTAL_PARTICLE_COUNT -> MolangRuntime.MolangValue.ZERO; // No stable Java client particle/emitter counters here.
            default -> null;
        };
    }

    private static double moonBrightness(int phase) {
        return switch (phase & 7) {
            case 0 -> 1.0d;
            case 1, 7 -> 0.75d;
            case 2, 6 -> 0.5d;
            case 3, 5 -> 0.25d;
            default -> 0.0d;
        };
    }
}
