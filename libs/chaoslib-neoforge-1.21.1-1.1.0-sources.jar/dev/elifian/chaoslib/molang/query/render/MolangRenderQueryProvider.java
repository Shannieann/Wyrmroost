package dev.elifian.chaoslib.molang.query.render;

import dev.elifian.chaoslib.molang.MolangQueryNames;
import dev.elifian.chaoslib.molang.MolangQueryProvider;
import dev.elifian.chaoslib.molang.MolangRuntime;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayDeque;
import java.util.List;
import java.util.Map;

public final class MolangRenderQueryProvider implements MolangQueryProvider {
    public interface Access {
        double getClientMaxRenderDistance();

        double getLastFrameTimeSeconds();

        @Nullable Double getDistanceFromCamera();

        double getCameraPitch();

        double getCameraYaw();

        @Nullable MolangRuntime.MolangValue getRotationToCamera();

        double getActorCount();

        String getGraphicsMode();
    }

    private static final int FRAME_HISTORY_CAPACITY = 120;
    private static final ArrayDeque<Double> FRAME_HISTORY = new ArrayDeque<>(FRAME_HISTORY_CAPACITY);
    private static double frameHistorySum;
    private final @Nullable Entity entity;
    private final @Nullable Access access;

    public MolangRenderQueryProvider(@Nullable Entity entity) {
        this.entity = entity;
        this.access = entity == null ? null : new Access() {
            @Override
            public double getClientMaxRenderDistance() {
                return Minecraft.getInstance().options.renderDistance().get() * 16.0d;
            }

            @Override
            public double getLastFrameTimeSeconds() {
                return Minecraft.getInstance().getTimer().getGameTimeDeltaTicks() / 20.0d;
            }

            @Override
            public @Nullable Double getDistanceFromCamera() {
                return distanceFromCamera(Minecraft.getInstance(), entity);
            }

            @Override
            public double getCameraPitch() {
                return Minecraft.getInstance().gameRenderer.getMainCamera().getXRot();
            }

            @Override
            public double getCameraYaw() {
                return Minecraft.getInstance().gameRenderer.getMainCamera().getYRot();
            }

            @Override
            public @Nullable MolangRuntime.MolangValue getRotationToCamera() {
                return rotationToCamera(Minecraft.getInstance(), entity);
            }

            @Override
            public double getActorCount() {
                return actorCount(Minecraft.getInstance());
            }

            @Override
            public String getGraphicsMode() {
                return Minecraft.getInstance().options.graphicsMode().get().toString().toLowerCase();
            }
        };
    }

    public MolangRenderQueryProvider(@Nullable Access access) {
        this.entity = null;
        this.access = access;
    }

    @Override
    public @Nullable MolangRuntime.MolangValue getQueryValue(String normalizedPath) {
        if (this.access == null) {
            return null;
        }
        updateFrameHistory(this.access.getLastFrameTimeSeconds());

        // Render-tier queries that depend on Bedrock-specific device classification still do not
        // map cleanly to the Java client.
        return switch (normalizedPath) {
            case MolangQueryNames.CLIENT_MAX_RENDER_DISTANCE -> number(this.access.getClientMaxRenderDistance());
            case MolangQueryNames.LAST_FRAME_TIME -> number(lastFrameTime());
            case MolangQueryNames.AVERAGE_FRAME_TIME -> number(averageFrameTime());
            case MolangQueryNames.MAXIMUM_FRAME_TIME -> number(maximumFrameTime());
            case MolangQueryNames.MINIMUM_FRAME_TIME -> number(minimumFrameTime());
            case MolangQueryNames.DISTANCE_FROM_CAMERA -> this.access.getDistanceFromCamera() == null ? null : number(this.access.getDistanceFromCamera());
            case MolangQueryNames.CAMERA_ROTATION -> vec(this.access.getCameraPitch(), this.access.getCameraYaw(), 0.0d);
            case MolangQueryNames.ROTATION_TO_CAMERA -> this.access.getRotationToCamera();
            case MolangQueryNames.ACTOR_COUNT -> number(this.access.getActorCount());
            case MolangQueryNames.TIME_STAMP -> number(System.currentTimeMillis() / 1000.0d);
            case MolangQueryNames.GRAPHICS_MODE_IS_ANY -> null;
            default -> null;
        };
    }

    @Override
    public @Nullable MolangRuntime.MolangValue callQuery(String normalizedName, List<MolangRuntime.MolangValue> args) {
        return switch (normalizedName) {
            case MolangQueryNames.GRAPHICS_MODE_IS_ANY -> graphicsModeIsAny(args);
            case MolangQueryNames.CAMERA_DISTANCE_RANGE_LERP -> cameraDistanceRangeLerp(args);
            default -> null;
        };
    }

    private MolangRuntime.MolangValue graphicsModeIsAny(List<MolangRuntime.MolangValue> args) {
        if (this.access == null) {
            return MolangRuntime.MolangValue.FALSE;
        }
        String current = this.access.getGraphicsMode();
        for (MolangRuntime.MolangValue arg : args) {
            if (current.equals(arg.asString().toLowerCase())) {
                return MolangRuntime.MolangValue.TRUE;
            }
        }
        return MolangRuntime.MolangValue.FALSE;
    }

    private @Nullable MolangRuntime.MolangValue cameraDistanceRangeLerp(List<MolangRuntime.MolangValue> args) {
        if (this.access == null || this.access.getDistanceFromCamera() == null) {
            return null;
        }
        double distance = this.access.getDistanceFromCamera();
        double min = args.isEmpty() ? 0.0d : args.get(0).asNumber();
        double max = args.size() < 2 ? min + 1.0d : args.get(1).asNumber();
        if (max <= min) {
            return number(distance >= max ? 1.0d : 0.0d);
        }
        return number(Math.max(0.0d, Math.min(1.0d, (distance - min) / (max - min))));
    }

    private static double distanceFromCamera(Minecraft client, Entity entity) {
        return client.gameRenderer.getMainCamera().getPosition().distanceTo(entity.position());
    }

    private static MolangRuntime.MolangValue rotationToCamera(Minecraft client, Entity entity) {
        Vec3 cameraPos = client.gameRenderer.getMainCamera().getPosition();
        Vec3 delta = cameraPos.subtract(entity.position());
        double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        double pitch = Math.toDegrees(-Math.atan2(delta.y, horizontal));
        double yaw = Math.toDegrees(Math.atan2(delta.x, delta.z));
        return vec(pitch, yaw, 0.0d);
    }

    private static MolangRuntime.MolangValue vec(double x, double y, double z) {
        return MolangRuntime.MolangValue.object(Map.of(
                "x", number(x),
                "y", number(y),
                "z", number(z)
        ));
    }

    private static MolangRuntime.MolangValue number(double value) {
        return MolangRuntime.MolangValue.number(value);
    }

    private static double actorCount(Minecraft client) {
        int count = 0;
        for (Entity ignored : client.level.entitiesForRendering()) {
            count++;
        }
        return count;
    }

    private static void updateFrameHistory(double frameTimeSeconds) {
        FRAME_HISTORY.addLast(frameTimeSeconds);
        frameHistorySum += frameTimeSeconds;
        while (FRAME_HISTORY.size() > FRAME_HISTORY_CAPACITY) {
            frameHistorySum -= FRAME_HISTORY.removeFirst();
        }
    }

    private static double lastFrameTime() {
        return FRAME_HISTORY.isEmpty() ? 0.0d : FRAME_HISTORY.peekLast();
    }

    private static double averageFrameTime() {
        return FRAME_HISTORY.isEmpty() ? 0.0d : frameHistorySum / FRAME_HISTORY.size();
    }

    private static double maximumFrameTime() {
        double max = 0.0d;
        for (double value : FRAME_HISTORY) {
            max = Math.max(max, value);
        }
        return max;
    }

    private static double minimumFrameTime() {
        if (FRAME_HISTORY.isEmpty()) {
            return 0.0d;
        }
        double min = Double.POSITIVE_INFINITY;
        for (double value : FRAME_HISTORY) {
            min = Math.min(min, value);
        }
        return min;
    }
}
