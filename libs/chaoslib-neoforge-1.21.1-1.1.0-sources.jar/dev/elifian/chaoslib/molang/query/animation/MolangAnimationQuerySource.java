package dev.elifian.chaoslib.molang.query.animation;

public interface MolangAnimationQuerySource {
    double animTimeSeconds();

    double lifeTimeSeconds();

    double deltaTimeSeconds();

    default double keyFrameLerpTime() {
        return 0.0d;
    }

    default double frameAlpha() {
        return 0.0d;
    }

    default boolean allAnimationsFinished() {
        return false;
    }

    default boolean anyAnimationFinished() {
        return false;
    }

    default double stateTimeSeconds() {
        return 0.0d;
    }
}
