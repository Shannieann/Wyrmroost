package dev.elifian.chaoslib.molang.query.animation;

import dev.elifian.chaoslib.molang.MolangQueryNames;
import dev.elifian.chaoslib.molang.MolangQueryProvider;
import dev.elifian.chaoslib.molang.MolangRuntime;
import org.jetbrains.annotations.Nullable;

public final class MolangAnimationQueryProvider implements MolangQueryProvider {
    private final MolangAnimationQuerySource source;

    public MolangAnimationQueryProvider(MolangAnimationQuerySource source) {
        this.source = source;
    }

    @Override
    public @Nullable MolangRuntime.MolangValue getQueryValue(String normalizedPath) {
        if (this.source == null) {
            return null;
        }

        return switch (normalizedPath) {
            case MolangQueryNames.ANIM_TIME -> MolangRuntime.MolangValue.number(this.source.animTimeSeconds());
            case MolangQueryNames.LIFE_TIME -> MolangRuntime.MolangValue.number(this.source.lifeTimeSeconds());
            case MolangQueryNames.DELTA_TIME -> MolangRuntime.MolangValue.number(this.source.deltaTimeSeconds());
            case MolangQueryNames.KEY_FRAME_LERP_TIME -> MolangRuntime.MolangValue.number(this.source.keyFrameLerpTime());
            case MolangQueryNames.FRAME_ALPHA -> MolangRuntime.MolangValue.number(this.source.frameAlpha());
            case MolangQueryNames.ALL_ANIMATIONS_FINISHED -> this.source.allAnimationsFinished() ? MolangRuntime.MolangValue.TRUE : MolangRuntime.MolangValue.FALSE;
            case MolangQueryNames.ANY_ANIMATION_FINISHED -> this.source.anyAnimationFinished() ? MolangRuntime.MolangValue.TRUE : MolangRuntime.MolangValue.FALSE;
            case MolangQueryNames.STATE_TIME -> MolangRuntime.MolangValue.number(this.source.stateTimeSeconds());
            default -> null;
        };
    }
}
