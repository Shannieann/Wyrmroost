package dev.elifian.chaoslib.molang.query.block;

import dev.elifian.chaoslib.molang.MolangQueryNames;
import dev.elifian.chaoslib.molang.MolangQueryProvider;
import dev.elifian.chaoslib.molang.MolangRuntime;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.levelgen.Heightmap;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public final class MolangBlockQueryProvider implements MolangQueryProvider {
    public interface Access {
        int getBlockFace();

        @Nullable MolangRuntime.MolangValue getBlockStateValue(String name);

        boolean hasBlockTag(int relativeX, int relativeY, int relativeZ, String tagName);

        boolean hasBiomeTag(String tagName);

        int getHeightmap(int x, int z);

        int getAboveTopSolid(int x, int z);
    }

    private final @Nullable BlockEntity blockEntity;
    private final @Nullable MolangPropertyAccess propertyAccess;
    private final @Nullable Access access;

    public MolangBlockQueryProvider(@Nullable BlockEntity blockEntity, @Nullable MolangPropertyAccess propertyAccess) {
        this.blockEntity = blockEntity;
        this.propertyAccess = propertyAccess;
        this.access = blockEntity == null ? null : new Access() {
            @Override
            public int getBlockFace() {
                return resolveBlockFace(blockEntity.getBlockState());
            }

            @Override
            public @Nullable MolangRuntime.MolangValue getBlockStateValue(String name) {
                Property<?> property = findProperty(blockEntity.getBlockState(), normalizePropertyName(name));
                if (property == null) {
                    return null;
                }
                return propertyToValueUnchecked(blockEntity.getBlockState(), property);
            }

            @Override
            public boolean hasBlockTag(int relativeX, int relativeY, int relativeZ, String tagName) {
                if (blockEntity.getLevel() == null) {
                    return false;
                }
                BlockState state = blockEntity.getLevel().getBlockState(blockEntity.getBlockPos().offset(relativeX, relativeY, relativeZ));
                return MolangBlockQueryProvider.hasBlockTag(state, tagName);
            }

            @Override
            public boolean hasBiomeTag(String tagName) {
                return MolangBlockQueryProvider.this.hasBiomeTag(tagName);
            }

            @Override
            public int getHeightmap(int x, int z) {
                if (blockEntity.getLevel() == null) {
                    return 0;
                }
                return blockEntity.getLevel().getHeight(Heightmap.Types.WORLD_SURFACE, x, z);
            }

            @Override
            public int getAboveTopSolid(int x, int z) {
                if (blockEntity.getLevel() == null) {
                    return 0;
                }
                return blockEntity.getLevel().getHeight(Heightmap.Types.MOTION_BLOCKING, x, z) + 1;
            }
        };
    }

    public MolangBlockQueryProvider(@Nullable Access access, @Nullable MolangPropertyAccess propertyAccess) {
        this.blockEntity = null;
        this.propertyAccess = propertyAccess;
        this.access = access;
    }

    @Override
    public @Nullable MolangRuntime.MolangValue getQueryValue(String normalizedPath) {
        if (this.access == null) {
            return null;
        }

        return switch (normalizedPath) {
            case MolangQueryNames.BLOCK_FACE -> MolangRuntime.MolangValue.number(this.access.getBlockFace());
            default -> null;
        };
    }

    @Override
    public @Nullable MolangRuntime.MolangValue callQuery(String normalizedName, List<MolangRuntime.MolangValue> args) {
        if (this.access == null) {
            return null;
        }

        // Bedrock relative/neighbor tag queries are only implemented for block tags; biome/context-
        // dependent placement queries still require extra Java-side context not available here.
        return switch (normalizedName) {
            case MolangQueryNames.BLOCK_STATE -> blockStateValue(firstArg(args));
            case MolangQueryNames.HAS_BLOCK_STATE -> bool(blockStateValue(firstArg(args)) != null);
            case MolangQueryNames.PROPERTY -> propertyValue(firstArg(args));
            case MolangQueryNames.HAS_PROPERTY -> bool(propertyValue(firstArg(args)) != null);
            case MolangQueryNames.BLOCK_HAS_ALL_TAGS -> bool(blockHasAllTags(args, 3));
            case MolangQueryNames.BLOCK_HAS_ANY_TAG -> bool(blockHasAnyTags(args, 3));
            case MolangQueryNames.BLOCK_NEIGHBOR_HAS_ALL_TAGS -> bool(blockHasAllTags(args, 0));
            case MolangQueryNames.BLOCK_NEIGHBOR_HAS_ANY_TAG -> bool(blockHasAnyTags(args, 0));
            case MolangQueryNames.RELATIVE_BLOCK_HAS_ALL_TAGS -> bool(blockHasAllTags(args, 3));
            case MolangQueryNames.RELATIVE_BLOCK_HAS_ANY_TAG -> bool(blockHasAnyTags(args, 3));
            case MolangQueryNames.HAS_BIOME_TAG -> bool(hasBiomeTag(firstArg(args)));
            case MolangQueryNames.HEIGHTMAP -> heightmap(args);
            case MolangQueryNames.ABOVE_TOP_SOLID -> aboveTopSolid(args);
            default -> null;
        };
    }

    private @Nullable MolangRuntime.MolangValue propertyValue(@Nullable String name) {
        if (name == null || this.propertyAccess == null) {
            return null;
        }
        return this.propertyAccess.getMolangProperty(name);
    }

    private @Nullable MolangRuntime.MolangValue blockStateValue(@Nullable String name) {
        if (name == null) {
            return null;
        }
        return this.access == null ? null : this.access.getBlockStateValue(name);
    }

    private static @Nullable Property<?> findProperty(BlockState state, String name) {
        for (Property<?> property : state.getProperties()) {
            if (property.getName().equals(name)) {
                return property;
            }
        }
        return null;
    }

    private static String normalizePropertyName(String rawName) {
        int separator = rawName.indexOf(':');
        return separator >= 0 ? rawName.substring(separator + 1) : rawName;
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static MolangRuntime.MolangValue propertyToValueUnchecked(BlockState state, Property<?> property) {
        Property rawProperty = property;
        Comparable value = state.getValue(rawProperty);
        if (value instanceof Boolean boolValue) {
            return bool(boolValue);
        }
        if (value instanceof Number number) {
            return MolangRuntime.MolangValue.number(number.doubleValue());
        }
        if (value instanceof Enum<?> enumValue) {
            return MolangRuntime.MolangValue.string(enumValue.name().toLowerCase());
        }
        return MolangRuntime.MolangValue.string(rawProperty.getName(value));
    }

    private static int resolveBlockFace(BlockState state) {
        Property<?> facing = findProperty(state, "facing");
        if (facing == null) {
            return 6;
        }

        Comparable<?> value = state.getValue(facing);
        if (!(value instanceof Direction direction)) {
            return 6;
        }

        return switch (direction) {
            case DOWN -> 0;
            case UP -> 1;
            case NORTH -> 2;
            case SOUTH -> 3;
            case WEST -> 4;
            case EAST -> 5;
        };
    }

    private static @Nullable String firstArg(List<MolangRuntime.MolangValue> args) {
        return args.isEmpty() ? null : args.get(0).asString();
    }

    private boolean hasBiomeTag(@Nullable String tagName) {
        if (tagName == null || this.blockEntity.getLevel() == null) {
            return false;
        }
        try {
            int separator = tagName.indexOf(':');
            ResourceLocation id = separator >= 0
                    ? ResourceLocation.tryBuild(tagName.substring(0, separator), tagName.substring(separator + 1))
                    : ResourceLocation.tryBuild("minecraft", tagName);
            return this.blockEntity.getLevel().getBiome(this.blockEntity.getBlockPos()).is(TagKey.create(Registries.BIOME, id));
        } catch (RuntimeException ignored) {
            return false;
        }
    }

    private MolangRuntime.MolangValue heightmap(List<MolangRuntime.MolangValue> args) {
        if (this.access == null) {
            return MolangRuntime.MolangValue.ZERO;
        }
        int x = args.isEmpty() ? 0 : (int) args.get(0).asNumber();
        int z = args.size() < 2 ? 0 : (int) args.get(1).asNumber();
        int y = this.access.getHeightmap(x, z);
        return MolangRuntime.MolangValue.number(y);
    }

    private MolangRuntime.MolangValue aboveTopSolid(List<MolangRuntime.MolangValue> args) {
        if (this.access == null) {
            return MolangRuntime.MolangValue.ZERO;
        }
        int x = args.isEmpty() ? 0 : (int) args.get(0).asNumber();
        int z = args.size() < 2 ? 0 : (int) args.get(1).asNumber();
        return MolangRuntime.MolangValue.number(this.access.getAboveTopSolid(x, z));
    }

    private boolean blockHasAllTags(List<MolangRuntime.MolangValue> args, int offsetStartIndex) {
        if (this.access == null || args.size() <= offsetStartIndex) {
            return false;
        }
        for (int i = offsetStartIndex; i < args.size(); i++) {
            if (!this.access.hasBlockTag(relativeX(args, offsetStartIndex), relativeY(args, offsetStartIndex), relativeZ(args, offsetStartIndex), args.get(i).asString())) {
                return false;
            }
        }
        return true;
    }

    private boolean blockHasAnyTags(List<MolangRuntime.MolangValue> args, int offsetStartIndex) {
        if (this.access == null || args.size() <= offsetStartIndex) {
            return false;
        }
        for (int i = offsetStartIndex; i < args.size(); i++) {
            if (this.access.hasBlockTag(relativeX(args, offsetStartIndex), relativeY(args, offsetStartIndex), relativeZ(args, offsetStartIndex), args.get(i).asString())) {
                return true;
            }
        }
        return false;
    }

    private static int relativeX(List<MolangRuntime.MolangValue> args, int tagStartIndex) {
        return tagStartIndex >= 3 ? (int) args.get(0).asNumber() : 0;
    }

    private static int relativeY(List<MolangRuntime.MolangValue> args, int tagStartIndex) {
        return tagStartIndex >= 3 ? (int) args.get(1).asNumber() : 0;
    }

    private static int relativeZ(List<MolangRuntime.MolangValue> args, int tagStartIndex) {
        return tagStartIndex >= 3 ? (int) args.get(2).asNumber() : 0;
    }

    private static BlockPos offsetPos(BlockPos origin, List<MolangRuntime.MolangValue> args, int tagStartIndex) {
        int x = tagStartIndex >= 3 ? (int) args.get(0).asNumber() : 0;
        int y = tagStartIndex >= 3 ? (int) args.get(1).asNumber() : 0;
        int z = tagStartIndex >= 3 ? (int) args.get(2).asNumber() : 0;
        return origin.offset(x, y, z);
    }

    private static boolean hasBlockTag(BlockState state, String tagName) {
        try {
            int separator = tagName.indexOf(':');
            ResourceLocation id = separator >= 0
                    ? ResourceLocation.tryBuild(tagName.substring(0, separator), tagName.substring(separator + 1))
                    : ResourceLocation.tryBuild("minecraft", tagName);
            return state.is(TagKey.create(Registries.BLOCK, id));
        } catch (RuntimeException ignored) {
            return false;
        }
    }

    private static MolangRuntime.MolangValue bool(boolean value) {
        return value ? MolangRuntime.MolangValue.TRUE : MolangRuntime.MolangValue.FALSE;
    }
}
