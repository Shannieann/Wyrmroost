package dev.elifian.chaoslib.molang.query.block;

import dev.elifian.chaoslib.molang.MolangRuntime;
import org.jetbrains.annotations.Nullable;

public interface MolangPropertyAccess {
    @Nullable MolangRuntime.MolangValue getMolangProperty(String normalizedName);

    default boolean hasMolangProperty(String normalizedName) {
        return getMolangProperty(normalizedName) != null;
    }
}
