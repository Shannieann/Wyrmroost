package dev.elifian.chaoslib.molang.query.item;

import dev.elifian.chaoslib.molang.MolangQueryNames;
import dev.elifian.chaoslib.molang.MolangQueryProvider;
import dev.elifian.chaoslib.molang.MolangRuntime;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.tags.TagKey;
import net.minecraft.world.InteractionHand;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public final class MolangItemQueryProvider implements MolangQueryProvider {
    public interface StackAccess {
        boolean isEmpty();

        int getMaxUseTime();

        int getMaxDamage();

        int getDamage();

        boolean isDamageable();

        boolean isUsedOnRelease();

        boolean hasItemTag(String tagName);

        @Nullable String getItemId();

        @Nullable String getArmorMaterialName();
    }

    public interface Access {
        StackAccess getMainHandStack();

        StackAccess getOffHandStack();

        StackAccess getActiveItem();

        boolean isUsingItem();

        InteractionHand getActiveHand();

        int getItemUseTimeLeft();

        StackAccess getEquippedStack(EquipmentSlot slot);

        boolean isCoolingDown(StackAccess stack);
    }

    private final @Nullable LivingEntity living;
    private final @Nullable Access access;

    public MolangItemQueryProvider(@Nullable LivingEntity living) {
        this.living = living;
        this.access = living == null ? null : new Access() {
            @Override
            public StackAccess getMainHandStack() {
                return wrapStack(living.getMainHandItem(), living);
            }

            @Override
            public StackAccess getOffHandStack() {
                return wrapStack(living.getOffhandItem(), living);
            }

            @Override
            public StackAccess getActiveItem() {
                return wrapStack(living.getUseItem(), living);
            }

            @Override
            public boolean isUsingItem() {
                return living.isUsingItem();
            }

            @Override
            public InteractionHand getActiveHand() {
                return living.getUsedItemHand();
            }

            @Override
            public int getItemUseTimeLeft() {
                return living.getUseItemRemainingTicks();
            }

            @Override
            public StackAccess getEquippedStack(EquipmentSlot slot) {
                return wrapStack(living.getItemBySlot(slot), living);
            }

            @Override
            public boolean isCoolingDown(StackAccess stack) {
                return living instanceof Player player && stack != null && !stack.isEmpty() && living.getMainHandItem() != null && player.getCooldowns().isOnCooldown(living.getMainHandItem().getItem());
            }
        };
    }

    public MolangItemQueryProvider(@Nullable Access access) {
        this.living = null;
        this.access = access;
    }

    @Override
    public @Nullable MolangRuntime.MolangValue getQueryValue(String normalizedPath) {
        if (this.access == null) {
            return null;
        }

        // Bone-mapping queries remain unresolved here because Java runtime does not expose
        // Bedrock-style slot->bone conventions.
        return switch (normalizedPath) {
            case MolangQueryNames.ITEM_MAX_USE_DURATION -> number(maxUseDuration(this.access.getActiveItem()));
            case MolangQueryNames.ITEM_IN_USE_DURATION -> number(itemUseDuration());
            case MolangQueryNames.ITEM_REMAINING_USE_DURATION -> number(itemRemainingUseDuration());
            case MolangQueryNames.MAIN_HAND_ITEM_MAX_DURATION -> number(maxUseDuration(this.access.getMainHandStack()));
            case MolangQueryNames.MAIN_HAND_ITEM_USE_DURATION -> number(mainHandItemUseDuration());
            case MolangQueryNames.MAX_DURABILITY -> number(this.access.getMainHandStack().getMaxDamage());
            case MolangQueryNames.REMAINING_DURABILITY -> number(remainingDurability(this.access.getMainHandStack()));
            case MolangQueryNames.EQUIPMENT_COUNT -> number(equipmentCount());
            case MolangQueryNames.COOLDOWN_TIME,
                 MolangQueryNames.COOLDOWN_TIME_REMAINING -> cooldownTime(this.access.getMainHandStack());
            default -> null;
        };
    }

    @Override
    public @Nullable MolangRuntime.MolangValue callQuery(String normalizedName, List<MolangRuntime.MolangValue> args) {
        if (this.access == null) {
            return null;
        }

        return switch (normalizedName) {
            case MolangQueryNames.IS_ITEM_EQUIPPED -> bool(!resolveHand(args).isEmpty());
            case MolangQueryNames.ITEM_IS_CHARGED -> bool(resolveHand(args).isUsedOnRelease());
            case MolangQueryNames.IS_ITEM_NAME_ANY -> bool(itemNameMatchesAny(resolveHand(args), args.size() > 1 ? args.subList(1, args.size()) : args));
            case MolangQueryNames.EQUIPPED_ITEM_ALL_TAGS -> bool(itemHasAllTags(resolveSlot(args), args.subList(1, args.size())));
            case MolangQueryNames.EQUIPPED_ITEM_ANY_TAG -> bool(itemHasAnyTag(resolveSlot(args), args.subList(1, args.size())));
            case MolangQueryNames.EQUIPPED_ITEM_IS_ATTACHABLE -> bool(false); // No Bedrock attachable system on Java.
            case MolangQueryNames.ARMOR_COLOR_SLOT -> armorColor(args);
            case MolangQueryNames.ARMOR_DAMAGE_SLOT -> armorDamage(args);
            case MolangQueryNames.ARMOR_MATERIAL_SLOT -> armorMaterial(args);
            case MolangQueryNames.ARMOR_TEXTURE_SLOT -> armorTexture(args);
            case MolangQueryNames.HAS_ARMOR_SLOT -> bool(!armorStack(args).isEmpty());
            case MolangQueryNames.ITEM_SLOT_TO_BONE_NAME -> itemSlotToBoneName(args);
            default -> null;
        };
    }

    private double itemUseDuration() {
        if (this.access == null || !this.access.isUsingItem()) {
            return 0.0d;
        }
        return (this.access.getActiveItem().getMaxUseTime() - this.access.getItemUseTimeLeft()) / 20.0d;
    }

    private double itemRemainingUseDuration() {
        return this.access != null && this.access.isUsingItem() ? this.access.getItemUseTimeLeft() / 20.0d : 0.0d;
    }

    private double mainHandItemUseDuration() {
        if (this.access == null || !this.access.isUsingItem() || this.access.getActiveHand() != InteractionHand.MAIN_HAND) {
            return 0.0d;
        }
        return itemUseDuration();
    }

    private StackAccess resolveHand(List<MolangRuntime.MolangValue> args) {
        if (this.access == null) {
            return emptyStack();
        }
        if (args.isEmpty()) {
            return this.access.getMainHandStack();
        }

        MolangRuntime.MolangValue slot = args.get(0);
        if (slot.type() == MolangRuntime.MolangValue.Type.STRING) {
            return "off_hand".equals(slot.asString()) ? this.access.getOffHandStack() : this.access.getMainHandStack();
        }
        return slot.asNumber() >= 1.0d ? this.access.getOffHandStack() : this.access.getMainHandStack();
    }

    private StackAccess resolveSlot(List<MolangRuntime.MolangValue> args) {
        if (this.access == null) {
            return emptyStack();
        }
        if (args.isEmpty()) {
            return this.access.getMainHandStack();
        }
        String slot = args.get(0).asString();
        return switch (slot) {
            case "off_hand" -> this.access.getOffHandStack();
            case "head" -> this.access.getEquippedStack(EquipmentSlot.HEAD);
            case "chest" -> this.access.getEquippedStack(EquipmentSlot.CHEST);
            case "legs" -> this.access.getEquippedStack(EquipmentSlot.LEGS);
            case "feet" -> this.access.getEquippedStack(EquipmentSlot.FEET);
            default -> this.access.getMainHandStack();
        };
    }

    private static double maxUseDuration(StackAccess stack) {
        return stack.isEmpty() ? 0.0d : stack.getMaxUseTime() / 20.0d;
    }

    private static double remainingDurability(StackAccess stack) {
        return stack.isDamageable() ? stack.getMaxDamage() - stack.getDamage() : 0.0d;
    }

    private int equipmentCount() {
        if (this.access == null) {
            return 0;
        }
        int count = 0;
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            if (slot.getType() == EquipmentSlot.Type.HUMANOID_ARMOR && !this.access.getEquippedStack(slot).isEmpty()) {
                count++;
            }
        }
        return count;
    }

    private static boolean itemNameMatchesAny(StackAccess stack, List<MolangRuntime.MolangValue> names) {
        if (stack.isEmpty()) {
            return false;
        }
        String actual = stack.getItemId();
        if (actual == null) {
            return false;
        }
        for (MolangRuntime.MolangValue name : names) {
            if (actual.equalsIgnoreCase(name.asString())) {
                return true;
            }
        }
        return false;
    }

    private boolean itemHasAllTags(StackAccess stack, List<MolangRuntime.MolangValue> tags) {
        if (stack.isEmpty()) {
            return false;
        }
        for (MolangRuntime.MolangValue tag : tags) {
            if (!stack.hasItemTag(tag.asString())) {
                return false;
            }
        }
        return true;
    }

    private boolean itemHasAnyTag(StackAccess stack, List<MolangRuntime.MolangValue> tags) {
        if (stack.isEmpty()) {
            return false;
        }
        for (MolangRuntime.MolangValue tag : tags) {
            if (stack.hasItemTag(tag.asString())) {
                return true;
            }
        }
        return false;
    }

    private MolangRuntime.MolangValue armorColor(List<MolangRuntime.MolangValue> args) {
        return MolangRuntime.MolangValue.ZERO;
    }

    private MolangRuntime.MolangValue armorDamage(List<MolangRuntime.MolangValue> args) {
        return number(armorStack(args).getDamage());
    }

    private MolangRuntime.MolangValue armorMaterial(List<MolangRuntime.MolangValue> args) {
        StackAccess stack = armorStack(args);
        if (stack.getArmorMaterialName() != null) {
            return MolangRuntime.MolangValue.string(stack.getArmorMaterialName());
        }
        return MolangRuntime.MolangValue.NULL;
    }

    private MolangRuntime.MolangValue armorTexture(List<MolangRuntime.MolangValue> args) {
        StackAccess stack = armorStack(args);
        if (stack.getArmorMaterialName() != null) {
            return MolangRuntime.MolangValue.string(stack.getArmorMaterialName());
        }
        return MolangRuntime.MolangValue.NULL;
    }

    private StackAccess armorStack(List<MolangRuntime.MolangValue> args) {
        if (this.access == null) {
            return emptyStack();
        }
        int slotIndex = args.isEmpty() ? 0 : (int) args.get(0).asNumber();
        EquipmentSlot slot = switch (slotIndex) {
            case 1 -> EquipmentSlot.CHEST;
            case 2 -> EquipmentSlot.LEGS;
            case 3 -> EquipmentSlot.FEET;
            default -> EquipmentSlot.HEAD;
        };
        return this.access.getEquippedStack(slot);
    }

    private MolangRuntime.MolangValue itemSlotToBoneName(List<MolangRuntime.MolangValue> args) {
        if (args.isEmpty()) {
            return MolangRuntime.MolangValue.string("main_hand");
        }
        if (args.get(0).type() == MolangRuntime.MolangValue.Type.STRING) {
            return MolangRuntime.MolangValue.string(args.get(0).asString().toLowerCase());
        }
        int slotIndex = (int) args.get(0).asNumber();
        String boneName = switch (slotIndex) {
            case 1 -> "off_hand";
            case 2 -> "head";
            case 3 -> "chest";
            case 4 -> "legs";
            case 5 -> "feet";
            default -> "main_hand";
        };
        return MolangRuntime.MolangValue.string(boneName);
    }

    private MolangRuntime.MolangValue cooldownTime(StackAccess stack) {
        if (this.access == null || stack.isEmpty()) {
            return MolangRuntime.MolangValue.ZERO;
        }
        return bool(this.access.isCoolingDown(stack));
    }

    private static StackAccess wrapStack(ItemStack stack, @Nullable LivingEntity living) {
        return new StackAccess() {
            @Override
            public boolean isEmpty() {
                return stack.isEmpty();
            }

            @Override
            public int getMaxUseTime() {
                return living == null ? 0 : stack.getUseDuration(living);
            }

            @Override
            public int getMaxDamage() {
                return stack.getMaxDamage();
            }

            @Override
            public int getDamage() {
                return stack.getDamageValue();
            }

            @Override
            public boolean isDamageable() {
                return stack.isDamageableItem();
            }

            @Override
            public boolean isUsedOnRelease() {
                return stack.useOnRelease();
            }

            @Override
            public boolean hasItemTag(String tagName) {
                try {
                    int separator = tagName.indexOf(':');
                    ResourceLocation id = separator >= 0
                            ? ResourceLocation.fromNamespaceAndPath(tagName.substring(0, separator), tagName.substring(separator + 1))
                            : ResourceLocation.fromNamespaceAndPath("minecraft", tagName);
                    return stack.is(TagKey.create(Registries.ITEM, id));
                } catch (RuntimeException ignored) {
                    return false;
                }
            }

            @Override
            public @Nullable String getItemId() {
                return stack.isEmpty() ? null : BuiltInRegistries.ITEM.getKey(stack.getItem()).toString();
            }

            @Override
            public @Nullable String getArmorMaterialName() {
                return stack.getItem() instanceof ArmorItem armorItem ? armorItem.getMaterial().getRegisteredName() : null;
            }
        };
    }

    private static StackAccess emptyStack() {
        return new StackAccess() {
            @Override
            public boolean isEmpty() {
                return true;
            }

            @Override
            public int getMaxUseTime() {
                return 0;
            }

            @Override
            public int getMaxDamage() {
                return 0;
            }

            @Override
            public int getDamage() {
                return 0;
            }

            @Override
            public boolean isDamageable() {
                return false;
            }

            @Override
            public boolean isUsedOnRelease() {
                return false;
            }

            @Override
            public boolean hasItemTag(String tagName) {
                return false;
            }

            @Override
            public @Nullable String getItemId() {
                return null;
            }

            @Override
            public @Nullable String getArmorMaterialName() {
                return null;
            }
        };
    }

    private static MolangRuntime.MolangValue number(double value) {
        return MolangRuntime.MolangValue.number(value);
    }

    private static MolangRuntime.MolangValue bool(boolean value) {
        return value ? MolangRuntime.MolangValue.TRUE : MolangRuntime.MolangValue.FALSE;
    }
}
