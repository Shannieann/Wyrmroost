package dev.elifian.chaoslib.molang.query.player;

import dev.elifian.chaoslib.molang.MolangQueryNames;
import dev.elifian.chaoslib.molang.MolangQueryProvider;
import dev.elifian.chaoslib.molang.MolangRuntime;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.CameraType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.core.registries.BuiltInRegistries;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public final class MolangPlayerQueryProvider implements MolangQueryProvider {
    public interface Access {
        boolean isLocalPlayer();

        boolean isFirstPerson();

        boolean isSpectator();

        boolean hasCape();

        int getPlayerLevel();

        boolean isTouchOnlyAffectsHotbar();

        @Nullable String getSkinId();

        String getLastInputMode();

        boolean isSelectedItem(List<String> itemIds);
    }

    private final @Nullable Player player;
    private final @Nullable Access access;

    public MolangPlayerQueryProvider(@Nullable Player player) {
        this.player = player;
        this.access = player == null ? null : new Access() {
            @Override
            public boolean isLocalPlayer() {
                return Minecraft.getInstance().player == player;
            }

            @Override
            public boolean isFirstPerson() {
                Minecraft client = Minecraft.getInstance();
                CameraType perspective = client.options.getCameraType();
                return client.player == player && perspective.isFirstPerson();
            }

            @Override
            public boolean isSpectator() {
                return player.isSpectator();
            }

            @Override
            public boolean hasCape() {
                return player instanceof AbstractClientPlayer clientPlayer && clientPlayer.getSkin().capeTexture() != null;
            }

            @Override
            public int getPlayerLevel() {
                return player.experienceLevel;
            }

            @Override
            public boolean isTouchOnlyAffectsHotbar() {
                return Minecraft.getInstance().options.touchscreen().get();
            }

            @Override
            public @Nullable String getSkinId() {
                return player instanceof AbstractClientPlayer clientPlayer ? clientPlayer.getSkin().texture().toString() : null;
            }

            @Override
            public String getLastInputMode() {
                return Minecraft.getInstance().options.touchscreen().get() ? "touch" : "keyboard_mouse";
            }

            @Override
            public boolean isSelectedItem(List<String> itemIds) {
                if (player.getMainHandItem().isEmpty()) {
                    return false;
                }
                if (itemIds.isEmpty()) {
                    return true;
                }
                String actual = BuiltInRegistries.ITEM.getKey(player.getMainHandItem().getItem()).toString();
                return itemIds.stream().anyMatch(actual::equalsIgnoreCase);
            }
        };
    }

    public MolangPlayerQueryProvider(@Nullable Access access) {
        this.player = null;
        this.access = access;
    }

    @Override
    public @Nullable MolangRuntime.MolangValue getQueryValue(String normalizedPath) {
        if (this.access == null) {
            return null;
        }

        // Input-mode and premium-skin queries do not have a stable Java-side API equivalent here.
        return switch (normalizedPath) {
            case MolangQueryNames.IS_LOCAL_PLAYER -> bool(this.access.isLocalPlayer());
            case MolangQueryNames.IS_FIRST_PERSON -> bool(this.access.isFirstPerson());
            case MolangQueryNames.IS_SPECTATOR -> bool(this.access.isSpectator());
            case MolangQueryNames.HAS_CAPE -> bool(this.access.hasCape());
            case MolangQueryNames.PLAYER_LEVEL -> number(this.access.getPlayerLevel());
            case MolangQueryNames.TOUCH_ONLY_AFFECTS_HOTBAR -> bool(this.access.isTouchOnlyAffectsHotbar());
            case MolangQueryNames.SKIN_ID -> skinId();
            default -> null;
        };
    }

    @Override
    public @Nullable MolangRuntime.MolangValue callQuery(String normalizedName, List<MolangRuntime.MolangValue> args) {
        if (this.access == null) {
            return null;
        }

        return switch (normalizedName) {
            case MolangQueryNames.LAST_INPUT_MODE_IS_ANY -> lastInputModeIsAny(args);
            case MolangQueryNames.IS_SELECTED_ITEM -> isSelectedItem(args);
            default -> null;
        };
    }

    private MolangRuntime.MolangValue skinId() {
        if (this.access != null && this.access.getSkinId() != null) {
            return MolangRuntime.MolangValue.string(this.access.getSkinId());
        }
        return MolangRuntime.MolangValue.NULL;
    }

    private MolangRuntime.MolangValue lastInputModeIsAny(List<MolangRuntime.MolangValue> args) {
        if (this.access == null) {
            return MolangRuntime.MolangValue.FALSE;
        }
        String current = this.access.getLastInputMode();
        for (MolangRuntime.MolangValue arg : args) {
            if (current.equalsIgnoreCase(arg.asString())) {
                return MolangRuntime.MolangValue.TRUE;
            }
        }
        return MolangRuntime.MolangValue.FALSE;
    }

    private MolangRuntime.MolangValue isSelectedItem(List<MolangRuntime.MolangValue> args) {
        if (this.access == null) {
            return MolangRuntime.MolangValue.FALSE;
        }
        List<String> ids = args.stream().map(MolangRuntime.MolangValue::asString).toList();
        return bool(this.access.isSelectedItem(ids));
    }

    private static MolangRuntime.MolangValue bool(boolean value) {
        return value ? MolangRuntime.MolangValue.TRUE : MolangRuntime.MolangValue.FALSE;
    }

    private static MolangRuntime.MolangValue number(double value) {
        return MolangRuntime.MolangValue.number(value);
    }
}
