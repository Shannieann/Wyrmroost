package dev.elifian.chaoslib.molang;

import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.Supplier;

public final class MolangRuntime {
    private MolangRuntime() {
    }

    public static MolangExpression constant(double value) {
        return new ConstantExpression(MolangValue.number(value));
    }

    public static MolangExpression constant(String value) {
        return new ConstantExpression(MolangValue.string(value));
    }

    public static boolean isConstant(MolangExpression expression) {
        return expression instanceof ConstantExpression;
    }

    public static MolangValue constantValue(MolangExpression expression) {
        return expression instanceof ConstantExpression constant ? constant.value : MolangValue.NULL;
    }

    public static MolangExpression parse(String source) {
        return new Parser(source).parseProgram();
    }

    @FunctionalInterface
    public interface MolangExpression {
        MolangValue evaluate(Context context);

        default double evaluateNumber(Context context) {
            return this.evaluate(context).asNumber();
        }
    }

    private static final class ConstantExpression implements MolangExpression {
        private final MolangValue value;

        private ConstantExpression(MolangValue value) {
            this.value = value;
        }

        @Override
        public MolangValue evaluate(Context context) {
            return this.value;
        }
    }

    public interface Context {
        MolangValue get(String path);

        void set(String path, MolangValue value);

        void setLazy(String path, Supplier<MolangValue> valueSupplier);

        MolangValue call(String name, List<MolangValue> args);

        Context branch(@Nullable MolangValue thisValue);
    }

    public static class MutableContext implements Context {
        private static final Map<String, String> ALIASES = Map.of(
                "q", "query",
                "v", "variable",
                "t", "temp",
                "c", "context"
        );
        private static final MutableContext ROOT = createRootContext();

        private final Scope scope;
        private final @Nullable MutableContext parent;
        private final Map<String, MolangValue> queryValueCache = new HashMap<>();
        private final Map<QueryCallKey, MolangValue> queryCallCache = new HashMap<>();
        private MolangQueryResolver queryResolver;
        private MolangValue thisValue = MolangValue.NULL;

        public MutableContext() {
            this(new Scope(), ROOT);
        }

        private MutableContext(Scope scope, @Nullable MutableContext parent) {
            this.scope = scope;
            this.parent = parent;
            this.queryResolver = parent == null ? MolangQueryResolvers.standard() : parent.queryResolver;
            if (parent == null) {
                seedConstants();
            }
        }

        private static MutableContext createRootContext() {
            return new MutableContext(new Scope(), null);
        }

        public MutableContext withValue(String path, double value) {
            set(path, MolangValue.number(value));
            return this;
        }

        public MutableContext withValue(String path, String value) {
            set(path, MolangValue.string(value));
            return this;
        }

        public MutableContext withValue(String path, MolangValue value) {
            set(path, value);
            return this;
        }

        public MutableContext withValueSupplier(String path, Supplier<MolangValue> valueSupplier) {
            setLazy(path, valueSupplier);
            return this;
        }

        public MutableContext withReadonlyValue(String path, double value) {
            setReadonly(path, MolangValue.number(value));
            return this;
        }

        public MutableContext withReadonlyValue(String path, String value) {
            setReadonly(path, MolangValue.string(value));
            return this;
        }

        public MutableContext withReadonlyValue(String path, MolangValue value) {
            setReadonly(path, value);
            return this;
        }

        public MutableContext withReadonlyValueSupplier(String path, Supplier<MolangValue> valueSupplier) {
            setReadonlyLazy(path, valueSupplier);
            return this;
        }

        public MutableContext withThis(MolangValue value) {
            this.thisValue = value == null ? MolangValue.NULL : value;
            return this;
        }

        public MutableContext withQueryResolver(MolangQueryResolver queryResolver) {
            this.queryResolver = queryResolver == null ? MolangQueryResolvers.empty() : queryResolver;
            clearQueryCaches();
            return this;
        }

        protected final void clearLocalState() {
            this.scope.clear();
            this.thisValue = MolangValue.NULL;
            clearQueryCaches();
        }

        public MutableContext reset() {
            clearLocalState();
            return this;
        }

        @Override
        public MolangValue get(String path) {
            String normalized = normalizePath(path);
            if ("this".equals(normalized)) {
                return this.thisValue;
            }

            MolangValue local = this.scope.get(normalized);
            if (local != null) {
                return local;
            }

            if (normalized.startsWith("query.") && this.queryResolver != null) {
                if (shouldCacheQueryValue(normalized)) {
                    MolangValue cached = this.queryValueCache.get(normalized);
                    if (cached != null) {
                        return cached;
                    }
                }
                MolangValue resolved = this.queryResolver.resolveValue(normalized, this);
                if (resolved != null) {
                    if (shouldCacheQueryValue(normalized)) {
                        this.queryValueCache.put(normalized, resolved);
                    }
                    return resolved;
                }
            }

            if (this.parent != null) {
                return this.parent.get(normalized);
            }

            return MolangValue.NULL;
        }

        @Override
        public void set(String path, MolangValue value) {
            String normalized = normalizePath(path);
            if (!isAssignable(normalized)) {
                return;
            }
            this.scope.set(normalized, value == null ? MolangValue.NULL : value, false);
        }

        @Override
        public void setLazy(String path, Supplier<MolangValue> valueSupplier) {
            String normalized = normalizePath(path);
            if (!isAssignable(normalized)) {
                return;
            }
            this.scope.setLazy(normalized, valueSupplier, false);
        }

        protected final void setReadonly(String path, MolangValue value) {
            this.scope.set(normalizePath(path), value == null ? MolangValue.NULL : value, true);
        }

        protected final void setReadonlyNormalized(String normalizedPath, MolangValue value) {
            this.scope.set(normalizedPath, value == null ? MolangValue.NULL : value, true);
        }

        protected final void setReadonlyLazy(String path, Supplier<MolangValue> valueSupplier) {
            this.scope.setLazy(normalizePath(path), valueSupplier, true);
        }

        @Override
        public MolangValue call(String name, List<MolangValue> args) {
            String normalized = normalizePath(name);
            if (normalized.startsWith("query.") && this.queryResolver != null) {
                QueryCallKey cacheKey = null;
                if (shouldCacheQueryCall(normalized, args)) {
                    cacheKey = QueryCallKey.of(normalized, args);
                    MolangValue cached = this.queryCallCache.get(cacheKey);
                    if (cached != null) {
                        return cached;
                    }
                }
                MolangValue resolved = this.queryResolver.resolveCall(normalized, args, this);
                if (resolved != null) {
                    if (cacheKey != null) {
                        this.queryCallCache.put(cacheKey, resolved);
                    }
                    return resolved;
                }
            }
            return MolangBuiltins.call(normalized, args);
        }

        @Override
        public Context branch(@Nullable MolangValue thisValue) {
            MutableContext child = new MutableContext(new Scope(), this);
            child.thisValue = thisValue == null ? this.thisValue : thisValue;
            child.queryResolver = this.queryResolver;
            return child;
        }

        protected boolean isAssignable(String path) {
            return path.startsWith("temp.") || path.startsWith("variable.") || path.startsWith("context.");
        }

        protected void clearQueryCaches() {
            this.queryValueCache.clear();
            this.queryCallCache.clear();
        }

        protected final void cacheQueryValueNormalized(String normalizedPath, MolangValue value) {
            this.queryValueCache.put(normalizedPath, value == null ? MolangValue.NULL : value);
        }

        protected boolean shouldCacheQueryValue(String normalizedPath) {
            return true;
        }

        protected boolean shouldCacheQueryCall(String normalizedName, List<MolangValue> args) {
            return true;
        }

        private void seedConstants() {
            setReadonly("math.pi", MolangValue.number(Math.PI));
            setReadonly("math.e", MolangValue.number(Math.E));
            setReadonly("true", MolangValue.number(1.0d));
            setReadonly("false", MolangValue.number(0.0d));
        }

        protected static String normalizePath(String path) {
            if (path == null || path.isBlank()) {
                return "";
            }
            String lower = path.toLowerCase(Locale.ROOT);
            int dot = lower.indexOf('.');
            if (dot < 0) {
                return ALIASES.getOrDefault(lower, lower);
            }
            String head = lower.substring(0, dot);
            String alias = ALIASES.getOrDefault(head, head);
            return alias + lower.substring(dot);
        }

        private record QueryCallKey(String normalizedName, List<QueryCallArg> args) {
            private static QueryCallKey of(String normalizedName, List<MolangValue> args) {
                ArrayList<QueryCallArg> keyArgs = new ArrayList<>(args.size());
                for (MolangValue arg : args) {
                    keyArgs.add(QueryCallArg.of(arg));
                }
                return new QueryCallKey(normalizedName, List.copyOf(keyArgs));
            }
        }

        private record QueryCallArg(MolangValue.Type type, double numberValue, String stringValue) {
            private static QueryCallArg of(MolangValue value) {
                MolangValue actual = value == null ? MolangValue.NULL : value;
                return new QueryCallArg(actual.type(), actual.asNumber(), actual.asString());
            }
        }
    }

    public static final class MolangValue {
        private static final int INTEGER_CACHE_LOW = -64;
        private static final int INTEGER_CACHE_HIGH = 256;
        private static final MolangValue[] INTEGER_CACHE = createIntegerCache();
        public static final MolangValue NULL = new MolangValue(Type.NULL, 0.0d, null);
        public static final MolangValue ZERO = INTEGER_CACHE[-INTEGER_CACHE_LOW];
        public static final MolangValue ONE = INTEGER_CACHE[1 - INTEGER_CACHE_LOW];
        public static final MolangValue TRUE = ONE;
        public static final MolangValue FALSE = ZERO;
        private static final MolangValue EMPTY_STRING = new MolangValue(Type.STRING, 0.0d, "");

        private final Type type;
        private final double numberValue;
        private final Object value;

        private MolangValue(Type type, double numberValue, Object value) {
            this.type = type;
            this.numberValue = numberValue;
            this.value = value;
        }

        public static MolangValue number(double value) {
            if (value == 0.0d) {
                return ZERO;
            }
            if (value == 1.0d) {
                return ONE;
            }
            if (value >= INTEGER_CACHE_LOW && value <= INTEGER_CACHE_HIGH && value == Math.rint(value)) {
                return INTEGER_CACHE[(int) value - INTEGER_CACHE_LOW];
            }
            return new MolangValue(Type.NUMBER, value, null);
        }

        public static MolangValue string(String value) {
            String normalized = value == null ? "" : value;
            return normalized.isEmpty() ? EMPTY_STRING : new MolangValue(Type.STRING, 0.0d, normalized);
        }

        public static MolangValue array(List<MolangValue> values) {
            return new MolangValue(Type.ARRAY, 0.0d, List.copyOf(values));
        }

        public static MolangValue object(Map<String, MolangValue> values) {
            LinkedHashMap<String, MolangValue> copy = new LinkedHashMap<>();
            for (Map.Entry<String, MolangValue> entry : values.entrySet()) {
                copy.put(MutableContext.normalizePath(entry.getKey()), entry.getValue());
            }
            return new MolangValue(Type.OBJECT, 0.0d, copy);
        }

        public Type type() {
            return this.type;
        }

        public boolean isNull() {
            return this.type == Type.NULL;
        }

        public double asNumber() {
            return switch (this.type) {
                case NUMBER -> this.numberValue;
                case STRING -> parseNumber((String) this.value);
                case ARRAY -> ((List<?>) this.value).isEmpty() ? 0.0d : 1.0d;
                case OBJECT -> 1.0d;
                case NULL -> 0.0d;
            };
        }

        public String asString() {
            return switch (this.type) {
                case NUMBER -> trimDouble(this.numberValue);
                case STRING -> (String) this.value;
                case ARRAY -> "array";
                case OBJECT -> "object";
                case NULL -> "";
            };
        }

        public boolean isTruthy() {
            return switch (this.type) {
                case STRING -> !((String) this.value).isEmpty();
                case ARRAY -> !((List<?>) this.value).isEmpty();
                case OBJECT -> true;
                case NUMBER -> this.numberValue != 0.0d;
                case NULL -> false;
            };
        }

        public MolangValue getMember(String member) {
            if (this.type != Type.OBJECT) {
                return NULL;
            }
            Map<String, MolangValue> members = asObjectMap();
            return members.getOrDefault(MutableContext.normalizePath(member), NULL);
        }

        public MolangValue index(MolangValue index) {
            if (this.type == Type.ARRAY) {
                List<MolangValue> values = asArray();
                if (values.isEmpty()) {
                    return NULL;
                }
                int i = clampIndex(index.asNumber(), values.size());
                return values.get(i);
            }
            if (this.type == Type.STRING) {
                String string = (String) this.value;
                if (string.isEmpty()) {
                    return NULL;
                }
                int i = clampIndex(index.asNumber(), string.length());
                return string(String.valueOf(string.charAt(i)));
            }
            if (this.type == Type.OBJECT) {
                return getMember(index.asString());
            }
            return NULL;
        }

        @SuppressWarnings("unchecked")
        public List<MolangValue> asArray() {
            return this.type == Type.ARRAY ? (List<MolangValue>) this.value : List.of();
        }

        @SuppressWarnings("unchecked")
        public Map<String, MolangValue> asObjectMap() {
            return this.type == Type.OBJECT ? (Map<String, MolangValue>) this.value : Map.of();
        }

        private static MolangValue[] createIntegerCache() {
            MolangValue[] cache = new MolangValue[INTEGER_CACHE_HIGH - INTEGER_CACHE_LOW + 1];
            for (int i = 0; i < cache.length; i++) {
                int value = INTEGER_CACHE_LOW + i;
                cache[i] = new MolangValue(Type.NUMBER, value, null);
            }
            return cache;
        }

        private static double parseNumber(String value) {
            try {
                return Double.parseDouble(value);
            } catch (NumberFormatException ignored) {
                return 0.0d;
            }
        }

        private static String trimDouble(double value) {
            long longValue = (long) value;
            return longValue == value ? Long.toString(longValue) : Double.toString(value);
        }

        private static int clampIndex(double index, int size) {
            if (size <= 0) {
                return 0;
            }
            int converted = (int) index;
            if (converted < 0) {
                return 0;
            }
            return Math.min(size - 1, converted);
        }

        public enum Type {
            NUMBER,
            STRING,
            ARRAY,
            OBJECT,
            NULL
        }
    }

    private static final class Scope {
        private final Map<String, MolangValue> values = new HashMap<>();
        private final Map<String, Supplier<MolangValue>> lazyValues = new HashMap<>();
        private final Set<String> readonly = new HashSet<>();

        private void clear() {
            this.values.clear();
            this.lazyValues.clear();
            this.readonly.clear();
        }

        private @Nullable MolangValue get(String path) {
            Supplier<MolangValue> lazyValue = this.lazyValues.get(path);
            if (lazyValue != null) {
                MolangValue resolved = lazyValue.get();
                return resolved == null ? MolangValue.NULL : resolved;
            }
            int dot = path.indexOf('.');
            if (dot < 0) {
                return this.values.get(path);
            }

            MolangValue current = this.values.get(path.substring(0, dot));
            if (current == null) {
                return null;
            }

            int partStart = dot + 1;
            while (partStart <= path.length()) {
                if (current.type() != MolangValue.Type.OBJECT) {
                    return null;
                }

                int nextDot = path.indexOf('.', partStart);
                String part = nextDot < 0 ? path.substring(partStart) : path.substring(partStart, nextDot);
                current = current.asObjectMap().get(part);
                if (current == null || current.isNull()) {
                    return null;
                }

                if (nextDot < 0) {
                    return current;
                }
                partStart = nextDot + 1;
            }

            return current;
        }

        private void set(String path, MolangValue value, boolean readonly) {
            if (this.readonly.contains(path)) {
                return;
            }
            this.lazyValues.remove(path);

            String[] parts = path.split("\\.");
            if (parts.length == 1) {
                this.values.put(parts[0], value);
                if (readonly) {
                    this.readonly.add(path);
                }
                return;
            }

            MolangValue root = this.values.get(parts[0]);
            LinkedHashMap<String, MolangValue> map = root != null && root.type() == MolangValue.Type.OBJECT
                    ? new LinkedHashMap<>(root.asObjectMap())
                    : new LinkedHashMap<>();
            putNested(map, parts, 1, value);
            this.values.put(parts[0], MolangValue.object(map));
            if (readonly) {
                this.readonly.add(path);
            }
        }

        private void setLazy(String path, Supplier<MolangValue> valueSupplier, boolean readonly) {
            if (this.readonly.contains(path)) {
                return;
            }

            this.lazyValues.put(path, valueSupplier == null ? () -> MolangValue.NULL : valueSupplier);
            if (readonly) {
                this.readonly.add(path);
            }
        }

        private static void putNested(Map<String, MolangValue> map, String[] parts, int index, MolangValue value) {
            String key = MutableContext.normalizePath(parts[index]);
            if (index == parts.length - 1) {
                map.put(key, value);
                return;
            }

            MolangValue nested = map.get(key);
            LinkedHashMap<String, MolangValue> nestedMap = nested != null && nested.type() == MolangValue.Type.OBJECT
                    ? new LinkedHashMap<>(nested.asObjectMap())
                    : new LinkedHashMap<>();
            putNested(nestedMap, parts, index + 1, value);
            map.put(key, MolangValue.object(nestedMap));
        }
    }

    private static final class Parser {
        private final List<Token> tokens;
        private int index;

        private Parser(String source) {
            this.tokens = new Tokenizer(source).tokenize();
        }

        private MolangExpression parseProgram() {
            List<Executable> statements = parseStatements(TokenType.EOF);
            return context -> executeStatements(statements, context, false);
        }

        private List<Executable> parseStatements(TokenType terminator) {
            ArrayList<Executable> statements = new ArrayList<>();
            while (!check(terminator) && !check(TokenType.EOF)) {
                statements.add(parseStatement());
                match(TokenType.SEMICOLON);
            }
            return statements;
        }

        private Executable parseStatement() {
            if (match(TokenType.RETURN)) {
                MolangExpression expression = parseExpression();
                return context -> {
                    throw new ReturnSignal(expression.evaluate(context));
                };
            }
            if (match(TokenType.BREAK)) {
                return context -> {
                    throw BreakSignal.INSTANCE;
                };
            }
            if (match(TokenType.CONTINUE)) {
                return context -> {
                    throw ContinueSignal.INSTANCE;
                };
            }
            if (check(TokenType.LEFT_BRACE)) {
                MolangExpression block = parseBlock();
                return block::evaluate;
            }
            MolangExpression expression = parseExpression();
            return expression::evaluate;
        }

        private MolangExpression parseBlock() {
            expect(TokenType.LEFT_BRACE);
            List<Executable> statements = parseStatements(TokenType.RIGHT_BRACE);
            expect(TokenType.RIGHT_BRACE);
            return context -> executeStatements(statements, context.branch(null), true);
        }

        private MolangExpression parseExpression() {
            return parseAssignment();
        }

        private MolangExpression parseAssignment() {
            MolangExpression expression = parseBinaryConditional();
            if (!match(TokenType.ASSIGN)) {
                return expression;
            }

            if (!(expression instanceof AssignableExpression assignable)) {
                throw error("assignment target must be assignable");
            }
            MolangExpression right = parseAssignment();
            return context -> {
                MolangValue value = right.evaluate(context);
                assignable.assign(context, value);
                return value;
            };
        }

        private MolangExpression parseBinaryConditional() {
            MolangExpression condition = parseCoalesce();
            if (!match(TokenType.QUESTION)) {
                return condition;
            }
            MolangExpression ifTrue = parseAssignment();
            if (match(TokenType.COLON)) {
                MolangExpression ifFalse = parseAssignment();
                return context -> condition.evaluate(context).isTruthy() ? ifTrue.evaluate(context) : ifFalse.evaluate(context);
            }
            return context -> condition.evaluate(context).isTruthy() ? ifTrue.evaluate(context) : MolangValue.NULL;
        }

        private MolangExpression parseCoalesce() {
            MolangExpression expression = parseOr();
            while (match(TokenType.COALESCE)) {
                MolangExpression left = expression;
                MolangExpression right = parseOr();
                expression = context -> {
                    MolangValue value = left.evaluate(context);
                    return value.isNull() ? right.evaluate(context) : value;
                };
            }
            return expression;
        }

        private MolangExpression parseOr() {
            MolangExpression expression = parseAnd();
            while (match(TokenType.OR)) {
                MolangExpression left = expression;
                MolangExpression right = parseAnd();
                expression = context -> MolangValue.number(left.evaluate(context).isTruthy() || right.evaluate(context).isTruthy() ? 1.0d : 0.0d);
            }
            return expression;
        }

        private MolangExpression parseAnd() {
            MolangExpression expression = parseEquality();
            while (match(TokenType.AND)) {
                MolangExpression left = expression;
                MolangExpression right = parseEquality();
                expression = context -> MolangValue.number(left.evaluate(context).isTruthy() && right.evaluate(context).isTruthy() ? 1.0d : 0.0d);
            }
            return expression;
        }

        private MolangExpression parseEquality() {
            MolangExpression expression = parseComparison();
            while (true) {
                if (match(TokenType.EQUAL)) {
                    MolangExpression left = expression;
                    MolangExpression right = parseComparison();
                    expression = context -> MolangValue.number(equalsValue(left.evaluate(context), right.evaluate(context)) ? 1.0d : 0.0d);
                } else if (match(TokenType.NOT_EQUAL)) {
                    MolangExpression left = expression;
                    MolangExpression right = parseComparison();
                    expression = context -> MolangValue.number(!equalsValue(left.evaluate(context), right.evaluate(context)) ? 1.0d : 0.0d);
                } else {
                    return expression;
                }
            }
        }

        private MolangExpression parseComparison() {
            MolangExpression expression = parseAdditive();
            while (true) {
                if (match(TokenType.LESS)) {
                    MolangExpression left = expression;
                    MolangExpression right = parseAdditive();
                    expression = context -> MolangValue.number(left.evaluate(context).asNumber() < right.evaluate(context).asNumber() ? 1.0d : 0.0d);
                } else if (match(TokenType.LESS_EQUAL)) {
                    MolangExpression left = expression;
                    MolangExpression right = parseAdditive();
                    expression = context -> MolangValue.number(left.evaluate(context).asNumber() <= right.evaluate(context).asNumber() ? 1.0d : 0.0d);
                } else if (match(TokenType.GREATER)) {
                    MolangExpression left = expression;
                    MolangExpression right = parseAdditive();
                    expression = context -> MolangValue.number(left.evaluate(context).asNumber() > right.evaluate(context).asNumber() ? 1.0d : 0.0d);
                } else if (match(TokenType.GREATER_EQUAL)) {
                    MolangExpression left = expression;
                    MolangExpression right = parseAdditive();
                    expression = context -> MolangValue.number(left.evaluate(context).asNumber() >= right.evaluate(context).asNumber() ? 1.0d : 0.0d);
                } else {
                    return expression;
                }
            }
        }

        private MolangExpression parseAdditive() {
            MolangExpression expression = parseMultiplicative();
            while (true) {
                if (match(TokenType.PLUS)) {
                    MolangExpression left = expression;
                    MolangExpression right = parseMultiplicative();
                    expression = context -> add(left.evaluate(context), right.evaluate(context));
                } else if (match(TokenType.MINUS)) {
                    MolangExpression left = expression;
                    MolangExpression right = parseMultiplicative();
                    expression = context -> MolangValue.number(left.evaluate(context).asNumber() - right.evaluate(context).asNumber());
                } else {
                    return expression;
                }
            }
        }

        private MolangExpression parseMultiplicative() {
            MolangExpression expression = parseUnary();
            while (true) {
                if (match(TokenType.STAR)) {
                    MolangExpression left = expression;
                    MolangExpression right = parseUnary();
                    expression = context -> MolangValue.number(left.evaluate(context).asNumber() * right.evaluate(context).asNumber());
                } else if (match(TokenType.SLASH)) {
                    MolangExpression left = expression;
                    MolangExpression right = parseUnary();
                    expression = context -> {
                        double denominator = right.evaluate(context).asNumber();
                        return MolangValue.number(denominator == 0.0d ? 0.0d : left.evaluate(context).asNumber() / denominator);
                    };
                } else if (match(TokenType.PERCENT)) {
                    MolangExpression left = expression;
                    MolangExpression right = parseUnary();
                    expression = context -> {
                        double denominator = right.evaluate(context).asNumber();
                        return MolangValue.number(denominator == 0.0d ? 0.0d : left.evaluate(context).asNumber() % denominator);
                    };
                } else {
                    return expression;
                }
            }
        }

        private MolangExpression parseUnary() {
            if (match(TokenType.NOT)) {
                MolangExpression expression = parseUnary();
                return context -> MolangValue.number(expression.evaluate(context).isTruthy() ? 0.0d : 1.0d);
            }
            if (match(TokenType.MINUS)) {
                MolangExpression expression = parseUnary();
                return context -> MolangValue.number(-expression.evaluate(context).asNumber());
            }
            if (match(TokenType.PLUS)) {
                return parseUnary();
            }
            return parsePostfix(parsePrimary());
        }

        private MolangExpression parsePrimary() {
            if (match(TokenType.LEFT_BRACE)) {
                this.index--;
                return parseBlock();
            }

            Token token = advance();
            return switch (token.type) {
                case NUMBER -> constant(Double.parseDouble(token.lexeme));
                case STRING -> constant(token.literal);
                case IDENTIFIER -> parseIdentifier(token.lexeme);
                case LEFT_PAREN -> {
                    MolangExpression expression = parseExpression();
                    expect(TokenType.RIGHT_PAREN);
                    yield expression;
                }
                default -> throw error("unexpected token '" + token.lexeme + "'");
            };
        }

        private MolangExpression parseIdentifier(String name) {
            if ("loop".equals(name) && check(TokenType.LEFT_PAREN)) {
                return parseLoop();
            }
            if ("for_each".equals(name) && check(TokenType.LEFT_PAREN)) {
                return parseForEach();
            }
            if ("return".equals(name)) {
                return context -> MolangValue.NULL;
            }
            if (check(TokenType.LEFT_PAREN)) {
                return parseCall(new VariableAccess(name));
            }
            return new VariableAccess(name);
        }

        private MolangExpression parseLoop() {
            expect(TokenType.LEFT_PAREN);
            MolangExpression countExpression = parseExpression();
            expect(TokenType.COMMA);
            MolangExpression body = parseBlock();
            expect(TokenType.RIGHT_PAREN);
            return context -> {
                int count = Math.max(0, (int) countExpression.evaluate(context).asNumber());
                MolangValue last = MolangValue.NULL;
                for (int i = 0; i < count; i++) {
                    try {
                        last = body.evaluate(context.branch(null));
                    } catch (ContinueSignal ignored) {
                        continue;
                    } catch (BreakSignal ignored) {
                        break;
                    }
                }
                return last;
            };
        }

        private MolangExpression parseForEach() {
            expect(TokenType.LEFT_PAREN);
            MolangExpression target = parseExpression();
            if (!(target instanceof AssignableExpression assignable)) {
                throw error("for_each first argument must be assignable");
            }
            expect(TokenType.COMMA);
            MolangExpression iterableExpression = parseExpression();
            expect(TokenType.COMMA);
            MolangExpression body = parseBlock();
            expect(TokenType.RIGHT_PAREN);
            return context -> {
                List<MolangValue> items = iterableExpression.evaluate(context).asArray();
                MolangValue last = MolangValue.NULL;
                for (MolangValue item : items) {
                    Context child = context.branch(item);
                    assignable.assign(child, item);
                    try {
                        last = body.evaluate(child);
                    } catch (ContinueSignal ignored) {
                        continue;
                    } catch (BreakSignal ignored) {
                        break;
                    }
                }
                return last;
            };
        }

        private MolangExpression parsePostfix(MolangExpression base) {
            MolangExpression expression = base;
            while (true) {
                if (check(TokenType.LEFT_PAREN)) {
                    expression = parseCall(expression);
                    continue;
                }
                if (match(TokenType.LEFT_BRACKET)) {
                    MolangExpression indexExpression = parseExpression();
                    expect(TokenType.RIGHT_BRACKET);
                    MolangExpression target = expression;
                    expression = context -> target.evaluate(context).index(indexExpression.evaluate(context));
                    continue;
                }
                if (match(TokenType.ARROW)) {
                    expression = parseArrow(expression);
                    continue;
                }
                return expression;
            }
        }

        private MolangExpression parseCall(MolangExpression callee) {
            expect(TokenType.LEFT_PAREN);
            ArrayList<MolangExpression> arguments = new ArrayList<>();
            if (!check(TokenType.RIGHT_PAREN)) {
                do {
                    arguments.add(parseExpression());
                } while (match(TokenType.COMMA));
            }
            expect(TokenType.RIGHT_PAREN);

            if (!(callee instanceof VariableAccess variableAccess)) {
                return context -> MolangValue.NULL;
            }

            return context -> {
                ArrayList<MolangValue> values = new ArrayList<>(arguments.size());
                for (MolangExpression argument : arguments) {
                    values.add(argument.evaluate(context));
                }
                return context.call(variableAccess.path, values);
            };
        }

        private MolangExpression parseArrow(MolangExpression left) {
            MolangExpression right = parsePostfix(parsePrimary());
            return context -> {
                MolangValue target = left.evaluate(context);
                if (target.isNull()) {
                    return MolangValue.NULL;
                }
                return right.evaluate(new ArrowContext(context, target));
            };
        }

        private boolean match(TokenType type) {
            if (!check(type)) {
                return false;
            }
            this.index++;
            return true;
        }

        private boolean check(TokenType type) {
            return peek().type == type;
        }

        private Token expect(TokenType type) {
            if (!check(type)) {
                throw error("expected " + type + " but found '" + peek().lexeme + "'");
            }
            return advance();
        }

        private Token advance() {
            return this.tokens.get(this.index++);
        }

        private Token peek() {
            return this.tokens.get(this.index);
        }

        private IllegalArgumentException error(String message) {
            return new IllegalArgumentException("Invalid Molang expression: " + message);
        }

        private static MolangValue add(MolangValue left, MolangValue right) {
            if (left.type() == MolangValue.Type.STRING || right.type() == MolangValue.Type.STRING) {
                return MolangValue.string(left.asString() + right.asString());
            }
            return MolangValue.number(left.asNumber() + right.asNumber());
        }

        private static boolean equalsValue(MolangValue left, MolangValue right) {
            if (left.type() == MolangValue.Type.STRING || right.type() == MolangValue.Type.STRING) {
                return left.asString().equals(right.asString());
            }
            return Double.compare(left.asNumber(), right.asNumber()) == 0;
        }

        private static MolangValue executeStatements(List<Executable> statements, Context context, boolean isolatedBlock) {
            MolangValue value = MolangValue.NULL;
            try {
                for (Executable statement : statements) {
                    value = statement.execute(context);
                }
                return value;
            } catch (ReturnSignal signal) {
                if (isolatedBlock) {
                    throw signal;
                }
                return signal.value;
            }
        }
    }

    private interface Executable {
        MolangValue execute(Context context);
    }

    private interface AssignableExpression extends MolangExpression {
        void assign(Context context, MolangValue value);
    }

    private static final class VariableAccess implements AssignableExpression {
        private final String path;

        private VariableAccess(String path) {
            this.path = MutableContext.normalizePath(path);
        }

        @Override
        public MolangValue evaluate(Context context) {
            return context.get(this.path);
        }

        @Override
        public void assign(Context context, MolangValue value) {
            context.set(this.path, value);
        }
    }

    private static final class ArrowContext implements Context {
        private final Context parent;
        private final MolangValue target;

        private ArrowContext(Context parent, MolangValue target) {
            this.parent = parent;
            this.target = target;
        }

        @Override
        public MolangValue get(String path) {
            String normalized = MutableContext.normalizePath(path);
            if ("this".equals(normalized)) {
                return this.target;
            }
            MolangValue candidate = resolveInTarget(normalized);
            return candidate.isNull() ? this.parent.get(normalized) : candidate;
        }

        @Override
        public void set(String path, MolangValue value) {
            this.parent.set(path, value);
        }

        @Override
        public void setLazy(String path, Supplier<MolangValue> valueSupplier) {
            this.parent.setLazy(path, valueSupplier);
        }

        @Override
        public MolangValue call(String name, List<MolangValue> args) {
            return this.parent.call(name, args);
        }

        @Override
        public Context branch(@Nullable MolangValue thisValue) {
            return this.parent.branch(thisValue == null ? this.target : thisValue);
        }

        private MolangValue resolveInTarget(String path) {
            String[] parts = path.split("\\.");
            MolangValue current = this.target;
            for (String part : parts) {
                current = current.getMember(part);
                if (current.isNull()) {
                    return MolangValue.NULL;
                }
            }
            return current;
        }
    }

    private static final class Tokenizer {
        private final String source;
        private final int length;
        private int index;

        private Tokenizer(String source) {
            this.source = source;
            this.length = source.length();
        }

        private List<Token> tokenize() {
            ArrayList<Token> tokens = new ArrayList<>();
            while (this.index < this.length) {
                char current = this.source.charAt(this.index);
                if (Character.isWhitespace(current)) {
                    this.index++;
                    continue;
                }
                if (Character.isDigit(current) || current == '.') {
                    tokens.add(readNumber());
                    continue;
                }
                if (current == '\'' || current == '"') {
                    tokens.add(readString(current));
                    continue;
                }
                if (Character.isLetter(current) || current == '_') {
                    tokens.add(readIdentifier());
                    continue;
                }

                switch (current) {
                    case '+' -> tokens.add(single(TokenType.PLUS));
                    case '-' -> tokens.add(match('>') ? token(TokenType.ARROW, "->") : single(TokenType.MINUS));
                    case '*' -> tokens.add(single(TokenType.STAR));
                    case '/' -> tokens.add(single(TokenType.SLASH));
                    case '%' -> tokens.add(single(TokenType.PERCENT));
                    case '!' -> tokens.add(match('=') ? token(TokenType.NOT_EQUAL, "!=") : single(TokenType.NOT));
                    case '&' -> {
                        expect('&');
                        tokens.add(token(TokenType.AND, "&&"));
                    }
                    case '|' -> {
                        expect('|');
                        tokens.add(token(TokenType.OR, "||"));
                    }
                    case '=' -> tokens.add(match('=') ? token(TokenType.EQUAL, "==") : single(TokenType.ASSIGN));
                    case '<' -> tokens.add(match('=') ? token(TokenType.LESS_EQUAL, "<=") : single(TokenType.LESS));
                    case '>' ->
                            tokens.add(match('=') ? token(TokenType.GREATER_EQUAL, ">=") : single(TokenType.GREATER));
                    case '(' -> tokens.add(single(TokenType.LEFT_PAREN));
                    case ')' -> tokens.add(single(TokenType.RIGHT_PAREN));
                    case '[' -> tokens.add(single(TokenType.LEFT_BRACKET));
                    case ']' -> tokens.add(single(TokenType.RIGHT_BRACKET));
                    case '{' -> tokens.add(single(TokenType.LEFT_BRACE));
                    case '}' -> tokens.add(single(TokenType.RIGHT_BRACE));
                    case ',' -> tokens.add(single(TokenType.COMMA));
                    case ';' -> tokens.add(single(TokenType.SEMICOLON));
                    case ':' -> tokens.add(single(TokenType.COLON));
                    case '?' -> tokens.add(match('?') ? token(TokenType.COALESCE, "??") : single(TokenType.QUESTION));
                    default ->
                            throw new IllegalArgumentException("Invalid Molang expression: unexpected character '" + current + "'");
                }
                this.index++;
            }
            tokens.add(new Token(TokenType.EOF, "", null));
            return tokens;
        }

        private Token readNumber() {
            int start = this.index++;
            while (this.index < this.length) {
                char next = this.source.charAt(this.index);
                if (!Character.isDigit(next) && next != '.') {
                    break;
                }
                this.index++;
            }
            return token(TokenType.NUMBER, this.source.substring(start, this.index));
        }

        private Token readString(char quote) {
            int start = ++this.index;
            StringBuilder builder = new StringBuilder();
            while (this.index < this.length) {
                char current = this.source.charAt(this.index++);
                if (current == quote) {
                    return new Token(TokenType.STRING, this.source.substring(start - 1, this.index), builder.toString());
                }
                if (current == '\\' && this.index < this.length) {
                    char escaped = this.source.charAt(this.index++);
                    builder.append(switch (escaped) {
                        case 'n' -> '\n';
                        case 't' -> '\t';
                        case '\\' -> '\\';
                        case '\'' -> '\'';
                        case '"' -> '"';
                        default -> escaped;
                    });
                    continue;
                }
                builder.append(current);
            }
            throw new IllegalArgumentException("Invalid Molang expression: unterminated string");
        }

        private Token readIdentifier() {
            int start = this.index++;
            while (this.index < this.length) {
                char next = this.source.charAt(this.index);
                if (!Character.isLetterOrDigit(next) && next != '_' && next != '.') {
                    break;
                }
                this.index++;
            }
            String lexeme = this.source.substring(start, this.index).toLowerCase(Locale.ROOT);
            TokenType type = switch (lexeme) {
                case "return" -> TokenType.RETURN;
                case "break" -> TokenType.BREAK;
                case "continue" -> TokenType.CONTINUE;
                default -> TokenType.IDENTIFIER;
            };
            return new Token(type, lexeme, null);
        }

        private Token single(TokenType type) {
            return token(type, String.valueOf(this.source.charAt(this.index)));
        }

        private Token token(TokenType type, String lexeme) {
            return new Token(type, lexeme, null);
        }

        private boolean match(char expected) {
            return this.index + 1 < this.length && this.source.charAt(this.index + 1) == expected;
        }

        private void expect(char expected) {
            if (!match(expected)) {
                throw new IllegalArgumentException("Invalid Molang expression: expected '" + expected + "'");
            }
        }
    }

    private record Token(TokenType type, String lexeme, @Nullable String literal) {
    }

    private enum TokenType {
        NUMBER,
        STRING,
        IDENTIFIER,
        RETURN,
        BREAK,
        CONTINUE,
        PLUS,
        MINUS,
        STAR,
        SLASH,
        PERCENT,
        NOT,
        AND,
        OR,
        EQUAL,
        NOT_EQUAL,
        LESS,
        LESS_EQUAL,
        GREATER,
        GREATER_EQUAL,
        ASSIGN,
        ARROW,
        COALESCE,
        QUESTION,
        COLON,
        COMMA,
        SEMICOLON,
        LEFT_PAREN,
        RIGHT_PAREN,
        LEFT_BRACKET,
        RIGHT_BRACKET,
        LEFT_BRACE,
        RIGHT_BRACE,
        EOF
    }

    private static final class ReturnSignal extends RuntimeException {
        private final MolangValue value;

        private ReturnSignal(MolangValue value) {
            this.value = value;
        }
    }

    private static final class BreakSignal extends RuntimeException {
        private static final BreakSignal INSTANCE = new BreakSignal();
    }

    private static final class ContinueSignal extends RuntimeException {
        private static final ContinueSignal INSTANCE = new ContinueSignal();
    }
}
