package dev.elifian.chaoslib.molang;

import org.jetbrains.annotations.Nullable;

import java.util.List;

public interface MolangQueryResolver {
    @Nullable MolangRuntime.MolangValue resolveValue(String normalizedPath, MolangRuntime.Context context);

    @Nullable MolangRuntime.MolangValue resolveCall(String normalizedName, List<MolangRuntime.MolangValue> args, MolangRuntime.Context context);
}
