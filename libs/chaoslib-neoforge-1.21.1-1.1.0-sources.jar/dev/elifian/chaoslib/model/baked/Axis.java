package dev.elifian.chaoslib.model.baked;


import dev.elifian.chaoslib.platform.ClientOnly;

@ClientOnly
public enum Axis {
    X,
    Y,
    Z
}
