package dev.elifian.chaoslib.model.baked;

import dev.elifian.chaoslib.cache.object.BakedGeoModel;
import dev.elifian.chaoslib.cache.object.GeoBone;
import dev.elifian.chaoslib.cache.object.GeoCube;
import dev.elifian.chaoslib.cache.object.GeoQuad;
import dev.elifian.chaoslib.cache.object.GeoVertex;
import dev.elifian.chaoslib.api.model.GeoModel;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.block.model.ItemOverrides;
import net.minecraft.client.renderer.block.model.ItemTransforms;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;

import dev.elifian.chaoslib.platform.ClientOnly;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;

@ClientOnly
public class StaticGeoBakedModel implements BakedModel {
    private final Map<String, Map<StaticGeoRenderMode, LayeredQuadBuckets>> quadsByVariant;
    private final Function<String, Map<StaticGeoRenderMode, LayeredQuadBuckets>> variantBaker;
    private final StaticGeoRenderModeSelector renderModeSelector;
    private final Function<BlockState, String> variantSelector;
    private final Function<BlockState, RenderType> renderLayerSelector;
    private final Predicate<BlockState> staticEmissiveSelector;
    private final TextureAtlasSprite particleSprite;
    private final boolean ambientOcclusion;
    private final boolean depth;
    private final boolean sideLit;
    private final ItemTransforms transformation;
    private final Matrix4f postTransformation;
    private final ItemOverrides overrides;

    protected StaticGeoBakedModel(
            Map<String, Map<StaticGeoRenderMode, LayeredQuadBuckets>> quadsByVariant,
            @Nullable Function<String, Map<StaticGeoRenderMode, LayeredQuadBuckets>> variantBaker,
            StaticGeoRenderModeSelector renderModeSelector,
            Function<BlockState, String> variantSelector,
            Function<BlockState, RenderType> renderLayerSelector,
            Predicate<BlockState> staticEmissiveSelector,
            TextureAtlasSprite particleSprite,
            boolean ambientOcclusion,
            boolean depth,
            boolean sideLit,
            ItemTransforms transformation,
            @Nullable Matrix4f postTransformation,
            ItemOverrides overrides
    ) {
        ConcurrentHashMap<String, Map<StaticGeoRenderMode, LayeredQuadBuckets>> variantMap = new ConcurrentHashMap<>();
        quadsByVariant.forEach((variantKey, byMode) -> {
            EnumMap<StaticGeoRenderMode, LayeredQuadBuckets> modeMap = new EnumMap<>(StaticGeoRenderMode.class);
            byMode.forEach((mode, quads) -> modeMap.put(mode, quads.freeze()));
            variantMap.put(variantKey, Map.copyOf(modeMap));
        });
        this.quadsByVariant = variantMap;
        this.variantBaker = variantBaker == null ? null : variantKey -> freezeVariant(variantBaker.apply(variantKey));
        this.renderModeSelector = renderModeSelector;
        this.variantSelector = variantSelector;
        this.renderLayerSelector = renderLayerSelector;
        this.staticEmissiveSelector = staticEmissiveSelector;
        this.particleSprite = particleSprite;
        this.ambientOcclusion = ambientOcclusion;
        this.depth = depth;
        this.sideLit = sideLit;
        this.transformation = transformation;
        this.postTransformation = postTransformation == null ? null : new Matrix4f(postTransformation);
        this.overrides = overrides;
    }

    public static Map<StaticGeoRenderMode, LayeredQuadBuckets> bakeQuadsByMode(
            BakedGeoModel model,
            Matrix4f rootTransform,
            TextureAtlasSprite sprite,
            Map<StaticGeoRenderMode, Set<String>> includedBonesByMode,
            Map<String, StaticGeoBonePose> staticBonePoses,
            StaticGeoQuadCullingMode quadCullingMode,
            ResourceLocation textureId,
            boolean emissiveBake
    ) {
        return bakeQuadsByMode(model, rootTransform, sprite, includedBonesByMode, staticBonePoses, quadCullingMode, textureId, null, emissiveBake, 0);
    }

    public static Map<StaticGeoRenderMode, LayeredQuadBuckets> bakeQuadsByMode(
            BakedGeoModel model,
            Matrix4f rootTransform,
            TextureAtlasSprite sprite,
            Map<StaticGeoRenderMode, Set<String>> includedBonesByMode,
            Map<String, StaticGeoBonePose> staticBonePoses,
            StaticGeoQuadCullingMode quadCullingMode,
            ResourceLocation textureId,
            @Nullable RenderType forcedRenderLayer,
            boolean emissiveBake
    ) {
        return bakeQuadsByMode(model, rootTransform, sprite, includedBonesByMode, staticBonePoses, quadCullingMode, textureId, forcedRenderLayer, emissiveBake, 0);
    }

    public static Map<StaticGeoRenderMode, LayeredQuadBuckets> bakeQuadsByMode(
            BakedGeoModel model,
            Matrix4f rootTransform,
            TextureAtlasSprite sprite,
            Map<StaticGeoRenderMode, Set<String>> includedBonesByMode,
            Map<String, StaticGeoBonePose> staticBonePoses,
            StaticGeoQuadCullingMode quadCullingMode,
            ResourceLocation textureId,
            boolean emissiveBake,
            int emissivePassIndex
    ) {
        return bakeQuadsByMode(model, rootTransform, sprite, includedBonesByMode, staticBonePoses, quadCullingMode, textureId, null, emissiveBake, emissivePassIndex);
    }

    public static Map<StaticGeoRenderMode, LayeredQuadBuckets> bakeQuadsByMode(
            BakedGeoModel model,
            Matrix4f rootTransform,
            TextureAtlasSprite sprite,
            Map<StaticGeoRenderMode, Set<String>> includedBonesByMode,
            Map<String, StaticGeoBonePose> staticBonePoses,
            StaticGeoQuadCullingMode quadCullingMode,
            ResourceLocation textureId,
            @Nullable RenderType forcedRenderLayer,
            boolean emissiveBake,
            int emissivePassIndex
    ) {
        EnumMap<StaticGeoRenderMode, LayeredQuadBuckets> quadsByMode = new EnumMap<>(StaticGeoRenderMode.class);
        GeoModel.TextureTransparencyProfile transparency = GeoModel.TextureTransparencyProfile.get(textureId);
        for (Map.Entry<StaticGeoRenderMode, Set<String>> entry : includedBonesByMode.entrySet()) {
            LayeredQuadBuckets quads = new LayeredQuadBuckets();
            Matrix4f[] matrixStack = new Matrix4f[Math.max(model.orderedBones().size() + 1, 2)];
            for (int i = 0; i < matrixStack.length; i++) {
                matrixStack[i] = new Matrix4f();
            }

            matrixStack[0].set(rootTransform);
            emitBones(model.topLevelBones(), quads, matrixStack, 1, sprite, entry.getValue(), staticBonePoses, quadCullingMode, transparency, forcedRenderLayer, emissiveBake, emissivePassIndex);
            quadsByMode.put(entry.getKey(), quads);
        }

        return quadsByMode;
    }

    public static StaticGeoBakedModel create(
            BakedGeoModel model,
            Map<String, Map<StaticGeoRenderMode, LayeredQuadBuckets>> quadsByVariant,
            TextureAtlasSprite particleSprite,
            StaticGeoRenderModeSelector renderModeSelector,
            Function<BlockState, String> variantSelector,
            Function<BlockState, RenderType> renderLayerSelector,
            Predicate<BlockState> staticEmissiveSelector,
            boolean ambientOcclusion,
            boolean depth,
            boolean sideLit,
            ItemTransforms transformation,
            @Nullable Matrix4f postTransformation,
            ItemOverrides overrides
    ) {
        if (particleSprite == null) {
            throw new IllegalStateException("Missing particle sprite for ChaosLib static baked model");
        }
        return new StaticGeoBakedModel(quadsByVariant, null, renderModeSelector, variantSelector, renderLayerSelector, staticEmissiveSelector, particleSprite, ambientOcclusion, depth, sideLit, transformation, postTransformation, overrides);
    }

    public static StaticGeoBakedModel createLazy(
            BakedGeoModel model,
            Map<String, Map<StaticGeoRenderMode, LayeredQuadBuckets>> eagerlyPreparedVariants,
            Function<String, Map<StaticGeoRenderMode, LayeredQuadBuckets>> variantBaker,
            TextureAtlasSprite particleSprite,
            StaticGeoRenderModeSelector renderModeSelector,
            Function<BlockState, String> variantSelector,
            Function<BlockState, RenderType> renderLayerSelector,
            Predicate<BlockState> staticEmissiveSelector,
            boolean ambientOcclusion,
            boolean depth,
            boolean sideLit,
            ItemTransforms transformation,
            @Nullable Matrix4f postTransformation,
            ItemOverrides overrides
    ) {
        if (particleSprite == null) {
            throw new IllegalStateException("Missing particle sprite for ChaosLib static baked model");
        }
        return new StaticGeoBakedModel(eagerlyPreparedVariants, variantBaker, renderModeSelector, variantSelector, renderLayerSelector, staticEmissiveSelector, particleSprite, ambientOcclusion, depth, sideLit, transformation, postTransformation, overrides);
    }

    @Override
    public List<BakedQuad> getQuads(BlockState state, Direction face, RandomSource random) {
        return this.getQuads(state, face, null, null);
    }

    public List<BakedQuad> getQuads(@Nullable BlockState state, @Nullable Direction face,
                                    @Nullable GeoStaticModelData.State staticState, @Nullable RenderType renderType) {
        LayeredQuadBuckets buckets = resolveBuckets(state, staticState);
        if (buckets == null) {
            return List.of();
        }
        return buckets.get(renderType, face, this.staticEmissiveSelector.test(state));
    }

    @Override
    public boolean useAmbientOcclusion() {
        return this.ambientOcclusion;
    }

    @Override
    public boolean isGui3d() {
        return this.depth;
    }

    @Override
    public boolean usesBlockLight() {
        return this.sideLit;
    }

    @Override
    public boolean isCustomRenderer() {
        return false;
    }

    @Override
    public TextureAtlasSprite getParticleIcon() {
        return this.particleSprite;
    }

    @Override
    public ItemTransforms getTransforms() {
        return this.transformation;
    }

    @Override
    public ItemOverrides getOverrides() {
        return this.overrides;
    }

    public BakedModel applyTransform(ItemDisplayContext transformType, PoseStack poseStack, boolean applyLeftHandTransform) {
        this.transformation.getTransform(transformType).apply(applyLeftHandTransform, poseStack);
        if (this.postTransformation != null) {
            poseStack.mulPose(this.postTransformation);
        }
        return this;
    }

    public List<RenderType> getRenderLayers(BlockState state, @Nullable GeoStaticModelData.State staticState) {
        LayeredQuadBuckets buckets = resolveBuckets(state, staticState);
        RenderType fallbackLayer = sanitizeChunkRenderLayer(this.renderLayerSelector.apply(state));
        if (buckets == null) {
            return List.of(fallbackLayer);
        }

        Collection<RenderType> layers = buckets.renderLayers(this.staticEmissiveSelector.test(state));
        return layers.isEmpty() ? List.of(fallbackLayer) : List.copyOf(layers);
    }

    private static void emitBones(
            Iterable<GeoBone> bones,
            LayeredQuadBuckets quads,
            Matrix4f[] matrixStack,
            int depth,
            TextureAtlasSprite sprite,
            Set<String> includedBones,
            Map<String, StaticGeoBonePose> staticBonePoses,
            StaticGeoQuadCullingMode quadCullingMode,
            GeoModel.TextureTransparencyProfile transparency,
            @Nullable RenderType forcedRenderLayer,
            boolean emissiveBake,
            int emissivePassIndex
    ) {
        Matrix4f parentMatrix = matrixStack[depth - 1];

        for (GeoBone bone : bones) {
            StaticGeoBonePose pose = staticBonePoses.getOrDefault(bone.getName(), StaticGeoBonePose.IDENTITY);
            float posX = bone.getPosX() + pose.posX();
            float posY = bone.getPosY() + pose.posY();
            float posZ = bone.getPosZ() + pose.posZ();
            float rotX = bone.getRotX() + pose.rotX();
            float rotY = bone.getRotY() + pose.rotY();
            float rotZ = bone.getRotZ() + pose.rotZ();
            float scaleX = bone.getScaleX() * pose.scaleX();
            float scaleY = bone.getScaleY() * pose.scaleY();
            float scaleZ = bone.getScaleZ() * pose.scaleZ();
            Matrix4f boneMatrix = matrixStack[depth]
                    .set(parentMatrix)
                    .translate(-posX / 16.0f, posY / 16.0f, posZ / 16.0f)
                    .translate(bone.getPivotX() / 16.0f, bone.getPivotY() / 16.0f, bone.getPivotZ() / 16.0f)
                    .rotateZ(rotZ)
                    .rotateY(rotY)
                    .rotateX(rotX)
                    .scale(scaleX, scaleY, scaleZ)
                    .translate(-bone.getPivotX() / 16.0f, -bone.getPivotY() / 16.0f, -bone.getPivotZ() / 16.0f);

            if (!pose.hidden() && (includedBones == null || includedBones.contains(bone.getName()))) {
                for (GeoCube cube : bone.getCubes()) {
                    emitCube(quads, boneMatrix, cube, sprite, quadCullingMode, transparency, forcedRenderLayer, emissiveBake, emissivePassIndex);
                }
            }

            emitBones(bone.getChildBones(), quads, matrixStack, depth + 1, sprite, includedBones, staticBonePoses, quadCullingMode, transparency, forcedRenderLayer, emissiveBake, emissivePassIndex);
        }
    }

    private static void emitCube(LayeredQuadBuckets quads, Matrix4f boneMatrix, GeoCube cube, TextureAtlasSprite sprite, StaticGeoQuadCullingMode quadCullingMode, GeoModel.TextureTransparencyProfile transparency, @Nullable RenderType forcedRenderLayer, boolean emissiveBake, int emissivePassIndex) {
        Matrix4f cubeMatrix = new Matrix4f(boneMatrix)
                .translate((float) cube.pivot().x() / 16.0f, (float) cube.pivot().y() / 16.0f, (float) cube.pivot().z() / 16.0f)
                .rotateZ((float) cube.rotation().z())
                .rotateY((float) cube.rotation().y())
                .rotateX((float) cube.rotation().x())
                .translate((float) -cube.pivot().x() / 16.0f, (float) -cube.pivot().y() / 16.0f, (float) -cube.pivot().z() / 16.0f);
        Matrix3f normalMatrix = new Matrix3f(cubeMatrix);

        for (GeoQuad quad : cube.quads()) {
            if (quad != null) {
                BuiltQuad builtQuad = buildQuad(cubeMatrix, normalMatrix, quad, sprite, quadCullingMode, transparency, forcedRenderLayer, emissiveBake, emissivePassIndex, false);
                quads.add(builtQuad.renderLayer(), builtQuad.quad(), builtQuad.cullFace(), emissiveBake);

                if (!transparency.isOpaque(quad)) {
                    BuiltQuad backQuad = buildQuad(cubeMatrix, normalMatrix, quad, sprite, quadCullingMode, transparency, forcedRenderLayer, emissiveBake, emissivePassIndex, true);
                    quads.add(backQuad.renderLayer(), backQuad.quad(), null, emissiveBake);
                }
            }
        }
    }

    private static BuiltQuad buildQuad(Matrix4f matrix, Matrix3f normalMatrix, GeoQuad quad, TextureAtlasSprite sprite, StaticGeoQuadCullingMode quadCullingMode, GeoModel.TextureTransparencyProfile transparency, @Nullable RenderType forcedRenderLayer, boolean emissiveBake, int emissivePassIndex, boolean backFace) {
        int[] data = new int[4 * StaticGeoVertexFormat.STRIDE];
        Vector3f normal = new Vector3f(quad.normalX(), quad.normalY(), quad.normalZ());
        normalMatrix.transform(normal).normalize();
        if (backFace) {
            normal.negate();
        }
        Vector3f positionOffset = emissiveBake
                ? new Vector3f(normal).mul(0.0005f * (emissivePassIndex + 1))
                : null;
        int packedNormal = packNormal(normal);

        for (int i = 0; i < 4; i++) {
            GeoVertex vertex = quad.vertices()[backFace ? 3 - i : i];
            Vector4f transformed = matrix.transform(new Vector4f(vertex.x(), vertex.y(), vertex.z(), 1.0f));
            if (positionOffset != null) {
                transformed.add(positionOffset.x(), positionOffset.y(), positionOffset.z(), 0.0f);
            }
            int offset = i * StaticGeoVertexFormat.STRIDE;
            data[offset + StaticGeoVertexFormat.POSITION] = Float.floatToRawIntBits(transformed.x());
            data[offset + StaticGeoVertexFormat.POSITION + 1] = Float.floatToRawIntBits(transformed.y());
            data[offset + StaticGeoVertexFormat.POSITION + 2] = Float.floatToRawIntBits(transformed.z());
            data[offset + StaticGeoVertexFormat.COLOR] = -1;
            data[offset + StaticGeoVertexFormat.UV0] = Float.floatToRawIntBits(sprite.getU(vertex.texU()));
            data[offset + StaticGeoVertexFormat.UV0 + 1] = Float.floatToRawIntBits(sprite.getV(vertex.texV()));

            if (StaticGeoVertexFormat.UV1 >= 0) {
                data[offset + StaticGeoVertexFormat.UV1] = 0;
            }
            if (StaticGeoVertexFormat.UV2 >= 0) {
                data[offset + StaticGeoVertexFormat.UV2] = 0;
            }
            if (StaticGeoVertexFormat.NORMAL >= 0) {
                data[offset + StaticGeoVertexFormat.NORMAL] = packedNormal;
            }
        }

        Direction cullFace = backFace ? null : resolveCullFace(transformedVertices(quad, matrix), normal, quadCullingMode);
        RenderType renderLayer = selectStaticRenderLayer(quad, transparency, forcedRenderLayer);
        BakedQuad bakedQuad = new BakedQuad(data, -1, facingFromNormal(normal), sprite, false);
        if (emissiveBake) {
            StaticGeoVertexFormat.setMaxEmissivity(data);
        }
        return new BuiltQuad(bakedQuad, cullFace, renderLayer);
    }

    protected LayeredQuadBuckets resolveBuckets(@Nullable BlockState state, @Nullable GeoStaticModelData.State staticState) {
        StaticGeoRenderMode mode = staticState != null && staticState.renderMode() != null
                ? staticState.renderMode()
                : this.renderModeSelector.select(state);
        String variantKey = staticState != null && staticState.variantKey() != null
                ? staticState.variantKey()
                : this.variantSelector.apply(state);
        Map<StaticGeoRenderMode, LayeredQuadBuckets> byMode = resolveVariant(variantKey);
        return byMode == null ? null : byMode.get(mode);
    }

    private Map<StaticGeoRenderMode, LayeredQuadBuckets> resolveVariant(@Nullable String variantKey) {
        String resolvedVariantKey = variantKey == null ? "default" : variantKey;
        Map<StaticGeoRenderMode, LayeredQuadBuckets> byMode = this.quadsByVariant.get(resolvedVariantKey);
        if (byMode != null) {
            return byMode;
        }
        if (this.variantBaker != null) {
            byMode = this.quadsByVariant.computeIfAbsent(resolvedVariantKey, this.variantBaker);
            if (byMode != null) {
                return byMode;
            }
        }
        String normalized = normalizeVariantKey(resolvedVariantKey);
        if (normalized != null) {
            byMode = this.quadsByVariant.get(normalized);
            if (byMode != null) {
                return byMode;
            }
        }
        return this.quadsByVariant.get("default");
    }

    private String normalizeVariantKey(String variantKey) {
        if (variantKey == null || variantKey.isEmpty() || "default".equals(variantKey)) {
            return "default";
        }

        Map<String, String> values = parseVariantValues(variantKey);
        if (values.isEmpty()) {
            return null;
        }

        String bestKey = null;
        int bestSize = -1;
        for (String candidate : this.quadsByVariant.keySet()) {
            Map<String, String> candidateValues = parseVariantValues(candidate);
            if (candidateValues.isEmpty()) {
                continue;
            }

            boolean matches = true;
            for (Map.Entry<String, String> entry : candidateValues.entrySet()) {
                String value = values.get(entry.getKey());
                if (!entry.getValue().equals(value)) {
                    matches = false;
                    break;
                }
            }
            if (!matches) {
                continue;
            }

            int size = candidateValues.size();
            if (size > bestSize) {
                bestSize = size;
                bestKey = candidate;
            }
        }

        return bestKey;
    }

    private static Map<String, String> parseVariantValues(String variantKey) {
        if (variantKey == null || variantKey.isEmpty()) {
            return Map.of();
        }

        LinkedHashMap<String, String> values = new LinkedHashMap<>();
        String[] parts = variantKey.split("[|,]");
        for (String part : parts) {
            if (part.isEmpty()) {
                continue;
            }

            int separator = part.indexOf('=');
            if (separator <= 0 || separator == part.length() - 1) {
                continue;
            }

            values.put(part.substring(0, separator), part.substring(separator + 1));
        }
        return values;
    }

    private static Map<StaticGeoRenderMode, LayeredQuadBuckets> freezeVariant(Map<StaticGeoRenderMode, LayeredQuadBuckets> byMode) {
        if (byMode == null) {
            return null;
        }

        EnumMap<StaticGeoRenderMode, LayeredQuadBuckets> modeMap = new EnumMap<>(StaticGeoRenderMode.class);
        byMode.forEach((mode, quads) -> modeMap.put(mode, quads.freeze()));
        return Map.copyOf(modeMap);
    }

    private static Vector4f[] transformedVertices(GeoQuad quad, Matrix4f matrix) {
        Vector4f[] transformed = new Vector4f[4];
        for (int i = 0; i < 4; i++) {
            GeoVertex vertex = quad.vertices()[i];
            transformed[i] = matrix.transform(new Vector4f(vertex.x(), vertex.y(), vertex.z(), 1.0f));
        }
        return transformed;
    }

    private static Direction resolveCullFace(Vector4f[] vertices, Vector3f normal, StaticGeoQuadCullingMode quadCullingMode) {
        if (quadCullingMode == StaticGeoQuadCullingMode.FORCE_NO_CULL) {
            return null;
        }

        if (quadCullingMode == StaticGeoQuadCullingMode.FORCE_CULL) {
            return facingFromNormal(normal);
        }

        final float epsilon = 1.0e-4f;

        if (isPlane(vertices, 0, 0.0f, epsilon) && normal.x() < -0.999f) {
            return Direction.WEST;
        }
        if (isPlane(vertices, 0, 1.0f, epsilon) && normal.x() > 0.999f) {
            return Direction.EAST;
        }
        if (isPlane(vertices, 1, 0.0f, epsilon) && normal.y() < -0.999f) {
            return Direction.DOWN;
        }
        if (isPlane(vertices, 1, 1.0f, epsilon) && normal.y() > 0.999f) {
            return Direction.UP;
        }
        if (isPlane(vertices, 2, 0.0f, epsilon) && normal.z() < -0.999f) {
            return Direction.NORTH;
        }
        if (isPlane(vertices, 2, 1.0f, epsilon) && normal.z() > 0.999f) {
            return Direction.SOUTH;
        }

        return null;
    }

    private static RenderType selectStaticRenderLayer(GeoQuad quad, GeoModel.TextureTransparencyProfile transparency, @Nullable RenderType forcedRenderLayer) {
        if (forcedRenderLayer != null) {
            return forcedRenderLayer;
        }

        if (transparency.isOpaque(quad)) {
            return RenderType.solid();
        }

        return transparency.isTranslucent(quad) ? RenderType.translucent() : RenderType.cutout();
    }

    private static RenderType sanitizeChunkRenderLayer(@Nullable RenderType layer) {
        return layer != null && RenderType.chunkBufferLayers().contains(layer) ? layer : RenderType.cutout();
    }

    private static boolean isPlane(Vector4f[] vertices, int axis, float value, float epsilon) {
        for (Vector4f vertex : vertices) {
            float coordinate = switch (axis) {
                case 0 -> vertex.x();
                case 1 -> vertex.y();
                default -> vertex.z();
            };

            if (Math.abs(coordinate - value) > epsilon) {
                return false;
            }
        }

        return true;
    }

    private static Direction facingFromNormal(Vector3f normal) {
        float absX = Math.abs(normal.x());
        float absY = Math.abs(normal.y());
        float absZ = Math.abs(normal.z());

        if (absY >= absX && absY >= absZ) {
            return normal.y() >= 0.0f ? Direction.UP : Direction.DOWN;
        }

        if (absZ >= absX) {
            return normal.z() >= 0.0f ? Direction.SOUTH : Direction.NORTH;
        }

        return normal.x() >= 0.0f ? Direction.EAST : Direction.WEST;
    }

    private static int packNormal(Vector3f normal) {
        int x = ((byte) (normal.x() * 127.0f)) & 0xFF;
        int y = (((byte) (normal.y() * 127.0f)) & 0xFF) << 8;
        int z = (((byte) (normal.z() * 127.0f)) & 0xFF) << 16;
        return x | y | z;
    }

    public static final class QuadBuckets {
        private final EnumMap<Direction, List<BakedQuad>> culled = new EnumMap<>(Direction.class);
        private final List<BakedQuad> unculled = new ArrayList<>();

        public void add(BakedQuad quad, Direction face) {
            if (face == null) {
                this.unculled.add(quad);
                return;
            }

            this.culled.computeIfAbsent(face, ignored -> new ArrayList<>()).add(quad);
        }

        public List<BakedQuad> get(Direction face) {
            if (face == null) {
                return this.unculled;
            }

            return this.culled.getOrDefault(face, List.of());
        }

        public QuadBuckets freeze() {
            QuadBuckets frozen = new QuadBuckets();
            this.culled.forEach((face, quads) -> frozen.culled.put(face, List.copyOf(quads)));
            frozen.unculled.addAll(List.copyOf(this.unculled));
            return frozen;
        }

        public void mergeFrom(QuadBuckets other) {
            other.culled.forEach((face, quads) -> this.culled.computeIfAbsent(face, ignored -> new ArrayList<>()).addAll(quads));
            this.unculled.addAll(other.unculled);
        }
    }

    public static final class LayeredQuadBuckets {
        private final Map<RenderType, QuadBuckets> baseBucketsByLayer = new LinkedHashMap<>();
        private final Map<RenderType, QuadBuckets> emissiveBucketsByLayer = new LinkedHashMap<>();
        private Map<QueryKey, List<BakedQuad>> queryCache = Map.of();
        private Collection<RenderType> baseRenderLayers = List.of();
        private Collection<RenderType> allRenderLayers = List.of();

        public void add(RenderType layer, BakedQuad quad, Direction cullFace, boolean emissive) {
            Map<RenderType, QuadBuckets> target = emissive ? this.emissiveBucketsByLayer : this.baseBucketsByLayer;
            target.computeIfAbsent(layer, ignored -> new QuadBuckets()).add(quad, cullFace);
            invalidateCaches();
        }

        public List<BakedQuad> get(@Nullable RenderType layer, @Nullable Direction face, boolean includeEmissive) {
            QueryKey key = new QueryKey(layer, face, includeEmissive);
            List<BakedQuad> cached = this.queryCache.get(key);
            if (cached != null) {
                return cached;
            }

            List<BakedQuad> resolved = buildQueryResult(layer, face, includeEmissive);
            if (this.queryCache.isEmpty()) {
                this.queryCache = new HashMap<>();
            }
            this.queryCache.put(key, resolved);
            return resolved;
        }

        public Collection<RenderType> renderLayers(boolean includeEmissive) {
            return includeEmissive ? this.allRenderLayers : this.baseRenderLayers;
        }

        public void mergeFrom(LayeredQuadBuckets other) {
            other.baseBucketsByLayer.forEach((layer, buckets) ->
                    this.baseBucketsByLayer.computeIfAbsent(layer, ignored -> new QuadBuckets()).mergeFrom(buckets)
            );
            other.emissiveBucketsByLayer.forEach((layer, buckets) ->
                    this.emissiveBucketsByLayer.computeIfAbsent(layer, ignored -> new QuadBuckets()).mergeFrom(buckets)
            );
            invalidateCaches();
        }

        public LayeredQuadBuckets freeze() {
            LayeredQuadBuckets frozen = new LayeredQuadBuckets();
            this.baseBucketsByLayer.forEach((layer, buckets) -> frozen.baseBucketsByLayer.put(layer, buckets.freeze()));
            this.emissiveBucketsByLayer.forEach((layer, buckets) -> frozen.emissiveBucketsByLayer.put(layer, buckets.freeze()));
            frozen.rebuildRenderLayerCaches();
            return frozen;
        }

        private List<BakedQuad> buildQueryResult(@Nullable RenderType layer, @Nullable Direction face, boolean includeEmissive) {
            ArrayList<BakedQuad> result = new ArrayList<>();
            if (layer == null) {
                this.baseBucketsByLayer.values().forEach(buckets -> result.addAll(buckets.get(face)));
                if (includeEmissive) {
                    this.emissiveBucketsByLayer.values().forEach(buckets -> result.addAll(buckets.get(face)));
                }
            } else {
                QuadBuckets baseBuckets = this.baseBucketsByLayer.get(layer);
                if (baseBuckets != null) {
                    result.addAll(baseBuckets.get(face));
                }
                if (includeEmissive) {
                    QuadBuckets emissiveBuckets = this.emissiveBucketsByLayer.get(layer);
                    if (emissiveBuckets != null) {
                        result.addAll(emissiveBuckets.get(face));
                    }
                }
            }

            return result.isEmpty() ? List.of() : List.copyOf(result);
        }

        private void rebuildRenderLayerCaches() {
            this.baseRenderLayers = List.copyOf(this.baseBucketsByLayer.keySet());
            LinkedHashSet<RenderType> layers = new LinkedHashSet<>(this.baseBucketsByLayer.keySet());
            layers.addAll(this.emissiveBucketsByLayer.keySet());
            this.allRenderLayers = List.copyOf(layers);
            this.queryCache = new HashMap<>();
        }

        private void invalidateCaches() {
            this.queryCache = Map.of();
            this.baseRenderLayers = List.of();
            this.allRenderLayers = List.of();
        }
    }

    private record QueryKey(@Nullable RenderType layer, @Nullable Direction face, boolean includeEmissive) {
    }

    private record BuiltQuad(BakedQuad quad, Direction cullFace, RenderType renderLayer) {
    }

}
