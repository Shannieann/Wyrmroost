package dev.elifian.chaoslib.model.baked;

import org.jetbrains.annotations.Nullable;

public final class GeoStaticModelData {
    private GeoStaticModelData() {
    }

    public record State(@Nullable StaticGeoRenderMode renderMode, @Nullable String variantKey) {
        public boolean isEmpty() {
            return this.renderMode == null && this.variantKey == null;
        }
    }
}
