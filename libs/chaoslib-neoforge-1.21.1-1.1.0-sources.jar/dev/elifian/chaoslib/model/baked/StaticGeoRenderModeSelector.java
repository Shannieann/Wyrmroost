package dev.elifian.chaoslib.model.baked;

import net.minecraft.world.level.block.state.BlockState;

import dev.elifian.chaoslib.platform.ClientOnly;
import org.jetbrains.annotations.Nullable;

@ClientOnly
@FunctionalInterface
public interface StaticGeoRenderModeSelector {
    StaticGeoRenderMode select(@Nullable BlockState state);
}
