package dev.elifian.chaoslib.model.baked;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormatElement;
import dev.elifian.chaoslib.platform.ClientOnly;

/**
 * Offsets into the packed vertex data of a {@code BakedQuad}, in ints, derived from the vanilla
 * block format. Mirrors what NeoForge exposes as {@code IQuadTransformer}, without the dependency.
 */
@ClientOnly
public final class StaticGeoVertexFormat {
    public static final int STRIDE = DefaultVertexFormat.BLOCK.getVertexSize() / Integer.BYTES;
    public static final int POSITION = offsetOf(VertexFormatElement.POSITION);
    public static final int COLOR = offsetOf(VertexFormatElement.COLOR);
    public static final int UV0 = offsetOf(VertexFormatElement.UV0);
    public static final int UV1 = offsetOf(VertexFormatElement.UV1);
    public static final int UV2 = offsetOf(VertexFormatElement.UV2);
    public static final int NORMAL = offsetOf(VertexFormatElement.NORMAL);

    private static final int FULL_BRIGHT_LIGHT = 0x00F000F0;

    private StaticGeoVertexFormat() {
    }

    /**
     * Raises every vertex's lightmap to full brightness, the way an emissive bake needs it.
     */
    public static void setMaxEmissivity(int[] vertexData) {
        if (UV2 < 0) {
            return;
        }

        for (int vertex = 0; vertex < 4; vertex++) {
            vertexData[vertex * STRIDE + UV2] = FULL_BRIGHT_LIGHT;
        }
    }

    private static int offsetOf(VertexFormatElement element) {
        int offset = DefaultVertexFormat.BLOCK.getOffset(element);
        return offset < 0 ? -1 : offset / Integer.BYTES;
    }
}
