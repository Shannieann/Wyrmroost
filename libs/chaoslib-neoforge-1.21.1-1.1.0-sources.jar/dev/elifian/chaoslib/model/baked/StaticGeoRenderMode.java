package dev.elifian.chaoslib.model.baked;


import dev.elifian.chaoslib.platform.ClientOnly;

@ClientOnly
public enum StaticGeoRenderMode {
    NONE,
    ALL_BONES,
    STATIC_ONLY
}
