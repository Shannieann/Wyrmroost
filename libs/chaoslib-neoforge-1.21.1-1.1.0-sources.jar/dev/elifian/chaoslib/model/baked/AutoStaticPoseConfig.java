package dev.elifian.chaoslib.model.baked;

import dev.elifian.chaoslib.cache.object.BakedGeoModel;
import dev.elifian.chaoslib.cache.object.GeoBone;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.IntegerProperty;

import dev.elifian.chaoslib.platform.ClientOnly;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@ClientOnly
public final class AutoStaticPoseConfig {
    private static final Pattern TRAILING_DIGITS = Pattern.compile("^(.*?)(\\d+)$");
    private static final float FULL_TURN = (float) (Math.PI * 2.0);
    private static final AutoStaticPoseConfig EMPTY = new AutoStaticPoseConfig(List.of());

    private final List<Rule> rules;

    private AutoStaticPoseConfig(List<Rule> rules) {
        this.rules = rules;
    }

    public static AutoStaticPoseConfig empty() {
        return EMPTY;
    }

    public static AutoStaticPoseConfig create() {
        return empty();
    }

    public boolean isEmpty() {
        return this.rules.isEmpty();
    }

    public AutoStaticPoseConfig quantize(String boneName, Axis axis, int steps, float from, float to) {
        return append(new TranslationRule(boneName, axis, steps, from, to));
    }

    public AutoStaticPoseConfig quantizeRotation(String boneName, Axis axis, int steps) {
        return quantizeRotation(boneName, axis, steps, 0.0f, FULL_TURN);
    }

    public AutoStaticPoseConfig quantizeRotation(String boneName, Axis axis, int steps, float from, float to) {
        return append(new RotationRule(boneName, axis, steps, from, to));
    }

    public StaticGeoStatePoseProfile createStatePoseProfile(@Nullable BlockState templateState) {
        if (templateState == null || this.rules.isEmpty()) {
            return StaticGeoStatePoseProfile.empty();
        }

        Map<IntegerProperty, List<Rule>> rulesByProperty = new LinkedHashMap<>();
        for (Rule rule : this.rules) {
            IntegerProperty property = resolveProperty(templateState, rule);
            if (property == null) {
                continue;
            }

            rulesByProperty.computeIfAbsent(property, ignored -> new ArrayList<>()).add(rule);
        }

        if (rulesByProperty.isEmpty()) {
            return StaticGeoStatePoseProfile.empty();
        }

        StaticGeoStatePoseProfile.Builder builder = StaticGeoStatePoseProfile.builder();
        for (Map.Entry<IntegerProperty, List<Rule>> entry : rulesByProperty.entrySet()) {
            builder.addPropertyPoses(entry.getKey(), value -> buildPropertyPoses(entry.getValue(), value));
        }
        return builder.build();
    }

    public Object createCurrentPoseCacheKey(BakedGeoModel model) {
        if (model == null || this.rules.isEmpty()) {
            return "default";
        }

        int[] buckets = new int[this.rules.size()];
        int index = 0;
        for (Rule rule : this.rules) {
            GeoBone bone = model.getBone(rule.boneName()).orElse(null);
            buckets[index++] = rule.quantizeCurrent(bone);
        }
        return new BucketKey(buckets);
    }

    private static final class BucketKey {
        private final int[] buckets;
        private final int hash;

        private BucketKey(int[] buckets) {
            this.buckets = buckets;
            this.hash = Arrays.hashCode(buckets);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof BucketKey bucketKey) || this.hash != bucketKey.hash) {
                return false;
            }
            return Arrays.equals(this.buckets, bucketKey.buckets);
        }

        @Override
        public int hashCode() {
            return this.hash;
        }
    }

    private Map<String, StaticGeoBonePose> buildPropertyPoses(List<Rule> rules, int value) {
        LinkedHashMap<String, StaticGeoBonePose> poses = new LinkedHashMap<>();
        for (Rule rule : rules) {
            poses.merge(rule.boneName(), rule.poseForStage(value), StaticGeoBonePose::combine);
        }
        return Map.copyOf(poses);
    }

    private IntegerProperty resolveProperty(BlockState templateState, Rule rule) {
        return templateState.getProperties().stream()
                .filter(IntegerProperty.class::isInstance)
                .map(IntegerProperty.class::cast)
                .filter(property -> matchesSteps(property, rule.steps()))
                .max(Comparator.comparingInt(property -> scorePropertyMatch(rule.groupKey(), property.getName())))
                .filter(property -> scorePropertyMatch(rule.groupKey(), property.getName()) > 0)
                .orElse(null);
    }

    private boolean matchesSteps(IntegerProperty property, int steps) {
        Collection<Integer> values = property.getPossibleValues();
        return !values.isEmpty() && values.size() == steps;
    }

    private int scorePropertyMatch(String groupKey, String propertyName) {
        String left = normalize(groupKey);
        String right = normalize(propertyName);
        return longestCommonSubstring(left, right);
    }

    private int longestCommonSubstring(String left, String right) {
        if (left.isEmpty() || right.isEmpty()) {
            return 0;
        }

        int[][] dp = new int[left.length() + 1][right.length() + 1];
        int best = 0;
        for (int i = 1; i <= left.length(); i++) {
            for (int j = 1; j <= right.length(); j++) {
                if (left.charAt(i - 1) != right.charAt(j - 1)) {
                    continue;
                }

                dp[i][j] = dp[i - 1][j - 1] + 1;
                best = Math.max(best, dp[i][j]);
            }
        }
        return best;
    }

    private String normalize(String value) {
        return value.toLowerCase(Locale.ROOT).replace("_", "");
    }

    private AutoStaticPoseConfig append(Rule rule) {
        ArrayList<Rule> updated = new ArrayList<>(this.rules);
        updated.add(rule);
        return new AutoStaticPoseConfig(List.copyOf(updated));
    }

    private interface Rule {
        String boneName();

        String groupKey();

        int steps();

        StaticGeoBonePose poseForStage(int stage);

        int quantizeCurrent(@Nullable GeoBone bone);
    }

    private abstract static class BaseRule implements Rule {
        private final String boneName;
        private final String groupKey;
        private final int steps;
        private final int indexedStage;

        private BaseRule(String boneName, int steps) {
            if (steps < 2) {
                throw new IllegalArgumentException("Auto static pose quantization requires at least 2 steps");
            }

            this.boneName = boneName;
            this.steps = steps;
            IndexedBone indexedBone = parseIndexedBone(boneName);
            this.groupKey = indexedBone.groupKey();
            this.indexedStage = indexedBone.stageIndex();
        }

        @Override
        public String boneName() {
            return this.boneName;
        }

        @Override
        public String groupKey() {
            return this.groupKey;
        }

        @Override
        public int steps() {
            return this.steps;
        }

        protected final float stageProgress(int stage) {
            int clamped = Math.max(0, Math.min(this.steps - 1, stage));
            if (this.indexedStage >= 0) {
                return clamped > this.indexedStage ? 1.0f : 0.0f;
            }
            return this.steps <= 1 ? 0.0f : (float) clamped / (float) (this.steps - 1);
        }

        protected final int quantizeLinear(float value, float from, float to) {
            if (this.steps <= 1) {
                return 0;
            }

            float min = Math.min(from, to);
            float max = Math.max(from, to);
            if (Math.abs(max - min) < 1.0e-6f) {
                return 0;
            }

            float clamped = Math.max(min, Math.min(max, value));
            float normalized = (clamped - from) / (to - from);
            float bounded = Math.max(0.0f, Math.min(1.0f, normalized));
            return Math.min(this.steps - 1, Math.round(bounded * (this.steps - 1)));
        }

        protected final int quantizeWrapped(float value, float from, float to) {
            float range = to - from;
            if (Math.abs(range) < 1.0e-6f || this.steps <= 1) {
                return 0;
            }

            float wrapped = (value - from) % range;
            if (wrapped < 0.0f) {
                wrapped += range;
            }

            float normalized = wrapped / range;
            return Math.min(this.steps - 1, Math.round(normalized * (this.steps - 1)));
        }
    }

    private static final class TranslationRule extends BaseRule {
        private final Axis axis;
        private final float from;
        private final float to;

        private TranslationRule(String boneName, Axis axis, int steps, float from, float to) {
            super(boneName, steps);
            this.axis = axis;
            this.from = from;
            this.to = to;
        }

        @Override
        public StaticGeoBonePose poseForStage(int stage) {
            float value = lerp(this.from, this.to, stageProgress(stage));
            return switch (this.axis) {
                case X -> StaticGeoBonePose.translate(value, 0.0f, 0.0f);
                case Y -> StaticGeoBonePose.translate(0.0f, value, 0.0f);
                case Z -> StaticGeoBonePose.translate(0.0f, 0.0f, value);
            };
        }

        @Override
        public int quantizeCurrent(@Nullable GeoBone bone) {
            if (bone == null) {
                return 0;
            }

            float value = switch (this.axis) {
                case X -> bone.getPosX();
                case Y -> bone.getPosY();
                case Z -> bone.getPosZ();
            };
            return quantizeLinear(value, this.from, this.to);
        }
    }

    private static final class RotationRule extends BaseRule {
        private final Axis axis;
        private final float from;
        private final float to;

        private RotationRule(String boneName, Axis axis, int steps, float from, float to) {
            super(boneName, steps);
            this.axis = axis;
            this.from = from;
            this.to = to;
        }

        @Override
        public StaticGeoBonePose poseForStage(int stage) {
            float value = lerp(this.from, this.to, stageProgress(stage));
            return switch (this.axis) {
                case X -> new StaticGeoBonePose(0.0f, 0.0f, 0.0f, value, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f, false);
                case Y -> new StaticGeoBonePose(0.0f, 0.0f, 0.0f, 0.0f, value, 0.0f, 1.0f, 1.0f, 1.0f, false);
                case Z -> new StaticGeoBonePose(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, value, 1.0f, 1.0f, 1.0f, false);
            };
        }

        @Override
        public int quantizeCurrent(@Nullable GeoBone bone) {
            if (bone == null) {
                return 0;
            }

            float value = switch (this.axis) {
                case X -> bone.getRotX();
                case Y -> bone.getRotY();
                case Z -> bone.getRotZ();
            };
            return quantizeWrapped(value, this.from, this.to);
        }
    }

    private static IndexedBone parseIndexedBone(String boneName) {
        Matcher matcher = TRAILING_DIGITS.matcher(boneName);
        if (!matcher.matches()) {
            return new IndexedBone(boneName, -1);
        }

        String baseName = matcher.group(1);
        int index = Integer.parseInt(matcher.group(2)) - 1;
        return new IndexedBone(baseName, Math.max(index, -1));
    }

    private static float lerp(float start, float end, float progress) {
        return start + (end - start) * progress;
    }

    private record IndexedBone(String groupKey, int stageIndex) {
    }
}
