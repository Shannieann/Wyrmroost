package dev.elifian.chaoslib.model.baked;


import dev.elifian.chaoslib.platform.ClientOnly;

@ClientOnly
public enum StaticGeoQuadCullingMode {
    AUTO,
    FORCE_CULL,
    FORCE_NO_CULL
}
