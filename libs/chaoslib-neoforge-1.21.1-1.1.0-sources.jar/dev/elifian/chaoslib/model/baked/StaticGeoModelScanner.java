package dev.elifian.chaoslib.model.baked;

import dev.elifian.chaoslib.ChaosLib;
import dev.elifian.chaoslib.api.model.GeoModel;
import dev.elifian.chaoslib.platform.ClientOnly;
import dev.elifian.chaoslib.platform.Services;
import org.objectweb.asm.ClassReader;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Stream;

/**
 * Finds every direct GeoModel subclass. A loader that keeps scan data of its own answers straight
 * away; otherwise the class files under the roots it points at are read here.
 */
@ClientOnly
public final class StaticGeoModelScanner {
    private static final String GEO_MODEL_INTERNAL_NAME = GeoModel.class.getName().replace('.', '/');

    private StaticGeoModelScanner() {
    }

    public static List<String> findGeoModelClassNames() {
        List<String> known = Services.MODEL_DISCOVERY.knownGeoModelClassNames();
        if (!known.isEmpty()) {
            return known;
        }

        Set<String> classNames = new TreeSet<>();
        for (Path root : Services.MODEL_DISCOVERY.classScanRoots()) {
            scan(root, classNames);
        }

        return List.copyOf(classNames);
    }

    private static void scan(Path root, Set<String> classNames) {
        try (Stream<Path> files = Files.walk(root)) {
            files.filter(Files::isRegularFile)
                    .filter(path -> path.getFileName().toString().endsWith(".class"))
                    .forEach(path -> {
                        String className = geoModelClassName(path);
                        if (className != null) {
                            classNames.add(className);
                        }
                    });
        } catch (Exception exception) {
            ChaosLib.LOGGER.warn("Failed to scan {} for ChaosLib geo models", root, exception);
        }
    }

    private static String geoModelClassName(Path classFile) {
        try (InputStream input = Files.newInputStream(classFile)) {
            ClassReader reader = new ClassReader(input);
            if (!GEO_MODEL_INTERNAL_NAME.equals(reader.getSuperName())) {
                return null;
            }

            return reader.getClassName().replace('/', '.');
        } catch (Exception exception) {
            return null;
        }
    }
}
