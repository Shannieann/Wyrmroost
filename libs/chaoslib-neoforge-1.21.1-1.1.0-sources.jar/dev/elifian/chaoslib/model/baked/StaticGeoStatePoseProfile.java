package dev.elifian.chaoslib.model.baked;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;

import dev.elifian.chaoslib.platform.ClientOnly;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.Function;

@ClientOnly
public final class StaticGeoStatePoseProfile {
    private static final StaticGeoStatePoseProfile EMPTY = new StaticGeoStatePoseProfile(Set.of("default"), Map.of("default", Map.of()), List.of());

    private final Set<String> variantKeys;
    private final Map<String, Map<String, StaticGeoBonePose>> posesByVariant;
    private final List<Entry<?>> entries;
    private final Set<String> affectedBoneNames;
    private final Map<BlockState, String> variantKeyCache = Collections.synchronizedMap(new IdentityHashMap<>());

    private StaticGeoStatePoseProfile(
            Set<String> variantKeys,
            Map<String, Map<String, StaticGeoBonePose>> posesByVariant,
            List<Entry<?>> entries
    ) {
        this.variantKeys = variantKeys;
        this.posesByVariant = posesByVariant;
        this.entries = entries;
        this.affectedBoneNames = collectAffectedBoneNames(posesByVariant);
    }

    public static StaticGeoStatePoseProfile empty() {
        return EMPTY;
    }

    public static Builder builder() {
        return new Builder();
    }

    public boolean isEmpty() {
        return this.entries.isEmpty();
    }

    public Set<String> getVariantKeys() {
        return this.variantKeys;
    }

    public String getVariantKey(@Nullable BlockState state) {
        if (state == null || this.entries.isEmpty()) {
            return "default";
        }

        String cached = this.variantKeyCache.get(state);
        if (cached != null) {
            return cached;
        }

        StringBuilder key = new StringBuilder();
        for (int i = 0; i < this.entries.size(); i++) {
            Entry<?> entry = this.entries.get(i);
            if (!state.hasProperty(entry.property)) {
                return "default";
            }

            if (i > 0) {
                key.append(',');
            }

            appendStateKeyPart(key, state, entry.property);
        }

        String resolved = key.toString();
        this.variantKeyCache.put(state, resolved);
        return resolved;
    }

    public Map<String, StaticGeoBonePose> getBoneRestPoses(String variantKey) {
        if (variantKey == null) {
            return this.posesByVariant.getOrDefault("default", Map.of());
        }

        Map<String, StaticGeoBonePose> poses = this.posesByVariant.get(variantKey);
        if (poses != null) {
            return poses;
        }

        String normalized = normalizeVariantKey(variantKey);
        if (normalized != null) {
            poses = this.posesByVariant.get(normalized);
            if (poses != null) {
                return poses;
            }
        }

        return this.posesByVariant.getOrDefault("default", Map.of());
    }

    public Set<String> getAffectedBoneNames() {
        return this.affectedBoneNames;
    }

    private static Set<String> collectAffectedBoneNames(Map<String, Map<String, StaticGeoBonePose>> posesByVariant) {
        if (posesByVariant.isEmpty()) {
            return Set.of();
        }

        LinkedHashSet<String> bones = new LinkedHashSet<>();
        for (Map<String, StaticGeoBonePose> poses : posesByVariant.values()) {
            bones.addAll(poses.keySet());
        }
        return Set.copyOf(bones);
    }

    private static <T extends Comparable<T>> void appendStateKeyPart(StringBuilder key, BlockState state, Property<T> property) {
        key.append(property.getName()).append('=').append(property.getName(state.getValue(property)));
    }

    private static <T extends Comparable<T>> void appendVariantKeyPart(StringBuilder key, Property<T> property, T value) {
        key.append(property.getName()).append('=').append(property.getName(value));
    }

    private String normalizeVariantKey(String variantKey) {
        if (variantKey.isEmpty() || "default".equals(variantKey) || this.entries.isEmpty()) {
            return "default";
        }

        Map<String, String> values = parseVariantValues(variantKey);
        if (values.isEmpty()) {
            return null;
        }

        StringBuilder key = new StringBuilder();
        for (int i = 0; i < this.entries.size(); i++) {
            Entry<?> entry = this.entries.get(i);
            String value = values.get(entry.property.getName());
            if (value == null) {
                return null;
            }

            if (i > 0) {
                key.append(',');
            }
            key.append(entry.property.getName()).append('=').append(value);
        }
        return key.toString();
    }

    private static Map<String, String> parseVariantValues(String variantKey) {
        if (variantKey == null || variantKey.isEmpty()) {
            return Map.of();
        }

        LinkedHashMap<String, String> values = new LinkedHashMap<>();
        String[] parts = variantKey.split("[|,]");
        for (String part : parts) {
            if (part.isEmpty()) {
                continue;
            }

            int separator = part.indexOf('=');
            if (separator <= 0 || separator == part.length() - 1) {
                continue;
            }

            values.put(part.substring(0, separator), part.substring(separator + 1));
        }
        return values;
    }

    private static Map<String, StaticGeoBonePose> mergePoses(Map<String, StaticGeoBonePose> left, Map<String, StaticGeoBonePose> right) {
        if (left.isEmpty()) {
            return right;
        }
        if (right.isEmpty()) {
            return left;
        }

        LinkedHashMap<String, StaticGeoBonePose> merged = new LinkedHashMap<>(left);
        right.forEach((boneName, pose) -> merged.merge(boneName, pose, StaticGeoBonePose::combine));
        return Map.copyOf(merged);
    }

    private static void buildVariants(
            List<Entry<?>> entries,
            int index,
            StringBuilder key,
            Map<String, StaticGeoBonePose> accumulatedPoses,
            LinkedHashSet<String> variantKeys,
            LinkedHashMap<String, Map<String, StaticGeoBonePose>> posesByVariant
    ) {
        if (index >= entries.size()) {
            String variantKey = key.toString();
            variantKeys.add(variantKey);
            posesByVariant.put(variantKey, accumulatedPoses);
            return;
        }

        Entry<?> rawEntry = entries.get(index);
        buildVariantsForEntry(rawEntry, entries, index, key, accumulatedPoses, variantKeys, posesByVariant);
    }

    private static <T extends Comparable<T>> void buildVariantsForEntry(
            Entry<T> entry,
            List<Entry<?>> entries,
            int index,
            StringBuilder key,
            Map<String, StaticGeoBonePose> accumulatedPoses,
            LinkedHashSet<String> variantKeys,
            LinkedHashMap<String, Map<String, StaticGeoBonePose>> posesByVariant
    ) {
        int keyLength = key.length();

        for (T value : entry.values) {
            if (keyLength > 0) {
                key.append(',');
            }
            appendVariantKeyPart(key, entry.property, value);

            buildVariants(
                    entries,
                    index + 1,
                    key,
                    mergePoses(accumulatedPoses, entry.poseResolver.apply(value)),
                    variantKeys,
                    posesByVariant
            );

            key.setLength(keyLength);
        }
    }

    public static final class Builder {
        private final List<Entry<?>> entries = new ArrayList<>();

        public <T extends Comparable<T>> Builder addPropertyPoses(
                Property<T> property,
                Function<T, Map<String, StaticGeoBonePose>> poseResolver
        ) {
            this.entries.add(new Entry<>(property, List.copyOf(property.getPossibleValues()), poseResolver));
            return this;
        }

        public StaticGeoStatePoseProfile build() {
            if (this.entries.isEmpty()) {
                return empty();
            }

            LinkedHashSet<String> variantKeys = new LinkedHashSet<>();
            LinkedHashMap<String, Map<String, StaticGeoBonePose>> posesByVariant = new LinkedHashMap<>();
            buildVariants(this.entries, 0, new StringBuilder(), Map.of(), variantKeys, posesByVariant);
            posesByVariant.put("default", posesByVariant.getOrDefault(variantKeys.iterator().next(), Map.of()));
            variantKeys.add("default");
            return new StaticGeoStatePoseProfile(Set.copyOf(variantKeys), Map.copyOf(posesByVariant), List.copyOf(this.entries));
        }
    }

    private record Entry<T extends Comparable<T>>(
            Property<T> property,
            Collection<T> values,
            Function<T, Map<String, StaticGeoBonePose>> poseResolver
    ) {
    }
}
