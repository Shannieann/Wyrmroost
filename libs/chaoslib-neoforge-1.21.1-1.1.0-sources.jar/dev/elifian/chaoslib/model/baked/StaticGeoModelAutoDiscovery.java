package dev.elifian.chaoslib.model.baked;

import dev.elifian.chaoslib.api.model.GeoModel;
import net.minecraft.resources.ResourceLocation;

import dev.elifian.chaoslib.platform.ClientOnly;


import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Supplier;

@ClientOnly
public final class StaticGeoModelAutoDiscovery {
    private static final AtomicBoolean DISCOVERED = new AtomicBoolean(false);

    private StaticGeoModelAutoDiscovery() {
    }

    public static void ensureDiscovered() {
        if (!DISCOVERED.compareAndSet(false, true)) {
            return;
        }

        StaticGeoModelScanner.findGeoModelClassNames()
                .forEach(StaticGeoModelAutoDiscovery::instantiateStaticGeoModel);
    }

    @SuppressWarnings("rawtypes")
    private static void instantiateStaticGeoModel(String className) {
        try {
            Class<?> rawClass = Class.forName(className);
            if (!GeoModel.class.isAssignableFrom(rawClass) || Modifier.isAbstract(rawClass.getModifiers())) {
                return;
            }

            GeoModel<?> modelInstance;
            Field instanceField = findInstanceField(rawClass);
            if (instanceField != null) {
                instanceField.setAccessible(true);
                modelInstance = (GeoModel<?>) instanceField.get(null);
            } else {
                Constructor<?> constructor = rawClass.getDeclaredConstructor();
                constructor.setAccessible(true);
                modelInstance = (GeoModel<?>) constructor.newInstance();
            }

            if (!hasAutoDiscoverableStaticDefinition(modelInstance)) {
                return;
            }

            modelInstance.registerStaticModelDefinition();
        } catch (ReflectiveOperationException exception) {
            throw new IllegalStateException("Failed to auto-register ChaosLib static geo model " + className, exception);
        }
    }

    private static boolean hasAutoDiscoverableStaticDefinition(GeoModel<?> modelInstance) {
        IdentifierPair block = resolveStaticBlockDefinition(modelInstance);
        if (block.modelId != null && block.geoModelId != null) {
            return true;
        }

        IdentifierPair item = resolveStaticItemDefinition(modelInstance);
        return item.modelId != null && item.geoModelId != null;
    }

    private static IdentifierPair resolveStaticBlockDefinition(GeoModel<?> modelInstance) {
        return new IdentifierPair(
                safeResolve(modelInstance::getStaticModelId),
                safeResolve(modelInstance::getStaticGeoModelResource)
        );
    }

    private static IdentifierPair resolveStaticItemDefinition(GeoModel<?> modelInstance) {
        return new IdentifierPair(
                safeResolve(modelInstance::getStaticItemModelId),
                safeResolve(modelInstance::getStaticItemGeoModelResource)
        );
    }

    private static ResourceLocation safeResolve(Supplier<ResourceLocation> supplier) {
        try {
            return supplier.get();
        } catch (RuntimeException ignored) {
            return null;
        }
    }

    private static Field findInstanceField(Class<?> rawClass) {
        try {
            Field field = rawClass.getDeclaredField("INSTANCE");
            if (!GeoModel.class.isAssignableFrom(field.getType())) {
                return null;
            }
            return field;
        } catch (NoSuchFieldException ignored) {
            return null;
        }
    }

    private record IdentifierPair(ResourceLocation modelId, ResourceLocation geoModelId) {
    }
}
