package dev.elifian.chaoslib.model.baked;

import org.jetbrains.annotations.Nullable;

import java.util.*;

/**
 * Structured encoder/decoder for static geo variant keys.
 */
public final class StaticGeoVariantKey {
    private static final String DEFAULT_KEY = "default";
    private final Map<String, String> values;

    private StaticGeoVariantKey(Map<String, String> values) {
        this.values = values;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static StaticGeoVariantKey parse(@Nullable String encoded) {
        if (encoded == null || encoded.isEmpty() || DEFAULT_KEY.equals(encoded)) {
            return new StaticGeoVariantKey(Map.of());
        }

        LinkedHashMap<String, String> values = new LinkedHashMap<>();
        for (String part : encoded.split("\\|")) {
            if (part.isEmpty()) {
                continue;
            }

            int separator = part.indexOf('=');
            if (separator <= 0 || separator == part.length() - 1) {
                continue;
            }

            values.put(part.substring(0, separator), part.substring(separator + 1));
        }
        return new StaticGeoVariantKey(Map.copyOf(values));
    }

    public String encode() {
        if (this.values.isEmpty()) {
            return DEFAULT_KEY;
        }

        StringBuilder builder = new StringBuilder();
        boolean first = true;
        for (Map.Entry<String, String> entry : this.values.entrySet()) {
            if (!first) {
                builder.append('|');
            }
            first = false;
            builder.append(entry.getKey()).append('=').append(entry.getValue());
        }
        return builder.toString();
    }

    public int getInt(String key, int fallback) {
        String value = this.values.get(key);
        if (value == null) {
            return fallback;
        }

        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException ignored) {
            return fallback;
        }
    }

    public Set<String> getTokenSet(String key) {
        String value = this.values.get(key);
        if (value == null || value.isEmpty()) {
            return Set.of();
        }

        return Set.of(value.split("\\+"));
    }

    public static final class Builder {
        private final LinkedHashMap<String, String> values = new LinkedHashMap<>();

        public Builder put(String key, int value) {
            this.values.put(key, Integer.toString(value));
            return this;
        }

        public Builder putTokens(String key, Collection<String> values) {
            if (values.isEmpty()) {
                return this;
            }

            LinkedHashSet<String> ordered = new LinkedHashSet<>(values);
            this.values.put(key, String.join("+", ordered));
            return this;
        }

        public String encode() {
            return this.build().encode();
        }

        public StaticGeoVariantKey build() {
            return new StaticGeoVariantKey(Map.copyOf(this.values));
        }
    }
}
