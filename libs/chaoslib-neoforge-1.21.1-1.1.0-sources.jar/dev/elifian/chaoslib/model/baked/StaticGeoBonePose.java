package dev.elifian.chaoslib.model.baked;


import dev.elifian.chaoslib.platform.ClientOnly;

@ClientOnly
public record StaticGeoBonePose(
        float posX,
        float posY,
        float posZ,
        float rotX,
        float rotY,
        float rotZ,
        float scaleX,
        float scaleY,
        float scaleZ,
        boolean hidden
) {
    public static final StaticGeoBonePose IDENTITY = new StaticGeoBonePose(
            0.0f, 0.0f, 0.0f,
            0.0f, 0.0f, 0.0f,
            1.0f, 1.0f, 1.0f,
            false
    );

    public static StaticGeoBonePose translate(float posX, float posY, float posZ) {
        return new StaticGeoBonePose(posX, posY, posZ, 0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f, false);
    }

    public StaticGeoBonePose combine(StaticGeoBonePose other) {
        if (this == IDENTITY) {
            return other;
        }
        if (other == IDENTITY) {
            return this;
        }

        return new StaticGeoBonePose(
                this.posX + other.posX,
                this.posY + other.posY,
                this.posZ + other.posZ,
                this.rotX + other.rotX,
                this.rotY + other.rotY,
                this.rotZ + other.rotZ,
                this.scaleX * other.scaleX,
                this.scaleY * other.scaleY,
                this.scaleZ * other.scaleZ,
                this.hidden || other.hidden
        );
    }
}
