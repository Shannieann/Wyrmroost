package dev.elifian.chaoslib.model.baked;

import dev.elifian.chaoslib.api.model.GeoModel;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.resources.ResourceLocation;

import dev.elifian.chaoslib.platform.ClientOnly;
import org.joml.Matrix4f;

import java.util.LinkedHashMap;
import java.util.Map;

@ClientOnly
public final class StaticGeoModelRegistry {
    private static final Map<ResourceLocation, Entry> ENTRIES = new LinkedHashMap<>();

    private StaticGeoModelRegistry() {
    }

    public static void register(
            ResourceLocation modelId,
            ResourceLocation geoModelId,
            Matrix4f rootTransform,
            GeoModel<?> geoModel,
            StaticGeoRenderMode renderMode
    ) {
        register(modelId, geoModelId, rootTransform, geoModel, state -> renderMode);
    }

    public static void register(
            ResourceLocation modelId,
            ResourceLocation geoModelId,
            Matrix4f rootTransform,
            GeoModel<?> geoModel,
            StaticGeoRenderModeSelector renderModeSelector
    ) {
        ENTRIES.put(modelId, new Entry(geoModelId, new Matrix4f(rootTransform), geoModel, renderModeSelector));
    }

    public static Entry lookup(ResourceLocation modelId) {
        StaticGeoModelAutoDiscovery.ensureDiscovered();
        return ENTRIES.get(modelId);
    }

    public static Entry lookup(ModelResourceLocation modelId) {
        StaticGeoModelAutoDiscovery.ensureDiscovered();
        Entry direct = ENTRIES.get(modelId.id());
        if (direct != null) {
            return direct;
        }
        if (!"inventory".equals(modelId.getVariant())) {
            return null;
        }

        ResourceLocation id = modelId.id();
        return ENTRIES.get(ResourceLocation.fromNamespaceAndPath(id.getNamespace(), "block/" + id.getPath()));
    }

    public record Entry(
            ResourceLocation geoModelId,
            Matrix4f rootTransform,
            GeoModel<?> geoModelDefinition,
            StaticGeoRenderModeSelector renderModeSelector
    ) {
    }
}
