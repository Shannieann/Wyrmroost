package dev.elifian.chaoslib.model;

import dev.elifian.chaoslib.api.animatable.GeoAnimatable;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.Nullable;

/**
 * Resolves model resources independently from rendering/runtime concerns.
 */
public interface GeoResourceSet<T extends GeoAnimatable> {
    ResourceLocation getModelResource(T animatable);

    ResourceLocation getTextureResource(T animatable);

    @Nullable ResourceLocation getAnimationResource(T animatable);
}
