package dev.elifian.chaoslib.model;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.function.IntToDoubleFunction;

public final class BoneSelectionCache {
    private final String[][] groups;
    private final int[] shifts;
    private final int totalStates;
    private final AnimatedBoneSelection[] selections;
    private final Set<String>[] boneSets;

    private BoneSelectionCache(String[][] groups) {
        this.groups = groups;
        this.shifts = new int[groups.length];

        int stateCount = 1;
        int shift = 0;
        for (int i = 0; i < groups.length; i++) {
            this.shifts[i] = shift;
            stateCount <<= groups[i].length;
            shift += groups[i].length;
        }

        this.totalStates = stateCount;
        this.selections = new AnimatedBoneSelection[this.totalStates];
        @SuppressWarnings("unchecked")
        Set<String>[] cachedSets = new Set[this.totalStates];
        this.boneSets = cachedSets;
        buildCaches();
    }

    public static BoneSelectionCache of(String[]... groups) {
        return new BoneSelectionCache(groups);
    }

    public AnimatedBoneSelection selection(int... masks) {
        return this.selections[index(masks)];
    }

    public Set<String> bones(int... masks) {
        return this.boneSets[index(masks)];
    }

    public int activeMask(IntToDoubleFunction progressGetter, int boneCount, float epsilon) {
        int mask = 0;
        for (int i = 0; i < boneCount; i++) {
            if (progressGetter.applyAsDouble(i) > epsilon) {
                mask |= 1 << i;
            }
        }
        return mask;
    }

    public int sequentialMask(int activeCount, int boneCount) {
        int mask = 0;
        int clamped = Math.max(0, Math.min(activeCount, boneCount));
        for (int i = 0; i < clamped; i++) {
            mask |= 1 << i;
        }
        return mask;
    }

    private int index(int... masks) {
        if (masks.length != this.groups.length) {
            throw new IllegalArgumentException("Mask count does not match group count");
        }

        int index = 0;
        for (int i = 0; i < masks.length; i++) {
            index |= masks[i] << this.shifts[i];
        }
        return index;
    }

    private void buildCaches() {
        for (int index = 0; index < this.totalStates; index++) {
            LinkedHashSet<String> bones = new LinkedHashSet<>();
            for (int groupIndex = 0; groupIndex < this.groups.length; groupIndex++) {
                addBonesFromMask(bones, this.groups[groupIndex], (index >> this.shifts[groupIndex]) & ((1 << this.groups[groupIndex].length) - 1));
            }
            this.selections[index] = AnimatedBoneSelection.of(bones);
            this.boneSets[index] = bones.isEmpty() ? Set.of() : Set.copyOf(bones);
        }
    }

    private static void addBonesFromMask(Set<String> target, String[] bones, int mask) {
        for (int i = 0; i < bones.length; i++) {
            if ((mask & (1 << i)) != 0) {
                target.add(bones[i]);
            }
        }
    }
}
