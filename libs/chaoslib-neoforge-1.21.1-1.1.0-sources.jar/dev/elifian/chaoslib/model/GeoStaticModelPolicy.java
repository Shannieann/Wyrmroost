package dev.elifian.chaoslib.model;

import dev.elifian.chaoslib.cache.object.BakedGeoModel;
import dev.elifian.chaoslib.api.animatable.GeoAnimatable;
import dev.elifian.chaoslib.model.baked.AutoStaticPoseConfig;
import dev.elifian.chaoslib.model.baked.StaticGeoBonePose;
import dev.elifian.chaoslib.model.baked.StaticGeoQuadCullingMode;
import dev.elifian.chaoslib.model.baked.StaticGeoRenderMode;
import dev.elifian.chaoslib.model.baked.StaticGeoRenderModeSelector;
import dev.elifian.chaoslib.model.baked.StaticGeoStatePoseProfile;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

import java.util.Map;
import java.util.Set;

/**
 * Defines baked/static rendering policy for a geo model.
 */
public interface GeoStaticModelPolicy<T extends GeoAnimatable> {
    default @Nullable ResourceLocation getStaticModelId() {
        ResourceLocation baseId = deriveDefaultStaticModelBaseId(this.getStaticGeoModelResource());
        return baseId == null ? null : ResourceLocation.fromNamespaceAndPath(baseId.getNamespace(), "block/" + baseId.getPath());
    }

    @Nullable ResourceLocation getStaticGeoModelResource();

    default @Nullable ResourceLocation getStaticItemModelId() {
        return deriveDefaultStaticModelBaseId(this.getStaticGeoModelResource());
    }

    default @Nullable ResourceLocation getStaticItemGeoModelResource() {
        return this.getStaticGeoModelResource();
    }

    @Nullable ResourceLocation getStaticTextureResource();

    Matrix4f getStaticItemRootTransform();

    StaticGeoRenderModeSelector getStaticItemRenderModeSelector();

    StaticGeoRenderModeSelector getStaticRenderModeSelector();

    boolean shouldRenderStaticEmissive(@Nullable BlockState state);

    AnimatedBoneSelection getStaticEmissiveBoneSelection(String variantKey);

    int getStaticEmissivePassCount();

    RenderType getStaticRenderLayer(@Nullable BlockState state);

    StaticGeoQuadCullingMode getStaticQuadCullingMode(@Nullable BlockState state);

    Map<String, StaticGeoBonePose> getBoneRestPoses();

    AutoStaticPoseConfig getAutoStaticPoseConfig();

    Object createFrozenPoseCacheKey(T animatable, BakedGeoModel model, Map<String, StaticGeoBonePose> frozenBonePoses);

    StaticGeoStatePoseProfile getStaticStatePoseProfile();

    Set<String> getStaticPoseVariantKeys();

    String getStaticPoseVariantKey(@Nullable BlockState state);

    Map<String, StaticGeoBonePose> getBoneRestPoses(String variantKey);

    Set<String> getStaticBoneNames(BakedGeoModel model, StaticGeoRenderMode renderMode);

    Set<String> getStaticEmissiveBoneNames(BakedGeoModel model, String variantKey, StaticGeoRenderMode renderMode);

    private static @Nullable ResourceLocation deriveDefaultStaticModelBaseId(@Nullable ResourceLocation staticGeoModelId) {
        if (staticGeoModelId == null) {
            return null;
        }

        String path = staticGeoModelId.getPath();
        if (!path.startsWith("geo/") || !path.endsWith(".geo.json")) {
            return null;
        }

        String basePath = path.substring("geo/".length(), path.length() - ".geo.json".length());
        if (basePath.isBlank()) {
            return null;
        }

        return ResourceLocation.fromNamespaceAndPath(staticGeoModelId.getNamespace(), basePath);
    }
}
