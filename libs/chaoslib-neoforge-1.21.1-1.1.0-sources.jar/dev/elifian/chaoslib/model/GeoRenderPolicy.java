package dev.elifian.chaoslib.model;

import dev.elifian.chaoslib.cache.object.BakedGeoModel;
import dev.elifian.chaoslib.api.animatable.GeoAnimatable;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

import java.util.Set;

/**
 * Groups render-time policy decisions for a geo model.
 */
public interface GeoRenderPolicy<T extends GeoAnimatable> {
    Matrix4f getStaticRootTransform();

    Matrix4f getStaticRootTransform(@Nullable BlockState state);

    Matrix4f getBlockEntityRootTransform(T animatable);

    Matrix4f getEntityRootTransform(T animatable);

    RenderType getRenderType(T animatable, ResourceLocation texture);

    boolean useEmissiveLayer();

    boolean shouldRenderEmissive(T animatable);

    AnimatedBoneSelection getBakeExcludedBones();

    AnimatedBoneSelection getLiveRenderBones(T animatable);

    AnimatedBoneSelection getFrozenRenderBones(T animatable);

    AnimatedBoneSelection getEmissiveBoneSelection(T animatable);

    Set<String> getResolvedEmissiveBones(T animatable, BakedGeoModel model, @Nullable Set<String> dynamicRenderBones);

    ResourceLocation getEmissiveTextureResource(T animatable);

    ResourceLocation getStaticEmissiveTextureResource();

    RenderType getEmissiveRenderType(T animatable, ResourceLocation texture);

    float getBlockEntityEmissiveStrength(T animatable);

    boolean renderEmissiveInBasePass();

    boolean usePoseCache(T animatable);

    boolean sharePoseCacheAcrossInstances(T animatable);

    boolean useEnclosedVisibilityCulling();

    double getFrozenBlockEntityRenderRadius();

    double getFrozenBlockEntityVisibilityRadius();

    float getFrozenBlockEntityThawDurationTicks();

    boolean useStaticAmbientOcclusion();
}
