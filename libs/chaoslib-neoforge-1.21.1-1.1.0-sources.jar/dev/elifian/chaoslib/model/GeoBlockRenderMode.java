package dev.elifian.chaoslib.model;

/**
 * Selects how a ChaosLib block entity participates in block rendering.
 */
public enum GeoBlockRenderMode {
    /**
     * Default ChaosLib behavior: static chunk model when possible, BER for live pose/additions.
     */
    AUTO,

    /**
     * Fully static block path. The model is rendered only by the baked block model and the BER is
     * skipped even when the block entity exists.
     */
    STATIC_ONLY
}
