package dev.elifian.chaoslib.model;

import dev.elifian.chaoslib.api.animatable.GeoAnimatable;

import java.util.Set;

/**
 * Defines which bone transforms are exported back to the animatable.
 */
public interface GeoTrackingPolicy<T extends GeoAnimatable> {
    Set<String> getTrackedBones(T animatable);
}
