package dev.elifian.chaoslib.model;

import dev.elifian.chaoslib.cache.object.BakedGeoModel;

import dev.elifian.chaoslib.platform.ClientOnly;

import java.util.LinkedHashSet;
import java.util.Set;

@ClientOnly
public final class AnimatedBoneSelection {
    private static final AnimatedBoneSelection NONE = new AnimatedBoneSelection(Mode.NONE, Set.of());
    private static final AnimatedBoneSelection AUTO = new AnimatedBoneSelection(Mode.AUTO, Set.of());
    private static final AnimatedBoneSelection ALL = new AnimatedBoneSelection(Mode.ALL, Set.of());

    private final Mode mode;
    private final Set<String> bones;

    private AnimatedBoneSelection(Mode mode, Set<String> bones) {
        this.mode = mode;
        this.bones = bones;
    }

    public static AnimatedBoneSelection none() {
        return NONE;
    }

    public static AnimatedBoneSelection all() {
        return ALL;
    }

    public static AnimatedBoneSelection auto() {
        return AUTO;
    }

    public static AnimatedBoneSelection of(Set<String> bones) {
        return bones.isEmpty() ? NONE : new AnimatedBoneSelection(Mode.ONLY, Set.copyOf(bones));
    }

    public static AnimatedBoneSelection of(String... bones) {
        if (bones.length == 0) {
            return NONE;
        }

        LinkedHashSet<String> names = new LinkedHashSet<>(bones.length);
        for (String bone : bones) {
            names.add(bone);
        }

        return new AnimatedBoneSelection(Mode.ONLY, Set.copyOf(names));
    }

    public static AnimatedBoneSelection excluding(Set<String> bones) {
        return bones.isEmpty() ? ALL : new AnimatedBoneSelection(Mode.EXCLUDING, Set.copyOf(bones));
    }

    public static AnimatedBoneSelection excluding(String... bones) {
        if (bones.length == 0) {
            return ALL;
        }

        LinkedHashSet<String> names = new LinkedHashSet<>(bones.length);
        for (String bone : bones) {
            names.add(bone);
        }

        return new AnimatedBoneSelection(Mode.EXCLUDING, Set.copyOf(names));
    }

    public Set<String> resolve(BakedGeoModel model) {
        return switch (this.mode) {
            case NONE -> Set.of();
            case AUTO -> Set.of();
            case ALL -> model.boneNames();
            case ONLY -> this.bones;
            case EXCLUDING -> {
                LinkedHashSet<String> resolved = new LinkedHashSet<>(model.boneNames());
                resolved.removeAll(this.bones);
                yield resolved.isEmpty() ? Set.of() : Set.copyOf(resolved);
            }
        };
    }

    public boolean isNone() {
        return this.mode == Mode.NONE;
    }

    public boolean isAuto() {
        return this.mode == Mode.AUTO;
    }

    public boolean isAll() {
        return this.mode == Mode.ALL;
    }

    private enum Mode {
        NONE,
        AUTO,
        ALL,
        ONLY,
        EXCLUDING
    }
}
