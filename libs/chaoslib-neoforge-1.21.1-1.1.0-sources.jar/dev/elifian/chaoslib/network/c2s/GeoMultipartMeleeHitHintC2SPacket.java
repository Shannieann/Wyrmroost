package dev.elifian.chaoslib.network.c2s;

import dev.elifian.chaoslib.ChaosLib;
import dev.elifian.chaoslib.api.multipart.GeoMultipartEntity;
import dev.elifian.chaoslib.multipart.interaction.GeoMultipartMeleeHitHintStore;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;

public final class GeoMultipartMeleeHitHintC2SPacket implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<GeoMultipartMeleeHitHintC2SPacket> TYPE =
            new CustomPacketPayload.Type<>(ChaosLib.id("multipart_melee_hit_hint"));

    public static final StreamCodec<FriendlyByteBuf, GeoMultipartMeleeHitHintC2SPacket> STREAM_CODEC =
            CustomPacketPayload.codec(
                    GeoMultipartMeleeHitHintC2SPacket::encode,
                    GeoMultipartMeleeHitHintC2SPacket::decode
            );

    private static final int MAX_BONE_NAME_LENGTH = 64;
    private final int entityId;
    private final String trackedBoneName;

    public GeoMultipartMeleeHitHintC2SPacket(int entityId, String trackedBoneName) {
        this.entityId = entityId;
        this.trackedBoneName = trackedBoneName;
    }

    public static GeoMultipartMeleeHitHintC2SPacket decode(FriendlyByteBuf buf) {
        return new GeoMultipartMeleeHitHintC2SPacket(
                buf.readVarInt(),
                buf.readUtf(MAX_BONE_NAME_LENGTH)
        );
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeVarInt(this.entityId);
        buf.writeUtf(this.trackedBoneName, MAX_BONE_NAME_LENGTH);
    }

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(GeoMultipartMeleeHitHintC2SPacket packet, ServerPlayer sender) {
        if (packet.trackedBoneName.isBlank()) {
            return;
        }

        Entity entity = sender.level().getEntity(packet.entityId);
        if (!(entity instanceof GeoMultipartEntity multipart)) {
            return;
        }

        if (sender.distanceToSqr(entity) > 8.0d * 8.0d) {
            return;
        }

        if (!multipart.getTrackedBones().contains(packet.trackedBoneName)) {
            return;
        }

        GeoMultipartMeleeHitHintStore.put(
                sender, packet.entityId, packet.trackedBoneName, sender.level().getGameTime());
    }
}
