package dev.elifian.chaoslib.network.c2s;

import dev.elifian.chaoslib.ChaosLib;
import dev.elifian.chaoslib.api.multipart.GeoMultipartEntity;
import dev.elifian.chaoslib.api.multipart.GeoTrackedBonePose;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public final class GeoMultipartBoneSyncC2SPacket implements CustomPacketPayload {
    public static final CustomPacketPayload.Type<GeoMultipartBoneSyncC2SPacket> TYPE =
            new CustomPacketPayload.Type<>(ChaosLib.id("multipart_bone_sync"));

    public static final StreamCodec<FriendlyByteBuf, GeoMultipartBoneSyncC2SPacket> STREAM_CODEC =
            CustomPacketPayload.codec(GeoMultipartBoneSyncC2SPacket::encode, GeoMultipartBoneSyncC2SPacket::decode);

    private static final int MAX_TRACKED_BONES = 32;
    private static final int MAX_BONE_NAME_LENGTH = 64;
    private final int entityId;
    private final Map<String, GeoTrackedBonePose> poses;

    public GeoMultipartBoneSyncC2SPacket(int entityId, Map<String, GeoTrackedBonePose> positions) {
        this.entityId = entityId;
        this.poses = new HashMap<>(positions);
    }

    public static GeoMultipartBoneSyncC2SPacket decode(FriendlyByteBuf buf) {
        int entityId = buf.readVarInt();
        int count = Math.min(MAX_TRACKED_BONES, buf.readVarInt());
        HashMap<String, GeoTrackedBonePose> positions = new HashMap<>();
        for (int i = 0; i < count; i++) {
            String name = buf.readUtf(MAX_BONE_NAME_LENGTH);
            positions.put(name, new GeoTrackedBonePose(
                    buf.readDouble(),
                    buf.readDouble(),
                    buf.readDouble(),
                    buf.readFloat(),
                    buf.readFloat(),
                    buf.readFloat(),
                    buf.readFloat()
            ));
        }
        return new GeoMultipartBoneSyncC2SPacket(entityId, positions);
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeVarInt(this.entityId);
        buf.writeVarInt(Math.min(MAX_TRACKED_BONES, this.poses.size()));
        int written = 0;
        for (Map.Entry<String, GeoTrackedBonePose> entry : this.poses.entrySet()) {
            if (written++ >= MAX_TRACKED_BONES) {
                break;
            }
            buf.writeUtf(entry.getKey(), MAX_BONE_NAME_LENGTH);
            GeoTrackedBonePose pose = entry.getValue();
            buf.writeDouble(pose.x());
            buf.writeDouble(pose.y());
            buf.writeDouble(pose.z());
            buf.writeFloat(pose.qx());
            buf.writeFloat(pose.qy());
            buf.writeFloat(pose.qz());
            buf.writeFloat(pose.qw());
        }
    }

    @Override
    public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(GeoMultipartBoneSyncC2SPacket packet, ServerPlayer sender) {
        Entity entity = sender.level().getEntity(packet.entityId);
        if (!(entity instanceof GeoMultipartEntity multipart) || !multipart.acceptsMultipartSync(sender)) {
            return;
        }

        if (sender.distanceToSqr(entity) > 256.0d * 256.0d) {
            return;
        }

        Map<String, GeoTrackedBonePose> poses = packet.poses;
        if (poses.isEmpty()) {
            return;
        }

        Set<String> allowed = multipart.getTrackedBones();
        if (allowed.isEmpty()) {
            return;
        }

        HashMap<String, GeoTrackedBonePose> filtered = new HashMap<>(Math.min(allowed.size(), poses.size()));
        for (Map.Entry<String, GeoTrackedBonePose> entry : poses.entrySet()) {
            if (allowed.contains(entry.getKey())) {
                filtered.put(entry.getKey(), entry.getValue());
            }
        }

        if (filtered.isEmpty()) {
            return;
        }

        if (filtered.size() == poses.size()) {
            multipart.receiveTrackedBonePoses(poses);
            return;
        }

        multipart.receiveTrackedBonePoses(filtered);
    }
}
