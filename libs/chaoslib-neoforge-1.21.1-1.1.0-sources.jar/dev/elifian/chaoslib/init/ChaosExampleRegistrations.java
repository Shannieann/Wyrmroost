package dev.elifian.chaoslib.init;

import dev.elifian.chaoslib.ChaosLib;
import dev.elifian.chaoslib.api.example.AnimatedEntityExample;
import dev.elifian.chaoslib.api.example.AnimatedEntityRendererExample;
import dev.elifian.chaoslib.api.example.ChaosExampleContent;
import dev.elifian.chaoslib.api.example.MultipartMobExample;
import dev.elifian.chaoslib.api.example.MultipartMobRendererExample;
import dev.elifian.chaoslib.api.example.ProceduralBlockEntityExample;
import dev.elifian.chaoslib.api.example.ProceduralBlockExample;
import dev.elifian.chaoslib.api.example.ProceduralBlockRendererExample;
import dev.elifian.chaoslib.platform.ClientOnly;
import dev.elifian.chaoslib.platform.Services;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;

import java.util.function.Supplier;

/**
 * The bundled examples: what they are and how they are built, in one place. Registration itself is
 * left to the platform layer, so both loaders end up with identical content.
 */
public final class ChaosExampleRegistrations {
    private static Supplier<EntityType<MultipartMobExample>> multipartEntity;
    private static Supplier<EntityType<AnimatedEntityExample>> animatedEntity;
    private static Supplier<Block> proceduralBlock;
    private static Supplier<BlockEntityType<ProceduralBlockEntityExample>> proceduralBlockEntity;

    private ChaosExampleRegistrations() {
    }

    public static void register() {
        multipartEntity = Services.REGISTRATION.registerEntityType(
                ChaosLib.id(ChaosExampleContent.MULTIPART_ENTITY_ID),
                () -> EntityType.Builder.of(MultipartMobExample::new, MobCategory.CREATURE)
                        .sized(0.9f, 1.9f)
                        .clientTrackingRange(10)
                        .build(ChaosExampleContent.MULTIPART_ENTITY_ID)
        );

        animatedEntity = Services.REGISTRATION.registerEntityType(
                ChaosLib.id(ChaosExampleContent.ANIMATED_ENTITY_ID),
                () -> EntityType.Builder.of(AnimatedEntityExample::new, MobCategory.CREATURE)
                        .sized(0.8f, 1.6f)
                        .clientTrackingRange(10)
                        .build(ChaosExampleContent.ANIMATED_ENTITY_ID)
        );

        proceduralBlock = Services.REGISTRATION.registerBlock(
                ChaosLib.id(ChaosExampleContent.PROCEDURAL_BLOCK_ID),
                () -> new ProceduralBlockExample(BlockBehaviour.Properties.of()
                        .mapColor(MapColor.STONE)
                        .strength(3.0f)
                        .sound(SoundType.STONE)
                        .noOcclusion())
        );

        Services.REGISTRATION.registerItem(
                ChaosLib.id(ChaosExampleContent.PROCEDURAL_BLOCK_ID),
                () -> new BlockItem(proceduralBlock.get(), new Item.Properties())
        );

        proceduralBlockEntity = Services.REGISTRATION.registerBlockEntityType(
                ChaosLib.id(ChaosExampleContent.PROCEDURAL_BLOCK_ID),
                ProceduralBlockEntityExample::new,
                proceduralBlock
        );

        Services.REGISTRATION.registerAttributes(multipartEntity, () -> MultipartMobExample.createAttributes().build());
        Services.REGISTRATION.registerAttributes(animatedEntity, () -> AnimatedEntityExample.createAttributes().build());
    }

    /**
     * Publishes the registered types once the platform has actually created them.
     */
    public static void publish() {
        ChaosExampleContent.setMultipartEntity(multipartEntity.get());
        ChaosExampleContent.setAnimatedEntity(animatedEntity.get());
        ChaosExampleContent.setProceduralBlock(proceduralBlock.get());
        ChaosExampleContent.setProceduralBlockEntity(proceduralBlockEntity.get());
    }

    @ClientOnly
    public static void registerRenderers() {
        Services.REGISTRATION.registerEntityRenderer(multipartEntity, MultipartMobRendererExample::new);
        Services.REGISTRATION.registerEntityRenderer(animatedEntity, AnimatedEntityRendererExample::new);
        Services.REGISTRATION.registerBlockEntityRenderer(proceduralBlockEntity, ProceduralBlockRendererExample::new);
    }
}
