package dev.elifian.chaoslib.init;

import dev.elifian.chaoslib.network.c2s.GeoMultipartBoneSyncC2SPacket;
import dev.elifian.chaoslib.network.c2s.GeoMultipartMeleeHitHintC2SPacket;
import dev.elifian.chaoslib.network.c2s.GeoMultipartUseHintC2SPacket;
import dev.elifian.chaoslib.platform.Services;

/**
 * Every packet ChaosLib speaks, in one place. The platform layer only knows how to register them.
 */
public final class ChaosNetworkRegistrations {
    private ChaosNetworkRegistrations() {
    }

    public static void register() {
        Services.NETWORK.registerServerbound(
                GeoMultipartBoneSyncC2SPacket.TYPE,
                GeoMultipartBoneSyncC2SPacket.STREAM_CODEC,
                GeoMultipartBoneSyncC2SPacket::handle
        );
        Services.NETWORK.registerServerbound(
                GeoMultipartMeleeHitHintC2SPacket.TYPE,
                GeoMultipartMeleeHitHintC2SPacket.STREAM_CODEC,
                GeoMultipartMeleeHitHintC2SPacket::handle
        );
        Services.NETWORK.registerServerbound(
                GeoMultipartUseHintC2SPacket.TYPE,
                GeoMultipartUseHintC2SPacket.STREAM_CODEC,
                GeoMultipartUseHintC2SPacket::handle
        );
    }
}
