package dev.elifian.chaoslib.init;

import dev.elifian.chaoslib.client.resource.ChaosLibClientReloadManager;
import dev.elifian.chaoslib.compat.sodium.ChaosSodiumCompatBootstrap;
import dev.elifian.chaoslib.compat.sodium.ChaosSodiumDebugOverlay;
import dev.elifian.chaoslib.config.ChaosLibClientConfig;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuRuntimePolicy;
import dev.elifian.chaoslib.gpu.shader.ChaosGpuShaderManager;
import dev.elifian.chaoslib.gpu.shader.ChaosGuiShaderManager;
import dev.elifian.chaoslib.model.baked.StaticGeoModelAutoDiscovery;
import dev.elifian.chaoslib.platform.ClientOnly;
import dev.elifian.chaoslib.platform.Services;

/**
 * Everything ChaosLib sets up, in the order it must happen. Each loader calls this and supplies the
 * services underneath; nothing about the sequence itself lives on the platform side.
 */
public final class ChaosLibBootstrap {
    private ChaosLibBootstrap() {
    }

    public static void init() {
        ChaosNetworkRegistrations.register();
        ChaosExampleRegistrations.register();
    }

    @ClientOnly
    public static void initClient() {
        ChaosLibClientConfig.load();
        StaticGeoModelAutoDiscovery.ensureDiscovered();

        Services.CLIENT_LIFECYCLE.onRegisterShaders(registry -> {
            ChaosGpuRuntimePolicy.initialize();
            ChaosGpuShaderManager.registerShaders(registry);
            ChaosGuiShaderManager.registerShaders(registry);
        });
        Services.CLIENT_LIFECYCLE.onClientResourceReload(ChaosLibClientReloadManager::reload);
        Services.CLIENT_LIFECYCLE.registerDebugOverlay(ChaosSodiumDebugOverlay::renderOverlay);

        ChaosExampleRegistrations.registerRenderers();
        ChaosClientRenderRegistrar.register();
        ChaosSodiumCompatBootstrap.registerIfAvailable();
    }
}
