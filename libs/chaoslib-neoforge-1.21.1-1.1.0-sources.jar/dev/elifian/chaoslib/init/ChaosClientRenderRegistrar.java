package dev.elifian.chaoslib.init;

import dev.elifian.chaoslib.client.multipart.GeoMultipartDebugRenderer;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuWorldLightVolumeStorage;
import dev.elifian.chaoslib.gpu.render.ChaosGpuWorldRenderDispatcher;
import dev.elifian.chaoslib.platform.Services;

/**
 * Wires ChaosLib's runtime render hooks: the GPU world render dispatcher (the batched flush),
 * the world light-volume updates and the multipart debug renderer. Every hook goes through the
 * platform layer, so both loaders call this the same way.
 */
public final class ChaosClientRenderRegistrar {
    private ChaosClientRenderRegistrar() {
    }

    public static void register() {
        Services.RENDER_EVENTS.registerWorldRenderStageListener(GeoMultipartDebugRenderer::onWorldRenderStage);
        ChaosGpuWorldLightVolumeStorage.registerLightUpdateListener();
        ChaosGpuWorldRenderDispatcher.register();
    }
}
