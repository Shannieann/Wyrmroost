package dev.elifian.chaoslib.cache;

import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class GeoClientResourceCache {
    private final Map<ResourceLocation, Boolean> existence = new ConcurrentHashMap<>();

    public boolean hasClientResource(ResourceLocation resourceId) {
        return this.existence.computeIfAbsent(resourceId, id ->
                Minecraft.getInstance().getResourceManager().getResource(id).isPresent()
        );
    }

    public void clear() {
        this.existence.clear();
    }
}
