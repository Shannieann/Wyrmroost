package dev.elifian.chaoslib.cache.object;

import dev.elifian.chaoslib.api.model.GeoBoneHandle;
import dev.elifian.chaoslib.api.model.GeoLocatorHandle;

import dev.elifian.chaoslib.platform.ClientOnly;
import org.joml.Vector3d;

@ClientOnly
public final class GeoLocator implements GeoLocatorHandle {
    private final String name;
    private final float offsetX;
    private final float offsetY;
    private final float offsetZ;
    private final float rotX;
    private final float rotY;
    private final float rotZ;

    public GeoLocator(String name, float offsetX, float offsetY, float offsetZ, float rotX, float rotY, float rotZ) {
        this.name = name;
        this.offsetX = offsetX;
        this.offsetY = offsetY;
        this.offsetZ = offsetZ;
        this.rotX = rotX;
        this.rotY = rotY;
        this.rotZ = rotZ;
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public float getOffsetX() {
        return this.offsetX;
    }

    @Override
    public float getOffsetY() {
        return this.offsetY;
    }

    @Override
    public float getOffsetZ() {
        return this.offsetZ;
    }

    @Override
    public Vector3d getWorldPosition(GeoBoneHandle bone) {
        return bone.transformModelPoint(
                bone.getPivotX() + this.offsetX,
                bone.getPivotY() + this.offsetY,
                bone.getPivotZ() + this.offsetZ
        );
    }

    @Override
    public float getRotX() {
        return this.rotX;
    }

    @Override
    public float getRotY() {
        return this.rotY;
    }

    @Override
    public float getRotZ() {
        return this.rotZ;
    }
}
