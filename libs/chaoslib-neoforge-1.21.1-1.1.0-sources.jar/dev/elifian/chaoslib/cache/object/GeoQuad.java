package dev.elifian.chaoslib.cache.object;

import net.minecraft.core.Direction;

import dev.elifian.chaoslib.platform.ClientOnly;

@ClientOnly
public record GeoQuad(GeoVertex[] vertices, float normalX, float normalY, float normalZ, Direction direction) {
    public static GeoQuad build(GeoVertex[] vertices, double[] uvCoords, double[] uvSize, float texWidth, float texHeight, boolean mirror, Direction direction) {
        return build(vertices, (float) uvCoords[0], (float) uvCoords[1], (float) uvSize[0], (float) uvSize[1], texWidth, texHeight, mirror, direction, 0);
    }

    public static GeoQuad build(GeoVertex[] vertices, double[] uvCoords, double[] uvSize, float texWidth, float texHeight, boolean mirror, Direction direction, int uvRotationDegrees) {
        return build(vertices, (float) uvCoords[0], (float) uvCoords[1], (float) uvSize[0], (float) uvSize[1], texWidth, texHeight, mirror, direction, uvRotationDegrees);
    }

    public static GeoQuad build(GeoVertex[] vertices, float u, float v, float uSize, float vSize, float texWidth, float texHeight, boolean mirror, Direction direction) {
        return build(vertices, u, v, uSize, vSize, texWidth, texHeight, mirror, direction, 0);
    }

    public static GeoQuad build(GeoVertex[] vertices, float u, float v, float uSize, float vSize, float texWidth, float texHeight, boolean mirror, Direction direction, int uvRotationDegrees) {
        float uWidth = (u + uSize) / texWidth;
        float vHeight = (v + vSize) / texHeight;
        u /= texWidth;
        v /= texHeight;
        float normalX = direction.getStepX();
        float normalY = direction.getStepY();
        float normalZ = direction.getStepZ();

        if (!mirror) {
            float tempWidth = uWidth;
            uWidth = u;
            u = tempWidth;
        } else {
            normalX *= -1.0f;
        }

        float[] rotatedUvs = rotateUvs(u, v, uWidth, vHeight, uvRotationDegrees);

        for (int i = 0; i < vertices.length; i++) {
            vertices[i] = vertices[i].withUVs(rotatedUvs[i * 2], rotatedUvs[i * 2 + 1]);
        }

        return new GeoQuad(vertices, normalX, normalY, normalZ, direction);
    }

    private static float[] rotateUvs(float u0, float v0, float u1, float v1, int uvRotationDegrees) {
        return switch (normalizeGeckoRotation(uvRotationDegrees)) {
            case 0 -> new float[]{u0, v0, u1, v0, u1, v1, u0, v1};
            case 90 -> new float[]{u1, v0, u1, v1, u0, v1, u0, v0};
            case 180 -> new float[]{u1, v1, u0, v1, u0, v0, u1, v0};
            case 270 -> new float[]{u0, v1, u0, v0, u1, v0, u1, v1};
            default -> throw new IllegalStateException("Unexpected normalized UV rotation");
        };
    }

    private static int normalizeGeckoRotation(int uvRotationDegrees) {
        int normalized = uvRotationDegrees % 360;

        if (normalized >= 0 && normalized % 90 == 0) {
            return normalized;
        }

        int snappedRotation = (int) Math.floor(Math.abs(uvRotationDegrees) / 90.0f) * 90;

        return normalizeGeckoRotation(snappedRotation);
    }
}
