package dev.elifian.chaoslib.cache.object;

import dev.elifian.chaoslib.api.model.GeoBoneHandle;

import dev.elifian.chaoslib.platform.ClientOnly;
import org.joml.Matrix4f;
import org.joml.Vector3d;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@ClientOnly
public final class GeoBone implements GeoBoneHandle {
    private final GeoBone parent;
    private final String name;
    private final List<GeoBone> children = new ArrayList<>();
    private final List<GeoCube> cubes = new ArrayList<>();
    private final List<GeoLocator> locators = new ArrayList<>();
    private final Float initialPivotX;
    private final Float initialPivotY;
    private final Float initialPivotZ;
    private final Float initialRotX;
    private final Float initialRotY;
    private final Float initialRotZ;

    private float scaleX = 1.0f;
    private float scaleY = 1.0f;
    private float scaleZ = 1.0f;
    private float positionX;
    private float positionY;
    private float positionZ;
    private float pivotX;
    private float pivotY;
    private float pivotZ;
    private float rotX;
    private float rotY;
    private float rotZ;
    private boolean hidden;
    private boolean childrenHidden;
    private boolean trackingMatrices;
    private final Matrix4f modelSpaceMatrix = new Matrix4f().identity();
    private final Matrix4f localSpaceMatrix = new Matrix4f().identity();
    private final Matrix4f worldSpaceMatrix = new Matrix4f().identity();

    public GeoBone(GeoBone parent, String name, float pivotX, float pivotY, float pivotZ, float rotX, float rotY, float rotZ) {
        this.parent = parent;
        this.name = name;
        this.pivotX = pivotX;
        this.pivotY = pivotY;
        this.pivotZ = pivotZ;
        this.rotX = rotX;
        this.rotY = rotY;
        this.rotZ = rotZ;
        this.initialPivotX = pivotX;
        this.initialPivotY = pivotY;
        this.initialPivotZ = pivotZ;
        this.initialRotX = rotX;
        this.initialRotY = rotY;
        this.initialRotZ = rotZ;
    }

    public String getName() {
        return this.name;
    }

    @Override
    public GeoBone getParent() {
        return this.parent;
    }

    @Override
    public List<GeoBone> getChildBones() {
        return this.children;
    }

    public List<GeoCube> getCubes() {
        return this.cubes;
    }

    @Override
    public List<GeoLocator> getLocators() {
        return this.locators;
    }

    @Override
    public Optional<GeoLocator> getLocator(String locatorName) {
        for (GeoLocator locator : this.locators) {
            if (locator.getName().equals(locatorName)) {
                return Optional.of(locator);
            }
        }
        return Optional.empty();
    }

    public float getPosX() {
        return this.positionX;
    }

    public float getPosY() {
        return this.positionY;
    }

    public float getPosZ() {
        return this.positionZ;
    }

    public void setPosX(float value) {
        this.positionX = value;
    }

    public void setPosY(float value) {
        this.positionY = value;
    }

    public void setPosZ(float value) {
        this.positionZ = value;
    }

    public float getPivotX() {
        return this.pivotX;
    }

    public float getPivotY() {
        return this.pivotY;
    }

    public float getPivotZ() {
        return this.pivotZ;
    }

    public void setPivotX(float value) {
        this.pivotX = value;
    }

    public void setPivotY(float value) {
        this.pivotY = value;
    }

    public void setPivotZ(float value) {
        this.pivotZ = value;
    }

    public float getRotX() {
        return this.rotX;
    }

    public float getRotY() {
        return this.rotY;
    }

    public float getRotZ() {
        return this.rotZ;
    }

    public float getInitialPivotX() {
        return this.initialPivotX;
    }

    public float getInitialPivotY() {
        return this.initialPivotY;
    }

    public float getInitialPivotZ() {
        return this.initialPivotZ;
    }

    public float getInitialRotX() {
        return this.initialRotX;
    }

    public float getInitialRotY() {
        return this.initialRotY;
    }

    public float getInitialRotZ() {
        return this.initialRotZ;
    }

    public void setRotX(float value) {
        this.rotX = value;
    }

    public void setRotY(float value) {
        this.rotY = value;
    }

    public void setRotZ(float value) {
        this.rotZ = value;
    }

    public float getScaleX() {
        return this.scaleX;
    }

    public float getScaleY() {
        return this.scaleY;
    }

    public float getScaleZ() {
        return this.scaleZ;
    }

    public void setScaleX(float value) {
        this.scaleX = value;
    }

    public void setScaleY(float value) {
        this.scaleY = value;
    }

    public void setScaleZ(float value) {
        this.scaleZ = value;
    }

    public boolean isHidden() {
        return this.hidden;
    }

    public void setHidden(boolean hidden) {
        this.hidden = hidden;
    }

    public boolean isHidingChildren() {
        return this.childrenHidden;
    }

    public void setChildrenHidden(boolean hideChildren) {
        this.childrenHidden = hideChildren;
    }

    public boolean isTrackingMatrices() {
        return this.trackingMatrices;
    }

    public void setTrackingMatrices(boolean trackingMatrices) {
        this.trackingMatrices = trackingMatrices;
    }

    public Matrix4f getModelSpaceMatrix() {
        return this.modelSpaceMatrix;
    }

    public void setModelSpaceMatrix(Matrix4f matrix) {
        this.modelSpaceMatrix.set(matrix);
    }

    public Matrix4f getLocalSpaceMatrix() {
        return this.localSpaceMatrix;
    }

    public void setLocalSpaceMatrix(Matrix4f matrix) {
        this.localSpaceMatrix.set(matrix);
    }

    public Matrix4f getWorldSpaceMatrix() {
        return this.worldSpaceMatrix;
    }

    public void setWorldSpaceMatrix(Matrix4f matrix) {
        this.worldSpaceMatrix.set(matrix);
    }

    @Override
    public Vector3d getWorldPosition() {
        return this.transformModelPoint(this.pivotX, this.pivotY, this.pivotZ);
    }

    @Override
    public Vector3d transformModelPoint(float x, float y, float z) {
        Vector3f transformed = this.worldSpaceMatrix.transformPosition(x / 16.0f, y / 16.0f, z / 16.0f, new Vector3f());
        return new Vector3d(transformed.x, transformed.y, transformed.z);
    }

    @Override
    public void resetPose() {
        this.positionX = 0.0f;
        this.positionY = 0.0f;
        this.positionZ = 0.0f;
        this.scaleX = 1.0f;
        this.scaleY = 1.0f;
        this.scaleZ = 1.0f;
        this.pivotX = this.initialPivotX;
        this.pivotY = this.initialPivotY;
        this.pivotZ = this.initialPivotZ;
        this.rotX = this.initialRotX;
        this.rotY = this.initialRotY;
        this.rotZ = this.initialRotZ;
        this.hidden = false;
        this.childrenHidden = false;

        for (GeoBone child : this.children) {
            child.resetPose();
        }
    }

    public Optional<GeoBone> findBone(String boneName) {
        if (this.name.equals(boneName)) {
            return Optional.of(this);
        }

        for (GeoBone child : this.children) {
            Optional<GeoBone> found = child.findBone(boneName);
            if (found.isPresent()) {
                return found;
            }
        }

        return Optional.empty();
    }
}
