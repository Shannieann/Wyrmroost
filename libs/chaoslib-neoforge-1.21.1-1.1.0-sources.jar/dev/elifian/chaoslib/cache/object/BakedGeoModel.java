package dev.elifian.chaoslib.cache.object;

import dev.elifian.chaoslib.loading.json.raw.ModelProperties;

import dev.elifian.chaoslib.platform.ClientOnly;

import java.util.*;

@ClientOnly
public record BakedGeoModel(List<GeoBone> topLevelBones, ModelProperties properties, Map<String, GeoBone> boneIndex,
                            List<GeoBone> orderedBones, Set<String> boneNames) {
    public BakedGeoModel(List<GeoBone> topLevelBones, ModelProperties properties) {
        this(topLevelBones, properties, indexBones(topLevelBones), List.copyOf(collectBones(topLevelBones)), Set.copyOf(collectBoneNames(topLevelBones)));
    }

    public Optional<GeoBone> getBone(String name) {
        return Optional.ofNullable(this.boneIndex.get(name));
    }

    public void resetPose() {
        for (GeoBone bone : this.topLevelBones) {
            bone.resetPose();
        }
    }

    private static Map<String, GeoBone> indexBones(List<GeoBone> bones) {
        Map<String, GeoBone> boneIndex = new HashMap<>();

        for (GeoBone bone : bones) {
            indexBoneRecursive(bone, boneIndex);
        }

        return Map.copyOf(boneIndex);
    }

    private static List<GeoBone> collectBones(List<GeoBone> bones) {
        List<GeoBone> orderedBones = new ArrayList<>();

        for (GeoBone bone : bones) {
            collectBoneRecursive(bone, orderedBones);
        }

        return orderedBones;
    }

    private static Set<String> collectBoneNames(List<GeoBone> bones) {
        Set<String> names = new LinkedHashSet<>();

        for (GeoBone bone : bones) {
            collectBoneNamesRecursive(bone, names);
        }

        return names;
    }

    private static void indexBoneRecursive(GeoBone bone, Map<String, GeoBone> boneIndex) {
        boneIndex.put(bone.getName(), bone);

        for (GeoBone child : bone.getChildBones()) {
            indexBoneRecursive(child, boneIndex);
        }
    }

    private static void collectBoneRecursive(GeoBone bone, List<GeoBone> orderedBones) {
        orderedBones.add(bone);

        for (GeoBone child : bone.getChildBones()) {
            collectBoneRecursive(child, orderedBones);
        }
    }

    private static void collectBoneNamesRecursive(GeoBone bone, Set<String> names) {
        names.add(bone.getName());

        for (GeoBone child : bone.getChildBones()) {
            collectBoneNamesRecursive(child, names);
        }
    }
}
