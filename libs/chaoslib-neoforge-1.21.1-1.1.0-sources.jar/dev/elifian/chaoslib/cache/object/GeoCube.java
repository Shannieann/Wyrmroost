package dev.elifian.chaoslib.cache.object;


import dev.elifian.chaoslib.platform.ClientOnly;
import org.joml.Vector3d;

@ClientOnly
public record GeoCube(GeoQuad[] quads, Vector3d pivot, Vector3d rotation, Vector3d size, double inflate,
                      boolean mirror) {
}
