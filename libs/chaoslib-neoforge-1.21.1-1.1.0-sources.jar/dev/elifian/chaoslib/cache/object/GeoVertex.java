package dev.elifian.chaoslib.cache.object;


import dev.elifian.chaoslib.platform.ClientOnly;

@ClientOnly
public record GeoVertex(float x, float y, float z, float texU, float texV) {
    public GeoVertex(double x, double y, double z) {
        this((float) x, (float) y, (float) z, 0.0f, 0.0f);
    }

    public GeoVertex withUVs(float texU, float texV) {
        return new GeoVertex(this.x, this.y, this.z, texU, texV);
    }
}
