package dev.elifian.chaoslib.cache;

import dev.elifian.chaoslib.api.model.GeoModel;

public final class ChaosLibCacheRegistry {
    private static final ChaosLibCacheRegistry INSTANCE = new ChaosLibCacheRegistry();

    private final GeoModelCacheService modelCache = new GeoModelCacheService();
    private final GeoAnimationCacheService animationCache = new GeoAnimationCacheService();
    private final GeoPoseCacheService<GeoModel.PoseCacheEntry> poseCache = new GeoPoseCacheService<>(256);
    private final GeoClientResourceCache clientResourceCache = new GeoClientResourceCache();

    private ChaosLibCacheRegistry() {
    }

    public static ChaosLibCacheRegistry getInstance() {
        return INSTANCE;
    }

    public GeoModelCacheService modelCache() {
        return this.modelCache;
    }

    public GeoAnimationCacheService animationCache() {
        return this.animationCache;
    }

    public GeoPoseCacheService<GeoModel.PoseCacheEntry> poseCache() {
        return this.poseCache;
    }

    public GeoClientResourceCache clientResourceCache() {
        return this.clientResourceCache;
    }

    public void clearAll() {
        this.modelCache.clear();
        this.animationCache.clear();
        this.poseCache.clear();
        this.clientResourceCache.clear();
    }
}
