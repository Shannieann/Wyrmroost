package dev.elifian.chaoslib.cache;

import dev.elifian.chaoslib.cache.object.BakedGeoModel;

import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public final class GeoPoseCacheService<V> {
    private final int maxEntriesPerModel;
    private final Map<BakedGeoModel, Map<Object, V>> caches = new IdentityHashMap<>();
    private BakedGeoModel lastModel;
    private Map<Object, V> lastCache;

    public GeoPoseCacheService(int maxEntriesPerModel) {
        this.maxEntriesPerModel = maxEntriesPerModel;
    }

    public Map<Object, V> get(BakedGeoModel model) {
        if (model == this.lastModel) {
            return this.lastCache;
        }

        Map<Object, V> cache = this.caches.get(model);
        this.lastModel = model;
        this.lastCache = cache;
        return cache;
    }

    public Map<Object, V> getOrCreate(BakedGeoModel model) {
        Map<Object, V> cache = get(model);
        if (cache != null) {
            return cache;
        }

        cache = new LinkedHashMap<>(64, 0.75f, true) {
            @Override
            protected boolean removeEldestEntry(Map.Entry<Object, V> eldest) {
                return size() > GeoPoseCacheService.this.maxEntriesPerModel;
            }
        };
        this.caches.put(model, cache);
        this.lastModel = model;
        this.lastCache = cache;
        return cache;
    }

    public int totalEntries() {
        int total = 0;
        for (Map<Object, V> cache : this.caches.values()) {
            total += cache.size();
        }
        return total;
    }

    public void clear() {
        this.caches.clear();
        this.lastModel = null;
        this.lastCache = null;
    }
}
