package dev.elifian.chaoslib.cache;

import dev.elifian.chaoslib.client.animation.GeoAnimationData;
import dev.elifian.chaoslib.client.animation.GeoAnimationLoader;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.resources.ResourceLocation;
import org.jetbrains.annotations.Nullable;

public final class GeoAnimationCacheService {
    public @Nullable GeoAnimationData get(@Nullable ResourceLocation location) {
        if (location == null) {
            return null;
        }
        return GeoAnimationLoader.load(location);
    }

    public void clear() {
        GeoAnimationLoader.clearCache();
    }

    public void preload(ResourceManager resourceManager) {
        GeoAnimationLoader.preload(resourceManager);
    }
}
