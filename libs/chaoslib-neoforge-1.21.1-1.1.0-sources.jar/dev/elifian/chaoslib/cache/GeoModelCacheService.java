package dev.elifian.chaoslib.cache;

import dev.elifian.chaoslib.cache.object.BakedGeoModel;
import dev.elifian.chaoslib.loading.GeoModelLoader;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.resources.ResourceLocation;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class GeoModelCacheService {
    private final Map<ResourceLocation, BakedGeoModel> modelCache = new ConcurrentHashMap<>();

    public BakedGeoModel get(ResourceLocation location) {
        return this.modelCache.computeIfAbsent(location, GeoModelLoader::load);
    }

    public BakedGeoModel get(ResourceLocation location, ResourceManager resourceManager) {
        return this.modelCache.computeIfAbsent(location, key -> GeoModelLoader.load(key, resourceManager));
    }

    public void clear() {
        this.modelCache.clear();
    }
}
