package dev.elifian.chaoslib.animatable.cache;

import java.util.Arrays;

public final class GeoPoseCacheKeyBuilder {
    private int[] values = new int[8];
    private int size;

    public GeoPoseCacheKeyBuilder add(float value) {
        return this.addBits(Float.floatToIntBits(value));
    }

    public GeoPoseCacheKeyBuilder add(float[] source) {
        for (float value : source) {
            this.add(value);
        }
        return this;
    }

    public GeoPoseCacheKeyBuilder addBits(int value) {
        ensureCapacity(this.size + 1);
        this.values[this.size++] = value;
        return this;
    }

    public Object build() {
        return switch (this.size) {
            case 0 -> EmptyKey.INSTANCE;
            case 1 -> new PackedKey1(this.values[0]);
            case 2 -> new PackedKey2(this.values[0], this.values[1]);
            case 3 -> new PackedKey3(this.values[0], this.values[1], this.values[2]);
            case 4 -> new PackedKey4(this.values[0], this.values[1], this.values[2], this.values[3]);
            case 5 -> new PackedKey5(this.values[0], this.values[1], this.values[2], this.values[3], this.values[4]);
            case 6 ->
                    new PackedKey6(this.values[0], this.values[1], this.values[2], this.values[3], this.values[4], this.values[5]);
            case 7 ->
                    new PackedKey7(this.values[0], this.values[1], this.values[2], this.values[3], this.values[4], this.values[5], this.values[6]);
            case 8 ->
                    new PackedKey8(this.values[0], this.values[1], this.values[2], this.values[3], this.values[4], this.values[5], this.values[6], this.values[7]);
            default -> new PackedKey(Arrays.copyOf(this.values, this.size));
        };
    }

    private void ensureCapacity(int capacity) {
        if (capacity <= this.values.length) {
            return;
        }

        int nextCapacity = this.values.length;
        while (nextCapacity < capacity) {
            nextCapacity <<= 1;
        }
        this.values = Arrays.copyOf(this.values, nextCapacity);
    }

    private enum EmptyKey {
        INSTANCE
    }

    private static final class PackedKey1 {
        private final int a0;
        private final int hash;

        private PackedKey1(int a0) {
            this.a0 = a0;
            this.hash = a0;
        }

        @Override
        public boolean equals(Object other) {
            return other instanceof PackedKey1 key && this.a0 == key.a0;
        }

        @Override
        public int hashCode() {
            return this.hash;
        }
    }

    private static final class PackedKey2 {
        private final int a0, a1, hash;

        private PackedKey2(int a0, int a1) {
            this.a0 = a0;
            this.a1 = a1;
            int result = a0;
            result = 31 * result + a1;
            this.hash = result;
        }

        @Override
        public boolean equals(Object other) {
            return other instanceof PackedKey2 key && this.a0 == key.a0 && this.a1 == key.a1;
        }

        @Override
        public int hashCode() {
            return this.hash;
        }
    }

    private static final class PackedKey3 {
        private final int a0, a1, a2, hash;

        private PackedKey3(int a0, int a1, int a2) {
            this.a0 = a0;
            this.a1 = a1;
            this.a2 = a2;
            int result = a0;
            result = 31 * result + a1;
            result = 31 * result + a2;
            this.hash = result;
        }

        @Override
        public boolean equals(Object other) {
            return other instanceof PackedKey3 key && this.a0 == key.a0 && this.a1 == key.a1 && this.a2 == key.a2;
        }

        @Override
        public int hashCode() {
            return this.hash;
        }
    }

    private static final class PackedKey4 {
        private final int a0, a1, a2, a3, hash;

        private PackedKey4(int a0, int a1, int a2, int a3) {
            this.a0 = a0;
            this.a1 = a1;
            this.a2 = a2;
            this.a3 = a3;
            int result = a0;
            result = 31 * result + a1;
            result = 31 * result + a2;
            result = 31 * result + a3;
            this.hash = result;
        }

        @Override
        public boolean equals(Object other) {
            return other instanceof PackedKey4 key
                    && this.a0 == key.a0 && this.a1 == key.a1 && this.a2 == key.a2 && this.a3 == key.a3;
        }

        @Override
        public int hashCode() {
            return this.hash;
        }
    }

    private static final class PackedKey5 {
        private final int a0, a1, a2, a3, a4, hash;

        private PackedKey5(int a0, int a1, int a2, int a3, int a4) {
            this.a0 = a0;
            this.a1 = a1;
            this.a2 = a2;
            this.a3 = a3;
            this.a4 = a4;
            int result = a0;
            result = 31 * result + a1;
            result = 31 * result + a2;
            result = 31 * result + a3;
            result = 31 * result + a4;
            this.hash = result;
        }

        @Override
        public boolean equals(Object other) {
            return other instanceof PackedKey5 key
                    && this.a0 == key.a0 && this.a1 == key.a1 && this.a2 == key.a2 && this.a3 == key.a3 && this.a4 == key.a4;
        }

        @Override
        public int hashCode() {
            return this.hash;
        }
    }

    private static final class PackedKey6 {
        private final int a0, a1, a2, a3, a4, a5, hash;

        private PackedKey6(int a0, int a1, int a2, int a3, int a4, int a5) {
            this.a0 = a0;
            this.a1 = a1;
            this.a2 = a2;
            this.a3 = a3;
            this.a4 = a4;
            this.a5 = a5;
            int result = a0;
            result = 31 * result + a1;
            result = 31 * result + a2;
            result = 31 * result + a3;
            result = 31 * result + a4;
            result = 31 * result + a5;
            this.hash = result;
        }

        @Override
        public boolean equals(Object other) {
            return other instanceof PackedKey6 key
                    && this.a0 == key.a0 && this.a1 == key.a1 && this.a2 == key.a2
                    && this.a3 == key.a3 && this.a4 == key.a4 && this.a5 == key.a5;
        }

        @Override
        public int hashCode() {
            return this.hash;
        }
    }

    private static final class PackedKey7 {
        private final int a0, a1, a2, a3, a4, a5, a6, hash;

        private PackedKey7(int a0, int a1, int a2, int a3, int a4, int a5, int a6) {
            this.a0 = a0;
            this.a1 = a1;
            this.a2 = a2;
            this.a3 = a3;
            this.a4 = a4;
            this.a5 = a5;
            this.a6 = a6;
            int result = a0;
            result = 31 * result + a1;
            result = 31 * result + a2;
            result = 31 * result + a3;
            result = 31 * result + a4;
            result = 31 * result + a5;
            result = 31 * result + a6;
            this.hash = result;
        }

        @Override
        public boolean equals(Object other) {
            return other instanceof PackedKey7 key
                    && this.a0 == key.a0 && this.a1 == key.a1 && this.a2 == key.a2
                    && this.a3 == key.a3 && this.a4 == key.a4 && this.a5 == key.a5 && this.a6 == key.a6;
        }

        @Override
        public int hashCode() {
            return this.hash;
        }
    }

    private static final class PackedKey8 {
        private final int a0, a1, a2, a3, a4, a5, a6, a7, hash;

        private PackedKey8(int a0, int a1, int a2, int a3, int a4, int a5, int a6, int a7) {
            this.a0 = a0;
            this.a1 = a1;
            this.a2 = a2;
            this.a3 = a3;
            this.a4 = a4;
            this.a5 = a5;
            this.a6 = a6;
            this.a7 = a7;
            int result = a0;
            result = 31 * result + a1;
            result = 31 * result + a2;
            result = 31 * result + a3;
            result = 31 * result + a4;
            result = 31 * result + a5;
            result = 31 * result + a6;
            result = 31 * result + a7;
            this.hash = result;
        }

        @Override
        public boolean equals(Object other) {
            return other instanceof PackedKey8 key
                    && this.a0 == key.a0 && this.a1 == key.a1 && this.a2 == key.a2 && this.a3 == key.a3
                    && this.a4 == key.a4 && this.a5 == key.a5 && this.a6 == key.a6 && this.a7 == key.a7;
        }

        @Override
        public int hashCode() {
            return this.hash;
        }
    }

    private static final class PackedKey {
        private final int[] values;
        private final int hash;

        private PackedKey(int[] values) {
            this.values = values;
            this.hash = Arrays.hashCode(values);
        }

        @Override
        public boolean equals(Object other) {
            if (this == other) {
                return true;
            }
            if (!(other instanceof PackedKey packedKey) || this.hash != packedKey.hash) {
                return false;
            }
            return Arrays.equals(this.values, packedKey.values);
        }

        @Override
        public int hashCode() {
            return this.hash;
        }
    }
}
