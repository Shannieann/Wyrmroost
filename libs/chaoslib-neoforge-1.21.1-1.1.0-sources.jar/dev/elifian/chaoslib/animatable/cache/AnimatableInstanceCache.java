package dev.elifian.chaoslib.animatable.cache;

import dev.elifian.chaoslib.api.animatable.GeoAnimatable;
import dev.elifian.chaoslib.api.animation.AnimatableManager;

public final class AnimatableInstanceCache {
    private final GeoAnimatable animatable;
    private AnimatableManager<?> manager;

    public AnimatableInstanceCache(GeoAnimatable animatable) {
        this.animatable = animatable;
    }

    public GeoAnimatable getAnimatable() {
        return this.animatable;
    }

    @SuppressWarnings("unchecked")
    public <T extends GeoAnimatable> AnimatableManager<T> getManager() {
        if (this.manager == null) {
            this.manager = AnimatableManager.create((T) this.animatable);
        }
        return (AnimatableManager<T>) this.manager;
    }
}
