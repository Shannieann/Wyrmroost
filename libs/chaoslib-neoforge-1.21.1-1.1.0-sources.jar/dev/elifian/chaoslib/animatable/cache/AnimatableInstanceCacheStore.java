package dev.elifian.chaoslib.animatable.cache;

import dev.elifian.chaoslib.api.animatable.GeoAnimatable;

import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * Stores lazily created instance caches for animatable objects.
 */
public final class AnimatableInstanceCacheStore {
    private static final Map<GeoAnimatable, AnimatableInstanceCache> CACHES =
            Collections.synchronizedMap(new WeakHashMap<>());
    private static final ThreadLocal<CacheAccess> LAST_ACCESS = ThreadLocal.withInitial(CacheAccess::new);

    private AnimatableInstanceCacheStore() {
    }

    /**
     * Returns the runtime cache for the given animatable instance.
     */
    public static AnimatableInstanceCache get(GeoAnimatable animatable) {
        CacheAccess lastAccess = LAST_ACCESS.get();
        if (lastAccess.animatable == animatable && lastAccess.cache != null) {
            return lastAccess.cache;
        }

        AnimatableInstanceCache cache;
        synchronized (CACHES) {
            cache = CACHES.get(animatable);
            if (cache == null) {
                cache = new AnimatableInstanceCache(animatable);
                CACHES.put(animatable, cache);
            }
        }

        lastAccess.animatable = animatable;
        lastAccess.cache = cache;
        return cache;
    }

    private static final class CacheAccess {
        private GeoAnimatable animatable;
        private AnimatableInstanceCache cache;
    }
}
