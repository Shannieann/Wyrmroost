package dev.elifian.chaoslib.animatable.cache;

import java.util.function.Supplier;

public final class GeoPoseCacheState {
    private boolean dirty = true;
    private Object cachedKey = new GeoPoseCacheKeyBuilder().build();

    public Object getOrBuild(Supplier<Object> builder) {
        if (this.dirty) {
            this.cachedKey = builder.get();
            this.dirty = false;
        }
        return this.cachedKey;
    }

    public void markDirty() {
        this.dirty = true;
    }
}
