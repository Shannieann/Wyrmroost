package dev.elifian.chaoslib.animatable.state;

import dev.elifian.chaoslib.api.animatable.GeoBlockEntity;
import dev.elifian.chaoslib.mixin.render.client.WorldRendererAccessor;
import dev.elifian.chaoslib.renderer.block.ChaosBlockEntityRenderFrameClock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.world.level.Level;

import java.util.Objects;

public final class GeoRenderStateTracker {
    private static int cachedGameTimeFrameId = Integer.MIN_VALUE;
    private static Level cachedGameTimeWorld;
    private static long cachedGameTime;

    private GeoRenderStateTracker() {
    }

    private static long currentGameTime(Level world) {
        int frameId = ChaosBlockEntityRenderFrameClock.frameId();
        if (frameId != cachedGameTimeFrameId || world != cachedGameTimeWorld) {
            cachedGameTimeFrameId = frameId;
            cachedGameTimeWorld = world;
            cachedGameTime = world.getGameTime();
        }
        return cachedGameTime;
    }

    public static boolean isActive(GeoBlockEntity entity) {
        if (!(entity instanceof BlockEntity blockEntity) || blockEntity.getLevel() == null) {
            return entity.hasLivePose();
        }

        long worldTime = currentGameTime(blockEntity.getLevel());
        GeoRenderStateAccess state = (GeoRenderStateAccess) blockEntity;
        if (state.getGeoRenderStateLastWorldTime() != worldTime) {
            state.setGeoRenderStateLastWorldTime(worldTime);
            boolean previousActive = state.isGeoRenderStateActive();
            boolean hasDynamicState = entity.hasLivePose();
            boolean poseChanged = updatePoseKey(state, entity.getPoseKey(), hasDynamicState);

            if (hasDynamicState && poseChanged) {
                int holdTicks = Math.max(0, entity.getGeoRenderPostAnimationHoldTicks());
                state.setGeoRenderStateRemainingTicks(holdTicks);
                state.setGeoRenderStateActive(true);
                state.setGeoRenderDeactivateGraceBeenUsed(false);
                state.setGeoRenderDeactivateGraceRemainingTicks(0);
            } else if (state.getGeoRenderStateRemainingTicks() > 0) {
                state.setGeoRenderStateRemainingTicks(state.getGeoRenderStateRemainingTicks() - 1);
                state.setGeoRenderStateActive(true);
                if (hasDynamicState) {
                    state.setGeoRenderDeactivateGraceBeenUsed(false);
                }
                state.setGeoRenderDeactivateGraceRemainingTicks(0);
            } else if (previousActive
                    && blockEntity.getLevel().isClientSide()
                    && !state.hasGeoRenderDeactivateGraceBeenUsed()) {
                int handoffGraceTicks = Math.max(0, entity.getGeoRenderStaticHandoffGraceTicks());
                state.setGeoRenderDeactivateGraceBeenUsed(true);
                state.setGeoRenderDeactivateGraceRemainingTicks(handoffGraceTicks);
                state.setGeoRenderStateActive(false);
            } else if (state.getGeoRenderDeactivateGraceRemainingTicks() > 0) {
                state.setGeoRenderDeactivateGraceRemainingTicks(state.getGeoRenderDeactivateGraceRemainingTicks() - 1);
                state.setGeoRenderStateActive(false);
            } else {
                state.setGeoRenderStateActive(false);
            }

            if (previousActive != state.isGeoRenderStateActive() && blockEntity.getLevel().isClientSide()) {
                state.setGeoShouldRenderLastFrameId(0);
                state.invalidateGeoModelDataCache();
                GeoClientRenderInvalidationCache.requestModelDataUpdate(blockEntity);
                markClientSectionDirty(blockEntity);
            }
        }

        return state.isGeoRenderStateActive();
    }

    public static void refreshClientStaticState(BlockEntity blockEntity) {
        if (blockEntity.getLevel() == null || !blockEntity.getLevel().isClientSide()) {
            return;
        }

        GeoRenderStateAccess state = (GeoRenderStateAccess) blockEntity;
        state.setGeoShouldRenderLastFrameId(0);
        state.setGeoRenderStateLastWorldTime(Long.MIN_VALUE);
        state.setGeoLastPoseKey(null);
        state.setGeoHasLastPoseKey(false);
        state.setGeoRenderDeactivateGraceBeenUsed(false);
        state.setGeoRenderDeactivateGraceRemainingTicks(0);
        state.invalidateGeoModelDataCache();
        GeoClientRenderInvalidationCache.requestModelDataUpdate(blockEntity);
        markClientSectionDirty(blockEntity);
    }

    public static void refreshClientRenderStateAfterTransientSync(GeoBlockEntity entity) {
        if (!(entity instanceof BlockEntity blockEntity)
                || blockEntity.getLevel() == null
                || !blockEntity.getLevel().isClientSide()) {
            return;
        }

        GeoRenderStateAccess state = (GeoRenderStateAccess) blockEntity;
        state.setGeoShouldRenderLastFrameId(0);
        state.setGeoRenderStateLastWorldTime(Long.MIN_VALUE);
        state.setGeoLastPoseKey(null);
        state.setGeoHasLastPoseKey(false);
        state.setGeoRenderDeactivateGraceBeenUsed(false);
        state.setGeoRenderDeactivateGraceRemainingTicks(0);

        if (!entity.rebuildStaticModelOnTransientSync()) {
            return;
        }

        state.invalidateGeoModelDataCache();
        GeoClientRenderInvalidationCache.requestModelDataUpdate(blockEntity);
        markClientSectionDirty(blockEntity);
    }

    private static void markClientSectionDirty(BlockEntity blockEntity) {
        LevelRenderer worldRenderer = Minecraft.getInstance().levelRenderer;
        if (!(worldRenderer instanceof WorldRendererAccessor accessor)) {
            return;
        }

        if (!GeoClientRenderInvalidationCache.shouldScheduleSectionRender(blockEntity)) {
            return;
        }

        accessor.invokeScheduleSectionRender(blockEntity.getBlockPos(), false);
    }

    private static boolean updatePoseKey(GeoRenderStateAccess state, Object poseKey, boolean hasDynamicState) {
        if (!state.hasGeoLastPoseKey()) {
            state.setGeoLastPoseKey(poseKey);
            state.setGeoHasLastPoseKey(true);
            return hasDynamicState;
        }

        boolean changed = !Objects.equals(state.getGeoLastPoseKey(), poseKey);
        state.setGeoLastPoseKey(poseKey);
        return changed;
    }
}
