package dev.elifian.chaoslib.animatable.state;

import dev.elifian.chaoslib.model.baked.GeoStaticModelData;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.core.BlockPos;

public interface GeoRenderStateAccess {
    long getGeoRenderStateLastWorldTime();

    void setGeoRenderStateLastWorldTime(long value);

    int getGeoRenderStateRemainingTicks();

    void setGeoRenderStateRemainingTicks(int value);

    boolean isGeoRenderStateActive();

    void setGeoRenderStateActive(boolean value);

    Object getGeoLastPoseKey();

    void setGeoLastPoseKey(Object value);

    boolean hasGeoLastPoseKey();

    void setGeoHasLastPoseKey(boolean value);

    boolean hasGeoRenderDeactivateGraceBeenUsed();

    void setGeoRenderDeactivateGraceBeenUsed(boolean value);

    int getGeoRenderDeactivateGraceRemainingTicks();

    void setGeoRenderDeactivateGraceRemainingTicks(int value);

    int getGeoShouldRenderLastFrameId();

    void setGeoShouldRenderLastFrameId(int value);

    boolean getGeoShouldRenderCachedValue();

    void setGeoShouldRenderCachedValue(boolean value);

    boolean isGeoModelDataOnly();

    void setGeoModelDataOnly(boolean value);

    BlockState getGeoCachedFacingState();

    void setGeoCachedFacingState(BlockState state);

    Object getGeoCachedFacingValue();

    void setGeoCachedFacingValue(Object value);

    BlockPos getGeoEnclosedCullPos();

    void setGeoEnclosedCullPos(BlockPos pos);

    BlockState getGeoEnclosedCullState();

    void setGeoEnclosedCullState(BlockState state);

    boolean getGeoEnclosedCullValue();

    void setGeoEnclosedCullValue(boolean value);

    long getGeoModelDataLastWorldTime();

    void setGeoModelDataLastWorldTime(long value);

    GeoStaticModelData.State getGeoCachedStaticModelDataState();

    void setGeoCachedStaticModelDataState(GeoStaticModelData.State state);

    void invalidateGeoModelDataCache();

    int getGeoRenderActiveLastFrameId();

    void setGeoRenderActiveLastFrameId(int value);

    boolean getGeoRenderActiveCachedValue();

    void setGeoRenderActiveCachedValue(boolean value);
}
