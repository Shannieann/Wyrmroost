package dev.elifian.chaoslib.animatable.state;

import dev.elifian.chaoslib.platform.Services;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;

import dev.elifian.chaoslib.platform.ClientOnly;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

@ClientOnly
final class GeoClientRenderInvalidationCache {
    private static final Set<Long> SCHEDULED_SECTIONS = new HashSet<>();
    private static final Map<BlockEntity, Long> MODEL_DATA_UPDATES = new WeakHashMap<>();
    private static ClientLevel lastWorld;
    private static long lastWorldTime = Long.MIN_VALUE;

    private GeoClientRenderInvalidationCache() {
    }

    static void requestModelDataUpdate(BlockEntity blockEntity) {
        if (!(blockEntity.getLevel() instanceof ClientLevel world)) {
            Services.STATIC_MODELS.requestModelDataUpdate(blockEntity);
            return;
        }

        prepareWindow(world);
        Long lastUpdate = MODEL_DATA_UPDATES.get(blockEntity);
        if (lastUpdate != null && lastUpdate == lastWorldTime) {
            return;
        }

        MODEL_DATA_UPDATES.put(blockEntity, lastWorldTime);
        Services.STATIC_MODELS.requestModelDataUpdate(blockEntity);
    }

    static boolean shouldScheduleSectionRender(BlockEntity blockEntity) {
        if (!(blockEntity.getLevel() instanceof ClientLevel world)) {
            return true;
        }

        prepareWindow(world);
        return SCHEDULED_SECTIONS.add(sectionKey(blockEntity.getBlockPos()));
    }

    private static void prepareWindow(ClientLevel world) {
        long worldTime = world.getGameTime();
        if (world != lastWorld || worldTime != lastWorldTime) {
            lastWorld = world;
            lastWorldTime = worldTime;
            SCHEDULED_SECTIONS.clear();
            MODEL_DATA_UPDATES.clear();
        }
    }

    private static long sectionKey(BlockPos pos) {
        return SectionPos.of(
                SectionPos.blockToSectionCoord(pos.getX()),
                SectionPos.blockToSectionCoord(pos.getY()),
                SectionPos.blockToSectionCoord(pos.getZ())
        ).asLong();
    }
}
