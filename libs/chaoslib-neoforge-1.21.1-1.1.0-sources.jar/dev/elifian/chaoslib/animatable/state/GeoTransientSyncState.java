package dev.elifian.chaoslib.animatable.state;

public final class GeoTransientSyncState {
    private boolean pending;
    private long lastSyncTick = Long.MIN_VALUE;

    public boolean isPending() {
        return this.pending;
    }

    public void request() {
        this.pending = true;
    }

    public boolean shouldFlush(long gameTime, long minIntervalTicks) {
        return this.pending
                && (this.lastSyncTick == Long.MIN_VALUE || gameTime - this.lastSyncTick >= minIntervalTicks);
    }

    public void markFlushed(long gameTime) {
        this.pending = false;
        this.lastSyncTick = gameTime;
    }
}
