package dev.elifian.chaoslib.animatable.sync;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.util.Mth;

public final class GeoTransientAnimationUtil {
    private GeoTransientAnimationUtil() {
    }

    public static void applyClientProgress(float[] progress, float[] velocity, float[] incoming, float maxProgress) {
        int max = Math.min(progress.length, incoming.length);
        for (int i = 0; i < max; i++) {
            float next = Mth.clamp(incoming[i], 0.0f, maxProgress);
            progress[i] = next;
            velocity[i] = 0.0f;
        }
        for (int i = max; i < progress.length; i++) {
            velocity[i] = 0.0f;
        }
    }

    public static void writeFloatBitsArray(CompoundTag nbt, String key, float[] source) {
        int[] packed = new int[source.length];
        for (int i = 0; i < source.length; i++) {
            packed[i] = Float.floatToRawIntBits(source[i]);
        }
        nbt.putIntArray(key, packed);
    }

    public static void readFloatBitsArray(CompoundTag nbt, String key, float[] target) {
        if (!nbt.contains(key, Tag.TAG_INT_ARRAY)) {
            return;
        }

        int[] packed = nbt.getIntArray(key);
        int max = Math.min(packed.length, target.length);
        for (int i = 0; i < max; i++) {
            target[i] = Float.intBitsToFloat(packed[i]);
        }
        for (int i = max; i < target.length; i++) {
            target[i] = 0.0f;
        }
    }
}
