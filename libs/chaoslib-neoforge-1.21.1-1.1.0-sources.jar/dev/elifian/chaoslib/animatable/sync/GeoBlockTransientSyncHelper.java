package dev.elifian.chaoslib.animatable.sync;

import dev.elifian.chaoslib.animatable.state.GeoTransientSyncState;
import dev.elifian.chaoslib.util.TrackingPlayerUtil;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;

import java.util.List;
import java.util.function.Consumer;

/**
 * Shared helpers for block-entity transient visual sync.
 */
public final class GeoBlockTransientSyncHelper {
    private GeoBlockTransientSyncHelper() {
    }

    public static void request(GeoTransientSyncState state) {
        if (state != null) {
            state.request();
        }
    }

    public static boolean flushIfNeeded(BlockEntity blockEntity, GeoTransientSyncState state, long intervalTicks, Runnable sender) {
        if (!(blockEntity.getLevel() instanceof ServerLevel serverWorld) || state == null || !state.isPending()) {
            return false;
        }

        long gameTime = serverWorld.getGameTime();
        if (!state.shouldFlush(gameTime, intervalTicks)) {
            return false;
        }

        sender.run();
        state.markFlushed(gameTime);
        return true;
    }

    public static List<ServerPlayer> getChunkTrackingPlayers(BlockEntity blockEntity, ServerLevel serverWorld) {
        return TrackingPlayerUtil.getChunkTrackingPlayers(blockEntity, serverWorld);
    }

    public static void forEachPlayerInRange(BlockEntity blockEntity, ServerLevel serverWorld, double radiusSquared, Consumer<ServerPlayer> consumer) {
        TrackingPlayerUtil.forEachPlayerInRange(blockEntity, serverWorld, radiusSquared, consumer);
    }
}
