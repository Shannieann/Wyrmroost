package dev.elifian.chaoslib.compat.sodium;

import net.minecraft.network.chat.Component;

import dev.elifian.chaoslib.platform.ClientOnly;

@ClientOnly
public enum ChaosSodiumGpuSkinningMode {
    AUTO("auto"),
    FORCE_GPU("force_gpu"),
    FORCE_CPU("force_cpu");

    private final String translationSuffix;

    ChaosSodiumGpuSkinningMode(String translationSuffix) {
        this.translationSuffix = translationSuffix;
    }

    public Component displayText() {
        return Component.translatable("chaoslib.sodium.option.skinning_mode.value." + this.translationSuffix);
    }
}
