package dev.elifian.chaoslib.compat.sodium;


import dev.elifian.chaoslib.platform.ClientOnly;
import dev.elifian.chaoslib.platform.Services;

@ClientOnly
public final class ChaosSodiumCompatBootstrap {
    private ChaosSodiumCompatBootstrap() {
    }

    public static void registerIfAvailable() {
        if (!Services.PLATFORM.isModLoaded("sodium")) {
            return;
        }

        ChaosSodiumCompat.register();
    }
}
