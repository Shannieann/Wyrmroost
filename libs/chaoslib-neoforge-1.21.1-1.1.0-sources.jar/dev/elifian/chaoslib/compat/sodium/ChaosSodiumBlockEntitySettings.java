package dev.elifian.chaoslib.compat.sodium;

import dev.elifian.chaoslib.api.animatable.GeoBlockEntity;
import dev.elifian.chaoslib.api.model.GeoModel;
import dev.elifian.chaoslib.cache.object.BakedGeoModel;
import dev.elifian.chaoslib.config.ChaosLibSodiumOptions;
import dev.elifian.chaoslib.config.ChaosLibClientConfig;
import dev.elifian.chaoslib.config.ChaosLibObjectOverride;
import dev.elifian.chaoslib.model.AnimatedBoneSelection;
import net.minecraft.world.level.block.entity.BlockEntity;

import dev.elifian.chaoslib.platform.ClientOnly;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

@ClientOnly
public final class ChaosSodiumBlockEntitySettings {
    private static final ConcurrentMap<Class<?>, RuntimeSettings> RUNTIME_SETTINGS = new ConcurrentHashMap<>();

    private ChaosSodiumBlockEntitySettings() {
    }

    public static boolean areDistanceOverridesEnabled() {
        return ChaosLibClientConfig.sodium().enableForcedBlockEntityDistances;
    }

    public static double resolveFrozenRenderRadius(double configuredRadius) {
        return resolveFrozenRenderRadius(null, configuredRadius);
    }

    public static double resolveFrozenRenderRadius(BlockEntity blockEntity, double configuredRadius) {
        return blockEntity == null
                ? resolveGlobalFrozenRenderRadius(configuredRadius)
                : runtimeSettings(blockEntity.getClass()).resolveFreezeRadius(configuredRadius);
    }

    public static double resolveModelDataTransitionDistance(double configuredDistance) {
        return resolveModelDataTransitionDistance(null, configuredDistance);
    }

    public static double resolveModelDataTransitionDistance(BlockEntity blockEntity, double configuredDistance) {
        return blockEntity == null
                ? resolveGlobalModelDataTransitionDistance(configuredDistance)
                : runtimeSettings(blockEntity.getClass()).resolveModelDataRadius(configuredDistance);
    }

    public static <T extends BlockEntity & GeoBlockEntity> boolean shouldKeepFrozenLiveBonesOnBer(GeoModel<T> model, T animatable) {
        if (!runtimeSettings(animatable.getClass()).keepFrozenLiveBonesOnBer()) {
            return false;
        }

        AnimatedBoneSelection selection = model.getFrozenRenderBones(animatable);
        if (selection.isNone()) {
            return false;
        }

        if (selection.isAll()) {
            return true;
        }

        BakedGeoModel bakedModel = model.getBakedModel(model.getModelResource(animatable));
        Set<String> liveBones = selection.resolve(bakedModel);
        return !liveBones.isEmpty();
    }

    public static ChaosSodiumGpuSkinningMode resolveGpuSkinningMode(BlockEntity blockEntity) {
        return runtimeSettings(blockEntity.getClass()).gpuSkinningMode();
    }

    public static void clearRuntimeCache() {
        RUNTIME_SETTINGS.clear();
    }

    private static RuntimeSettings runtimeSettings(Class<?> blockEntityClass) {
        long version = ChaosLibClientConfig.version();
        RuntimeSettings cached = RUNTIME_SETTINGS.get(blockEntityClass);
        if (cached != null && cached.version() == version) {
            return cached;
        }

        RuntimeSettings resolved = RuntimeSettings.create(blockEntityClass, version);
        RUNTIME_SETTINGS.put(blockEntityClass, resolved);
        return resolved;
    }

    private static double resolveGlobalFrozenRenderRadius(double configuredRadius) {
        ChaosLibSodiumOptions options = ChaosLibClientConfig.sodium();
        if (!options.enableForcedBlockEntityDistances) {
            return configuredRadius;
        }

        int override = options.forcedFreezeRadius;
        return override <= 0 ? Double.POSITIVE_INFINITY : override;
    }

    private static double resolveGlobalModelDataTransitionDistance(double configuredDistance) {
        ChaosLibSodiumOptions options = ChaosLibClientConfig.sodium();
        if (!options.enableForcedBlockEntityDistances) {
            return configuredDistance;
        }

        int override = options.forcedModelDataRadius;
        return override <= 0 ? Double.POSITIVE_INFINITY : override;
    }

    private static int toStoredRadius(double value) {
        if (!Double.isFinite(value)) {
            return 0;
        }

        return Math.max(0, (int) Math.round(value));
    }

    private record RuntimeSettings(
            long version,
            boolean forcedDistances,
            int forcedFreezeRadius,
            int forcedModelDataRadius,
            boolean globalKeepFrozenLiveBonesOnBer,
            boolean hasObjectOverride,
            boolean objectOverrideEnabled,
            int objectFreezeRadius,
            int objectModelDataRadius,
            boolean objectKeepAnimatedBones,
            ChaosSodiumGpuSkinningMode objectGpuSkinningMode
    ) {
        static RuntimeSettings create(Class<?> blockEntityClass, long version) {
            ChaosLibSodiumOptions options = ChaosLibClientConfig.sodium();
            ChaosSodiumBlockEntityOptionRegistry.Entry entry = ChaosSodiumBlockEntityOptionRegistry.get(blockEntityClass.getName());
            ChaosLibObjectOverride override = entry == null
                    ? null
                    : options.objectOverrides.get(entry.key());

            return new RuntimeSettings(
                    version,
                    options.enableForcedBlockEntityDistances,
                    options.forcedFreezeRadius,
                    options.forcedModelDataRadius,
                    options.keepFrozenLiveBonesOnBer,
                    override != null,
                    override != null && override.enabled,
                    override == null ? 0 : override.freezeRadius,
                    override == null ? 0 : override.modelDataRadius,
                    override != null && override.keepAnimatedBones,
                    override == null || override.gpuSkinningMode == null ? ChaosSodiumGpuSkinningMode.AUTO : override.gpuSkinningMode
            );
        }

        double resolveFreezeRadius(double configuredRadius) {
            if (this.forcedDistances) {
                return this.forcedFreezeRadius <= 0 ? Double.POSITIVE_INFINITY : this.forcedFreezeRadius;
            }

            if (!this.hasObjectOverride || !this.objectOverrideEnabled) {
                return configuredRadius;
            }

            return this.objectFreezeRadius <= 0 ? Double.POSITIVE_INFINITY : this.objectFreezeRadius;
        }

        double resolveModelDataRadius(double configuredDistance) {
            if (this.forcedDistances) {
                return this.forcedModelDataRadius <= 0 ? Double.POSITIVE_INFINITY : this.forcedModelDataRadius;
            }

            if (!this.hasObjectOverride || !this.objectOverrideEnabled) {
                return configuredDistance;
            }

            return this.objectModelDataRadius <= 0 ? Double.POSITIVE_INFINITY : this.objectModelDataRadius;
        }

        boolean keepFrozenLiveBonesOnBer() {
            if (this.forcedDistances) {
                return this.globalKeepFrozenLiveBonesOnBer;
            }

            return this.hasObjectOverride && this.objectOverrideEnabled && this.objectKeepAnimatedBones;
        }

        ChaosSodiumGpuSkinningMode gpuSkinningMode() {
            if (!this.hasObjectOverride || !this.objectOverrideEnabled) {
                return ChaosSodiumGpuSkinningMode.AUTO;
            }

            return this.objectGpuSkinningMode;
        }
    }
}
