package dev.elifian.chaoslib.compat.sodium;

import dev.elifian.chaoslib.config.ChaosLibClientConfig;

import dev.elifian.chaoslib.platform.ClientOnly;

@ClientOnly
public final class ChaosSodiumCompat {
    private ChaosSodiumCompat() {
    }

    public static void register() {
        ChaosLibClientConfig.load();
    }
}
