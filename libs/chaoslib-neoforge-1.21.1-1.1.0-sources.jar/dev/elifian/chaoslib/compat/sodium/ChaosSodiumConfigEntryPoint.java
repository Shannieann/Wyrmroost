package dev.elifian.chaoslib.compat.sodium;

import dev.elifian.chaoslib.ChaosLib;
import dev.elifian.chaoslib.config.ChaosLibClientConfig;
import net.caffeinemc.mods.sodium.api.config.ConfigEntryPoint;
import net.caffeinemc.mods.sodium.api.config.ConfigEntryPointForge;
import net.caffeinemc.mods.sodium.api.config.structure.ConfigBuilder;
import net.caffeinemc.mods.sodium.api.config.structure.ModOptionsBuilder;
import net.caffeinemc.mods.sodium.api.config.structure.OptionPageBuilder;

@ConfigEntryPointForge(ChaosLib.MOD_ID)
public class ChaosSodiumConfigEntryPoint implements ConfigEntryPoint {
    @Override
    public void registerConfigLate(ConfigBuilder builder) {
        ChaosLibClientConfig.load();

        ChaosSodiumOptionsStorage storage = new ChaosSodiumOptionsStorage();
        ModOptionsBuilder options = builder.registerOwnModOptions()
                .setName("ChaosLib")
                .setIcon(ChaosLib.id("textures/gui/sodium_icon.png"))
                .addPage(ChaosSodiumOptionGroupFactory.createGlobalPage(builder, storage))
                .addPage(ChaosSodiumOptionGroupFactory.createAdditionalPage(builder, storage));

        OptionPageBuilder individualPage = ChaosSodiumOptionGroupFactory.createIndividualPage(builder, storage);
        if (individualPage != null) {
            options.addPage(individualPage);
        }
    }
}
