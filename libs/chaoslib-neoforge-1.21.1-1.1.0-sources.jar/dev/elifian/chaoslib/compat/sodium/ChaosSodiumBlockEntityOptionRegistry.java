package dev.elifian.chaoslib.compat.sodium;

import dev.elifian.chaoslib.api.animatable.GeoBlockEntity;
import dev.elifian.chaoslib.api.model.GeoModel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

import dev.elifian.chaoslib.platform.ClientOnly;
import dev.elifian.chaoslib.model.baked.StaticGeoModelScanner;
import net.minecraft.core.registries.BuiltInRegistries;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Supplier;

@ClientOnly
public final class ChaosSodiumBlockEntityOptionRegistry {
    private static final AtomicBoolean DISCOVERED = new AtomicBoolean(false);
    private static final Map<String, Entry> ENTRIES = new LinkedHashMap<>();

    private ChaosSodiumBlockEntityOptionRegistry() {
    }

    public static List<Entry> entries() {
        ensureDiscovered();
        return List.copyOf(ENTRIES.values());
    }

    public static Entry get(String blockEntityClassName) {
        ensureDiscovered();
        return ENTRIES.get(blockEntityClassName);
    }

    private static void ensureDiscovered() {
        if (!DISCOVERED.compareAndSet(false, true)) {
            return;
        }

        StaticGeoModelScanner.findGeoModelClassNames()
                .forEach(ChaosSodiumBlockEntityOptionRegistry::registerModel);
    }

    @SuppressWarnings("unchecked")
    private static void registerModel(String className) {
        try {
            Class<?> rawClass = Class.forName(className);
            if (!GeoModel.class.isAssignableFrom(rawClass) || Modifier.isAbstract(rawClass.getModifiers())) {
                return;
            }

            Class<? extends BlockEntity> blockEntityClass = resolveBlockEntityClass(rawClass);
            if (blockEntityClass == null || !GeoBlockEntity.class.isAssignableFrom(blockEntityClass)) {
                return;
            }

            GeoModel<? extends GeoBlockEntity> model = (GeoModel<? extends GeoBlockEntity>) instantiateModel(rawClass);
            if (model == null) {
                return;
            }

            ResourceLocation staticModelId = safeResolve(model::getStaticModelId);
            Block block = resolveRegisteredBlock(staticModelId);
            if (block == null) {
                return;
            }

            String key = blockEntityClass.getName();
            ENTRIES.putIfAbsent(key, new Entry(
                    key,
                    blockEntityClass,
                    Component.translatable(block.getDescriptionId()),
                    resolveOptionPath(staticModelId, blockEntityClass),
                    model.getFrozenBlockEntityRenderRadius(),
                    64.0d
            ));
        } catch (ReflectiveOperationException exception) {
            throw new IllegalStateException("Failed to discover ChaosLib block entity model " + className, exception);
        }
    }

    private static GeoModel<?> instantiateModel(Class<?> rawClass) throws ReflectiveOperationException {
        Field instanceField = findInstanceField(rawClass);
        if (instanceField != null) {
            instanceField.setAccessible(true);
            return (GeoModel<?>) instanceField.get(null);
        }

        Constructor<?> constructor = rawClass.getDeclaredConstructor();
        constructor.setAccessible(true);
        return (GeoModel<?>) constructor.newInstance();
    }

    private static Field findInstanceField(Class<?> rawClass) {
        try {
            Field field = rawClass.getDeclaredField("INSTANCE");
            if (!GeoModel.class.isAssignableFrom(field.getType())) {
                return null;
            }
            return field;
        } catch (NoSuchFieldException ignored) {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    private static Class<? extends BlockEntity> resolveBlockEntityClass(Class<?> rawClass) {
        Type generic = rawClass.getGenericSuperclass();
        if (!(generic instanceof ParameterizedType parameterizedType)) {
            return null;
        }

        Type[] typeArguments = parameterizedType.getActualTypeArguments();
        if (typeArguments.length != 1 || !(typeArguments[0] instanceof Class<?> typeClass)) {
            return null;
        }

        if (!BlockEntity.class.isAssignableFrom(typeClass)) {
            return null;
        }

        return (Class<? extends BlockEntity>) typeClass;
    }

    private static Block resolveRegisteredBlock(ResourceLocation staticModelId) {
        ResourceLocation blockId = resolveBlockId(staticModelId);
        if (blockId == null || !BuiltInRegistries.BLOCK.containsKey(blockId)) {
            return null;
        }

        Block block = BuiltInRegistries.BLOCK.get(blockId);
        return block == Blocks.AIR ? null : block;
    }

    private static String resolveOptionPath(ResourceLocation staticModelId, Class<? extends BlockEntity> blockEntityClass) {
        ResourceLocation blockId = resolveBlockId(staticModelId);
        if (blockId != null) {
            return sanitizePath(blockId.getNamespace() + "_" + blockId.getPath());
        }

        return sanitizePath(blockEntityClass.getSimpleName());
    }

    private static ResourceLocation resolveBlockId(ResourceLocation staticModelId) {
        if (staticModelId == null) {
            return null;
        }

        String path = staticModelId.getPath();
        if (!path.startsWith("block/")) {
            return null;
        }

        return ResourceLocation.fromNamespaceAndPath(staticModelId.getNamespace(), path.substring("block/".length()));
    }

    private static String sanitizePath(String value) {
        String normalized = value.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9/._-]+", "_");
        return normalized.isBlank() ? "unknown" : normalized;
    }

    private static ResourceLocation safeResolve(Supplier<ResourceLocation> supplier) {
        try {
            return supplier.get();
        } catch (RuntimeException ignored) {
            return null;
        }
    }

    public record Entry(
            String key,
            Class<? extends BlockEntity> blockEntityClass,
            MutableComponent displayName,
            String optionPath,
            double defaultFreezeRadius,
            double defaultModelDataRadius
    ) {
    }
}
