package dev.elifian.chaoslib.compat.sodium;

import dev.elifian.chaoslib.config.ChaosLibClientConfig;
import dev.elifian.chaoslib.config.ChaosLibClientOptions;

import dev.elifian.chaoslib.platform.ClientOnly;

@ClientOnly
final class ChaosSodiumOptionsStorage {
    private final ChaosLibClientOptions data = ChaosLibClientConfig.get().copy();

    ChaosLibClientOptions getData() {
        return this.data;
    }

    void save() {
        ChaosLibClientConfig.apply(this.data);
    }
}
