package dev.elifian.chaoslib.compat.sodium;

import dev.elifian.chaoslib.ChaosLib;
import dev.elifian.chaoslib.api.animatable.GeoAnimatable;
import dev.elifian.chaoslib.api.animatable.GeoBlockEntity;
import dev.elifian.chaoslib.api.model.GeoModel;
import dev.elifian.chaoslib.api.renderer.GeoBlockRenderer;
import dev.elifian.chaoslib.api.renderer.GeoEntityRenderer;
import dev.elifian.chaoslib.cache.object.BakedGeoModel;
import dev.elifian.chaoslib.client.render.ChaosGuiBlurRenderer;
import dev.elifian.chaoslib.compat.chloride.ChlorideCompat;
import dev.elifian.chaoslib.config.ChaosLibClientConfig;
import dev.elifian.chaoslib.gpu.mesh.ChaosGpuGeoMesh;
import dev.elifian.chaoslib.gpu.render.ChaosGpuRenderRuntime;
import dev.elifian.chaoslib.mixin.compat.sodium.ConsoleActiveMessageAccessor;
import dev.elifian.chaoslib.mixin.compat.sodium.ConsoleRendererAccessor;
import dev.elifian.chaoslib.renderer.block.ChaosBlockEntityRenderDispatch;
import net.caffeinemc.mods.sodium.client.gui.console.ConsoleRenderer;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import dev.elifian.chaoslib.platform.ClientOnly;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@ClientOnly
public final class ChaosSodiumDebugOverlay {
    private static final Map<String, Snapshot> SNAPSHOTS = new ConcurrentHashMap<>();
    private static final int TEXT_COLOR = 0xFFE0E0E0;
    private static final int TITLE_COLOR = 0xFFFF8080;
    private static final int BACKGROUND_COLOR = 0x66000000;
    private static final int BACKGROUND_COLOR_NO_BLUR = 0x90000000;

    private ChaosSodiumDebugOverlay() {
    }

    public static int resolveTopLeftReservedOffset() {
        if (!ChaosLibClientConfig.sodium().showDebugOverlay) {
            return 0;
        }

        Minecraft client = Minecraft.getInstance();
        if (client.level == null || client.player == null
                || client.options.hideGui || client.getDebugOverlay().showDebugScreen()) {
            return 0;
        }

        OverlayState state = resolveOverlayState(client);
        if (state == null) {
            return 0;
        }

        int y = 8 + resolveSodiumConsoleOffset(client) + resolveChlorideFpsOffset(client);
        return y + state.lines().length * 10 + 5;
    }

    public static void recordBlockEntityDecision(BlockEntity blockEntity, ChaosSodiumGpuSkinningMode mode,
                                                 String path, boolean gpuPathSupported, boolean gpuLiveCapable,
                                                 String reasonKey) {
        SNAPSHOTS.put(blockEntity.getClass().getName(),
                new Snapshot(mode, path, gpuPathSupported, gpuLiveCapable, reasonKey));
    }

    public static void recordEntityDecision(Entity entity, String path, boolean gpuPathSupported,
                                            boolean gpuLiveCapable, String reasonKey) {
        SNAPSHOTS.put(entity.getClass().getName(),
                new Snapshot(null, path, gpuPathSupported, gpuLiveCapable, reasonKey));
    }

    public static void renderOverlay(GuiGraphics graphics, DeltaTracker deltaTracker) {
        boolean showDebugOverlay = ChaosLibClientConfig.sodium().showDebugOverlay;
        ChaosBlockEntityRenderDispatch.setDiagnosticsEnabled(showDebugOverlay);
        if (!showDebugOverlay) {
            return;
        }

        Minecraft client = Minecraft.getInstance();
        if (client.level == null || client.player == null
                || client.options.hideGui || client.getDebugOverlay().showDebugScreen()) {
            return;
        }

        OverlayState state = resolveOverlayState(client);
        if (state == null) {
            return;
        }

        int x = 8;
        int y = 8 + resolveSodiumConsoleOffset(client) + resolveChlorideFpsOffset(client);
        drawPanel(client, graphics, x, y, state.lines());
    }

    private static void drawPanel(Minecraft client, GuiGraphics graphics, int x, int y, Component[] lines) {
        int lineHeight = 10;
        int maxWidth = 0;
        for (Component line : lines) {
            maxWidth = Math.max(maxWidth, client.font.width(line));
        }

        int left = x - 3;
        int top = y - 3;
        int right = x + maxWidth + 3;
        int bottom = y + lines.length * lineHeight + 1;
        boolean blurred = ChaosGuiBlurRenderer.blur(graphics, left, top, right - left, bottom - top);
        graphics.fill(left, top, right, bottom, blurred ? BACKGROUND_COLOR : BACKGROUND_COLOR_NO_BLUR);
        for (int i = 0; i < lines.length; i++) {
            graphics.drawString(client.font, lines[i], x, y + i * lineHeight,
                    i == 0 ? TITLE_COLOR : TEXT_COLOR, true);
        }
    }

    private static BlockEntity resolveTargetedBlockEntity(Minecraft client) {
        if (!(client.hitResult instanceof BlockHitResult blockHit) || blockHit.getType() != HitResult.Type.BLOCK) {
            return null;
        }

        return client.level == null ? null : client.level.getBlockEntity(blockHit.getBlockPos());
    }

    private static Entity resolveTargetedEntity(Minecraft client) {
        if (client.crosshairPickEntity != null) {
            return client.crosshairPickEntity;
        }

        if (client.hitResult instanceof EntityHitResult entityHit && entityHit.getType() == HitResult.Type.ENTITY) {
            return entityHit.getEntity();
        }

        if (client.level == null || client.player == null) {
            return null;
        }

        Entity cameraEntity = client.getCameraEntity();
        if (cameraEntity == null) {
            return null;
        }

        float tickDelta = client.getTimer().getGameTimeDeltaPartialTick(false);
        double reach = client.player.entityInteractionRange();
        Vec3 start = cameraEntity.getEyePosition(tickDelta);
        Vec3 end = start.add(cameraEntity.getViewVector(tickDelta).scale(reach));
        double bestDistanceSquared = currentHitDistanceSquared(start, client.hitResult, reach);
        Entity bestEntity = null;
        AABB searchBox = new AABB(start, end).inflate(2.0);

        for (Entity entity : client.level.getEntities(cameraEntity, searchBox,
                candidate -> candidate instanceof GeoAnimatable && !candidate.isSpectator())) {
            AABB hitbox = entity.getBoundingBox().inflate(0.25d);
            var hit = hitbox.clip(start, end);
            if (hit.isEmpty()) {
                continue;
            }

            double hitDistanceSquared = start.distanceToSqr(hit.get());
            if (hitDistanceSquared < bestDistanceSquared) {
                bestDistanceSquared = hitDistanceSquared;
                bestEntity = entity;
            }
        }

        return bestEntity;
    }

    private static OverlayState resolveEntityOverlayState(Minecraft client, Entity entity) {
        DiagnosticState state = resolveEntityDiagnosticState(client, entity);
        Component[] lines = new Component[]{
                Component.translatable("chaoslib.sodium.debug.title"),
                Component.translatable("chaoslib.sodium.debug.target", entity.getDisplayName()),
                Component.translatable("chaoslib.sodium.debug.preparation_path",
                        Component.translatable("chaoslib.sodium.debug.path." + state.path().toLowerCase())),
                Component.translatable("chaoslib.sodium.debug.gpu_path_supported", yesNo(state.gpuPathSupported())),
                Component.translatable("chaoslib.sodium.debug.gpu_live_path_available", yesNo(state.gpuLiveCapable()))
        };
        if (state.shouldShowReason()) {
            lines = appendReason(lines, state.reasonKey());
        }
        return new OverlayState(lines);
    }

    private static OverlayState resolveOverlayState(Minecraft client) {
        if (client.level == null || client.player == null) {
            return null;
        }

        BlockEntity blockEntity = resolveTargetedBlockEntity(client);
        if (blockEntity instanceof GeoBlockEntity) {
            return resolveBlockEntityOverlayState(blockEntity);
        }

        Entity entity = resolveTargetedEntity(client);
        if (entity instanceof GeoAnimatable) {
            return resolveEntityOverlayState(client, entity);
        }

        return null;
    }

    private static OverlayState resolveBlockEntityOverlayState(BlockEntity blockEntity) {
        ChaosSodiumBlockEntityOptionRegistry.Entry entry =
                ChaosSodiumBlockEntityOptionRegistry.get(blockEntity.getClass().getName());
        if (entry == null) {
            return null;
        }

        DiagnosticState state = resolveBlockEntityDiagnosticState(blockEntity);
        ChaosBlockEntityRenderDispatch.Snapshot renderSnapshot = ChaosBlockEntityRenderDispatch.get(blockEntity);
        ChaosSodiumGpuSkinningMode mode = ChaosSodiumBlockEntitySettings.resolveGpuSkinningMode(blockEntity);
        Component[] lines = new Component[]{
                Component.translatable("chaoslib.sodium.debug.title"),
                Component.translatable("chaoslib.sodium.debug.target", entry.displayName()),
                Component.translatable("chaoslib.sodium.debug.render_backend", renderSnapshot.backend().displayText()),
                Component.translatable("chaoslib.sodium.debug.skinning", effectiveSkinningText(mode, state)),
                Component.translatable("chaoslib.sodium.debug.preparation_path",
                        Component.translatable("chaoslib.sodium.debug.path." + state.path().toLowerCase())),
                Component.translatable("chaoslib.sodium.debug.gpu_path_supported", yesNo(state.gpuPathSupported())),
                Component.translatable("chaoslib.sodium.debug.gpu_live_path_available", yesNo(state.gpuLiveCapable()))
        };
        if (state.shouldShowReason()) {
            lines = appendReason(lines, state.reasonKey());
        }
        return new OverlayState(lines);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static DiagnosticState resolveEntityDiagnosticState(Minecraft client, Entity entity) {
        Snapshot snapshot = SNAPSHOTS.get(entity.getClass().getName());
        if (snapshot != null) {
            return snapshotToDiagnostic(snapshot);
        }

        EntityRenderer renderer = client.getEntityRenderDispatcher().getRenderer(entity);
        if (!(renderer instanceof GeoEntityRenderer geoRenderer)) {
            return new DiagnosticState("UNSEEN", false, false, "renderer_not_geo");
        }

        GeoModel model = geoRenderer.getGeoModel();
        BakedGeoModel bakedModel = model.getBakedModel(model.getModelResource((GeoAnimatable) entity));
        boolean gpuPathSupported = ChaosGpuRenderRuntime.isGpuPathSupported(bakedModel);
        ChaosGpuGeoMesh mesh = ChaosGpuGeoMesh.getOrCreate(bakedModel);
        if (model.requiresCpuPoseSampling((GeoAnimatable) entity, mesh)) {
            return new DiagnosticState("CPU", false, false, "custom_cpu_pose");
        }

        GeoModel.GpuLiveRenderAnimationSupport support =
                model.getGpuLiveRenderAnimationSupport((GeoAnimatable) entity, mesh);
        return fromGpuSupport(gpuPathSupported, support);
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static DiagnosticState resolveBlockEntityDiagnosticState(BlockEntity blockEntity) {
        Snapshot snapshot = SNAPSHOTS.get(blockEntity.getClass().getName());
        if (snapshot != null) {
            return snapshotToDiagnostic(snapshot);
        }

        BlockEntityRenderer renderer =
                Minecraft.getInstance().getBlockEntityRenderDispatcher().getRenderer(blockEntity);
        if (!(renderer instanceof GeoBlockRenderer geoRenderer)) {
            return new DiagnosticState("UNSEEN", false, false, "renderer_not_geo");
        }

        try {
            GeoModel model = geoRenderer.getGeoModel();
            BakedGeoModel bakedModel = model.getBakedModel(model.getModelResource((GeoAnimatable) blockEntity));
            boolean gpuPathSupported = ChaosGpuRenderRuntime.isGpuPathSupported(bakedModel);
            ChaosGpuGeoMesh mesh = ChaosGpuGeoMesh.getOrCreate(bakedModel);
            GeoModel.GpuLiveRenderAnimationSupport support =
                    model.getGpuLiveRenderAnimationSupport((GeoAnimatable) blockEntity, mesh);
            ChaosSodiumGpuSkinningMode mode = ChaosSodiumBlockEntitySettings.resolveGpuSkinningMode(blockEntity);
            if (mode == ChaosSodiumGpuSkinningMode.FORCE_CPU) {
                return new DiagnosticState("CPU", false, false, "forced_cpu");
            }

            return fromGpuSupport(gpuPathSupported, support);
        } catch (Throwable throwable) {
            return new DiagnosticState("UNSEEN", false, false, "not_rendered_yet");
        }
    }

    private static DiagnosticState fromGpuSupport(boolean gpuPathSupported,
                                                  GeoModel.GpuLiveRenderAnimationSupport support) {
        final DiagnosticState diagnosticState = gpuPathSupported
                ? new DiagnosticState("GPU_LIVE", true, true, "gpu_animation")
                : new DiagnosticState("CPU", false, false, "gpu_backend_unavailable");
        return switch (support) {
            case NO_ANIMATION_DATA_AND_NO_GPU_PROCEDURAL ->
                    new DiagnosticState("NONE", gpuPathSupported, false, "no_animation");
            case CUSTOM_CPU_POSE -> new DiagnosticState("CPU", false, false, "custom_cpu_pose");
            case ANIMATION_RESOURCE_REQUIRES_CPU ->
                    new DiagnosticState("CPU", gpuPathSupported, false, "animation_requires_cpu");
            case GPU_PROCEDURAL_ONLY, GPU_LIVE_SAFE -> diagnosticState;
        };
    }

    private static DiagnosticState snapshotToDiagnostic(Snapshot snapshot) {
        if ("UNSEEN".equals(snapshot.path())) {
            return new DiagnosticState(snapshot.path(), snapshot.gpuPathSupported(), snapshot.gpuLiveCapable(),
                    "not_rendered_yet");
        }
        if ("NONE".equals(snapshot.path())) {
            return new DiagnosticState(snapshot.path(), snapshot.gpuPathSupported(), snapshot.gpuLiveCapable(),
                    "no_animation");
        }

        return new DiagnosticState(snapshot.path(), snapshot.gpuPathSupported(), snapshot.gpuLiveCapable(),
                snapshot.reasonKey());
    }

    private static int resolveSodiumConsoleOffset(Minecraft client) {
        ConsoleRenderer renderer = ConsoleRendererAccessor.getInstance();
        if (renderer == null) {
            return 0;
        }

        List<?> activeMessages = ((ConsoleRendererAccessor) renderer).getActiveMessages();
        if (activeMessages == null || activeMessages.isEmpty()) {
            return 0;
        }

        int y = 4;
        for (Object message : activeMessages) {
            Component text = ((ConsoleActiveMessageAccessor) message).getText();
            List<?> wrapped = client.font.getSplitter().splitLines(text, 250, Style.EMPTY);
            int lineCount = Math.max(1, wrapped.size());
            y += lineCount * 9 + 2;
        }

        return y;
    }

    private static int resolveChlorideFpsOffset(Minecraft client) {
        return ChlorideCompat.resolveTopLeftFpsHudOffset(client);
    }

    private static Component yesNo(boolean value) {
        return Component.translatable(value ? "chaoslib.sodium.debug.yes" : "chaoslib.sodium.debug.no");
    }

    private static Component effectiveSkinningText(ChaosSodiumGpuSkinningMode mode, DiagnosticState state) {
        return Component.translatable("chaoslib.sodium.debug.skinning_effective", mode.displayText(),
                Component.translatable("chaoslib.sodium.debug.path." + state.path().toLowerCase()));
    }

    private static double currentHitDistanceSquared(Vec3 start, HitResult hitResult, double reach) {
        if (hitResult == null || hitResult.getType() == HitResult.Type.MISS) {
            return reach * reach;
        }

        return start.distanceToSqr(hitResult.getLocation());
    }

    private static Component[] appendReason(Component[] lines, String reasonKey) {
        Component[] extended = new Component[lines.length + 1];
        System.arraycopy(lines, 0, extended, 0, lines.length);
        extended[lines.length] = Component.translatable("chaoslib.sodium.debug.reason",
                Component.translatable("chaoslib.sodium.debug.reason." + reasonKey));
        return extended;
    }

    private record OverlayState(Component[] lines) {
    }

    private record DiagnosticState(String path, boolean gpuPathSupported, boolean gpuLiveCapable, String reasonKey) {
        private boolean shouldShowReason() {
            return switch (this.reasonKey) {
                case "runtime", "gpu_animation" -> false;
                default -> true;
            };
        }
    }

    private record Snapshot(ChaosSodiumGpuSkinningMode mode, String path, boolean gpuPathSupported,
                            boolean gpuLiveCapable, String reasonKey) {
    }
}
