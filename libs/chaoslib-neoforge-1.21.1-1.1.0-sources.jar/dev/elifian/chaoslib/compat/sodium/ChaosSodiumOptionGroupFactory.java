package dev.elifian.chaoslib.compat.sodium;

import dev.elifian.chaoslib.ChaosLib;
import dev.elifian.chaoslib.config.ChaosAmdRenderingSafetyMode;
import dev.elifian.chaoslib.config.ChaosLibClientOptions;
import dev.elifian.chaoslib.config.ChaosLibObjectOverride;
import dev.elifian.chaoslib.gpu.backend.ChaosGpuDriverInfo;
import net.caffeinemc.mods.sodium.api.config.option.ControlValueFormatter;
import net.caffeinemc.mods.sodium.api.config.option.OptionFlag;
import net.caffeinemc.mods.sodium.api.config.option.OptionImpact;
import net.caffeinemc.mods.sodium.api.config.structure.ConfigBuilder;
import net.caffeinemc.mods.sodium.api.config.structure.EnumOptionBuilder;
import net.caffeinemc.mods.sodium.api.config.structure.OptionGroupBuilder;
import net.caffeinemc.mods.sodium.api.config.structure.OptionPageBuilder;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

import dev.elifian.chaoslib.platform.ClientOnly;
import org.jetbrains.annotations.Nullable;

import java.util.List;

@ClientOnly
final class ChaosSodiumOptionGroupFactory {
    private static final ResourceLocation ENABLE_ID = ChaosLib.id("sodium/enable_forced_block_entity_distances");
    private static final ResourceLocation FREEZE_DISTANCE_ID = ChaosLib.id("sodium/forced_freeze_radius");
    private static final ResourceLocation MODEL_DATA_DISTANCE_ID = ChaosLib.id("sodium/forced_modeldata_radius");
    private static final ResourceLocation KEEP_LIVE_BONES_ID = ChaosLib.id("sodium/keep_frozen_live_bones_on_ber");
    private static final ResourceLocation DEBUG_OVERLAY_ID = ChaosLib.id("sodium/debug_overlay");
    private static final ResourceLocation AMD_RENDERING_SAFETY_MODE_ID =
            ChaosLib.id("rendering/amd_rendering_safety_mode");
    private static final ResourceLocation WIDE_VIDEO_SETTINGS_ID =
            ChaosLib.id("additional/wide_sodium_video_settings");
    private static final int UNLIMITED_DISTANCE = 0;
    private static final int MIN_DISTANCE = 0;
    private static final int MAX_DISTANCE = 256;
    private static final int STEP = 1;

    private ChaosSodiumOptionGroupFactory() {
    }

    static OptionPageBuilder createGlobalPage(ConfigBuilder builder, ChaosSodiumOptionsStorage storage) {
        ChaosLibClientOptions opts = storage.getData();

        OptionGroupBuilder group = builder.createOptionGroup()
                .addOption(builder.createBooleanOption(ENABLE_ID)
                        .setName(Component.translatable("chaoslib.sodium.option.enable_forced_block_entity_distances"))
                        .setTooltip(Component.translatable(
                                "chaoslib.sodium.option.enable_forced_block_entity_distances.tooltip"))
                        .setDefaultValue(false)
                        .setBinding(value -> opts.sodium.enableForcedBlockEntityDistances = value,
                                () -> opts.sodium.enableForcedBlockEntityDistances)
                        .setStorageHandler(storage::save)
                        .setImpact(OptionImpact.HIGH)
                        .setFlags(OptionFlag.REQUIRES_RENDERER_UPDATE))
                .addOption(builder.createIntegerOption(FREEZE_DISTANCE_ID)
                        .setName(Component.translatable("chaoslib.sodium.option.forced_freeze_radius"))
                        .setTooltip(Component.translatable("chaoslib.sodium.option.forced_freeze_radius.tooltip"))
                        .setDefaultValue(64)
                        .setRange(MIN_DISTANCE, MAX_DISTANCE, STEP)
                        .setValueFormatter(radiusFormatter())
                        .setBinding(value -> opts.sodium.forcedFreezeRadius = value,
                                () -> opts.sodium.forcedFreezeRadius)
                        .setStorageHandler(storage::save)
                        .setImpact(OptionImpact.HIGH)
                        .setFlags(OptionFlag.REQUIRES_RENDERER_UPDATE))
                .addOption(builder.createBooleanOption(KEEP_LIVE_BONES_ID)
                        .setName(Component.translatable("chaoslib.sodium.option.keep_frozen_live_bones_on_ber"))
                        .setTooltip(Component.translatable(
                                "chaoslib.sodium.option.keep_frozen_live_bones_on_ber.tooltip"))
                        .setDefaultValue(false)
                        .setBinding(value -> opts.sodium.keepFrozenLiveBonesOnBer = value,
                                () -> opts.sodium.keepFrozenLiveBonesOnBer)
                        .setStorageHandler(storage::save)
                        .setImpact(OptionImpact.HIGH)
                        .setFlags(OptionFlag.REQUIRES_RENDERER_UPDATE))
                .addOption(builder.createIntegerOption(MODEL_DATA_DISTANCE_ID)
                        .setName(Component.translatable("chaoslib.sodium.option.forced_modeldata_radius"))
                        .setTooltip(Component.translatable("chaoslib.sodium.option.forced_modeldata_radius.tooltip"))
                        .setDefaultValue(64)
                        .setRange(MIN_DISTANCE, MAX_DISTANCE, STEP)
                        .setValueFormatter(radiusFormatter())
                        .setBinding(value -> opts.sodium.forcedModelDataRadius = value,
                                () -> opts.sodium.forcedModelDataRadius)
                        .setStorageHandler(storage::save)
                        .setImpact(OptionImpact.HIGH)
                        .setFlags(OptionFlag.REQUIRES_RENDERER_UPDATE))
                .addOption(builder.createBooleanOption(DEBUG_OVERLAY_ID)
                        .setName(Component.translatable("chaoslib.sodium.option.debug_overlay"))
                        .setTooltip(Component.translatable("chaoslib.sodium.option.debug_overlay.tooltip"))
                        .setDefaultValue(false)
                        .setBinding(value -> opts.sodium.showDebugOverlay = value,
                                () -> opts.sodium.showDebugOverlay)
                        .setStorageHandler(storage::save)
                        .setImpact(OptionImpact.LOW))
                .addOption(builder.createEnumOption(AMD_RENDERING_SAFETY_MODE_ID, ChaosAmdRenderingSafetyMode.class)
                        .setName(Component.translatable("chaoslib.config.option.amd_rendering_safety_mode"))
                        .setTooltip(Component.translatable("chaoslib.config.option.amd_rendering_safety_mode.tooltip"))
                        .setElementNameProvider(ChaosAmdRenderingSafetyMode::displayText)
                        .setDefaultValue(ChaosAmdRenderingSafetyMode.values()[0])
                        .setBinding(value -> opts.rendering.amdRenderingSafetyMode = value,
                                () -> opts.rendering.amdRenderingSafetyMode)
                        .setStorageHandler(storage::save)
                        .setEnabled(ChaosGpuDriverInfo.isAmdAtiRadeon())
                        .setImpact(OptionImpact.HIGH)
                        .setFlags(OptionFlag.REQUIRES_RENDERER_UPDATE));

        return builder.createOptionPage()
                .setName(Component.translatable("chaoslib.sodium.page.block_entity_rendering"))
                .addOptionGroup(group);
    }

    static OptionPageBuilder createAdditionalPage(ConfigBuilder builder, ChaosSodiumOptionsStorage storage) {
        ChaosLibClientOptions opts = storage.getData();

        OptionGroupBuilder group = builder.createOptionGroup()
                .addOption(builder.createBooleanOption(WIDE_VIDEO_SETTINGS_ID)
                        .setName(Component.translatable("chaoslib.config.additional.wide_sodium_video_settings"))
                        .setTooltip(Component.translatable(
                                "chaoslib.config.additional.wide_sodium_video_settings.tooltip"))
                        .setDefaultValue(true)
                        .setBinding(value -> opts.additional.wideSodiumVideoSettings = value,
                                () -> opts.additional.wideSodiumVideoSettings)
                        .setStorageHandler(storage::save)
                        .setImpact(OptionImpact.LOW));

        return builder.createOptionPage()
                .setName(Component.translatable("chaoslib.config.additional.title"))
                .addOptionGroup(group);
    }

    static @Nullable OptionPageBuilder createIndividualPage(ConfigBuilder builder,
                                                            ChaosSodiumOptionsStorage storage) {
        List<ChaosSodiumBlockEntityOptionRegistry.Entry> entries =
                ChaosSodiumBlockEntityOptionRegistry.entries();
        if (entries.isEmpty()) {
            return null;
        }

        OptionPageBuilder page = builder.createOptionPage()
                .setName(Component.translatable("chaoslib.sodium.page.block_entity_rendering_individual"));

        for (ChaosSodiumBlockEntityOptionRegistry.Entry entry : entries) {
            page.addOptionGroup(createObjectGroup(builder, storage, entry));
        }

        return page;
    }

    private static OptionGroupBuilder createObjectGroup(ConfigBuilder builder,
                                                        ChaosSodiumOptionsStorage storage,
                                                        ChaosSodiumBlockEntityOptionRegistry.Entry entry) {
        ChaosLibClientOptions opts = storage.getData();
        int defaultFreeze = toStoredRadius(entry.defaultFreezeRadius());
        int defaultModelData = toStoredRadius(entry.defaultModelDataRadius());
        ResourceLocation baseId = ChaosLib.id("sodium/object/" + entry.optionPath());

        EnumOptionBuilder<ChaosSodiumGpuSkinningMode> skinningOption =
                builder.createEnumOption(childId(baseId, "gpu_skinning"), ChaosSodiumGpuSkinningMode.class)
                        .setName(Component.translatable("chaoslib.sodium.option.skinning_mode"))
                        .setTooltip(Component.translatable("chaoslib.sodium.option.skinning_mode.tooltip"))
                        .setElementNameProvider(ChaosSodiumGpuSkinningMode::displayText)
                        .setDefaultValue(ChaosSodiumGpuSkinningMode.AUTO)
                        .setBinding(
                                value -> override(opts, entry, defaultFreeze, defaultModelData).gpuSkinningMode = value,
                                () -> override(opts, entry, defaultFreeze, defaultModelData).gpuSkinningMode)
                        .setStorageHandler(storage::save)
                        .setImpact(OptionImpact.HIGH)
                        .setFlags(OptionFlag.REQUIRES_RENDERER_UPDATE);

        return builder.createOptionGroup()
                .setName(entry.displayName().copy())
                .addOption(builder.createBooleanOption(childId(baseId, "enabled"))
                        .setName(entry.displayName().copy())
                        .setTooltip(Component.translatable("chaoslib.sodium.option.object_override.tooltip"))
                        .setDefaultValue(false)
                        .setBinding(value -> override(opts, entry, defaultFreeze, defaultModelData).enabled = value,
                                () -> override(opts, entry, defaultFreeze, defaultModelData).enabled)
                        .setStorageHandler(storage::save)
                        .setImpact(OptionImpact.HIGH)
                        .setFlags(OptionFlag.REQUIRES_RENDERER_UPDATE))
                .addOption(builder.createIntegerOption(childId(baseId, "freeze"))
                        .setName(Component.translatable("chaoslib.sodium.option.forced_freeze_radius"))
                        .setTooltip(Component.translatable("chaoslib.sodium.option.forced_freeze_radius.tooltip"))
                        .setDefaultValue(defaultFreeze)
                        .setRange(MIN_DISTANCE, MAX_DISTANCE, STEP)
                        .setValueFormatter(radiusFormatter())
                        .setBinding(value -> override(opts, entry, defaultFreeze, defaultModelData).freezeRadius = value,
                                () -> override(opts, entry, defaultFreeze, defaultModelData).freezeRadius)
                        .setStorageHandler(storage::save)
                        .setImpact(OptionImpact.HIGH)
                        .setFlags(OptionFlag.REQUIRES_RENDERER_UPDATE))
                .addOption(builder.createBooleanOption(childId(baseId, "bones"))
                        .setName(Component.translatable("chaoslib.sodium.option.keep_frozen_live_bones_on_ber"))
                        .setTooltip(Component.translatable(
                                "chaoslib.sodium.option.keep_frozen_live_bones_on_ber.tooltip"))
                        .setDefaultValue(false)
                        .setBinding(
                                value -> override(opts, entry, defaultFreeze, defaultModelData).keepAnimatedBones = value,
                                () -> override(opts, entry, defaultFreeze, defaultModelData).keepAnimatedBones)
                        .setStorageHandler(storage::save)
                        .setImpact(OptionImpact.HIGH)
                        .setFlags(OptionFlag.REQUIRES_RENDERER_UPDATE))
                .addOption(builder.createIntegerOption(childId(baseId, "modeldata"))
                        .setName(Component.translatable("chaoslib.sodium.option.forced_modeldata_radius"))
                        .setTooltip(Component.translatable("chaoslib.sodium.option.forced_modeldata_radius.tooltip"))
                        .setDefaultValue(defaultModelData)
                        .setRange(MIN_DISTANCE, MAX_DISTANCE, STEP)
                        .setValueFormatter(radiusFormatter())
                        .setBinding(
                                value -> override(opts, entry, defaultFreeze, defaultModelData).modelDataRadius = value,
                                () -> override(opts, entry, defaultFreeze, defaultModelData).modelDataRadius)
                        .setStorageHandler(storage::save)
                        .setImpact(OptionImpact.HIGH)
                        .setFlags(OptionFlag.REQUIRES_RENDERER_UPDATE))
                .addOption(skinningOption);
    }

    private static ChaosLibObjectOverride override(ChaosLibClientOptions opts,
                                                   ChaosSodiumBlockEntityOptionRegistry.Entry entry,
                                                   int defaultFreeze, int defaultModelData) {
        return opts.sodium.getOrCreateObjectOverride(entry.key(), defaultFreeze, defaultModelData);
    }

    private static ResourceLocation childId(ResourceLocation baseId, String suffix) {
        return ResourceLocation.fromNamespaceAndPath(baseId.getNamespace(), baseId.getPath() + "/" + suffix);
    }

    private static ControlValueFormatter radiusFormatter() {
        return value -> value == UNLIMITED_DISTANCE
                ? Component.translatable("chaoslib.sodium.option.radius.unlimited")
                : Component.translatable("chaoslib.sodium.option.radius.value", value);
    }

    private static int toStoredRadius(double value) {
        if (!Double.isFinite(value)) {
            return 0;
        }

        return Math.max(0, (int) Math.round(value));
    }
}
