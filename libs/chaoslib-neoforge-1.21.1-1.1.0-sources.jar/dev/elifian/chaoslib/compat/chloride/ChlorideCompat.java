package dev.elifian.chaoslib.compat.chloride;

import net.minecraft.client.Minecraft;
import dev.elifian.chaoslib.platform.Services;

public final class ChlorideCompat {
    private static Boolean chlorideLoaded;

    private ChlorideCompat() {
    }

    public static boolean isChlorideLoaded() {
        Boolean cached = chlorideLoaded;
        if (cached != null) {
            return cached;
        }

        boolean loaded = Services.PLATFORM.isModLoaded("chloride");
        chlorideLoaded = loaded;
        return loaded;
    }

    public static int resolveTopLeftFpsHudOffset(Minecraft client) {
        if (!isChlorideLoaded()) {
            return 0;
        }

        return ChlorideBridge.resolveTopLeftFpsHudOffset(client);
    }
}
