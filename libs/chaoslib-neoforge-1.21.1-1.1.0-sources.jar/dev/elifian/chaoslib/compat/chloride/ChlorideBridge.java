package dev.elifian.chaoslib.compat.chloride;

import me.srrapero720.chloride.ChlorideConfig;
import me.srrapero720.chloride.impl.Overlay;
import net.minecraft.client.Minecraft;

final class ChlorideBridge {
    private static final int TOP_MARGIN_PIXELS = 12;
    private static final int LINE_HEIGHT_PIXELS = 9;

    private ChlorideBridge() {
    }

    static int resolveTopLeftFpsHudOffset(Minecraft client) {
        if (client == null
                || ChlorideConfig.fpsDisplayAlign != Overlay.FPSAlign.LEFT
                || ChlorideConfig.fpsDisplayVAlign != Overlay.FPSVAlign.TOP) {
            return 0;
        }

        int lineCount = fpsLineCount(ChlorideConfig.fpsDisplayMode)
                + systemLineCount(ChlorideConfig.fpsDisplaySystemMode);
        if (lineCount == 0) {
            return 0;
        }

        double guiScale = client.getWindow().getGuiScale();
        int topMargin = guiScale > 0.0d
                ? (int) Math.ceil(TOP_MARGIN_PIXELS / guiScale)
                : TOP_MARGIN_PIXELS;
        return topMargin + lineCount * LINE_HEIGHT_PIXELS;
    }

    private static int fpsLineCount(Overlay.FPS mode) {
        if (mode == null) {
            return 0;
        }

        return switch (mode) {
            case OFF -> 0;
            case SIMPLE -> 1;
            case ADVANCED -> 3;
        };
    }

    private static int systemLineCount(Overlay.FPSDetails mode) {
        if (mode == null) {
            return 0;
        }

        return switch (mode) {
            case OFF -> 0;
            case GPU_ONLY, RAM_ONLY -> 1;
            case ALL -> 2;
        };
    }
}
