package dev.elifian.chaoslib.compat.iris;

import dev.elifian.chaoslib.ChaosLib;
import dev.elifian.chaoslib.compat.iris.access.IrisRenderingPipelineAccess;
import dev.elifian.chaoslib.compat.iris.access.ProgramSourceAccess;
import dev.elifian.chaoslib.gpu.render.ChaosShaderRenderPhase;
import net.irisshaders.iris.Iris;
import net.irisshaders.iris.pipeline.IrisRenderingPipeline;
import net.irisshaders.iris.pipeline.WorldRenderingPipeline;
import net.irisshaders.iris.pipeline.programs.ShaderKey;
import net.irisshaders.iris.shaderpack.programs.ProgramFallbackResolver;
import net.irisshaders.iris.shaderpack.programs.ProgramSet;
import net.irisshaders.iris.shaderpack.programs.ProgramSource;
import net.irisshaders.iris.shadows.ShadowRenderingState;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ShaderInstance;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.regex.Pattern;

public final class ChaosIrisShaderPackProgramCompiler {
    private static final Pattern ENTITY_GENERATED_NORMALS_CALL = Pattern.compile(
            "(?m)^(\\s*)if \\(!noGeneratedNormals\\) GenerateNormals\\(normalM, colorP\\);\\s*$"
    );
    private static final Pattern BLOCK_ENTITY_GENERATED_NORMALS_CALL = Pattern.compile(
            "(?m)^(\\s*)GenerateNormals\\(normalM, colorP\\);\\s*$"
    );
    private static final Map<IrisRenderingPipeline, Map<CacheKey, Optional<ShaderInstance>>> SHADER_CACHE =
            new WeakHashMap<>();
    private static final Map<ProgramSet, ProgramFallbackResolver> RESOLVER_CACHE = new WeakHashMap<>();
    private static final Set<String> LOGGED_FAILURES = new HashSet<>();
    private static int programCounter;

    private ChaosIrisShaderPackProgramCompiler() {
    }

    public static synchronized void invalidateAll() {
        SHADER_CACHE.clear();
        RESOLVER_CACHE.clear();
        LOGGED_FAILURES.clear();
    }

    public static synchronized @Nullable ShaderInstance getShader(
            ChaosShaderRenderPhase phase, RenderType renderLayer) {
        return getShader(phase, renderLayer, false);
    }

    public static synchronized @Nullable ShaderInstance getShader(
            ChaosShaderRenderPhase phase, RenderType renderLayer, boolean skinned) {
        WorldRenderingPipeline pipeline = Iris.getPipelineManager().getPipelineNullable();
        if (!(pipeline instanceof IrisRenderingPipeline irisPipeline)) {
            return null;
        }

        boolean shadowPass = ShadowRenderingState.areShadowsCurrentlyBeingRendered();
        ShaderKey shaderKey = selectShaderKey(phase, renderLayer, shadowPass);
        return getOrCreateShader(irisPipeline, new CacheKey(shaderKey, phase, skinned));
    }

    public static synchronized @Nullable ShaderInstance getShadowShader(ChaosShaderRenderPhase phase) {
        if (!ShadowRenderingState.areShadowsCurrentlyBeingRendered()) {
            return null;
        }

        WorldRenderingPipeline pipeline = Iris.getPipelineManager().getPipelineNullable();
        if (!(pipeline instanceof IrisRenderingPipeline irisPipeline)) {
            return null;
        }

        return getOrCreateShader(
                irisPipeline,
                new CacheKey(ShaderKey.SHADOW_ENTITIES_CUTOUT, phase, false)
        );
    }

    private static @Nullable ShaderInstance getOrCreateShader(
            IrisRenderingPipeline pipeline, CacheKey key) {
        Map<CacheKey, Optional<ShaderInstance>> pipelineCache =
                SHADER_CACHE.computeIfAbsent(pipeline, ignored -> new HashMap<>());
        Optional<ShaderInstance> cached = pipelineCache.get(key);
        if (cached != null) {
            return cached.orElse(null);
        }

        ShaderInstance shader = createShader(pipeline, key);
        pipelineCache.put(key, Optional.ofNullable(shader));
        return shader;
    }

    private static @Nullable ShaderInstance createShader(IrisRenderingPipeline pipeline, CacheKey key) {
        IrisRenderingPipelineAccess pipelineAccess = (IrisRenderingPipelineAccess) pipeline;
        ProgramSet programSet = pipelineAccess.chaoslib$getProgramSet();
        if (programSet == null) {
            logFailureOnce("missing-program-set",
                    "Iris shader pack program unavailable: pipeline has no ProgramSet");
            return null;
        }

        ProgramFallbackResolver resolver = RESOLVER_CACHE.computeIfAbsent(programSet, ProgramFallbackResolver::new);
        ProgramSource sourceReference = resolver.resolve(key.shaderKey().getProgram()).orElse(null);
        if (sourceReference == null
                || sourceReference.getVertexSource().isEmpty()
                || sourceReference.getFragmentSource().isEmpty()) {
            logFailureOnce("missing-source-" + key.shaderKey().getProgram(),
                    "Iris shader pack program unavailable: source " + key.shaderKey().getProgram()
                            + " has no vertex or fragment stage");
            return null;
        }

        ProgramSource source = copySource(
                "chaoslib_" + key.shaderKey().getProgram().name().toLowerCase(Locale.ROOT) + "_" + programCounter++,
                sourceReference,
                programSet,
                key.phase(),
                key.skinned()
        );
        if (source == null) {
            logFailureOnce("skinning-injection-" + key.shaderKey().getProgram(),
                    "Iris shader pack program " + key.shaderKey().getProgram()
                            + " cannot host ChaosLib skinning; falling back to transform feedback");
            return null;
        }

        try {
            if (key.shaderKey().isShadow()) {
                return pipelineAccess.chaoslib$createShadowShader(
                        source.getName(),
                        source,
                        key.shaderKey().getProgram(),
                        key.shaderKey().getAlphaTest(),
                        key.shaderKey().getVertexFormat(),
                        key.shaderKey().isIntensity(),
                        key.shaderKey().shouldIgnoreLightmap(),
                        key.shaderKey().isText(),
                        false
                );
            }

            return pipelineAccess.chaoslib$createShader(
                    source.getName(),
                    source,
                    key.shaderKey().getProgram(),
                    key.shaderKey().getAlphaTest(),
                    key.shaderKey().getVertexFormat(),
                    key.shaderKey().getFogMode(),
                    key.shaderKey().isIntensity(),
                    key.shaderKey().shouldIgnoreLightmap(),
                    key.shaderKey().isGlint(),
                    key.shaderKey().isText(),
                    false
            );
        } catch (IOException | RuntimeException exception) {
            logFailureOnce("compile-" + key.shaderKey(),
                    "Failed to compile Iris shader pack program for " + key.shaderKey());
            return null;
        }
    }

    private static void logFailureOnce(String key, String message) {
        if (LOGGED_FAILURES.add(key)) {
            ChaosLib.LOGGER.warn("ChaosLib: {}", message);
        }
    }

    private static @Nullable ProgramSource copySource(
            String name, ProgramSource source, ProgramSet programSet, ChaosShaderRenderPhase phase, boolean skinned) {
        ProgramSourceAccess sourceAccess = (ProgramSourceAccess) source;
        String vertexSource = source.getVertexSource().orElse(null);
        if (skinned) {
            vertexSource = ChaosShaderPackSkinningInjector.inject(vertexSource);
            if (vertexSource == null) {
                return null;
            }
        }
        String fragmentSource = mutateFragmentSourceForPhase(source.getFragmentSource().orElse(null), phase);
        return new ProgramSource(
                name,
                vertexSource,
                source.getGeometrySource().orElse(null),
                source.getTessControlSource().orElse(null),
                source.getTessEvalSource().orElse(null),
                fragmentSource,
                programSet,
                sourceAccess.chaoslib$getShaderProperties(),
                sourceAccess.chaoslib$getBlendModeOverride()
        );
    }

    private static String mutateFragmentSourceForPhase(
            @Nullable String fragmentSource, ChaosShaderRenderPhase phase) {
        if (fragmentSource == null) {
            return null;
        }

        return switch (phase) {
            case ENTITIES -> ENTITY_GENERATED_NORMALS_CALL.matcher(fragmentSource)
                    .replaceAll("$1/* ChaosLib: generated normals disabled for geo entities */");
            case BLOCK_ENTITIES -> BLOCK_ENTITY_GENERATED_NORMALS_CALL.matcher(fragmentSource)
                    .replaceAll("$1/* ChaosLib: generated normals disabled for geo block entities */");
            default -> fragmentSource;
        };
    }

    private static ShaderKey selectShaderKey(
            ChaosShaderRenderPhase phase, RenderType renderLayer, boolean shadowPass) {
        if (shadowPass) {
            return ShaderKey.SHADOW_ENTITIES_CUTOUT;
        }

        String layerName = renderLayer.toString().toLowerCase(Locale.ROOT);
        boolean translucent = layerName.contains("translucent") || layerName.contains("tripwire");
        boolean cutout = layerName.contains("cutout") || layerName.contains("decal") || layerName.contains("smooth");

        return switch (phase) {
            case BLOCK_ENTITIES, NONE, OUTLINE -> translucent
                    ? ShaderKey.BE_TRANSLUCENT
                    : ShaderKey.BLOCK_ENTITY_DIFFUSE;
            case ENTITIES -> translucent
                    ? ShaderKey.ENTITIES_TRANSLUCENT
                    : (cutout ? ShaderKey.ENTITIES_CUTOUT_DIFFUSE : ShaderKey.ENTITIES_CUTOUT);
        };
    }

    private record CacheKey(ShaderKey shaderKey, ChaosShaderRenderPhase phase, boolean skinned) {
    }
}
