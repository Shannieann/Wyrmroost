package dev.elifian.chaoslib.compat.iris.access;

import net.irisshaders.iris.gl.blending.AlphaTest;
import net.irisshaders.iris.gl.state.FogMode;
import net.irisshaders.iris.shaderpack.loading.ProgramId;
import net.irisshaders.iris.shaderpack.programs.ProgramSet;
import net.irisshaders.iris.shaderpack.programs.ProgramSource;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.renderer.ShaderInstance;

import java.io.IOException;

public interface IrisRenderingPipelineAccess {
    ProgramSet chaoslib$getProgramSet();

    ShaderInstance chaoslib$createShader(
            String name,
            ProgramSource source,
            ProgramId programId,
            AlphaTest fallbackAlpha,
            VertexFormat vertexFormat,
            FogMode fogMode,
            boolean isIntensity,
            boolean isFullbright,
            boolean isGlint,
            boolean isText,
            boolean isIeCompat
    ) throws IOException;

    ShaderInstance chaoslib$createShadowShader(
            String name,
            ProgramSource source,
            ProgramId programId,
            AlphaTest fallbackAlpha,
            VertexFormat vertexFormat,
            boolean isIntensity,
            boolean isFullbright,
            boolean isText,
            boolean isIeCompat
    ) throws IOException;
}
