package dev.elifian.chaoslib.compat.iris.access;

import net.irisshaders.iris.gl.blending.BlendModeOverride;
import net.irisshaders.iris.shaderpack.properties.ShaderProperties;

public interface ProgramSourceAccess {
    ShaderProperties chaoslib$getShaderProperties();

    BlendModeOverride chaoslib$getBlendModeOverride();
}
