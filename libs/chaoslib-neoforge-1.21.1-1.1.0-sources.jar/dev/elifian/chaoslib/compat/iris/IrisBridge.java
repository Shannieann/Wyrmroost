package dev.elifian.chaoslib.compat.iris;

import dev.elifian.chaoslib.gpu.render.ChaosShaderRenderPhase;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import net.irisshaders.iris.api.v0.IrisApi;
import net.irisshaders.iris.layer.BlockEntityRenderStateShard;
import net.irisshaders.iris.layer.EntityRenderStateShard;
import net.irisshaders.iris.layer.GbufferPrograms;
import net.irisshaders.iris.layer.IsOutlineRenderStateShard;
import net.irisshaders.iris.layer.OuterWrappedRenderType;
import net.irisshaders.iris.pipeline.WorldRenderingPhase;
import net.irisshaders.iris.shaderpack.materialmap.WorldRenderingSettings;
import net.irisshaders.iris.shadows.ShadowRenderingState;
import net.irisshaders.iris.uniforms.CapturedRenderingState;
import net.irisshaders.iris.vertices.ImmediateState;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;

import java.util.EnumMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Supplier;

final class IrisBridge {
    private static final Map<ChaosShaderRenderPhase, Map<RenderType, RenderType>> PHASED_RENDER_LAYER_CACHE =
            new EnumMap<>(ChaosShaderRenderPhase.class);

    private IrisBridge() {
    }

    static {
        PHASED_RENDER_LAYER_CACHE.put(ChaosShaderRenderPhase.ENTITIES, new ConcurrentHashMap<>());
        PHASED_RENDER_LAYER_CACHE.put(ChaosShaderRenderPhase.BLOCK_ENTITIES, new ConcurrentHashMap<>());
        PHASED_RENDER_LAYER_CACHE.put(ChaosShaderRenderPhase.OUTLINE, new ConcurrentHashMap<>());
    }

    static boolean isShaderPackActive() {
        return IrisApi.getInstance().isShaderPackInUse();
    }

    static RenderType wrapRenderLayer(RenderType renderLayer, ChaosShaderRenderPhase phase) {
        if (renderLayer == null) {
            return null;
        }

        Map<RenderType, RenderType> cache = PHASED_RENDER_LAYER_CACHE.get(phase);
        if (cache == null) {
            return renderLayer;
        }

        return cache.computeIfAbsent(renderLayer, key -> wrapRenderLayerInternal(key, phase));
    }

    static int currentRenderedEntityId() {
        return CapturedRenderingState.INSTANCE.getCurrentRenderedEntity();
    }

    static int currentRenderedBlockEntityId() {
        return CapturedRenderingState.INSTANCE.getCurrentRenderedBlockEntity();
    }

    static int currentRenderedItemId() {
        return CapturedRenderingState.INSTANCE.getCurrentRenderedItem();
    }

    static void withPhase(ChaosShaderRenderPhase phase, Runnable action) {
        if (GbufferPrograms.getCurrentPhase() == mapPhase(phase)) {
            action.run();
            return;
        }

        beginPhase(phase);
        try {
            action.run();
        } finally {
            endPhase(phase);
        }
    }

    static <T> T withPhase(ChaosShaderRenderPhase phase, Supplier<T> action) {
        if (GbufferPrograms.getCurrentPhase() == mapPhase(phase)) {
            return action.get();
        }

        beginPhase(phase);
        try {
            return action.get();
        } finally {
            endPhase(phase);
        }
    }

    static void withBlockEntityContext(BlockEntity blockEntity, Runnable action) {
        Object2IntMap<BlockState> blockStateIds = WorldRenderingSettings.INSTANCE.getBlockStateIds();
        if (blockStateIds == null) {
            action.run();
            return;
        }

        CapturedRenderingState renderingState = CapturedRenderingState.INSTANCE;
        int previousBlockEntity = renderingState.getCurrentRenderedBlockEntity();
        int blockEntityId = blockStateIds.getOrDefault(blockEntity.getBlockState(), -1);
        renderingState.setCurrentBlockEntity(blockEntityId);
        try {
            action.run();
        } finally {
            renderingState.setCurrentBlockEntity(previousBlockEntity);
        }
    }

    static boolean isShadowPassActive() {
        return ShadowRenderingState.areShadowsCurrentlyBeingRendered();
    }

    static void withVanillaVertexFormatState(Runnable action) {
        boolean previous = ImmediateState.renderWithExtendedVertexFormat;
        ImmediateState.renderWithExtendedVertexFormat = false;
        try {
            action.run();
        } finally {
            ImmediateState.renderWithExtendedVertexFormat = previous;
        }
    }

    static void clearCaches() {
        for (Map<RenderType, RenderType> cache : PHASED_RENDER_LAYER_CACHE.values()) {
            cache.clear();
        }
    }

    private static RenderType wrapRenderLayerInternal(RenderType renderLayer, ChaosShaderRenderPhase phase) {
        return switch (phase) {
            case ENTITIES -> OuterWrappedRenderType.wrapExactlyOnce(
                    "chaoslib:entities/" + renderLayer,
                    renderLayer,
                    EntityRenderStateShard.INSTANCE
            );
            case BLOCK_ENTITIES -> OuterWrappedRenderType.wrapExactlyOnce(
                    "chaoslib:block_entities/" + renderLayer,
                    renderLayer,
                    BlockEntityRenderStateShard.INSTANCE
            );
            case OUTLINE -> OuterWrappedRenderType.wrapExactlyOnce(
                    "chaoslib:outline/" + renderLayer,
                    renderLayer,
                    IsOutlineRenderStateShard.INSTANCE
            );
            default -> renderLayer;
        };
    }

    private static void beginPhase(ChaosShaderRenderPhase phase) {
        switch (phase) {
            case ENTITIES -> GbufferPrograms.beginEntities();
            case BLOCK_ENTITIES -> GbufferPrograms.beginBlockEntities();
            case OUTLINE -> GbufferPrograms.beginOutline();
            default -> GbufferPrograms.setOverridePhase(mapPhase(phase));
        }
    }

    private static void endPhase(ChaosShaderRenderPhase phase) {
        switch (phase) {
            case ENTITIES -> GbufferPrograms.endEntities();
            case BLOCK_ENTITIES -> GbufferPrograms.endBlockEntities();
            case OUTLINE -> GbufferPrograms.endOutline();
            default -> GbufferPrograms.setOverridePhase(null);
        }
    }

    private static WorldRenderingPhase mapPhase(ChaosShaderRenderPhase phase) {
        return switch (phase) {
            case ENTITIES -> WorldRenderingPhase.ENTITIES;
            case BLOCK_ENTITIES -> WorldRenderingPhase.BLOCK_ENTITIES;
            case OUTLINE -> WorldRenderingPhase.OUTLINE;
            case NONE -> WorldRenderingPhase.NONE;
        };
    }
}
