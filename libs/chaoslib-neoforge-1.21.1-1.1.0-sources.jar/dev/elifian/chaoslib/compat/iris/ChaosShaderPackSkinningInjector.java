package dev.elifian.chaoslib.compat.iris;

import dev.elifian.chaoslib.ChaosLib;
import dev.elifian.chaoslib.gpu.shader.ChaosGpuShaderSources;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class ChaosShaderPackSkinningInjector {
    private static final String SKINNING_MODULE =
            ChaosGpuShaderSources.load("assets/chaoslib/shaders/internal/shaderpack_inject/skinning.glsl");

    private static final Pattern DIRECTIVE_PREFIX = Pattern.compile(
            "(?s)\\A(\\s*(?:#version[^\\n]*\\n|#extension[^\\n]*\\n|//[^\\n]*\\n|/\\*.*?\\*/|\\s)*)"
    );

    private static final Pattern FTRANSFORM_CALL = Pattern.compile("\\bftransform\\s*\\(\\s*\\)");
    private static final String FTRANSFORM_PLACEHOLDER = "CHAOS_FTRANSFORM_PLACEHOLDER";
    private static boolean loggedRewrite;

    private static final AttributeNames COMPATIBILITY_NAMES = new AttributeNames(
            "gl_Vertex", "gl_Normal", "at_tangent", List.of("gl_MultiTexCoord1", "gl_MultiTexCoord2"), true
    );
    private static final AttributeNames CORE_NAMES = new AttributeNames(
            "vaPosition", "vaNormal", "at_tangent", List.of("vaUV2"), false
    );

    private ChaosShaderPackSkinningInjector() {
    }

    public static @Nullable String inject(@Nullable String vertexSource) {
        if (vertexSource == null || vertexSource.isBlank() || vertexSource.contains("chaos_skinPosition")) {
            return null;
        }

        AttributeNames names = resolveAttributeNames(vertexSource);
        if (names == null) {
            return null;
        }

        String rewritten = vertexSource;

        int ftransformCount = countMatches(FTRANSFORM_CALL, rewritten);
        rewritten = FTRANSFORM_CALL.matcher(rewritten).replaceAll(FTRANSFORM_PLACEHOLDER);

        for (String lightmapName : names.lightmap()) {
            rewritten = replaceIdentifier(rewritten, lightmapName, lightmapAccessor(names));
        }

        int positionCount = countMatches(identifierPattern(names.position()), rewritten);
        rewritten = replaceIdentifier(rewritten, names.position(), "chaos_skinPosition(" + rawPositionExpression(names) + ")");
        rewritten = replaceIdentifier(rewritten, names.normal(), "chaos_skinNormal(" + names.normal() + ")");
        if (containsIdentifier(rewritten, names.tangent())) {
            rewritten = replaceIdentifier(rewritten, names.tangent(), "chaos_skinTangent(" + names.tangent() + ")");
        }

        rewritten = rewritten.replace(
                FTRANSFORM_PLACEHOLDER,
                "(gl_ModelViewProjectionMatrix * chaos_skinPosition(gl_Vertex))"
        );

        if (positionCount == 0 && ftransformCount == 0) {
            return null;
        }

        logRewriteOnce(names, positionCount, ftransformCount);
        return insertAfterDirectives(rewritten, SKINNING_MODULE);
    }

    private static void logRewriteOnce(AttributeNames names, int positionCount, int ftransformCount) {
        if (loggedRewrite) {
            return;
        }

        loggedRewrite = true;
        ChaosLib.LOGGER.info(
                "ChaosLib: skinning injected into shader pack vertex stage ({} profile, {} position reads, {} ftransform calls)",
                names.compatibilityProfile() ? "compatibility" : "core",
                positionCount,
                ftransformCount
        );
    }

    private static @Nullable AttributeNames resolveAttributeNames(String vertexSource) {
        if (containsIdentifier(vertexSource, CORE_NAMES.position())) {
            return CORE_NAMES;
        }
        if (containsIdentifier(vertexSource, COMPATIBILITY_NAMES.position())
                || containsIdentifier(vertexSource, COMPATIBILITY_NAMES.normal())
                || FTRANSFORM_CALL.matcher(vertexSource).find()) {
            return COMPATIBILITY_NAMES;
        }

        return null;
    }

    private static String rawPositionExpression(AttributeNames names) {
        return names.compatibilityProfile()
                ? names.position()
                : "vec4(" + names.position() + ", 1.0)";
    }

    private static String lightmapAccessor(AttributeNames names) {
        String call = "chaos_lightmapCoord(" + rawPositionExpression(names) + ", " + names.normal() + ")";
        return names.compatibilityProfile() ? call : call + ".xy";
    }

    private static String insertAfterDirectives(String source, String module) {
        Matcher matcher = DIRECTIVE_PREFIX.matcher(source);
        int insertAt = matcher.find() ? matcher.end() : 0;
        return source.substring(0, insertAt) + module + source.substring(insertAt);
    }

    private static Pattern identifierPattern(String identifier) {
        return Pattern.compile("\\b" + Pattern.quote(identifier) + "\\b");
    }

    private static boolean containsIdentifier(String source, String identifier) {
        return identifierPattern(identifier).matcher(source).find();
    }

    private static String replaceIdentifier(String source, String identifier, String replacement) {
        return identifierPattern(identifier)
                .matcher(source)
                .replaceAll(Matcher.quoteReplacement(replacement));
    }

    private static int countMatches(Pattern pattern, String source) {
        Matcher matcher = pattern.matcher(source);
        int count = 0;
        while (matcher.find()) {
            count++;
        }
        return count;
    }

    private record AttributeNames(
            String position,
            String normal,
            String tangent,
            List<String> lightmap,
            boolean compatibilityProfile
    ) {
    }
}
