package dev.elifian.chaoslib.compat.iris;

import dev.elifian.chaoslib.gpu.render.ChaosShaderRenderPhase;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ShaderInstance;
import dev.elifian.chaoslib.platform.Services;
import org.jetbrains.annotations.Nullable;

import java.util.function.Supplier;

public final class IrisCompatInternal {
    private static Boolean irisLoaded;

    private IrisCompatInternal() {
    }

    public static boolean isIrisLoaded() {
        Boolean cached = irisLoaded;
        if (cached != null) {
            return cached;
        }

        boolean loaded = Services.PLATFORM.isModLoaded("iris");
        irisLoaded = loaded;
        return loaded;
    }

    public static boolean isIrisShaderPackActive() {
        return isIrisLoaded() && IrisBridge.isShaderPackActive();
    }

    public static RenderType wrapRenderLayer(RenderType renderLayer, ChaosShaderRenderPhase phase) {
        if (!isIrisShaderPackActive()) {
            return renderLayer;
        }

        return IrisBridge.wrapRenderLayer(renderLayer, phase);
    }

    public static RenderType wrapEntityRenderLayer(RenderType renderLayer) {
        return wrapRenderLayer(renderLayer, ChaosShaderRenderPhase.ENTITIES);
    }

    public static RenderType wrapEntityRenderLayer(RenderType renderLayer, RenderType shadowRenderLayer) {
        return wrapEntityRenderLayer(isShadowPassActive() ? shadowRenderLayer : renderLayer);
    }

    public static RenderType wrapBlockEntityRenderLayer(RenderType renderLayer) {
        return wrapRenderLayer(renderLayer, ChaosShaderRenderPhase.BLOCK_ENTITIES);
    }

    public static RenderType wrapOutlineRenderLayer(RenderType renderLayer) {
        return wrapRenderLayer(renderLayer, ChaosShaderRenderPhase.OUTLINE);
    }

    public static void withPhase(ChaosShaderRenderPhase phase, Runnable action) {
        if (!isIrisShaderPackActive()) {
            action.run();
            return;
        }

        IrisBridge.withPhase(phase, action);
    }

    public static <T> T withPhase(ChaosShaderRenderPhase phase, Supplier<T> action) {
        if (!isIrisShaderPackActive()) {
            return action.get();
        }

        return IrisBridge.withPhase(phase, action);
    }

    public static void withBlockEntityContext(BlockEntity blockEntity, Runnable action) {
        if (!isIrisShaderPackActive()) {
            action.run();
            return;
        }

        IrisBridge.withBlockEntityContext(blockEntity, action);
    }

    public static int currentRenderedEntityId() {
        if (!isIrisShaderPackActive()) {
            return 0;
        }

        return IrisBridge.currentRenderedEntityId();
    }

    public static int currentRenderedBlockEntityId() {
        if (!isIrisShaderPackActive()) {
            return 0;
        }

        return IrisBridge.currentRenderedBlockEntityId();
    }

    public static int currentRenderedItemId() {
        if (!isIrisShaderPackActive()) {
            return 0;
        }

        return IrisBridge.currentRenderedItemId();
    }

    public static boolean isShadowPassActive() {
        return isIrisShaderPackActive() && IrisBridge.isShadowPassActive();
    }

    public static @Nullable ShaderInstance getShadowShader(ChaosShaderRenderPhase phase) {
        if (!isShadowPassActive()) {
            return null;
        }

        return ChaosIrisShaderPackProgramCompiler.getShadowShader(phase);
    }

    public static void withVanillaVertexFormatState(Runnable action) {
        if (!isIrisShaderPackActive()) {
            action.run();
            return;
        }

        IrisBridge.withVanillaVertexFormatState(action);
    }

    public static void invalidateCaches() {
        if (!isIrisLoaded()) {
            return;
        }

        IrisBridge.clearCaches();
    }
}
