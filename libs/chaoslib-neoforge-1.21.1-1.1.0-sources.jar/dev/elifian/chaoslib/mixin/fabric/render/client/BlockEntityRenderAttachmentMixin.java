package dev.elifian.chaoslib.mixin.fabric.render.client;

import dev.elifian.chaoslib.api.animatable.GeoBlockEntity;
import dev.elifian.chaoslib.model.baked.GeoStaticModelData;
import dev.elifian.chaoslib.renderer.block.StaticGeoRenderStateResolver;
import net.minecraft.world.level.block.entity.BlockEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Fabric's counterpart to NeoForge's BlockEntity.getModelData(): hands the block entity's static
 * render state to the chunk mesher, where FabricStaticGeoBakedModel reads it back.
 *
 * <p>Fabric API already adds getRenderAttachmentData() to BlockEntity and always answers null, and
 * two mixins cannot write the same method -- so this injects into theirs instead of declaring its
 * own. The raised priority puts us after Fabric API, by which point the method exists.</p>
 */
@Mixin(value = BlockEntity.class, priority = 1500)
abstract class BlockEntityRenderAttachmentMixin {
    @Unique
    private static final StaticGeoRenderStateResolver CHAOS_STATIC_RENDER_STATE_RESOLVER = new StaticGeoRenderStateResolver();

    @Inject(method = "getRenderAttachmentData", at = @At("HEAD"), cancellable = true, remap = false)
    private void chaosStaticRenderState(CallbackInfoReturnable<Object> info) {
        if (!((Object) this instanceof GeoBlockEntity geoBlockEntity)) {
            return;
        }

        GeoStaticModelData.State state = CHAOS_STATIC_RENDER_STATE_RESOLVER.resolveState(geoBlockEntity);
        if (state != null) {
            info.setReturnValue(state);
        }
    }
}
