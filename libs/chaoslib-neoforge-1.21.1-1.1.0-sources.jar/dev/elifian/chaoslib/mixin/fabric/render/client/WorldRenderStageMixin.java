package dev.elifian.chaoslib.mixin.fabric.render.client;

import com.llamalad7.mixinextras.sugar.Local;
import com.mojang.blaze3d.vertex.PoseStack;
import dev.elifian.chaoslib.platform.render.ChaosWorldRenderStageDispatcher;
import dev.elifian.chaoslib.platform.render.ChaosWorldRenderStage;
import net.minecraft.client.Camera;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.LightTexture;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Drives ChaosLib's world render stages. NeoForge fires RenderLevelStageEvent for this; Fabric has
 * no equivalent, and WorldRenderEvents cannot be relied on once Sodium takes over the level render,
 * so the stages are cut straight into renderLevel at the same points NeoForge uses: right before
 * block entities are drawn (entities are done), and right before the block-breaking overlay
 * (block entities are done).
 */
@Mixin(LevelRenderer.class)
abstract class WorldRenderStageMixin {
    @Inject(
            method = "renderLevel",
            at = @At(value = "CONSTANT", args = "stringValue=blockentities")
    )
    private void chaosAfterEntities(
            DeltaTracker deltaTracker,
            boolean renderBlockOutline,
            Camera camera,
            GameRenderer gameRenderer,
            LightTexture lightTexture,
            Matrix4f frustumMatrix,
            Matrix4f projectionMatrix,
            CallbackInfo info,
            @Local PoseStack poseStack
    ) {
        ChaosWorldRenderStageDispatcher.dispatch(
                ChaosWorldRenderStage.AFTER_ENTITIES, projectionMatrix, poseStack, camera,
                deltaTracker.getGameTimeDeltaPartialTick(false));
    }

    @Inject(
            method = "renderLevel",
            at = @At(value = "CONSTANT", args = "stringValue=destroyProgress")
    )
    private void chaosAfterBlockEntities(
            DeltaTracker deltaTracker,
            boolean renderBlockOutline,
            Camera camera,
            GameRenderer gameRenderer,
            LightTexture lightTexture,
            Matrix4f frustumMatrix,
            Matrix4f projectionMatrix,
            CallbackInfo info,
            @Local PoseStack poseStack
    ) {
        ChaosWorldRenderStageDispatcher.dispatch(
                ChaosWorldRenderStage.AFTER_BLOCK_ENTITIES, projectionMatrix, poseStack, camera,
                deltaTracker.getGameTimeDeltaPartialTick(false));
    }
}
