package dev.elifian.chaoslib.mixin.additional.sodium;

import dev.elifian.chaoslib.config.ChaosLibClientConfig;
import net.caffeinemc.mods.sodium.client.gui.VideoSettingsScreen;
import net.caffeinemc.mods.sodium.client.gui.widgets.PageListWidget;
import net.caffeinemc.mods.sodium.client.util.Dim2i;
import net.minecraft.client.gui.screens.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = VideoSettingsScreen.class, remap = false)
public abstract class VideoSettingsScreenMixin {
    @Unique
    private static final int CHAOSLIB_RIGHT_MARGIN = 5;

    @Shadow
    private Dim2i dim;

    @Shadow
    private boolean insetX;

    @Shadow
    private boolean insetY;

    @Shadow
    private PageListWidget pageList;

    @Unique
    private static boolean chaoslib$enabled() {
        return ChaosLibClientConfig.additional().wideSodiumVideoSettings;
    }

    @Inject(method = "updateScreenDimensions", at = @At("TAIL"))
    private void stretchToFullWidth(CallbackInfo ci) {
        if (!chaoslib$enabled()) {
            return;
        }

        Screen self = (Screen) (Object) this;
        this.dim = new Dim2i(0, 0, self.width, self.height);
        this.insetX = false;
        this.insetY = false;
    }

    @ModifyConstant(method = "rebuild", constant = @Constant(intValue = 222))
    private int widenOptionList(int original) {
        if (!chaoslib$enabled()) {
            return original;
        }

        Screen self = (Screen) (Object) this;
        int available = self.width - this.pageList.getLimitX() - CHAOSLIB_RIGHT_MARGIN;
        return Math.max(original, available);
    }

    @ModifyConstant(method = "rebuild", constant = @Constant(intValue = 422))
    private int alwaysReserveActionButtonRow(int original) {
        return chaoslib$enabled() ? Integer.MAX_VALUE / 2 : original;
    }
}
