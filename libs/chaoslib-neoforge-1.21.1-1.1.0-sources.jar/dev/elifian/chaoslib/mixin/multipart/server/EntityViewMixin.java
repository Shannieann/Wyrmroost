package dev.elifian.chaoslib.mixin.multipart.server;

import dev.elifian.chaoslib.multipart.interaction.GeoMultipartServerHitHelper;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.shapes.BooleanOp;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.level.CollisionGetter;
import net.minecraft.world.level.border.WorldBorder;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

/**
 * Extends vanilla space checks with exact multipart OBB collisions.
 */
@Mixin(CollisionGetter.class)
public interface EntityViewMixin {
    /**
     * @author Codex
     * @reason Include virtual multipart OBB collisions in vanilla ledge and space checks.
     */
    @Overwrite
    default boolean noCollision(Entity entity, AABB box) {
        for (VoxelShape shape : ((CollisionGetter) this).getBlockCollisions(entity, box)) {
            if (!shape.isEmpty()) {
                return false;
            }
        }

        if (!((CollisionGetter) this).getEntityCollisions(entity, box).isEmpty()) {
            return false;
        }

        if (GeoMultipartServerHitHelper.hasMultipartCollision((CollisionGetter) this, entity, box)) {
            return false;
        }

        if (entity == null) {
            return true;
        }

        WorldBorder worldBorder = ((CollisionGetter) this).getWorldBorder();
        if (!worldBorder.isInsideCloseToBorder(entity, box)) {
            return true;
        }

        return !Shapes.joinIsNotEmpty(worldBorder.getCollisionShape(), Shapes.create(box), BooleanOp.AND);
    }
}
