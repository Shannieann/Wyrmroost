package dev.elifian.chaoslib.mixin.multipart.server;

import dev.elifian.chaoslib.multipart.interaction.GeoMultipartAttackStrength;
import dev.elifian.chaoslib.multipart.interaction.GeoMultipartServerHitHelper;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Player.class)
abstract class PlayerEntityMixin {
    @Inject(method = "attack", at = @At("HEAD"))
    private void captureMultipartAttackStrength(Entity target, CallbackInfo ci) {
        GeoMultipartAttackStrength.begin((Player) (Object) this);
    }

    @Inject(method = "attack", at = @At("RETURN"))
    private void releaseMultipartAttackStrength(Entity target, CallbackInfo ci) {
        GeoMultipartAttackStrength.end();
    }

    @Inject(method = "maybeBackOffFromEdge", at = @At("RETURN"), cancellable = true)
    private void clipMultipartSneakEdges(Vec3 movement, MoverType type, CallbackInfoReturnable<Vec3> cir) {
        Player self = (Player) (Object) this;
        cir.setReturnValue(GeoMultipartServerHitHelper.clipMovementForMultipartSneaking(
                self.level(),
                self,
                self.getBoundingBox(),
                cir.getReturnValue()
        ));
    }
}
