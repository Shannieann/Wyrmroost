package dev.elifian.chaoslib.mixin.multipart.server;

import net.minecraft.world.entity.projectile.Projectile;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(Projectile.class)
interface ProjectileEntityAccessor {
    @Accessor("leftOwner")
    boolean isLeftOwner();
}
