package dev.elifian.chaoslib.mixin.multipart.server;

import dev.elifian.chaoslib.api.multipart.GeoMultipartEntity;
import dev.elifian.chaoslib.multipart.interaction.GeoMultipartDamageDispatcher;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.damagesource.DamageSource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
abstract class LivingEntityMixin {
    @Inject(method = "tick", at = @At("HEAD"))
    private void multipartTickStart(CallbackInfo ci) {
        if ((Object) this instanceof GeoMultipartEntity multipart) {
            multipart.onMultipartTickStart();
        }
    }

    @Inject(method = "tick", at = @At("TAIL"))
    private void multipartTickEnd(CallbackInfo ci) {
        if ((Object) this instanceof GeoMultipartEntity multipart) {
            multipart.onMultipartTickEnd();
            if (((Entity) (Object) this).tickCount <= 1) {
                multipart.resetMultipartPreviousPartPositions();
            }
        }
    }

    @Inject(method = "hurt", at = @At("HEAD"), cancellable = true)
    private void dispatchVirtualMultipartDamage(DamageSource source, float amount, CallbackInfoReturnable<Boolean> cir) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (self.level().isClientSide || GeoMultipartDamageDispatcher.isReentrant() || !(self instanceof GeoMultipartEntity)) {
            return;
        }

        GeoMultipartDamageDispatcher.dispatch((LivingEntity & GeoMultipartEntity) self, source, amount)
                .ifPresent(cir::setReturnValue);
    }
}
