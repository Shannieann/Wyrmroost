package dev.elifian.chaoslib.mixin.multipart.server;

import dev.elifian.chaoslib.multipart.interaction.GeoMultipartHitResult;
import dev.elifian.chaoslib.multipart.interaction.GeoMultipartProjectileHitHintStore;
import dev.elifian.chaoslib.multipart.interaction.GeoMultipartServerHitHelper;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;
import java.util.function.Predicate;

@SuppressWarnings("AddedMixinMembersNamePattern")
@Mixin(ProjectileUtil.class)
abstract class ProjectileUtilMixin {
    @Inject(
            method = "getEntityHitResult(Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/AABB;Ljava/util/function/Predicate;)Lnet/minecraft/world/phys/EntityHitResult;",
            at = @At("RETURN"),
            cancellable = true
    )
    private static void appendMultipartEntityCollision(
            Level world,
            Entity entity,
            Vec3 from,
            Vec3 to,
            AABB searchBox,
            Predicate<Entity> predicate,
            CallbackInfoReturnable<EntityHitResult> cir
    ) {
        mergeMultipartCollision(world, entity, from, to, searchBox, predicate, 0.0f, cir);
    }

    @Inject(
            method = "getEntityHitResult(Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/AABB;Ljava/util/function/Predicate;F)Lnet/minecraft/world/phys/EntityHitResult;",
            at = @At("RETURN"),
            cancellable = true
    )
    private static void appendMultipartEntityCollisionWithMargin(
            Level world,
            Entity entity,
            Vec3 from,
            Vec3 to,
            AABB searchBox,
            Predicate<Entity> predicate,
            float margin,
            CallbackInfoReturnable<EntityHitResult> cir
    ) {
        mergeMultipartCollision(world, entity, from, to, searchBox, predicate, margin, cir);
    }

    @Unique
    private static void mergeMultipartCollision(
            Level world,
            Entity entity,
            Vec3 from,
            Vec3 to,
            AABB searchBox,
            Predicate<Entity> predicate,
            float margin,
            CallbackInfoReturnable<EntityHitResult> cir
    ) {
        double vanillaDistanceSquared = Double.POSITIVE_INFINITY;
        EntityHitResult vanillaHit = cir.getReturnValue();
        if (vanillaHit != null) {
            vanillaDistanceSquared = from.distanceToSqr(vanillaHit.getLocation());
        }

        Vec3 multipartCollisionHalfExtents = multipartCollisionHalfExtents(entity);
        double multipartCollisionMargin = margin;

        Predicate<Entity> multipartPredicate = predicate;
        if (entity instanceof Projectile projectile) {
            multipartPredicate = candidate -> canMultipartProjectileHit(projectile, candidate);
        }

        Optional<GeoMultipartHitResult> multipartHit = GeoMultipartServerHitHelper.findWorldHit(
                world,
                entity,
                from,
                to,
                searchBox,
                multipartPredicate,
                vanillaDistanceSquared,
                multipartCollisionMargin,
                multipartCollisionHalfExtents
        );
        if (multipartHit.isEmpty()) {
            return;
        }

        if (entity instanceof Projectile projectile) {
            GeoMultipartProjectileHitHintStore.put(projectile, multipartHit.get().part().getOwner(), multipartHit.get().part().getTrackedBoneName(), world.getGameTime());
        }

        cir.setReturnValue(new EntityHitResult(multipartHit.get().part().getOwner(), multipartHit.get().hitPos()));
    }

    @Unique
    private static boolean canMultipartProjectileHit(Projectile projectile, Entity entity) {
        if (!entity.isAlive()) {
            return false;
        }

        if (entity == projectile) {
            return false;
        }

        Entity owner = projectile.getOwner();
        boolean leftOwner = ((ProjectileEntityAccessor) projectile).isLeftOwner();
        return owner == null || leftOwner || !owner.isPassengerOfSameVehicle(entity);
    }

    @Unique
    private static Vec3 multipartCollisionHalfExtents(Entity entity) {
        AABB box = entity.getBoundingBox();
        return new Vec3(
                (box.maxX - box.minX) * 0.5d,
                (box.maxY - box.minY) * 0.5d,
                (box.maxZ - box.minZ) * 0.5d
        );
    }
}
