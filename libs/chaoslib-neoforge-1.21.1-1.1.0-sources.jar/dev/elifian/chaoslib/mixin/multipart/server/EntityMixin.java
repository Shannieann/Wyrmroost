package dev.elifian.chaoslib.mixin.multipart.server;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import dev.elifian.chaoslib.api.multipart.GeoMultipartEntity;
import dev.elifian.chaoslib.multipart.interaction.GeoMultipartServerHitHelper;
import dev.elifian.chaoslib.multipart.interaction.GeoMultipartUseDispatcher;
import dev.elifian.chaoslib.multipart.runtime.GeoMultipartManagerStore;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;

@Mixin(Entity.class)
abstract class EntityMixin {
    @WrapOperation(
            method = "collide(Lnet/minecraft/world/phys/Vec3;)Lnet/minecraft/world/phys/Vec3;",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/entity/Entity;collideBoundingBox(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/phys/Vec3;Lnet/minecraft/world/phys/AABB;Lnet/minecraft/world/level/Level;Ljava/util/List;)Lnet/minecraft/world/phys/Vec3;"
            )
    )
    private Vec3 applyMultipartObbCollisions(
            Entity entity,
            Vec3 movement,
            AABB box,
            Level world,
            List<VoxelShape> collisions,
            Operation<Vec3> original
    ) {
        Vec3 resolvedMovement = original.call(entity, movement, box, world, collisions);
        return GeoMultipartServerHitHelper.adjustMovementForMultipartCollisions(world, entity, box, resolvedMovement);
    }


    @Inject(method = "interact", at = @At("HEAD"), cancellable = true)
    private void dispatchVirtualMultipartInteract(Player player, InteractionHand hand, CallbackInfoReturnable<InteractionResult> cir) {
        Entity self = (Entity) (Object) this;
        if (GeoMultipartUseDispatcher.isReentrant()
                || !(self instanceof LivingEntity livingEntity)
                || !(self instanceof GeoMultipartEntity)) {
            return;
        }

        GeoMultipartUseDispatcher.dispatch((LivingEntity & GeoMultipartEntity) livingEntity, player, hand)
                .ifPresent(cir::setReturnValue);
    }

    @Inject(method = "interactAt", at = @At("HEAD"), cancellable = true)
    private void dispatchVirtualMultipartUse(Player player, Vec3 hitPos, InteractionHand hand, CallbackInfoReturnable<InteractionResult> cir) {
        Entity self = (Entity) (Object) this;
        if (GeoMultipartUseDispatcher.isReentrant()
                || !(self instanceof LivingEntity livingEntity)
                || !(self instanceof GeoMultipartEntity)) {
            return;
        }

        GeoMultipartUseDispatcher.dispatch((LivingEntity & GeoMultipartEntity) livingEntity, player, hand, hitPos)
                .ifPresent(cir::setReturnValue);
    }

    @Inject(method = "setId", at = @At("TAIL"))
    private void assignMultipartPartIds(int id, CallbackInfo ci) {
        if ((Object) this instanceof GeoMultipartEntity multipart) {
            multipart.assignMultipartPartIds(id);
        }
    }

    @Inject(method = "onClientRemoval", at = @At("TAIL"))
    private void cleanupMultipartManager(CallbackInfo ci) {
        if ((Object) this instanceof GeoMultipartEntity multipart) {
            GeoMultipartManagerStore.remove(multipart);
        }
    }
}
