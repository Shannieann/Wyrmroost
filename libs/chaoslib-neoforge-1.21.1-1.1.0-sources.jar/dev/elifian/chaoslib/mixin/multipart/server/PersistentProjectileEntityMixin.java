package dev.elifian.chaoslib.mixin.multipart.server;

import dev.elifian.chaoslib.multipart.interaction.GeoMultipartHitResult;
import dev.elifian.chaoslib.multipart.interaction.GeoMultipartProjectileHitHintStore;
import dev.elifian.chaoslib.multipart.interaction.GeoMultipartServerHitHelper;
import it.unimi.dsi.fastutil.ints.IntOpenHashSet;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;

@SuppressWarnings("AddedMixinMembersNamePattern")
@Mixin(AbstractArrow.class)
abstract class PersistentProjectileEntityMixin {
    @Final
    @Shadow
    private IntOpenHashSet piercingIgnoreEntityIds;

    @Inject(method = "findHitEntity", at = @At("RETURN"), cancellable = true)
    private void appendMultipartEntityCollision(Vec3 from, Vec3 to, CallbackInfoReturnable<EntityHitResult> cir) {
        AbstractArrow self = (AbstractArrow) (Object) this;
        Level world = self.level();

        double vanillaDistanceSquared = Double.POSITIVE_INFINITY;
        EntityHitResult vanillaHit = cir.getReturnValue();
        if (vanillaHit != null) {
            vanillaDistanceSquared = from.distanceToSqr(vanillaHit.getLocation());
        }

        Vec3 multipartCollisionHalfExtents = multipartCollisionHalfExtents(self.getBoundingBox());
        AABB searchBox = self.getBoundingBox().expandTowards(self.getDeltaMovement()).inflate(1.0d);
        Optional<GeoMultipartHitResult> multipartHit = GeoMultipartServerHitHelper.findWorldHit(
                world,
                self,
                from,
                to,
                searchBox,
                this::canMultipartProjectileHit,
                vanillaDistanceSquared,
                0.0d,
                multipartCollisionHalfExtents
        );
        if (multipartHit.isEmpty()) {
            return;
        }

        GeoMultipartProjectileHitHintStore.put(self, multipartHit.get().part().getOwner(), multipartHit.get().part().getTrackedBoneName(), world.getGameTime());
        cir.setReturnValue(new EntityHitResult(multipartHit.get().part().getOwner(), multipartHit.get().hitPos()));
    }

    @Unique
    private boolean canMultipartProjectileHit(Entity entity) {
        AbstractArrow self = (AbstractArrow) (Object) this;
        if (!entity.isAlive()) {
            return false;
        }

        if (entity == self) {
            return false;
        }

        Entity owner = self.getOwner();
        boolean leftOwner = ((ProjectileEntityAccessor) (Projectile) self).isLeftOwner();
        if (owner != null && !leftOwner && owner.isPassengerOfSameVehicle(entity)) {
            return false;
        }

        return this.piercingIgnoreEntityIds == null || !this.piercingIgnoreEntityIds.contains(entity.getId());
    }

    @Unique
    private static Vec3 multipartCollisionHalfExtents(AABB box) {
        return new Vec3(
                (box.maxX - box.minX) * 0.5d,
                (box.maxY - box.minY) * 0.5d,
                (box.maxZ - box.minZ) * 0.5d
        );
    }
}
