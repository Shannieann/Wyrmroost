package dev.elifian.chaoslib.mixin.multipart.client;

import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(Minecraft.class)
public interface MinecraftClientAccessor {
    @Accessor("missTime")
    void setAttackCooldown(int attackCooldown);
}
