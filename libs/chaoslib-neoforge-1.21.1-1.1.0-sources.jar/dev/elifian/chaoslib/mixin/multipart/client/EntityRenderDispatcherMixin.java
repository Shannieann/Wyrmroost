package dev.elifian.chaoslib.mixin.multipart.client;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.elifian.chaoslib.api.multipart.GeoMultipartEntity;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Keeps the F3+B hitbox of a multipart owner out of the debug renderer when the owner asks for it;
 * its parts draw their own boxes.
 *
 * <p>NeoForge needed a second hook here, to blank out the part array it adds to Entity. It does not
 * any more: GeoMultipartEntity no longer claims to be one of its multipart entities, so the branch
 * that reads that array is never taken.</p>
 */
@Mixin(EntityRenderDispatcher.class)
abstract class EntityRenderDispatcherMixin {
    @Inject(method = "renderHitbox", at = @At("HEAD"), cancellable = true)
    private static void skipVanillaRootDebugHitbox(
            PoseStack matrices,
            VertexConsumer vertices,
            Entity entity,
            float tickDelta,
            float red,
            float green,
            float blue,
            CallbackInfo ci
    ) {
        if (entity instanceof GeoMultipartEntity multipart && !multipart.shouldRenderRootDebugHitbox() && !entity.isPickable()) {
            ci.cancel();
        }
    }

    @WrapOperation(
            method = "renderHitbox",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;getBoundingBox()Lnet/minecraft/world/phys/AABB;")
    )
    private static AABB optionallyHideRootDebugHitbox(Entity entity, Operation<AABB> original) {
        if (entity instanceof GeoMultipartEntity multipart && !multipart.shouldRenderRootDebugHitbox() && !entity.isPickable()) {
            return new AABB(entity.getX(), entity.getY(), entity.getZ(), entity.getX(), entity.getY(), entity.getZ());
        }
        return original.call(entity);
    }
}
