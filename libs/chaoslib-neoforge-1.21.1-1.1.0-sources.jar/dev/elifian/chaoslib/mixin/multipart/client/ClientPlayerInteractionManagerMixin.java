package dev.elifian.chaoslib.mixin.multipart.client;

import dev.elifian.chaoslib.client.multipart.GeoMultipartRaycastHelper;
import dev.elifian.chaoslib.platform.Services;
import dev.elifian.chaoslib.api.multipart.GeoMultipartEntity;
import dev.elifian.chaoslib.multipart.interaction.GeoMultipartHitResult;
import dev.elifian.chaoslib.network.c2s.GeoMultipartMeleeHitHintC2SPacket;
import dev.elifian.chaoslib.network.c2s.GeoMultipartUseHintC2SPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.InteractionResult;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;

@SuppressWarnings("AddedMixinMembersNamePattern")
@Mixin(MultiPlayerGameMode.class)
abstract class ClientPlayerInteractionManagerMixin {
    @Shadow
    @Final
    private Minecraft minecraft;

    @Inject(method = "attack", at = @At("HEAD"))
    private void sendVirtualMultipartAttackHint(Player player, Entity target, CallbackInfo ci) {
        this.findMultipartHit()
                .ifPresent(hit -> {
                    Entity owner = hit.part().getOwner();
                    if (!(owner instanceof GeoMultipartEntity)) {
                        return;
                    }
                    Services.NETWORK.sendToServer(
                            new GeoMultipartMeleeHitHintC2SPacket(owner.getId(), hit.part().getTrackedBoneName())
                    );
                    if (this.minecraft.gameMode != null && this.minecraft.gameMode.hasMissTime()) {
                        ((MinecraftClientAccessor) this.minecraft).setAttackCooldown(10);
                    }
                });
    }

    @Inject(method = "interact", at = @At("HEAD"))
    private void sendVirtualMultipartUseHint(Player player, Entity entity, InteractionHand hand, CallbackInfoReturnable<InteractionResult> cir) {
        this.sendMultipartUseHint();
    }

    @Inject(method = "interactAt", at = @At("HEAD"))
    private void sendVirtualMultipartUseAtLocationHint(Player player, Entity entity, EntityHitResult hitResult, InteractionHand hand, CallbackInfoReturnable<InteractionResult> cir) {
        this.sendMultipartUseHint();
    }

    @Unique
    private Optional<GeoMultipartHitResult> findMultipartHit() {
        if (this.minecraft.getCameraEntity() == null) {
            return Optional.empty();
        }

        return GeoMultipartRaycastHelper.findMultipartPartHit(this.minecraft, this.minecraft.getCameraEntity(), this.minecraft.getTimer().getGameTimeDeltaPartialTick(false));
    }

    @Unique
    private void sendMultipartUseHint() {
        this.findMultipartHit().ifPresent(hit -> {
            Entity owner = hit.part().getOwner();
            if (!(owner instanceof GeoMultipartEntity)) {
                return;
            }
            Services.NETWORK.sendToServer(
                    new GeoMultipartUseHintC2SPacket(owner.getId(), hit.part().getTrackedBoneName())
            );
        });
    }
}
