package dev.elifian.chaoslib.mixin.multipart.client;

import dev.elifian.chaoslib.client.multipart.GeoMultipartRaycastHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
abstract class GameRendererMixin {
    @Shadow
    @Final
    Minecraft minecraft;

    @Inject(method = "pick", at = @At("TAIL"))
    private void updateMultipartTarget(float tickDelta, CallbackInfo ci) {
        if (this.minecraft.getCameraEntity() == null) {
            return;
        }

        GeoMultipartRaycastHelper.findMultipartHit(this.minecraft, this.minecraft.getCameraEntity(), tickDelta).ifPresentOrElse(hitResult -> {
            this.minecraft.hitResult = hitResult;
            this.minecraft.crosshairPickEntity = hitResult.getEntity();
        }, () -> {
        });
    }
}
