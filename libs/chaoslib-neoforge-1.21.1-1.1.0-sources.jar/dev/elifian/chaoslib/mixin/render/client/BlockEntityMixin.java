package dev.elifian.chaoslib.mixin.render.client;

import dev.elifian.chaoslib.animatable.state.GeoRenderStateAccess;
import dev.elifian.chaoslib.model.baked.GeoStaticModelData;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.core.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@SuppressWarnings("AddedMixinMembersNamePattern")
@Mixin(BlockEntity.class)
abstract class BlockEntityMixin implements GeoRenderStateAccess {
    @Unique
    private long geoRenderStateLastWorldTime = Long.MIN_VALUE;

    @Unique
    private int geoRenderStateRemainingTicks;

    @Unique
    private boolean geoRenderStateActive;

    @Unique
    private Object geoLastPoseKey;

    @Unique
    private boolean geoHasLastPoseKey;

    @Unique
    private boolean geoRenderDeactivateGraceBeenUsed;

    @Unique
    private int geoRenderDeactivateGraceRemainingTicks;

    @Unique
    private int geoShouldRenderLastFrameId;

    @Unique
    private boolean geoShouldRenderCachedValue;

    @Unique
    private int geoRenderActiveLastFrameId;

    @Unique
    private boolean geoRenderActiveCachedValue;

    @Unique
    private boolean geoModelDataOnly;

    @Unique
    private BlockState geoCachedFacingState;

    @Unique
    private Object geoCachedFacingValue;

    @Unique
    private BlockPos geoEnclosedCullPos;

    @Unique
    private BlockState geoEnclosedCullState;

    @Unique
    private boolean geoEnclosedCullValue;

    @Unique
    private long geoModelDataLastWorldTime = Long.MIN_VALUE;

    @Unique
    private GeoStaticModelData.State geoCachedStaticModelDataState;

    @Inject(method = "setBlockState", at = @At("HEAD"))
    private void invalidateGeoRenderCaches(BlockState state, CallbackInfo info) {
        this.geoEnclosedCullPos = null;
        this.geoEnclosedCullState = null;
        this.geoCachedFacingState = null;
        this.invalidateGeoModelDataCache();
    }

    @Override
    public long getGeoRenderStateLastWorldTime() {
        return this.geoRenderStateLastWorldTime;
    }

    @Override
    public void setGeoRenderStateLastWorldTime(long value) {
        this.geoRenderStateLastWorldTime = value;
    }

    @Override
    public int getGeoRenderStateRemainingTicks() {
        return this.geoRenderStateRemainingTicks;
    }

    @Override
    public void setGeoRenderStateRemainingTicks(int value) {
        this.geoRenderStateRemainingTicks = value;
    }

    @Override
    public boolean isGeoRenderStateActive() {
        return this.geoRenderStateActive;
    }

    @Override
    public void setGeoRenderStateActive(boolean value) {
        this.geoRenderStateActive = value;
    }

    @Override
    public Object getGeoLastPoseKey() {
        return this.geoLastPoseKey;
    }

    @Override
    public void setGeoLastPoseKey(Object value) {
        this.geoLastPoseKey = value;
    }

    @Override
    public boolean hasGeoLastPoseKey() {
        return this.geoHasLastPoseKey;
    }

    @Override
    public void setGeoHasLastPoseKey(boolean value) {
        this.geoHasLastPoseKey = value;
    }

    @Override
    public boolean hasGeoRenderDeactivateGraceBeenUsed() {
        return this.geoRenderDeactivateGraceBeenUsed;
    }

    @Override
    public void setGeoRenderDeactivateGraceBeenUsed(boolean value) {
        this.geoRenderDeactivateGraceBeenUsed = value;
    }

    @Override
    public int getGeoRenderDeactivateGraceRemainingTicks() {
        return this.geoRenderDeactivateGraceRemainingTicks;
    }

    @Override
    public void setGeoRenderDeactivateGraceRemainingTicks(int value) {
        this.geoRenderDeactivateGraceRemainingTicks = value;
    }

    @Override
    public int getGeoShouldRenderLastFrameId() {
        return this.geoShouldRenderLastFrameId;
    }

    @Override
    public void setGeoShouldRenderLastFrameId(int value) {
        this.geoShouldRenderLastFrameId = value;
    }

    @Override
    public boolean getGeoShouldRenderCachedValue() {
        return this.geoShouldRenderCachedValue;
    }

    @Override
    public void setGeoShouldRenderCachedValue(boolean value) {
        this.geoShouldRenderCachedValue = value;
    }

    @Override
    public int getGeoRenderActiveLastFrameId() {
        return this.geoRenderActiveLastFrameId;
    }

    @Override
    public void setGeoRenderActiveLastFrameId(int value) {
        this.geoRenderActiveLastFrameId = value;
    }

    @Override
    public boolean getGeoRenderActiveCachedValue() {
        return this.geoRenderActiveCachedValue;
    }

    @Override
    public void setGeoRenderActiveCachedValue(boolean value) {
        this.geoRenderActiveCachedValue = value;
    }

    @Override
    public boolean isGeoModelDataOnly() {
        return this.geoModelDataOnly;
    }

    @Override
    public void setGeoModelDataOnly(boolean value) {
        this.geoModelDataOnly = value;
    }

    @Override
    public BlockState getGeoCachedFacingState() {
        return this.geoCachedFacingState;
    }

    @Override
    public void setGeoCachedFacingState(BlockState state) {
        this.geoCachedFacingState = state;
    }

    @Override
    public Object getGeoCachedFacingValue() {
        return this.geoCachedFacingValue;
    }

    @Override
    public void setGeoCachedFacingValue(Object value) {
        this.geoCachedFacingValue = value;
    }

    @Override
    public BlockPos getGeoEnclosedCullPos() {
        return this.geoEnclosedCullPos;
    }

    @Override
    public void setGeoEnclosedCullPos(BlockPos pos) {
        this.geoEnclosedCullPos = pos;
    }

    @Override
    public BlockState getGeoEnclosedCullState() {
        return this.geoEnclosedCullState;
    }

    @Override
    public void setGeoEnclosedCullState(BlockState state) {
        this.geoEnclosedCullState = state;
    }

    @Override
    public boolean getGeoEnclosedCullValue() {
        return this.geoEnclosedCullValue;
    }

    @Override
    public void setGeoEnclosedCullValue(boolean value) {
        this.geoEnclosedCullValue = value;
    }

    @Override
    public long getGeoModelDataLastWorldTime() {
        return this.geoModelDataLastWorldTime;
    }

    @Override
    public void setGeoModelDataLastWorldTime(long value) {
        this.geoModelDataLastWorldTime = value;
    }

    @Override
    public GeoStaticModelData.State getGeoCachedStaticModelDataState() {
        return this.geoCachedStaticModelDataState;
    }

    @Override
    public void setGeoCachedStaticModelDataState(GeoStaticModelData.State state) {
        this.geoCachedStaticModelDataState = state;
    }

    @Override
    public void invalidateGeoModelDataCache() {
        this.geoModelDataLastWorldTime = Long.MIN_VALUE;
        this.geoCachedStaticModelDataState = null;
    }
}
