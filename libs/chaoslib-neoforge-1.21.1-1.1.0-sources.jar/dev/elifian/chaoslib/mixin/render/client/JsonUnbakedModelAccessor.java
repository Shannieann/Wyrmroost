package dev.elifian.chaoslib.mixin.render.client;

import net.minecraft.client.renderer.block.model.BlockModel;
import net.minecraft.resources.ResourceLocation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(BlockModel.class)
public interface JsonUnbakedModelAccessor {
    @Accessor("parentLocation")
    ResourceLocation getParentId();
}
