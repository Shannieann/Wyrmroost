package dev.elifian.chaoslib.mixin.render.client;

import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.core.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(LevelRenderer.class)
public interface WorldRendererAccessor {
    @Accessor("cullingFrustum")
    Frustum getFrustum();

    @Invoker("setBlockDirty")
    void invokeScheduleSectionRender(BlockPos pos, boolean important);
}
