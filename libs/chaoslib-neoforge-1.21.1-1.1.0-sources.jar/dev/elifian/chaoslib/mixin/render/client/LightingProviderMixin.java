package dev.elifian.chaoslib.mixin.render.client;

import dev.elifian.chaoslib.gpu.backend.ChaosGpuWorldLightUpdateDispatcher;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.core.SectionPos;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.chunk.DataLayer;
import net.minecraft.world.level.lighting.LevelLightEngine;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@SuppressWarnings("AddedMixinMembersNamePattern")
@Mixin(LevelLightEngine.class)
abstract class LightingProviderMixin {
    @Unique
    private static final int LIGHT_MASK_BLOCK = 1;
    @Unique
    private static final int LIGHT_MASK_SKY = 1 << 1;

    @Inject(method = "checkBlock", at = @At("TAIL"))
    private void onCheckBlock(BlockPos pos, CallbackInfo ci) {
        ClientLevel world = Minecraft.getInstance().level;
        if (world == null) {
            return;
        }

        int sectionX = SectionPos.blockToSectionCoord(pos.getX());
        int sectionY = SectionPos.blockToSectionCoord(pos.getY());
        int sectionZ = SectionPos.blockToSectionCoord(pos.getZ());
        for (int deltaY = -1; deltaY <= 1; deltaY++) {
            for (int deltaZ = -1; deltaZ <= 1; deltaZ++) {
                for (int deltaX = -1; deltaX <= 1; deltaX++) {
                    ChaosGpuWorldLightUpdateDispatcher.postSectionDirty(
                            world,
                            SectionPos.of(sectionX + deltaX, sectionY + deltaY, sectionZ + deltaZ).asLong(),
                            LIGHT_MASK_BLOCK | LIGHT_MASK_SKY
                    );
                }
            }
        }
    }

    @Inject(method = "updateSectionStatus", at = @At("TAIL"))
    private void onSetSectionStatus(SectionPos sectionPos, boolean notReady, CallbackInfo ci) {
        ClientLevel world = Minecraft.getInstance().level;
        if (world == null) {
            return;
        }

        ChaosGpuWorldLightUpdateDispatcher.postSectionDirty(world, sectionPos.asLong(), LIGHT_MASK_BLOCK | LIGHT_MASK_SKY);
    }

    @Inject(method = "queueSectionData", at = @At("TAIL"))
    private void onEnqueueSectionData(LightLayer lightType, SectionPos sectionPos, DataLayer nibbles, CallbackInfo ci) {
        ClientLevel world = Minecraft.getInstance().level;
        if (world == null) {
            return;
        }

        int lightMask = lightType == LightLayer.BLOCK ? LIGHT_MASK_BLOCK : LIGHT_MASK_SKY;
        ChaosGpuWorldLightUpdateDispatcher.postSectionDirty(world, sectionPos.asLong(), lightMask);
    }

    @Inject(method = "setLightEnabled", at = @At("TAIL"))
    private void onSetColumnEnabled(ChunkPos pos, boolean retainData, CallbackInfo ci) {
        markColumnDirty(pos);
    }

    @Inject(method = "propagateLightSources", at = @At("TAIL"))
    private void onPropagateLight(ChunkPos chunkPos, CallbackInfo ci) {
        markColumnDirty(chunkPos);
    }

    @Unique
    private static void markColumnDirty(ChunkPos pos) {
        ClientLevel world = Minecraft.getInstance().level;
        if (world == null) {
            return;
        }

        ChaosGpuWorldLightUpdateDispatcher.postColumnDirty(world, pos.toLong(), LIGHT_MASK_BLOCK | LIGHT_MASK_SKY);
    }
}
