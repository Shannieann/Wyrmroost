package dev.elifian.chaoslib.mixin.render.client;

import dev.elifian.chaoslib.api.animatable.GeoLivingEntity;
import dev.elifian.chaoslib.compat.iris.IrisCompatInternal;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntityRenderDispatcher.class)
abstract class EntityRenderDispatcherCullingMixin {
    @Shadow
    public abstract boolean shouldRender(Entity entity, Frustum frustum, double x, double y, double z);

    @Inject(
            method = "render(Lnet/minecraft/world/entity/Entity;DDDFFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V",
            at = @At("HEAD"),
            cancellable = true
    )
    private void cullGeoLivingEntities(
            Entity entity,
            double x,
            double y,
            double z,
            float yaw,
            float tickDelta,
            PoseStack matrices,
            MultiBufferSource vertexConsumers,
            int light,
            CallbackInfo info
    ) {
        if (!(entity instanceof LivingEntity) || !(entity instanceof GeoLivingEntity)) {
            return;
        }

        if (IrisCompatInternal.isShadowPassActive()) {
            return;
        }

        WorldRendererAccessor worldRenderer = (WorldRendererAccessor) Minecraft.getInstance().levelRenderer;
        Frustum frustum = worldRenderer.getFrustum();
        if (frustum == null) {
            return;
        }

        Vec3 cameraPos = Minecraft.getInstance().gameRenderer.getMainCamera().getPosition();
        if (!shouldRender(entity, frustum, cameraPos.x, cameraPos.y, cameraPos.z)) {
            info.cancel();
        }
    }
}
