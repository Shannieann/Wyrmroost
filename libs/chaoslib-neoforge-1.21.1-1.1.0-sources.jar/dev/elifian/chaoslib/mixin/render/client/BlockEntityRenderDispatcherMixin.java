package dev.elifian.chaoslib.mixin.render.client;

import dev.elifian.chaoslib.api.animatable.GeoBlockEntity;
import dev.elifian.chaoslib.api.renderer.GeoBlockRenderer;
import dev.elifian.chaoslib.compat.iris.IrisCompatInternal;
import dev.elifian.chaoslib.renderer.block.ChaosBlockEntityRenderBackend;
import dev.elifian.chaoslib.renderer.block.ChaosBlockEntityRenderDispatch;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.client.Camera;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderDispatcher;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.ReportedException;
import net.minecraft.CrashReport;
import net.minecraft.CrashReportCategory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@SuppressWarnings({"AddedMixinMembersNamePattern"})
@Mixin(BlockEntityRenderDispatcher.class)
abstract class BlockEntityRenderDispatcherMixin {
    @Unique
    private static BlockEntityType<?> lastSupportedType;
    @Unique
    private static BlockState lastSupportedState;
    @Unique
    private static boolean lastSupportsState;

    @Shadow
    public Camera camera;

    @Shadow
    public abstract <E extends BlockEntity> BlockEntityRenderer<E> getRenderer(E blockEntity);

    @Inject(
            method = "render(Lnet/minecraft/world/level/block/entity/BlockEntity;FLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;)V",
            at = @At("HEAD"),
            cancellable = true
    )
    private <E extends BlockEntity> void cullGeoBlockEntities(
            E blockEntity,
            float tickDelta,
            PoseStack matrices,
            MultiBufferSource vertexConsumers,
            CallbackInfo info
    ) {
        if (!(blockEntity instanceof GeoBlockEntity)) {
            return;
        }

        BlockEntityRenderer<E> renderer = getRenderer(blockEntity);
        if (renderer instanceof GeoBlockRenderer<?> geoRenderer) {
            if (geoRenderer.shouldSkipBlockEntityDispatch(blockEntity)) {
                ChaosBlockEntityRenderDispatch.record(blockEntity, ChaosBlockEntityRenderBackend.STATIC_ONLY, "static_only");
                info.cancel();
                return;
            }
        } else {
            ChaosBlockEntityRenderDispatch.record(blockEntity, ChaosBlockEntityRenderBackend.MINECRAFT, "renderer_not_geo");
        }

        if (renderer == null || renderer.shouldRenderOffScreen(blockEntity)) {
            if (renderer == null) {
                ChaosBlockEntityRenderDispatch.record(blockEntity, ChaosBlockEntityRenderBackend.MINECRAFT, "renderer_missing");
            }
            return;
        }

        if (renderer instanceof GeoBlockRenderer<?> geoRenderer) {
            if (IrisCompatInternal.isShadowPassActive()) {
                ChaosBlockEntityRenderDispatch.record(blockEntity, ChaosBlockEntityRenderBackend.MINECRAFT, "shadow_pass");
                return;
            }

            if (!geoRenderer.shouldUseChaosBlockEntityDispatch(blockEntity)) {
                ChaosBlockEntityRenderDispatch.record(blockEntity, ChaosBlockEntityRenderBackend.MINECRAFT, "renderer_opt_out");
                return;
            }

            if (!blockEntity.hasLevel() || !supportsCachedState(blockEntity)) {
                ChaosBlockEntityRenderDispatch.record(blockEntity, ChaosBlockEntityRenderBackend.CULLED, "invalid_block_state");
                info.cancel();
                return;
            }

            Camera activeCamera = this.camera;
            if (activeCamera != null && !renderer.shouldRender(blockEntity, activeCamera.getPosition())) {
                ChaosBlockEntityRenderDispatch.record(blockEntity, ChaosBlockEntityRenderBackend.CULLED, "render_distance");
                info.cancel();
                return;
            }

            ChaosBlockEntityRenderDispatch.record(blockEntity, ChaosBlockEntityRenderBackend.CHAOS, "chaos_dispatch");
            int light = blockEntity.getLevel() == null
                    ? 0xF000F0
                    : LevelRenderer.getLightColor(blockEntity.getLevel(), blockEntity.getBlockState(), blockEntity.getBlockPos());
            renderReported(renderer, blockEntity, tickDelta, matrices, vertexConsumers, light, OverlayTexture.NO_OVERLAY);
            info.cancel();
        }
    }

    @Inject(
            method = "renderItem(Lnet/minecraft/world/level/block/entity/BlockEntity;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;II)Z",
            at = @At("HEAD"),
            cancellable = true
    )
    private <E extends BlockEntity> void renderGeoBlockEntityWithChaosDispatch(
            E blockEntity,
            PoseStack matrices,
            MultiBufferSource vertexConsumers,
            int light,
            int overlay,
            CallbackInfoReturnable<Boolean> info
    ) {
        if (!(blockEntity instanceof GeoBlockEntity)) {
            return;
        }

        BlockEntityRenderer<E> renderer = getRenderer(blockEntity);
        if (!(renderer instanceof GeoBlockRenderer<?> geoRenderer)) {
            ChaosBlockEntityRenderDispatch.record(blockEntity, renderer == null ? ChaosBlockEntityRenderBackend.UNKNOWN : ChaosBlockEntityRenderBackend.MINECRAFT, renderer == null ? "renderer_missing" : "renderer_not_geo");
            return;
        }

        if (geoRenderer.shouldSkipBlockEntityDispatch(blockEntity)) {
            ChaosBlockEntityRenderDispatch.record(blockEntity, ChaosBlockEntityRenderBackend.STATIC_ONLY, "static_only");
            info.setReturnValue(true);
            return;
        }

        if (IrisCompatInternal.isShadowPassActive()) {
            ChaosBlockEntityRenderDispatch.record(blockEntity, ChaosBlockEntityRenderBackend.MINECRAFT, "shadow_pass");
            return;
        }

        if (!geoRenderer.shouldUseChaosBlockEntityDispatch(blockEntity)) {
            ChaosBlockEntityRenderDispatch.record(blockEntity, ChaosBlockEntityRenderBackend.MINECRAFT, "renderer_opt_out");
            return;
        }

        ChaosBlockEntityRenderDispatch.record(blockEntity, ChaosBlockEntityRenderBackend.CHAOS, "chaos_dispatch");
        renderReported(renderer, blockEntity, 0.0f, matrices, vertexConsumers, light, overlay);
        info.setReturnValue(false);
    }

    @Unique
    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void renderReported(BlockEntityRenderer renderer, BlockEntity blockEntity, float tickDelta, PoseStack matrices, MultiBufferSource vertexConsumers, int light, int overlay) {
        try {
            IrisCompatInternal.withBlockEntityContext(blockEntity, () -> renderer.render(blockEntity, tickDelta, matrices, vertexConsumers, light, overlay));
        } catch (Throwable throwable) {
            CrashReport crashReport = CrashReport.forThrowable(throwable, "Rendering ChaosLib Block Entity");
            CrashReportCategory section = crashReport.addCategory("Block Entity Details");
            blockEntity.fillCrashReportCategory(section);
            throw new ReportedException(crashReport);
        }
    }

    @Unique
    private static boolean supportsCachedState(BlockEntity blockEntity) {
        BlockEntityType<?> type = blockEntity.getType();
        BlockState state = blockEntity.getBlockState();
        if (type == lastSupportedType && state == lastSupportedState) {
            return lastSupportsState;
        }

        boolean supports = type.isValid(state);
        lastSupportedType = type;
        lastSupportedState = state;
        lastSupportsState = supports;
        return supports;
    }
}
