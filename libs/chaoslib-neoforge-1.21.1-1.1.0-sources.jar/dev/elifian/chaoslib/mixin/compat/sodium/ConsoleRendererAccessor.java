package dev.elifian.chaoslib.mixin.compat.sodium;

import net.caffeinemc.mods.sodium.client.gui.console.ConsoleRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.LinkedList;

@Mixin(value = ConsoleRenderer.class, remap = false)
public interface ConsoleRendererAccessor {
    @Accessor("INSTANCE")
    static ConsoleRenderer getInstance() {
        throw new AssertionError();
    }

    @Accessor("activeMessages")
    LinkedList<?> getActiveMessages();
}
