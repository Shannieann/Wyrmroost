package dev.elifian.chaoslib.mixin.compat.sodium;

import com.llamalad7.mixinextras.sugar.ref.LocalBooleanRef;
import com.mojang.blaze3d.vertex.PoseStack;
import dev.elifian.chaoslib.api.animatable.GeoBlockEntity;
import dev.elifian.chaoslib.gpu.render.ChaosGpuRenderRuntime;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import net.caffeinemc.mods.sodium.client.render.SodiumWorldRenderer;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderBuffers;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderDispatcher;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.BlockDestructionProgress;
import net.minecraft.world.level.block.entity.BlockEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.SortedSet;

@Mixin(value = SodiumWorldRenderer.class, remap = false)
abstract class SodiumWorldRendererMixin {
    @Inject(method = "renderBlockEntity", at = @At("HEAD"), cancellable = true, remap = false)
    private static void fastPathGeoBlockEntity(
            PoseStack matrices,
            RenderBuffers bufferBuilders,
            Long2ObjectMap<SortedSet<BlockDestructionProgress>> blockBreakingProgressions,
            float tickDelta,
            MultiBufferSource.BufferSource immediate,
            double cameraX,
            double cameraY,
            double cameraZ,
            BlockEntityRenderDispatcher dispatcher,
            BlockEntity blockEntity,
            LocalPlayer player,
            LocalBooleanRef isGlowing,
            CallbackInfo ci
    ) {
        if (!(blockEntity instanceof GeoBlockEntity)) {
            return;
        }
        if (ChaosGpuRenderRuntime.isShaderPackPipelineActive()) {
            return;
        }
        SortedSet<BlockDestructionProgress> breaking =
                blockBreakingProgressions.get(blockEntity.getBlockPos().asLong());
        if (breaking != null && !breaking.isEmpty() && breaking.last().getProgress() >= 0) {
            return;
        }

        BlockPos pos = blockEntity.getBlockPos();
        matrices.pushPose();
        matrices.translate(pos.getX() - cameraX, pos.getY() - cameraY, pos.getZ() - cameraZ);
        try {
            dispatcher.render(blockEntity, tickDelta, matrices, immediate);
        } finally {
            matrices.popPose();
        }
        ci.cancel();
    }
}
