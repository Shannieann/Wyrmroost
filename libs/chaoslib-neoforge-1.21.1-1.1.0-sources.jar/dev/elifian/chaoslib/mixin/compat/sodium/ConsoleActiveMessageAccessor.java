package dev.elifian.chaoslib.mixin.compat.sodium;

import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(targets = "net.caffeinemc.mods.sodium.client.gui.console.ConsoleRenderer$ActiveMessage", remap = false)
public interface ConsoleActiveMessageAccessor {
    @Accessor("text")
    Component getText();
}
