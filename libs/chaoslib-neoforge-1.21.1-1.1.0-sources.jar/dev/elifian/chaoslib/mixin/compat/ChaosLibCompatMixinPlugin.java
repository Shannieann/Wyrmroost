package dev.elifian.chaoslib.mixin.compat;

import org.objectweb.asm.tree.ClassNode;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;
import org.spongepowered.asm.service.MixinService;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Shared mixin config plugin for every third-party-mod compat config.
 *
 * <p>Each compat mixin lives in {@code dev.elifian.chaoslib.mixin.compat.<module>.*} and is only
 * applied when the corresponding mod is present. Presence is decided by looking for one of the mod's
 * own classes: this runs before either loader's mod list exists, and works the same on NeoForge and
 * Fabric.</p>
 */
public final class ChaosLibCompatMixinPlugin implements IMixinConfigPlugin {
    private static final String[] GATED_MARKERS = {".mixin.compat.", ".mixin.additional."};

    /** A class that only exists when the module's mod is installed. */
    private static final Map<String, List<String>> MODULE_MARKER_CLASSES = Map.of(
            "sodium", List.of("net.caffeinemc.mods.sodium.client.render.SodiumWorldRenderer"),
            "iris", List.of("net.irisshaders.iris.Iris")
    );

    @Override
    public void onLoad(String mixinPackage) {
    }

    @Override
    public String getRefMapperConfig() {
        return null;
    }

    @Override
    public boolean shouldApplyMixin(String targetClassName, String mixinClassName) {
        String module = moduleOf(mixinClassName);
        if (module == null) {
            // Not a compat.<module> mixin: nothing to gate, apply normally.
            return true;
        }

        for (String markerClass : MODULE_MARKER_CLASSES.getOrDefault(module, List.of())) {
            if (isClassPresent(markerClass)) {
                return true;
            }
        }

        return false;
    }

    private static boolean isClassPresent(String className) {
        try {
            MixinService.getService().getBytecodeProvider().getClassNode(className.replace('.', '/'));
            return true;
        } catch (Exception exception) {
            return false;
        }
    }

    private static String moduleOf(String mixinClassName) {
        for (String marker : GATED_MARKERS) {
            int start = mixinClassName.indexOf(marker);
            if (start < 0) {
                continue;
            }
            start += marker.length();
            int end = mixinClassName.indexOf('.', start);
            if (end >= 0) {
                return mixinClassName.substring(start, end);
            }
        }
        return null;
    }

    @Override
    public void acceptTargets(Set<String> myTargets, Set<String> otherTargets) {
    }

    @Override
    public List<String> getMixins() {
        return null;
    }

    @Override
    public void preApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {
    }

    @Override
    public void postApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {
    }
}
