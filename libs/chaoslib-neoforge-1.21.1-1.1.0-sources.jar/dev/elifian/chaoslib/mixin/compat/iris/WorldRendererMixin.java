package dev.elifian.chaoslib.mixin.compat.iris;

import dev.elifian.chaoslib.gpu.render.ChaosGpuWorldRenderDispatcher;
import dev.elifian.chaoslib.gpu.render.ChaosShaderRenderPhase;
import net.minecraft.client.renderer.LevelRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Slice;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LevelRenderer.class)
public abstract class WorldRendererMixin {
    @Inject(
            method = "renderLevel",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/MultiBufferSource$BufferSource;"
                            + "endBatch(Lnet/minecraft/client/renderer/RenderType;)V",
                    ordinal = 0
            ),
            slice = @Slice(
                    from = @At(value = "CONSTANT", args = "stringValue=blockentities"),
                    to = @At(value = "CONSTANT", args = "stringValue=destroyProgress")
            )
    )
    private void flushQueuedBlockEntitySolid(CallbackInfo ci) {
        ChaosGpuWorldRenderDispatcher.flushShaderPackMain(ChaosShaderRenderPhase.BLOCK_ENTITIES);
    }
}
