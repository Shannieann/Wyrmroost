package dev.elifian.chaoslib.mixin.compat.iris;

import dev.elifian.chaoslib.gpu.render.ChaosGpuWorldRenderDispatcher;
import net.irisshaders.iris.shadows.ShadowRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = ShadowRenderer.class, remap = false)
public abstract class ShadowRendererMixin {
    @Inject(
            method = "renderShadows",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/MultiBufferSource$BufferSource;endBatch()V",
                    shift = At.Shift.AFTER,
                    remap = true
            )
    )
    private void flushQueuedShadowSolid(CallbackInfo ci) {
        ChaosGpuWorldRenderDispatcher.flushShaderPackShadowSolid();
    }

    @Inject(
            method = "renderShadows",
            at = @At(value = "CONSTANT", args = "stringValue=translucent terrain")
    )
    private void flushQueuedShadowTranslucents(CallbackInfo ci) {
        ChaosGpuWorldRenderDispatcher.flushShaderPackShadowTranslucent();
    }
}
