package dev.elifian.chaoslib.mixin.compat.iris;

import com.mojang.blaze3d.vertex.VertexFormat;
import dev.elifian.chaoslib.compat.iris.access.IrisRenderingPipelineAccess;
import net.irisshaders.iris.gl.blending.AlphaTest;
import net.irisshaders.iris.gl.state.FogMode;
import net.irisshaders.iris.pipeline.IrisRenderingPipeline;
import net.irisshaders.iris.shaderpack.loading.ProgramId;
import net.irisshaders.iris.shaderpack.programs.ProgramSet;
import net.irisshaders.iris.shaderpack.programs.ProgramSource;
import net.minecraft.client.renderer.ShaderInstance;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.gen.Invoker;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.io.IOException;

@SuppressWarnings("AddedMixinMembersNamePattern")
@Mixin(value = IrisRenderingPipeline.class, remap = false)
public abstract class IrisRenderingPipelineAccessor implements IrisRenderingPipelineAccess {
    @Unique
    private ProgramSet chaoslib$programSet;

    @Inject(method = "<init>", at = @At("TAIL"))
    private void captureProgramSet(ProgramSet programSet, CallbackInfo ci) {
        this.chaoslib$programSet = programSet;
    }

    @Override
    public ProgramSet chaoslib$getProgramSet() {
        return this.chaoslib$programSet;
    }

    @Invoker("createShader")
    @Override
    public abstract ShaderInstance chaoslib$createShader(
            String name,
            ProgramSource source,
            ProgramId programId,
            AlphaTest fallbackAlpha,
            VertexFormat vertexFormat,
            FogMode fogMode,
            boolean isIntensity,
            boolean isFullbright,
            boolean isGlint,
            boolean isText,
            boolean isIeCompat
    ) throws IOException;

    @Invoker("createShadowShader")
    @Override
    public abstract ShaderInstance chaoslib$createShadowShader(
            String name,
            ProgramSource source,
            ProgramId programId,
            AlphaTest fallbackAlpha,
            VertexFormat vertexFormat,
            boolean isIntensity,
            boolean isFullbright,
            boolean isText,
            boolean isIeCompat
    ) throws IOException;
}
