package dev.elifian.chaoslib.mixin.compat.iris;

import dev.elifian.chaoslib.gpu.render.ChaosGpuWorldRenderDispatcher;
import net.irisshaders.iris.pipeline.IrisRenderingPipeline;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = IrisRenderingPipeline.class, remap = false)
public abstract class IrisRenderingPipelineMixin {
    @Inject(method = "beginTranslucents()V", at = @At("RETURN"))
    private void flushQueuedTranslucents(CallbackInfo ci) {
        ChaosGpuWorldRenderDispatcher.flushShaderPackTranslucent();
    }
}
