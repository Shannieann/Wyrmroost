package dev.elifian.chaoslib.mixin.compat.iris;

import dev.elifian.chaoslib.compat.iris.access.ProgramSourceAccess;
import net.irisshaders.iris.gl.blending.BlendModeOverride;
import net.irisshaders.iris.shaderpack.programs.ProgramSet;
import net.irisshaders.iris.shaderpack.programs.ProgramSource;
import net.irisshaders.iris.shaderpack.properties.ShaderProperties;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@SuppressWarnings("AddedMixinMembersNamePattern")
@Mixin(value = ProgramSource.class, remap = false)
public abstract class ProgramSourceAccessor implements ProgramSourceAccess {
    @Unique
    private ShaderProperties chaoslib$shaderProperties;

    @Unique
    private BlendModeOverride chaoslib$blendModeOverride;

    @Inject(
            method = "<init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;"
                    + "Ljava/lang/String;Ljava/lang/String;"
                    + "Lnet/irisshaders/iris/shaderpack/programs/ProgramSet;"
                    + "Lnet/irisshaders/iris/shaderpack/properties/ShaderProperties;"
                    + "Lnet/irisshaders/iris/gl/blending/BlendModeOverride;)V",
            at = @At("TAIL")
    )
    private void captureSourceProperties(
            String name,
            String vertexSource,
            String geometrySource,
            String tessControlSource,
            String tessEvalSource,
            String fragmentSource,
            ProgramSet parent,
            ShaderProperties shaderProperties,
            BlendModeOverride blendModeOverride,
            CallbackInfo ci
    ) {
        this.chaoslib$shaderProperties = shaderProperties;
        this.chaoslib$blendModeOverride = blendModeOverride;
    }

    @Override
    public ShaderProperties chaoslib$getShaderProperties() {
        return this.chaoslib$shaderProperties;
    }

    @Override
    public BlendModeOverride chaoslib$getBlendModeOverride() {
        return this.chaoslib$blendModeOverride;
    }
}
