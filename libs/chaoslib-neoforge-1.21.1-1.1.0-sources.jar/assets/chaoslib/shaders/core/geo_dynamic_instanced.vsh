#version 150

#moj_import <light.glsl>
#moj_import <fog.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in int BoneIndex;
in vec3 Normal;

uniform samplerBuffer BonePoseSampler;
uniform samplerBuffer InstanceMatrixSampler;
uniform isamplerBuffer InstancePackedLightSampler;
uniform samplerBuffer InstanceEmissiveStrengthSampler;
uniform samplerBuffer InstanceColorSampler;
uniform isamplerBuffer InstancePoseBaseSampler;
uniform isamplerBuffer InstanceEmissiveBaseSampler;
uniform isamplerBuffer InstanceLightBaseSampler;
uniform mat4 ProjMat;
uniform mat3 IViewRotMat;
uniform int FogShape;
uniform int UseBoneLightSampler;
uniform int UseWorldLightVolume;
uniform int UseEmissiveLayer;
uniform int BoneCount;
uniform int BoneDataResolved;
uniform vec3 Light0_Direction;
uniform vec3 Light1_Direction;
uniform vec3 CameraWorldPos;
uniform ivec3 LightVolumeBlockOrigin;
uniform ivec3 LightVolumeSize;
uniform sampler2D Sampler2;
uniform isamplerBuffer BoneLightSampler;
uniform isamplerBuffer BlockLightVolumeSampler;
uniform isamplerBuffer SkyLightVolumeSampler;
uniform mat4 TextureMat;

out vec2 texCoord0;
out float vertexDistance;
out vec4 vertexColor;
out vec4 lightMapColor;
out vec4 tintColorValue;
flat out float emissiveStrengthValue;
flat out int boneIndexValue;
flat out int emissiveBoneTexelIndex;

vec4 readBonePoseTexel(int texelIndex, int poseBase) {
    return texelFetch(BonePoseSampler, poseBase + texelIndex);
}

int readPackedLight(int instanceIndex) {
    return texelFetch(InstancePackedLightSampler, instanceIndex).r;
}

float readEmissiveStrength(int instanceIndex) {
    return texelFetch(InstanceEmissiveStrengthSampler, instanceIndex).r;
}

vec4 readInstanceColor(int instanceIndex) {
    return texelFetch(InstanceColorSampler, instanceIndex);
}

int readPoseBase(int instanceIndex) {
    return texelFetch(InstancePoseBaseSampler, instanceIndex).r;
}

int readEmissiveBase(int instanceIndex) {
    return texelFetch(InstanceEmissiveBaseSampler, instanceIndex).r;
}

int readLightBase(int instanceIndex) {
    return texelFetch(InstanceLightBaseSampler, instanceIndex).r;
}

mat4 readBonePoseData(int boneIndex, int poseBase) {
    int base = boneIndex * 4;
    return mat4(
        readBonePoseTexel(base, poseBase),
        readBonePoseTexel(base + 1, poseBase),
        readBonePoseTexel(base + 2, poseBase),
        readBonePoseTexel(base + 3, poseBase)
    );
}

mat4 readInstanceMatrix(int instanceIndex) {
    int base = instanceIndex * 4;
    return mat4(
        texelFetch(InstanceMatrixSampler, base),
        texelFetch(InstanceMatrixSampler, base + 1),
        texelFetch(InstanceMatrixSampler, base + 2),
        texelFetch(InstanceMatrixSampler, base + 3)
    );
}

mat4 translationMatrix(vec3 offset) {
    mat4 matrix = mat4(1.0);
    matrix[3] = vec4(offset, 1.0);
    return matrix;
}

mat4 scaleMatrix(vec3 amount) {
    mat4 matrix = mat4(1.0);
    matrix[0][0] = amount.x;
    matrix[1][1] = amount.y;
    matrix[2][2] = amount.z;
    return matrix;
}

mat4 rotationXMatrix(float angle) {
    float c = cos(angle);
    float s = sin(angle);
    return mat4(
        1.0, 0.0, 0.0, 0.0,
        0.0, c, s, 0.0,
        0.0, -s, c, 0.0,
        0.0, 0.0, 0.0, 1.0
    );
}

mat4 rotationYMatrix(float angle) {
    float c = cos(angle);
    float s = sin(angle);
    return mat4(
        c, 0.0, -s, 0.0,
        0.0, 1.0, 0.0, 0.0,
        s, 0.0, c, 0.0,
        0.0, 0.0, 0.0, 1.0
    );
}

mat4 rotationZMatrix(float angle) {
    float c = cos(angle);
    float s = sin(angle);
    return mat4(
        c, s, 0.0, 0.0,
        -s, c, 0.0, 0.0,
        0.0, 0.0, 1.0, 0.0,
        0.0, 0.0, 0.0, 1.0
    );
}

mat4 buildLocalMatrix(int boneIndex, int poseBase) {
    mat4 pose = readBonePoseData(boneIndex, poseBase);
    vec3 position = pose[0].xyz / 16.0;
    vec3 pivot = pose[1].xyz / 16.0;
    vec3 rotation = pose[2].xyz;
    vec3 scale = pose[3].xyz;

    return translationMatrix(vec3(-position.x, position.y, position.z))
        * translationMatrix(pivot)
        * rotationZMatrix(rotation.z)
        * rotationYMatrix(rotation.y)
        * rotationXMatrix(rotation.x)
        * scaleMatrix(scale)
        * translationMatrix(-pivot);
}

mat4 resolveBoneMatrix(int boneIndex, int poseBase) {
    if (BoneDataResolved != 0) {
        return readBonePoseData(boneIndex, poseBase);
    }

    mat4 finalMatrix = mat4(1.0);
    int current = boneIndex;
    for (int i = 0; i < BoneCount; i++) {
        if (current < 0) {
            break;
        }

        mat4 pose = readBonePoseData(current, poseBase);
        finalMatrix = buildLocalMatrix(current, poseBase) * finalMatrix;
        current = int(round(pose[0].w));
    }
    return finalMatrix;
}

int resolvePackedLight(int instanceIndex, int boneIndex) {
    if (UseBoneLightSampler != 0) {
        return texelFetch(BoneLightSampler, readLightBase(instanceIndex) + boneIndex).r;
    }

    return readPackedLight(instanceIndex);
}

int packWorldLight(int blockLight, int skyLight) {
    return ((blockLight & 15) << 4) | ((skyLight & 15) << 20);
}

const float LIGHT_SAMPLE_EPSILON = 1.0 / 64.0;

bool readWorldLightCell(ivec3 blockPos, out vec2 lightLevels) {
    ivec3 local = blockPos - LightVolumeBlockOrigin;
    if (any(lessThan(local, ivec3(0))) || any(greaterThanEqual(local, LightVolumeSize))) {
        lightLevels = vec2(-1.0);
        return false;
    }

    int index = local.x + LightVolumeSize.x * (local.y + LightVolumeSize.y * local.z);
    int blockLight = texelFetch(BlockLightVolumeSampler, index).r;
    int skyLight = texelFetch(SkyLightVolumeSampler, index).r;
    if (blockLight < 0 || blockLight > 15 || skyLight < 0 || skyLight > 15) {
        lightLevels = vec2(-1.0);
        return false;
    }

    lightLevels = vec2(float(blockLight), float(skyLight));
    return true;
}

int packWorldLight(vec2 lightLevels) {
    int blockLight = int(round(clamp(lightLevels.x, 0.0, 15.0)));
    int skyLight = int(round(clamp(lightLevels.y, 0.0, 15.0)));
    return packWorldLight(blockLight, skyLight);
}

int sampleWorldLight(vec3 worldPos, vec3 worldNormal, int fallbackPackedLight) {
    if (UseWorldLightVolume == 0) {
        return fallbackPackedLight;
    }

    ivec2 fallbackUv = ivec2(fallbackPackedLight & 0xFFFF, (fallbackPackedLight >> 16) & 0xFFFF);
    if (fallbackUv.x >= 240 && fallbackUv.y >= 240) {
        return fallbackPackedLight;
    }

    vec3 samplePos = worldPos + normalize(worldNormal) * LIGHT_SAMPLE_EPSILON;
    ivec3 basePos = ivec3(floor(samplePos));
    vec3 frac = fract(samplePos);

    vec2 light000;
    vec2 light100;
    vec2 light010;
    vec2 light110;
    vec2 light001;
    vec2 light101;
    vec2 light011;
    vec2 light111;

    if (!readWorldLightCell(basePos, light000)
            || !readWorldLightCell(basePos + ivec3(1, 0, 0), light100)
            || !readWorldLightCell(basePos + ivec3(0, 1, 0), light010)
            || !readWorldLightCell(basePos + ivec3(1, 1, 0), light110)
            || !readWorldLightCell(basePos + ivec3(0, 0, 1), light001)
            || !readWorldLightCell(basePos + ivec3(1, 0, 1), light101)
            || !readWorldLightCell(basePos + ivec3(0, 1, 1), light011)
            || !readWorldLightCell(basePos + ivec3(1, 1, 1), light111)) {
        return fallbackPackedLight;
    }

    vec2 lightX00 = mix(light000, light100, frac.x);
    vec2 lightX10 = mix(light010, light110, frac.x);
    vec2 lightX01 = mix(light001, light101, frac.x);
    vec2 lightX11 = mix(light011, light111, frac.x);
    vec2 lightY0 = mix(lightX00, lightX10, frac.y);
    vec2 lightY1 = mix(lightX01, lightX11, frac.y);
    return packWorldLight(mix(lightY0, lightY1, frac.z));
}

void main() {
    int poseBase = readPoseBase(gl_InstanceID);
    mat4 boneMat = resolveBoneMatrix(BoneIndex, poseBase);
    mat4 modelViewMat = readInstanceMatrix(gl_InstanceID);
    vec4 modelPosition = boneMat * vec4(Position, 1.0);
    vec4 viewPosition = modelViewMat * modelPosition;
    vec3 worldPos = CameraWorldPos + IViewRotMat * viewPosition.xyz;
    vec3 modelNormal = normalize(mat3(boneMat) * Normal);
    vec3 worldNormal = normalize(IViewRotMat * (mat3(modelViewMat) * modelNormal));
    int fallbackPackedLight = resolvePackedLight(gl_InstanceID, BoneIndex);
    int packedLight = sampleWorldLight(worldPos, worldNormal, fallbackPackedLight);
    ivec2 lightUv = ivec2(packedLight & 0xFFFF, (packedLight >> 16) & 0xFFFF);
    vec4 lightmapColor = texelFetch(Sampler2, lightUv / 16, 0);

    gl_Position = ProjMat * viewPosition;
    texCoord0 = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
    vertexDistance = fog_distance(modelPosition.xyz, FogShape);
    lightMapColor = vec4(1.0);
    vertexColor = vec4(Color.rgb * lightmapColor.rgb, Color.a);
    tintColorValue = readInstanceColor(gl_InstanceID);
    emissiveStrengthValue = UseEmissiveLayer != 0 ? readEmissiveStrength(gl_InstanceID) : 0.0;
    boneIndexValue = BoneIndex;
    emissiveBoneTexelIndex = UseEmissiveLayer != 0 ? readEmissiveBase(gl_InstanceID) + BoneIndex : -1;
}
