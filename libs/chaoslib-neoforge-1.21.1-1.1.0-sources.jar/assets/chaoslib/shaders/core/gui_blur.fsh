#version 150

uniform sampler2D Sampler0;
uniform vec2 BlurTexelSize;

in vec2 texCoord0;

out vec4 fragColor;

// 2D Gaussian over the captured framebuffer region behind the panel. RADIUS is the tap count per axis and
// SPREAD widens the sampling step (in framebuffer texels) so the blur reaches ~RADIUS*SPREAD texels.
const int RADIUS = 5;
const float SPREAD = 1.8;

void main() {
    vec3 sum = vec3(0.0);
    float total = 0.0;
    float sigma = float(RADIUS) * 0.6;
    for (int x = -RADIUS; x <= RADIUS; x++) {
        for (int y = -RADIUS; y <= RADIUS; y++) {
            float weight = exp(-float(x * x + y * y) / (2.0 * sigma * sigma));
            sum += texture(Sampler0, texCoord0 + vec2(float(x), float(y)) * SPREAD * BlurTexelSize).rgb * weight;
            total += weight;
        }
    }
    vec3 blurred = sum / total;

    // Frosted-acrylic styling so the panel reads as a translucent glass card rather than a plain blurred
    // patch: desaturate a touch, darken slightly and lift toward a cool tint.
    float luma = dot(blurred, vec3(0.299, 0.587, 0.114));
    vec3 frosted = mix(blurred, vec3(luma), 0.35);
    frosted = frosted * 0.82 + vec3(0.04, 0.05, 0.08);

    fragColor = vec4(frosted, 1.0);
}
