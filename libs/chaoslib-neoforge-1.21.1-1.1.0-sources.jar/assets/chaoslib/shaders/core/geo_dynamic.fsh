#version 150

#moj_import <fog.glsl>

uniform sampler2D Sampler0;
uniform sampler2D Sampler1;

uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;
uniform int UseEmissiveLayer;
uniform float EmissiveStrength;
uniform samplerBuffer EmissiveBoneMaskSampler;
uniform int BoneCount;

in vec2 texCoord0;
in float vertexDistance;
in vec4 vertexColor;
in vec4 lightMapColor;
in vec4 tintColorValue;
flat in float emissiveStrengthValue;
flat in int boneIndexValue;
flat in int emissiveBoneTexelIndex;

out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0);
    if (color.a < 0.1) {
        discard;
    }

    vec3 emissiveColor = vec3(0.0);
    float emissiveFactor = 0.0;
    if (UseEmissiveLayer != 0 && boneIndexValue >= 0 && boneIndexValue < BoneCount && emissiveBoneTexelIndex >= 0 && texelFetch(EmissiveBoneMaskSampler, emissiveBoneTexelIndex).r > 0.5) {
        vec4 emissiveSample = texture(Sampler1, texCoord0);
        emissiveColor = emissiveSample.rgb * ColorModulator.rgb * tintColorValue.rgb;
        emissiveFactor = emissiveSample.a * emissiveStrengthValue * tintColorValue.a;
    }

    color *= vertexColor * ColorModulator * tintColorValue;
    color *= lightMapColor;
    if (emissiveFactor > 0.0) {
        color.rgb = mix(color.rgb, emissiveColor, clamp(emissiveFactor, 0.0, 1.0));
    }
    fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
}
