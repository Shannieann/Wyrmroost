
uniform samplerBuffer chaos_BonePoseSampler;
uniform isamplerBuffer chaos_BoneIndexSampler;
uniform samplerBuffer chaos_InstanceMatrixSampler;
uniform isamplerBuffer chaos_InstancePoseBaseSampler;
uniform isamplerBuffer chaos_InstancePackedLightSampler;
uniform isamplerBuffer chaos_InstanceLightBaseSampler;
uniform int chaos_Instanced;
uniform isamplerBuffer chaos_BoneLightSampler;
uniform isamplerBuffer chaos_BlockLightVolumeSampler;
uniform isamplerBuffer chaos_SkyLightVolumeSampler;
uniform int chaos_BoneDataResolved;
uniform int chaos_PoseBase;
uniform int chaos_UseBoneLightSampler;
uniform int chaos_UseWorldLightVolume;
uniform ivec2 chaos_LightUV;
uniform mat4 chaos_ModelWorldRelMat;
uniform vec3 chaos_CameraWorldPos;
uniform ivec3 chaos_LightVolumeBlockOrigin;
uniform ivec3 chaos_LightVolumeSize;

const float chaos_LIGHT_SAMPLE_EPSILON = 1.0 / 64.0;

mat4 chaos_translationMatrix(vec3 offset) {
    mat4 matrix = mat4(1.0);
    matrix[3] = vec4(offset, 1.0);
    return matrix;
}

mat4 chaos_scaleMatrix(vec3 amount) {
    mat4 matrix = mat4(1.0);
    matrix[0][0] = amount.x;
    matrix[1][1] = amount.y;
    matrix[2][2] = amount.z;
    return matrix;
}

mat4 chaos_rotationXMatrix(float angle) {
    float c = cos(angle);
    float s = sin(angle);
    return mat4(1.0, 0.0, 0.0, 0.0, 0.0, c, s, 0.0, 0.0, -s, c, 0.0, 0.0, 0.0, 0.0, 1.0);
}

mat4 chaos_rotationYMatrix(float angle) {
    float c = cos(angle);
    float s = sin(angle);
    return mat4(c, 0.0, -s, 0.0, 0.0, 1.0, 0.0, 0.0, s, 0.0, c, 0.0, 0.0, 0.0, 0.0, 1.0);
}

mat4 chaos_rotationZMatrix(float angle) {
    float c = cos(angle);
    float s = sin(angle);
    return mat4(c, s, 0.0, 0.0, -s, c, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0);
}

int chaos_poseBase() {
    return chaos_Instanced != 0 ? texelFetch(chaos_InstancePoseBaseSampler, gl_InstanceID).r : chaos_PoseBase;
}

mat4 chaos_modelMatrix() {
    if (chaos_Instanced == 0) {
        return mat4(1.0);
    }

    int base = gl_InstanceID * 4;
    return mat4(
        texelFetch(chaos_InstanceMatrixSampler, base),
        texelFetch(chaos_InstanceMatrixSampler, base + 1),
        texelFetch(chaos_InstanceMatrixSampler, base + 2),
        texelFetch(chaos_InstanceMatrixSampler, base + 3)
    );
}

mat4 chaos_readBonePoseData(int boneIndex) {
    int base = chaos_poseBase() + boneIndex * 4;
    return mat4(
        texelFetch(chaos_BonePoseSampler, base),
        texelFetch(chaos_BonePoseSampler, base + 1),
        texelFetch(chaos_BonePoseSampler, base + 2),
        texelFetch(chaos_BonePoseSampler, base + 3)
    );
}

mat4 chaos_buildLocalMatrix(int boneIndex) {
    mat4 pose = chaos_readBonePoseData(boneIndex);
    vec3 position = pose[0].xyz / 16.0;
    vec3 pivot = pose[1].xyz / 16.0;
    vec3 rotation = pose[2].xyz;
    vec3 scale = pose[3].xyz;

    return chaos_translationMatrix(vec3(-position.x, position.y, position.z))
        * chaos_translationMatrix(pivot)
        * chaos_rotationZMatrix(rotation.z)
        * chaos_rotationYMatrix(rotation.y)
        * chaos_rotationXMatrix(rotation.x)
        * chaos_scaleMatrix(scale)
        * chaos_translationMatrix(-pivot);
}

mat4 chaos_resolveBoneMatrix(int boneIndex) {
    if (chaos_BoneDataResolved != 0) {
        return chaos_readBonePoseData(boneIndex);
    }

    mat4 finalMatrix = mat4(1.0);
    int current = boneIndex;
    for (int i = 0; i < 1024; i++) {
        if (current < 0) {
            break;
        }

        mat4 pose = chaos_readBonePoseData(current);
        finalMatrix = chaos_buildLocalMatrix(current) * finalMatrix;
        current = int(round(pose[0].w));
    }
    return finalMatrix;
}

int chaos_boneIndex() {
    return texelFetch(chaos_BoneIndexSampler, gl_VertexID).r;
}

mat4 chaos_cachedBoneMatrix = mat4(0.0);
bool chaos_boneMatrixResolved = false;

mat4 chaos_boneMatrix() {
    if (!chaos_boneMatrixResolved) {
        chaos_cachedBoneMatrix = chaos_resolveBoneMatrix(chaos_boneIndex());
        chaos_boneMatrixResolved = true;
    }
    return chaos_cachedBoneMatrix;
}

vec4 chaos_skinPosition(vec4 position) {
    return chaos_modelMatrix() * (chaos_boneMatrix() * position);
}

vec3 chaos_skinNormal(vec3 normal) {
    return normalize(mat3(chaos_modelMatrix()) * (mat3(chaos_boneMatrix()) * normal));
}

vec4 chaos_skinTangent(vec4 tangent) {
    return vec4(normalize(mat3(chaos_modelMatrix()) * (mat3(chaos_boneMatrix()) * tangent.xyz)), tangent.w);
}

bool chaos_readWorldLightCell(ivec3 blockPos, out vec2 lightLevels) {
    ivec3 local = blockPos - chaos_LightVolumeBlockOrigin;
    if (any(lessThan(local, ivec3(0))) || any(greaterThanEqual(local, chaos_LightVolumeSize))) {
        lightLevels = vec2(-1.0);
        return false;
    }

    int index = local.x + chaos_LightVolumeSize.x * (local.y + chaos_LightVolumeSize.y * local.z);
    int blockLight = texelFetch(chaos_BlockLightVolumeSampler, index).r;
    int skyLight = texelFetch(chaos_SkyLightVolumeSampler, index).r;
    if (blockLight < 0 || blockLight > 15 || skyLight < 0 || skyLight > 15) {
        lightLevels = vec2(-1.0);
        return false;
    }

    lightLevels = vec2(float(blockLight), float(skyLight));
    return true;
}

ivec2 chaos_boneLightUv() {
    if (chaos_Instanced != 0) {
        int packedLight = chaos_UseBoneLightSampler != 0
            ? texelFetch(chaos_BoneLightSampler, texelFetch(chaos_InstanceLightBaseSampler, gl_InstanceID).r + chaos_boneIndex()).r
            : texelFetch(chaos_InstancePackedLightSampler, gl_InstanceID).r;
        return ivec2(packedLight & 0xFFFF, (packedLight >> 16) & 0xFFFF);
    }

    if (chaos_UseBoneLightSampler == 0) {
        return chaos_LightUV;
    }

    int packedLight = texelFetch(chaos_BoneLightSampler, chaos_boneIndex()).r;
    return ivec2(packedLight & 0xFFFF, (packedLight >> 16) & 0xFFFF);
}

ivec2 chaos_worldLightUv(vec3 worldPos, vec3 worldNormal, ivec2 fallbackUv) {
    if (chaos_UseWorldLightVolume == 0 || (fallbackUv.x >= 240 && fallbackUv.y >= 240)) {
        return fallbackUv;
    }

    vec3 samplePos = worldPos + normalize(worldNormal) * chaos_LIGHT_SAMPLE_EPSILON;
    ivec3 basePos = ivec3(floor(samplePos));
    vec3 frac = fract(samplePos);

    vec2 light000;
    vec2 light100;
    vec2 light010;
    vec2 light110;
    vec2 light001;
    vec2 light101;
    vec2 light011;
    vec2 light111;
    if (!chaos_readWorldLightCell(basePos, light000)
            || !chaos_readWorldLightCell(basePos + ivec3(1, 0, 0), light100)
            || !chaos_readWorldLightCell(basePos + ivec3(0, 1, 0), light010)
            || !chaos_readWorldLightCell(basePos + ivec3(1, 1, 0), light110)
            || !chaos_readWorldLightCell(basePos + ivec3(0, 0, 1), light001)
            || !chaos_readWorldLightCell(basePos + ivec3(1, 0, 1), light101)
            || !chaos_readWorldLightCell(basePos + ivec3(0, 1, 1), light011)
            || !chaos_readWorldLightCell(basePos + ivec3(1, 1, 1), light111)) {
        return fallbackUv;
    }

    vec2 lightX00 = mix(light000, light100, frac.x);
    vec2 lightX10 = mix(light010, light110, frac.x);
    vec2 lightX01 = mix(light001, light101, frac.x);
    vec2 lightX11 = mix(light011, light111, frac.x);
    vec2 lightY0 = mix(lightX00, lightX10, frac.y);
    vec2 lightY1 = mix(lightX01, lightX11, frac.y);
    vec2 lightLevels = mix(lightY0, lightY1, frac.z);

    int blockLight = int(round(clamp(lightLevels.x, 0.0, 15.0)));
    int skyLight = int(round(clamp(lightLevels.y, 0.0, 15.0)));
    return ivec2(blockLight << 4, skyLight << 4);
}

vec4 chaos_lightmapCoord(vec4 skinnedPosition, vec3 skinnedNormal) {
    ivec2 fallbackUv = chaos_boneLightUv();
    vec3 worldPos = chaos_CameraWorldPos + (chaos_ModelWorldRelMat * skinnedPosition).xyz;
    vec3 worldNormal = normalize(mat3(chaos_ModelWorldRelMat) * skinnedNormal);
    ivec2 lightUv = chaos_worldLightUv(worldPos, worldNormal, fallbackUv);
    return vec4(float(lightUv.x), float(lightUv.y), 0.0, 1.0);
}
