uniform mat4 ModelWorldRelMat;
uniform int UseWorldLightVolume;
uniform vec3 CameraWorldPos;
uniform ivec3 LightVolumeBlockOrigin;
uniform ivec3 LightVolumeSize;
uniform isamplerBuffer BlockLightVolumeSampler;
uniform isamplerBuffer SkyLightVolumeSampler;

const float LIGHT_SAMPLE_EPSILON = 1.0 / 64.0;

mat3 resolveBoneNormalMatrix(mat4 boneMat) {
    mat3 linear = mat3(boneMat);
    float det = determinant(linear);
    if (abs(det) <= 1.0e-8) {
        return linear;
    }
    return transpose(inverse(linear));
}

vec3 resolveModelNormal(mat4 boneMat) {
    return normalize(resolveBoneNormalMatrix(boneMat) * Normal);
}

vec3 resolveModelTangent(mat4 boneMat) {
    return normalize(resolveBoneNormalMatrix(boneMat) * Tangent.xyz);
}

float resolveTangentHandedness(mat4 boneMat) {
    return determinant(mat3(boneMat)) < 0.0 ? -Tangent.w : Tangent.w;
}

int packWorldLight(int blockLight, int skyLight) {
    return ((blockLight & 15) << 4) | ((skyLight & 15) << 20);
}

bool readWorldLightCell(ivec3 blockPos, out vec2 lightLevels) {
    ivec3 local = blockPos - LightVolumeBlockOrigin;
    if (any(lessThan(local, ivec3(0))) || any(greaterThanEqual(local, LightVolumeSize))) {
        lightLevels = vec2(-1.0);
        return false;
    }

    int index = local.x + LightVolumeSize.x * (local.y + LightVolumeSize.y * local.z);
    int blockLight = texelFetch(BlockLightVolumeSampler, index).r;
    int skyLight = texelFetch(SkyLightVolumeSampler, index).r;
    if (blockLight < 0 || blockLight > 15 || skyLight < 0 || skyLight > 15) {
        lightLevels = vec2(-1.0);
        return false;
    }

    lightLevels = vec2(float(blockLight), float(skyLight));
    return true;
}

int packWorldLight(vec2 lightLevels) {
    int blockLight = int(round(clamp(lightLevels.x, 0.0, 15.0)));
    int skyLight = int(round(clamp(lightLevels.y, 0.0, 15.0)));
    return packWorldLight(blockLight, skyLight);
}

int sampleWorldLight(vec3 worldPos, vec3 worldNormal, int fallbackPackedLight) {
    if (UseWorldLightVolume == 0) {
        return fallbackPackedLight;
    }

    ivec2 fallbackUv = ivec2(fallbackPackedLight & 0xFFFF, (fallbackPackedLight >> 16) & 0xFFFF);
    if (fallbackUv.x >= 240 && fallbackUv.y >= 240) {
        return fallbackPackedLight;
    }

    vec3 samplePos = worldPos + normalize(worldNormal) * LIGHT_SAMPLE_EPSILON;
    ivec3 basePos = ivec3(floor(samplePos));
    vec3 frac = fract(samplePos);

    vec2 light000;
    vec2 light100;
    vec2 light010;
    vec2 light110;
    vec2 light001;
    vec2 light101;
    vec2 light011;
    vec2 light111;

    if (!readWorldLightCell(basePos, light000)
            || !readWorldLightCell(basePos + ivec3(1, 0, 0), light100)
            || !readWorldLightCell(basePos + ivec3(0, 1, 0), light010)
            || !readWorldLightCell(basePos + ivec3(1, 1, 0), light110)
            || !readWorldLightCell(basePos + ivec3(0, 0, 1), light001)
            || !readWorldLightCell(basePos + ivec3(1, 0, 1), light101)
            || !readWorldLightCell(basePos + ivec3(0, 1, 1), light011)
            || !readWorldLightCell(basePos + ivec3(1, 1, 1), light111)) {
        return fallbackPackedLight;
    }

    vec2 lightX00 = mix(light000, light100, frac.x);
    vec2 lightX10 = mix(light010, light110, frac.x);
    vec2 lightX01 = mix(light001, light101, frac.x);
    vec2 lightX11 = mix(light011, light111, frac.x);
    vec2 lightY0 = mix(lightX00, lightX10, frac.y);
    vec2 lightY1 = mix(lightX01, lightX11, frac.y);
    return packWorldLight(mix(lightY0, lightY1, frac.z));
}

int resolveOutputPackedLight(mat4 boneMat, vec4 modelPosition, vec3 modelNormal) {
    vec3 cameraRelativePos = (ModelWorldRelMat * modelPosition).xyz;
    vec3 worldPos = CameraWorldPos + cameraRelativePos;
    vec3 worldNormal = normalize(mat3(ModelWorldRelMat) * modelNormal);
    return sampleWorldLight(worldPos, worldNormal, resolvePackedLight(BoneIndex));
}
