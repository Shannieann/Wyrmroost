void main() {
    mat4 boneMat = resolveBoneMatrix(BoneIndex);
    vec4 modelPosition = boneMat * vec4(Position, 1.0);
    vec3 modelNormal = resolveModelNormal(boneMat);
    vec3 modelTangent = resolveModelTangent(boneMat);
    float tangentHandedness = resolveTangentHandedness(boneMat);

    TfPosition = modelPosition.xyz;
    TfUV2Packed = resolveOutputPackedLight(boneMat, modelPosition, modelNormal);
    TfNormalPacked = packNormal(modelNormal);
    TfTangentPacked = packTangent(vec4(modelTangent, tangentHandedness));
}
