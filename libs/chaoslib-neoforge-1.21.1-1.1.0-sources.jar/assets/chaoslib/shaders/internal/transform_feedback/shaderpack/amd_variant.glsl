mat3 resolveBoneNormalMatrix(mat4 boneMat) {
    return mat3(boneMat);
}

vec3 resolveModelNormal(mat4 boneMat) {
    return normalize(resolveBoneNormalMatrix(boneMat) * Normal);
}

vec3 resolveModelTangent(mat4 boneMat) {
    return normalize(resolveBoneNormalMatrix(boneMat) * Tangent.xyz);
}

float resolveTangentHandedness(mat4 boneMat) {
    return Tangent.w;
}

int resolveOutputPackedLight(mat4 boneMat, vec4 modelPosition, vec3 modelNormal) {
    return resolvePackedLight(BoneIndex);
}
