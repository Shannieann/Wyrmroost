#version 150

#include "common.glsl"
#include "default_variant.glsl"
#include "main.glsl"
