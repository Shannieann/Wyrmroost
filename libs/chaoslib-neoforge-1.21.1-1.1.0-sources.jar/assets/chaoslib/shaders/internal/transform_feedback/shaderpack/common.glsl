in vec3 Position;
in int BoneIndex;
in vec3 Normal;
in vec4 Tangent;

uniform samplerBuffer BonePoseSampler;
uniform int BonePoseBase;
uniform ivec2 LightUV;
uniform int UseBoneLightSampler;
uniform int BoneDataResolved;
uniform isamplerBuffer BoneLightSampler;

out vec3 TfPosition;
flat out int TfUV2Packed;
flat out int TfNormalPacked;
flat out int TfTangentPacked;

mat4 translationMatrix(vec3 offset) {
    mat4 matrix = mat4(1.0);
    matrix[3] = vec4(offset, 1.0);
    return matrix;
}

mat4 scaleMatrix(vec3 amount) {
    mat4 matrix = mat4(1.0);
    matrix[0][0] = amount.x;
    matrix[1][1] = amount.y;
    matrix[2][2] = amount.z;
    return matrix;
}

mat4 rotationXMatrix(float angle) {
    float c = cos(angle);
    float s = sin(angle);
    return mat4(
        1.0, 0.0, 0.0, 0.0,
        0.0, c, s, 0.0,
        0.0, -s, c, 0.0,
        0.0, 0.0, 0.0, 1.0
    );
}

mat4 rotationYMatrix(float angle) {
    float c = cos(angle);
    float s = sin(angle);
    return mat4(
        c, 0.0, -s, 0.0,
        0.0, 1.0, 0.0, 0.0,
        s, 0.0, c, 0.0,
        0.0, 0.0, 0.0, 1.0
    );
}

mat4 rotationZMatrix(float angle) {
    float c = cos(angle);
    float s = sin(angle);
    return mat4(
        c, s, 0.0, 0.0,
        -s, c, 0.0, 0.0,
        0.0, 0.0, 1.0, 0.0,
        0.0, 0.0, 0.0, 1.0
    );
}

vec4 readBonePoseTexel(int texelIndex) {
    return texelFetch(BonePoseSampler, BonePoseBase + texelIndex);
}

mat4 readBonePoseData(int boneIndex) {
    int base = boneIndex * 4;
    return mat4(
        readBonePoseTexel(base),
        readBonePoseTexel(base + 1),
        readBonePoseTexel(base + 2),
        readBonePoseTexel(base + 3)
    );
}

mat4 buildLocalMatrix(int boneIndex) {
    mat4 pose = readBonePoseData(boneIndex);
    vec3 position = pose[0].xyz / 16.0;
    vec3 pivot = pose[1].xyz / 16.0;
    vec3 rotation = pose[2].xyz;
    vec3 scale = pose[3].xyz;

    return translationMatrix(vec3(-position.x, position.y, position.z))
        * translationMatrix(pivot)
        * rotationZMatrix(rotation.z)
        * rotationYMatrix(rotation.y)
        * rotationXMatrix(rotation.x)
        * scaleMatrix(scale)
        * translationMatrix(-pivot);
}

mat4 resolveBoneMatrix(int boneIndex) {
    if (BoneDataResolved != 0) {
        return readBonePoseData(boneIndex);
    }

    mat4 finalMatrix = mat4(1.0);
    int current = boneIndex;
    for (int i = 0; i < 1024; i++) {
        if (current < 0) {
            break;
        }

        mat4 pose = readBonePoseData(current);
        finalMatrix = buildLocalMatrix(current) * finalMatrix;
        current = int(round(pose[0].w));
    }
    return finalMatrix;
}

int packShort2(ivec2 value) {
    return (value.x & 65535) | ((value.y & 65535) << 16);
}

int packNormal(vec3 value) {
    ivec3 packedNormal = ivec3(round(clamp(value, -1.0, 1.0) * 127.0));
    ivec3 encodedNormal = (packedNormal + 256) & 255;
    return encodedNormal.x | (encodedNormal.y << 8) | (encodedNormal.z << 16);
}

int packTangent(vec4 value) {
    ivec4 packedTangent = ivec4(round(clamp(value, -1.0, 1.0) * 127.0));
    ivec4 encodedTangent = (packedTangent + 256) & 255;
    return encodedTangent.x | (encodedTangent.y << 8) | (encodedTangent.z << 16) | (encodedTangent.w << 24);
}

int resolvePackedLight(int boneIndex) {
    if (UseBoneLightSampler != 0) {
        return texelFetch(BoneLightSampler, boneIndex).r;
    }

    return packShort2(LightUV);
}
