#version 150

#include "common.glsl"
#include "amd_variant.glsl"
#include "main.glsl"
