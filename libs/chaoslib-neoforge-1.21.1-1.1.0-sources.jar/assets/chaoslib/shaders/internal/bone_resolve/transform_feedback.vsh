#version 150

in int BoneIndex;
in int BoneDepth;

uniform samplerBuffer LocalBonePoseSampler;
uniform int LocalPoseBase;
uniform samplerBuffer PreviousResolvedBoneSampler;
uniform int ResolveDepth;

out vec4 TfPose0;
out vec4 TfPose1;
out vec4 TfPose2;
out vec4 TfPose3;

vec4 readLocalPoseTexel(int texelIndex) {
    return texelFetch(LocalBonePoseSampler, LocalPoseBase + texelIndex);
}

mat4 readLocalPose(int boneIndex) {
    int base = boneIndex * 4;
    return mat4(
        readLocalPoseTexel(base),
        readLocalPoseTexel(base + 1),
        readLocalPoseTexel(base + 2),
        readLocalPoseTexel(base + 3)
    );
}

mat4 readResolvedPose(int boneIndex) {
    int base = boneIndex * 4;
    return mat4(
        texelFetch(PreviousResolvedBoneSampler, base),
        texelFetch(PreviousResolvedBoneSampler, base + 1),
        texelFetch(PreviousResolvedBoneSampler, base + 2),
        texelFetch(PreviousResolvedBoneSampler, base + 3)
    );
}

mat4 translationMatrix(vec3 offset) {
    mat4 matrix = mat4(1.0);
    matrix[3] = vec4(offset, 1.0);
    return matrix;
}

mat4 scaleMatrix(vec3 amount) {
    mat4 matrix = mat4(1.0);
    matrix[0][0] = amount.x;
    matrix[1][1] = amount.y;
    matrix[2][2] = amount.z;
    return matrix;
}

mat4 rotationXMatrix(float angle) {
    float c = cos(angle);
    float s = sin(angle);
    return mat4(
        1.0, 0.0, 0.0, 0.0,
        0.0, c, s, 0.0,
        0.0, -s, c, 0.0,
        0.0, 0.0, 0.0, 1.0
    );
}

mat4 rotationYMatrix(float angle) {
    float c = cos(angle);
    float s = sin(angle);
    return mat4(
        c, 0.0, -s, 0.0,
        0.0, 1.0, 0.0, 0.0,
        s, 0.0, c, 0.0,
        0.0, 0.0, 0.0, 1.0
    );
}

mat4 rotationZMatrix(float angle) {
    float c = cos(angle);
    float s = sin(angle);
    return mat4(
        c, s, 0.0, 0.0,
        -s, c, 0.0, 0.0,
        0.0, 0.0, 1.0, 0.0,
        0.0, 0.0, 0.0, 1.0
    );
}

mat4 buildLocalMatrix(int boneIndex) {
    mat4 pose = readLocalPose(boneIndex);
    vec3 position = pose[0].xyz / 16.0;
    vec3 pivot = pose[1].xyz / 16.0;
    vec3 rotation = pose[2].xyz;
    vec3 scale = pose[3].xyz;

    return translationMatrix(vec3(-position.x, position.y, position.z))
        * translationMatrix(pivot)
        * rotationZMatrix(rotation.z)
        * rotationYMatrix(rotation.y)
        * rotationXMatrix(rotation.x)
        * scaleMatrix(scale)
        * translationMatrix(-pivot);
}

void main() {
    mat4 localPose = readLocalPose(BoneIndex);
    int parentIndex = int(round(localPose[0].w));
    mat4 finalMatrix = readResolvedPose(BoneIndex);

    if (BoneDepth == ResolveDepth) {
        mat4 parentMatrix = parentIndex < 0 ? mat4(1.0) : readResolvedPose(parentIndex);
        finalMatrix = parentMatrix * buildLocalMatrix(BoneIndex);
    }

    TfPose0 = finalMatrix[0];
    TfPose1 = finalMatrix[1];
    TfPose2 = finalMatrix[2];
    TfPose3 = finalMatrix[3];
}
