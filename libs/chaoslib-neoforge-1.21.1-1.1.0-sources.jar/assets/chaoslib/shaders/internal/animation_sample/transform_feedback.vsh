#version 140

uniform samplerBuffer ClipSampler;
uniform samplerBuffer ChannelSampler;
uniform samplerBuffer KeyframeSampler;
uniform samplerBuffer BoneDefinitionSampler;
uniform samplerBuffer ActiveStateSampler;
uniform samplerBuffer TransitionPoseSampler;
uniform samplerBuffer RuntimeChannelSampler;
uniform samplerBuffer ControllerStateSampler;
uniform int BoneCount;
uniform int ControllerStateCount;

out vec4 TfPose0;
out vec4 TfPose1;
out vec4 TfPose2;
out vec4 TfPose3;

#include "shared.glsl"

void main() {
    int boneIndex = gl_VertexID;
    gl_Position = vec4(0.0, 0.0, 0.0, 1.0);
    gControllerStateCount = ControllerStateCount;

    if (boneIndex < 0 || boneIndex >= BoneCount) {
        TfPose0 = vec4(0.0);
        TfPose1 = vec4(0.0);
        TfPose2 = vec4(0.0);
        TfPose3 = vec4(0.0);
        return;
    }

    sampleBonePose(boneIndex, TfPose0, TfPose1, TfPose2, TfPose3);
}
