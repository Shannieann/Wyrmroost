const int CHANNEL_TEXEL_STRIDE = 3;
const int KEYFRAME_TEXEL_STRIDE = 5;
const int MAX_BONE_DEPTH = 256;
const int TARGET_POSITION = 0;
const int TARGET_ROTATION = 1;
const int TARGET_SCALE = 2;
const int SPACE_LOCAL = 0;
const int SPACE_ENTITY = 1;
const int EASING_LINEAR = 0;
const int EASING_STEP = 1;
const int EASING_CATMULL_ROM = 2;
const int EASING_IN_SINE = 3;
const int EASING_OUT_SINE = 4;
const int EASING_IN_OUT_SINE = 5;
const int EASING_IN_QUAD = 6;
const int EASING_OUT_QUAD = 7;
const int EASING_IN_OUT_QUAD = 8;
const int EASING_IN_CUBIC = 9;
const int EASING_OUT_CUBIC = 10;
const int EASING_IN_OUT_CUBIC = 11;
const int EASING_IN_QUART = 12;
const int EASING_OUT_QUART = 13;
const int EASING_IN_OUT_QUART = 14;
const int EASING_IN_QUINT = 15;
const int EASING_OUT_QUINT = 16;
const int EASING_IN_OUT_QUINT = 17;
const int EASING_IN_EXPO = 18;
const int EASING_OUT_EXPO = 19;
const int EASING_IN_OUT_EXPO = 20;
const int EASING_IN_CIRC = 21;
const int EASING_OUT_CIRC = 22;
const int EASING_IN_OUT_CIRC = 23;
const int EASING_IN_BACK = 24;
const int EASING_OUT_BACK = 25;
const int EASING_IN_OUT_BACK = 26;
const int EASING_IN_ELASTIC = 27;
const int EASING_OUT_ELASTIC = 28;
const int EASING_IN_OUT_ELASTIC = 29;
const int EASING_IN_BOUNCE = 30;
const int EASING_OUT_BOUNCE = 31;
const int EASING_IN_OUT_BOUNCE = 32;

vec4 readClipTexel(int index) {
    return texelFetch(ClipSampler, index);
}

vec4 readChannelTexel(int index) {
    return texelFetch(ChannelSampler, index);
}

vec4 readKeyframeTexel(int index) {
    return texelFetch(KeyframeSampler, index);
}

vec4 readBoneDefinitionTexel(int index) {
    return texelFetch(BoneDefinitionSampler, index);
}

int gActiveStateBase = 0;
int gTransitionPoseBase = 0;
int gRuntimeChannelBase = 0;
int gControllerStateBase = 0;
int gControllerStateCount = 0;

vec4 readActiveStateTexel(int index) {
    return texelFetch(ActiveStateSampler, gActiveStateBase + index);
}

vec4 readTransitionPoseTexel(int index) {
    return texelFetch(TransitionPoseSampler, gTransitionPoseBase + index);
}

vec4 readRuntimeChannelTexel(int index) {
    return texelFetch(RuntimeChannelSampler, gRuntimeChannelBase + index);
}

vec4 readControllerStateTexel(int index) {
    return texelFetch(ControllerStateSampler, gControllerStateBase + index);
}

vec4 readClip(int clipIndex) {
    return readClipTexel(clipIndex);
}

vec4 readChannelMeta(int channelIndex) {
    return readChannelTexel(channelIndex * CHANNEL_TEXEL_STRIDE);
}

vec4 readChannelConstant(int channelIndex) {
    return readChannelTexel(channelIndex * CHANNEL_TEXEL_STRIDE + 1);
}

vec4 readChannelExtra(int channelIndex) {
    return readChannelTexel(channelIndex * CHANNEL_TEXEL_STRIDE + 2);
}

vec4 readKeyframeMeta(int keyframeIndex) {
    return readKeyframeTexel(keyframeIndex * KEYFRAME_TEXEL_STRIDE);
}

vec3 readKeyframeVector(int keyframeIndex, int vectorIndex) {
    return readKeyframeTexel(keyframeIndex * KEYFRAME_TEXEL_STRIDE + 1 + vectorIndex).xyz;
}

vec3 sampleLinear(vec3 a, vec3 b, float t) {
    return mix(a, b, t);
}

vec3 sampleBezier(vec3 p0, vec3 p1, vec3 p2, vec3 p3, float t) {
    float u = 1.0 - t;
    float tt = t * t;
    float uu = u * u;
    float uuu = uu * u;
    float ttt = tt * t;
    return uuu * p0 + 3.0 * uu * t * p1 + 3.0 * u * tt * p2 + ttt * p3;
}

float smoothBlend(float t) {
    return t * t * (3.0 - 2.0 * t);
}

float easeOut(float value) {
    return 1.0 - value;
}

float quadratic(float value) {
    return value * value;
}

float cubic(float value) {
    return value * value * value;
}

float sineIn(float value) {
    return 1.0 - cos(value * 3.14159265 / 2.0);
}

float circleIn(float value) {
    return 1.0 - sqrt(max(0.0, 1.0 - value * value));
}

float expIn(float value) {
    return value <= 0.0 ? 0.0 : pow(2.0, 10.0 * (value - 1.0));
}

float backIn(float value, float arg, bool hasArg) {
    float overshoot = hasArg ? arg : 1.70158;
    return value * value * ((overshoot + 1.0) * value - overshoot);
}

float elasticIn(float value, float arg, bool hasArg) {
    float oscillations = hasArg ? arg : 1.0;
    return 1.0 - pow(cos(value * 3.14159265 / 2.0), 3.0) * cos(value * oscillations * 3.14159265);
}

float bounceOut(float value, float arg, bool hasArg) {
    float bounciness = hasArg ? arg : 0.5;
    float scale = 1.0 + max(0.0, bounciness) * 0.5;
    return abs(sin((value + 1.0) * 3.14159265 * scale) * (1.0 - value));
}

float bounceIn(float value, float arg, bool hasArg) {
    return 1.0 - bounceOut(1.0 - value, arg, hasArg);
}

float catmullRom(float value) {
    return 0.5 * (2.0 * (value + 1.0) + ((value + 2.0) - value)
    + (2.0 * value - 5.0 * (value + 1.0) + 4.0 * (value + 2.0) - (value + 3.0))
    + (3.0 * (value + 1.0) - value - 3.0 * (value + 2.0) + (value + 3.0)));
}

float applyBaseEasing(int easingType, float value, float arg, bool hasArg) {
    switch (easingType) {
        case EASING_CATMULL_ROM:
            return catmullRom(value);
        case EASING_IN_SINE:
            return sineIn(value);
        case EASING_IN_QUAD:
            return quadratic(value);
        case EASING_IN_CUBIC:
            return cubic(value);
        case EASING_IN_QUART:
            return pow(value, 4.0);
        case EASING_IN_QUINT:
            return pow(value, 5.0);
        case EASING_IN_EXPO:
            return expIn(value);
        case EASING_IN_CIRC:
            return circleIn(value);
        case EASING_IN_BACK:
            return backIn(value, arg, hasArg);
        case EASING_IN_ELASTIC:
            return elasticIn(value, arg, hasArg);
        default :
            return value;
    }

    return value;
}

float easeInOut(float value, int baseType, float arg, bool hasArg) {
    if (value < 0.5) {
        return applyBaseEasing(baseType, value * 2.0, arg, hasArg) / 2.0;
    }
    return 1.0 - applyBaseEasing(baseType, (1.0 - value) * 2.0, arg, hasArg) / 2.0;
}

float applyEasing(int easingType, float alpha, float arg, bool hasArg) {
    float value = clamp(alpha, 0.0, 1.0);
    float result;
    switch (easingType) {
        case EASING_LINEAR:
            result = value;
            break;
        case EASING_STEP:
            result = value <= 0.0 ? 0.0 : 1.0;
            break;
        case EASING_CATMULL_ROM:
            result = easeInOut(value, EASING_CATMULL_ROM, arg, hasArg);
            break;
        case EASING_IN_SINE:
            result = sineIn(value);
            break;
        case EASING_OUT_SINE:
            result = easeOut(sineIn(1.0 - value));
            break;
        case EASING_IN_OUT_SINE:
            result = easeInOut(value, EASING_IN_SINE, arg, hasArg);
            break;
        case EASING_IN_QUAD:
            result = quadratic(value);
            break;
        case EASING_OUT_QUAD:
            result = easeOut(quadratic(1.0 - value));
            break;
        case EASING_IN_OUT_QUAD:
            result = easeInOut(value, EASING_IN_QUAD, arg, hasArg);
            break;
        case EASING_IN_CUBIC:
            result = cubic(value);
            break;
        case EASING_OUT_CUBIC:
            result = easeOut(cubic(1.0 - value));
            break;
        case EASING_IN_OUT_CUBIC:
            result = easeInOut(value, EASING_IN_CUBIC, arg, hasArg);
            break;
        case EASING_IN_QUART:
            result = pow(value, 4.0);
            break;
        case EASING_OUT_QUART:
            result = easeOut(pow(1.0 - value, 4.0));
            break;
        case EASING_IN_OUT_QUART:
            result = easeInOut(value, EASING_IN_QUART, arg, hasArg);
            break;
        case EASING_IN_QUINT:
            result = pow(value, 5.0);
            break;
        case EASING_OUT_QUINT:
            result = easeOut(pow(1.0 - value, 5.0));
            break;
        case EASING_IN_OUT_QUINT:
            result = easeInOut(value, EASING_IN_QUINT, arg, hasArg);
            break;
        case EASING_IN_EXPO:
            result = expIn(value);
            break;
        case EASING_OUT_EXPO:
            result = easeOut(expIn(1.0 - value));
            break;
        case EASING_IN_OUT_EXPO:
            result = easeInOut(value, EASING_IN_EXPO, arg, hasArg);
            break;
        case EASING_IN_CIRC:
            result = circleIn(value);
            break;
        case EASING_OUT_CIRC:
            result = easeOut(circleIn(1.0 - value));
            break;
        case EASING_IN_OUT_CIRC:
            result = easeInOut(value, EASING_IN_CIRC, arg, hasArg);
            break;
        case EASING_IN_BACK:
            result = backIn(value, arg, hasArg);
            break;
        case EASING_OUT_BACK:
            result = easeOut(backIn(1.0 - value, arg, hasArg));
            break;
        case EASING_IN_OUT_BACK:
            result = easeInOut(value, EASING_IN_BACK, arg, hasArg);
            break;
        case EASING_IN_ELASTIC:
            result = elasticIn(value, arg, hasArg);
            break;
        case EASING_OUT_ELASTIC:
            result = easeOut(elasticIn(1.0 - value, arg, hasArg));
            break;
        case EASING_IN_OUT_ELASTIC:
            result = easeInOut(value, EASING_IN_ELASTIC, arg, hasArg);
            break;
        case EASING_IN_BOUNCE:
            result = bounceIn(value, arg, hasArg);
            break;
        case EASING_OUT_BOUNCE:
            result = bounceOut(value, arg, hasArg);
            break;
        case EASING_IN_OUT_BOUNCE:
            if (value < 0.5) {
                result = bounceIn(value * 2.0, arg, hasArg) / 2.0;
            } else {
                result = 0.5 + bounceOut(value * 2.0 - 1.0, arg, hasArg) / 2.0;
            }
            break;
        default :
            result = value;
            break;
    }
    return clamp(result, 0.0, 1.0);
}

mat3 rotationXMatrix(float angle) {
    float c = cos(angle);
    float s = sin(angle);
    return mat3(
            1.0, 0.0, 0.0,
            0.0, c, s,
            0.0, -s, c
    );
}

mat3 rotationYMatrix(float angle) {
    float c = cos(angle);
    float s = sin(angle);
    return mat3(
            c, 0.0, -s,
            0.0, 1.0, 0.0,
            s, 0.0, c
    );
}

mat3 rotationZMatrix(float angle) {
    float c = cos(angle);
    float s = sin(angle);
    return mat3(
            c, s, 0.0,
            -s, c, 0.0,
            0.0, 0.0, 1.0
    );
}

mat3 eulerToMatrix(vec3 rotation) {
    return rotationZMatrix(rotation.z) * rotationYMatrix(rotation.y) * rotationXMatrix(rotation.x);
}

vec3 matrixToEulerZYX(mat3 matrix) {
    float m02 = matrix[2][0];
    return vec3(
            atan(matrix[2][1], matrix[2][2]),
            atan(-m02, sqrt(max(0.0, 1.0 - m02 * m02))),
            atan(matrix[1][0], matrix[0][0])
    );
}

int boneParentIndex(int boneIndex) {
    return int(round(readBoneDefinitionTexel(boneIndex * 4).w));
}

vec3 readBoneBaseRotation(int boneIndex) {
    return readBoneDefinitionTexel(boneIndex * 4 + 2).xyz;
}

int findChannelIndex(int clipIndex, int boneIndex, int target) {
    vec4 clip = readClip(clipIndex);
    int channelStart = int(clip.x);
    int channelCount = int(clip.y);
    for (int channelOffset = 0; channelOffset < channelCount; channelOffset++) {
        int channelIndex = channelStart + channelOffset;
        vec4 channelMeta = readChannelMeta(channelIndex);
        if (int(round(channelMeta.x)) == boneIndex && int(round(channelMeta.y)) == target) {
            return channelIndex;
        }
    }
    return -1;
}

vec4 sampleChannel(int channelIndex, float animTimeSeconds, int runtimeSampleStart) {
    vec4 constantData = readChannelConstant(channelIndex);
    if (constantData.w > 0.5) {
        return vec4(constantData.xyz, 1.0);
    }

    vec4 extra = readChannelExtra(channelIndex);
    int dynamicSlot = int(round(extra.y));
    if (runtimeSampleStart >= 0 && dynamicSlot >= 0) {
        return readRuntimeChannelTexel(runtimeSampleStart + dynamicSlot);
    }

    vec4 meta = readChannelMeta(channelIndex);
    int keyframeStart = int(meta.z);
    int keyframeCount = int(meta.w);
    if (keyframeCount <= 0) {
        return vec4(0.0, 0.0, 0.0, 0.0);
    }
    if (keyframeCount == 1) {
        return vec4(readKeyframeVector(keyframeStart, 1), 1.0);
    }

    vec4 previousMeta = readKeyframeMeta(keyframeStart);
    if (animTimeSeconds <= previousMeta.x) {
        return vec4(readKeyframeVector(keyframeStart, 0), 1.0);
    }

    for (int i = 1; i < keyframeCount; i++) {
        int keyframeIndex = keyframeStart + i;
        vec4 nextMeta = readKeyframeMeta(keyframeIndex);
        if (animTimeSeconds <= nextMeta.x) {
            float span = nextMeta.x - previousMeta.x;
            float alpha = span <= 1.0e-6 ? 1.0 : (animTimeSeconds - previousMeta.x) / span;
            vec3 start = readKeyframeVector(keyframeIndex - 1, 1);
            vec3 end = readKeyframeVector(keyframeIndex, 0);
            if (nextMeta.z >= 0.0) {
                bool hasArg = nextMeta.w == nextMeta.w;
                alpha = applyEasing(int(round(nextMeta.z)), alpha, nextMeta.w, hasArg);
                return vec4(sampleLinear(start, end, alpha), 1.0);
            }

            int lerpMode = int(round(nextMeta.y));
            if (lerpMode == 3) {
                return vec4(start, 1.0);
            }
            if (lerpMode == 1) {
                return vec4(sampleLinear(start, end, smoothBlend(alpha)), 1.0);
            }
            if (lerpMode == 2) {
                vec3 control1 = readKeyframeVector(keyframeIndex - 1, 3);
                vec3 control2 = readKeyframeVector(keyframeIndex, 2);
                return vec4(sampleBezier(start, control1, control2, end, alpha), 1.0);
            }
            return vec4(sampleLinear(start, end, alpha), 1.0);
        }
        previousMeta = nextMeta;
    }

    return vec4(readKeyframeVector(keyframeStart + keyframeCount - 1, 1), 1.0);
}

vec4 sampleChannelForState(int boneIndex, int target, vec4 activeState, out int space) {
    int clipIndex = int(round(activeState.x));
    int runtimeSampleStart = int(round(activeState.w));
    int channelIndex = findChannelIndex(clipIndex, boneIndex, target);
    if (channelIndex < 0) {
        space = SPACE_LOCAL;
        return vec4(0.0, 0.0, 0.0, 0.0);
    }
    space = int(round(readChannelExtra(channelIndex).x));
    return sampleChannel(channelIndex, activeState.y, runtimeSampleStart);
}

vec3 rawRotationRadians(vec3 rawDegrees) {
    return vec3(radians(-rawDegrees.x), radians(-rawDegrees.y), radians(rawDegrees.z));
}

vec4 resolveLocalRotationContribution(int boneIndex, vec4 activeState, mat3 parentModelRotation) {
    vec3 baseRotation = readBoneBaseRotation(boneIndex);
    bool hasRotationAnimation = findChannelIndex(int(round(activeState.x)), boneIndex, TARGET_ROTATION) >= 0;
    int space;
    vec4 sampled = sampleChannelForState(boneIndex, TARGET_ROTATION, activeState, space);
    if (sampled.w < 0.5) {
        return vec4(baseRotation, hasRotationAnimation ? 1.0 : 0.0);
    }

    vec3 rawRotation = rawRotationRadians(sampled.xyz);
    if (space == SPACE_ENTITY) {
        mat3 entityDelta = eulerToMatrix(rawRotation);
        mat3 localRotation = transpose(parentModelRotation) * entityDelta * parentModelRotation * eulerToMatrix(baseRotation);
        return vec4(matrixToEulerZYX(localRotation), 1.0);
    }

    return vec4(baseRotation + rawRotation, 1.0);
}

mat3 computeParentModelRotationForState(int boneIndex, vec4 activeState) {
    int parentIndex = boneParentIndex(boneIndex);
    if (parentIndex < 0) {
        return mat3(1.0);
    }

    int chain[MAX_BONE_DEPTH];
    int depth = 0;
    int current = parentIndex;
    for (int i = 0; i < MAX_BONE_DEPTH && current >= 0; i++) {
        chain[depth] = current;
        depth++;
        current = boneParentIndex(current);
    }

    mat3 rotation = mat3(1.0);
    for (int step = 0; step < depth; step++) {
        int ancestor = chain[depth - step - 1];
        vec4 localRotation = resolveLocalRotationContribution(ancestor, activeState, rotation);
        rotation = rotation * eulerToMatrix(localRotation.xyz);
    }
    return rotation;
}

vec4 resolveLocalPositionContribution(int boneIndex, vec4 activeState, mat3 parentModelRotation) {
    int space;
    vec4 sampled = sampleChannelForState(boneIndex, TARGET_POSITION, activeState, space);
    if (sampled.w < 0.5) {
        return sampled;
    }
    vec3 position = sampled.xyz;
    if (space == SPACE_ENTITY) {
        position = transpose(parentModelRotation) * position;
    }
    return vec4(position, 1.0);
}

vec4 resolveLocalScaleContribution(int boneIndex, vec4 activeState) {
    int ignoredSpace;
    return sampleChannelForState(boneIndex, TARGET_SCALE, activeState, ignoredSpace);
}

void sampleBonePose(int boneIndex, out vec4 pose0, out vec4 pose1, out vec4 pose2, out vec4 pose3) {
    int boneTexelBase = boneIndex * 4;
    vec4 boneMeta = readBoneDefinitionTexel(boneTexelBase);
    vec4 bonePivot = readBoneDefinitionTexel(boneTexelBase + 1);
    vec4 boneRotation = readBoneDefinitionTexel(boneTexelBase + 2);
    vec4 boneScale = readBoneDefinitionTexel(boneTexelBase + 3);

    vec3 position = boneMeta.xyz;
    vec3 pivot = bonePivot.xyz;
    float parentIndex = boneMeta.w;
    vec3 rotation = boneRotation.xyz;
    vec3 scale = boneScale.xyz;

    float positionWeight = 0.0;
    float rotationWeight = 0.0;
    float scaleWeight = 0.0;
    vec3 positionAccum = vec3(0.0);
    vec3 rotationAccum = vec3(0.0);
    vec3 scaleAccum = vec3(0.0);

    for (int controllerIndex = 0; controllerIndex < gControllerStateCount; controllerIndex++) {
        vec4 controllerState = readControllerStateTexel(controllerIndex);
        int stateStart = int(controllerState.x);
        int stateCount = int(controllerState.y);
        bool overrideBlend = controllerState.z > 0.5;
        int transitionBase = (controllerIndex * BoneCount + boneIndex) * 3;
        vec4 transitionPosition = readTransitionPoseTexel(transitionBase);
        vec4 transitionRotation = readTransitionPoseTexel(transitionBase + 1);
        vec4 transitionScale = readTransitionPoseTexel(transitionBase + 2);

        if (overrideBlend) {
            bool overridesPosition = false;
            bool overridesRotation = false;
            bool overridesScale = false;
            for (int stateOffset = 0; stateOffset < stateCount; stateOffset++) {
                vec4 activeState = readActiveStateTexel(stateStart + stateOffset);
                int clipIndex = int(round(activeState.x));
                overridesPosition = overridesPosition || findChannelIndex(clipIndex, boneIndex, TARGET_POSITION) >= 0;
                overridesRotation = overridesRotation || findChannelIndex(clipIndex, boneIndex, TARGET_ROTATION) >= 0;
                overridesScale = overridesScale || findChannelIndex(clipIndex, boneIndex, TARGET_SCALE) >= 0;
            }
            overridesPosition = overridesPosition || transitionPosition.w > 1.0e-6;
            overridesRotation = overridesRotation || transitionRotation.w > 1.0e-6;
            overridesScale = overridesScale || transitionScale.w > 1.0e-6;

            if (overridesPosition) {
                positionAccum = vec3(0.0);
                positionWeight = 0.0;
            }
            if (overridesRotation) {
                rotationAccum = vec3(0.0);
                rotationWeight = 0.0;
            }
            if (overridesScale) {
                scaleAccum = vec3(0.0);
                scaleWeight = 0.0;
            }
        }

        for (int stateOffset = 0; stateOffset < stateCount; stateOffset++) {
            vec4 activeState = readActiveStateTexel(stateStart + stateOffset);
            float weight = activeState.z;
            if (weight <= 1.0e-6) {
                continue;
            }

            mat3 parentModelRotation = computeParentModelRotationForState(boneIndex, activeState);

            vec4 sampledPosition = resolveLocalPositionContribution(boneIndex, activeState, parentModelRotation);
            if (sampledPosition.w > 0.5) {
                positionAccum += sampledPosition.xyz * weight;
                positionWeight += weight;
            }

            vec4 sampledRotation = resolveLocalRotationContribution(boneIndex, activeState, parentModelRotation);
            if (sampledRotation.w > 0.5) {
                rotationAccum += sampledRotation.xyz * weight;
                rotationWeight += weight;
            }

            vec4 sampledScale = resolveLocalScaleContribution(boneIndex, activeState);
            if (sampledScale.w > 0.5) {
                scaleAccum += (sampledScale.xyz - vec3(1.0)) * weight;
                scaleWeight += weight;
            }
        }

        positionAccum += transitionPosition.xyz;
        positionWeight += transitionPosition.w;
        rotationAccum += transitionRotation.xyz;
        rotationWeight += transitionRotation.w;
        scaleAccum += transitionScale.xyz;
        scaleWeight += transitionScale.w;
    }

    if (positionWeight > 1.0e-6) {
        position = positionAccum / positionWeight;
    }
    if (rotationWeight > 1.0e-6) {
        vec3 blendedRotation = rotationAccum / rotationWeight;
        rotation.x += blendedRotation.x - boneRotation.x;
        rotation.y += blendedRotation.y - boneRotation.y;
        rotation.z += blendedRotation.z - boneRotation.z;
    }
    if (scaleWeight > 1.0e-6) {
        scale += scaleAccum / scaleWeight;
    }

    pose0 = vec4(position, parentIndex);
    pose1 = vec4(pivot, 0.0);
    pose2 = vec4(rotation, 0.0);
    pose3 = vec4(scale, 0.0);
}
